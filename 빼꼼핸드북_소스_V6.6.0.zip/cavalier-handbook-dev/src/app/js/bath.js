
/* =============== V6.4 (2026-10-26): 목욕 관리 ===============
   홈 '목욕 줄' + 목욕 시트 + 달력 점. 판정: N = 오늘 날짜 − 마지막 목욕 날짜(시각 무관).
   기록 없음 → 보류(N≥14 이고 접종 후 0~3일) → 4주 이상(N≥28) → 해도 좋아요(N≥14) → 평소 순으로 먼저 맞는 것.
   근거: 13장 '목욕 2~4주 1회'(14일 하한·28일 상한), 04장 인계 지침 '목욕은 접종 후 4일 이후부터', 02장 '접종 당일 목욕 금지'.
   저장: S.bathLog{'YYYY-MM-DD':{t}} — 첫 기록 때 만들고, 마지막 기록을 지우면 키째 지운다(빈 객체를 남기지 않음). */
const BATH={due:14, late:28, hold:3, list:5};
const BATH_DOW=['일','월','화','수','목','금','토'];
function bathLog(){ const b=S.bathLog; return (b && typeof b==='object' && !Array.isArray(b))? b : {}; }
function bathKeys(){ return Object.keys(bathLog()).filter(function(k){ return /^\d{4}-\d{2}-\d{2}$/.test(k); }).sort(); }
function bathDiff(a, b){ return Math.round((new Date(b+'T00:00:00')-new Date(a+'T00:00:00'))/86400000); }
function bathPlus(k, n){ return d2s(addD(new Date(k+'T00:00:00'), n)); }
function bathMD(k){ return (+k.slice(5,7))+'월 '+(+k.slice(8,10))+'일'; }
function bathMDs(k){ return (+k.slice(5,7))+'/'+(+k.slice(8,10)); }
function bathLast(tk){ tk=tk||todayKey(); const ks=bathKeys().filter(function(k){ return k<=tk; }); return ks.length? ks[ks.length-1] : ''; }
function bathVaxDates(){
  const out=[];
  try{
    (typeof VAX_PLAN!=='undefined'? VAX_PLAN : []).forEach(function(p){
      if(!/접종/.test(String(p.t||''))) return;                 /* 항체가 검사 등 접종이 아닌 차수는 제외 */
      const v=(S.vax||{})[p.id]; if(v && v.done && v.date) out.push(String(v.date));
    });
  }catch(e){}
  (S.events||[]).forEach(function(e){ if(e && e.d && /접종/.test(String(e.t||''))) out.push(String(e.d)); });
  return out;
}
function bathHold(tk){
  tk=tk||todayKey(); let v='';
  bathVaxDates().forEach(function(d){ if(!/^\d{4}-\d{2}-\d{2}$/.test(d)) return; const n=bathDiff(d, tk); if(n>=0 && n<=BATH.hold && d>v) v=d; });
  return v? {vax:v, from:bathPlus(v, BATH.hold+1)} : null;
}
function bathState(){
  const tk=todayKey(), last=bathLast(tk);
  if(!last) return {k:'none'};
  const n=bathDiff(last, tk);
  if(n>=BATH.due){ const h=bathHold(tk); if(h) return {k:'hold', n:n, last:last, from:h.from}; }
  if(n>=BATH.late) return {k:'late', n:n, last:last};
  if(n>=BATH.due) return {k:'due', n:n, last:last};
  return {k:'ok', n:n, last:last};
}
function bathPaint(){
  const el=document.getElementById('bathRow'); if(!el) return;
  const st=bathState();
  let b='목욕', sub='', go=false;
  if(st.k==='none') sub='지난 목욕일을 넣어 주세요';
  else if(st.k==='ok') sub= st.n===0? '오늘' : st.n+'일 전';
  else if(st.k==='hold'){ b='목욕은 '+bathMDs(st.from)+'부터'; sub='접종 후 쉬는 기간'; }
  else { b='목욕해도 좋아요'; sub=st.n+'일 전'; go=true; }
  el.className='bath-row'+(go? ' due' : '')+(st.k==='late'? ' late' : '');
  el.innerHTML='<button type="button" class="br-main" data-bath="open"><svg class="ico br-ic" aria-hidden="true"><use href="#i-bath"/></svg>'+
    '<span class="br-tx"><b>'+b+'</b><span>'+sub+'</span></span>'+(go? '' : '<svg class="ico chev" aria-hidden="true"><use href="#i-chev"/></svg>')+'</button>'+
    (go? '<button type="button" class="br-go" data-bath="done" aria-label="오늘 목욕했어요"><span>했어요</span></button>' : '');
}
function bathSet(k, v){ const b=Object.assign({}, bathLog()); b[k]=v||{t:Date.now()}; S.bathLog=b; }
function bathUnset(k){ const b=Object.assign({}, bathLog()); delete b[k]; if(Object.keys(b).length) S.bathLog=b; else delete S.bathLog; }
function bathOpenNow(){ const o=document.getElementById('bathOvl'); return !!(o && o.classList.contains('on')); }
function bathAfter(){
  saveState();
  try{ renderQlog(); }catch(e){ console.error(e); }
  try{ renderCal(); }catch(e){}
  if(bathOpenNow()) bathSheetPaint();
}
function bathAdd(k, msg){
  if(bathLog()[k]) return false;
  const v={t:Date.now()};
  bathSet(k, v); bathAfter();
  uiToast(msg||'목욕 기록했어요', function(){ const cur=bathLog()[k]; if(cur && cur.t===v.t){ bathUnset(k); bathAfter(); } });
  return true;
}
function bathDone(){
  const tk=todayKey();
  if(bathLog()[tk]){ uiToast('오늘 목욕은 이미 기록돼 있어요'); return; }
  bathAdd(tk, '목욕 기록했어요');
}
function bathDel(k){
  const v=bathLog()[k]; if(!v) return;
  bathUnset(k); bathAfter();
  uiToast(bathMD(k)+' 목욕 기록을 지웠어요', function(){ if(!bathLog()[k]){ bathSet(k, v); bathAfter(); } });
}
function bathOpen(){
  const o=document.getElementById('bathOvl'); if(!o) return;
  const m=document.getElementById('bathMsg'); if(m) m.textContent='';
  const tk=todayKey(), di=document.getElementById('bathDate'), bd=(S.profile && S.profile.birth) || '';
  if(di){
    di.max=tk;
    if(bd) di.min=bd; else di.removeAttribute('min');
    let dv=bathPlus(tk, -1); if(bd && dv<bd) dv=tk;
    di.value=dv;
  }
  bathSheetPaint();
  o.classList.add('on');
}
function bathHide(){ const o=document.getElementById('bathOvl'); if(o) o.classList.remove('on'); }
function bathSheetPaint(){
  const tk=todayKey(), last=bathLast(tk), today=!!bathLog()[tk], h=bathHold(tk);
  const sub=document.getElementById('bathSub');
  if(sub) sub.textContent= last? '마지막 '+bathMD(last)+(last===tk? '(오늘)' : '')+' · '+bathMD(bathPlus(last, BATH.due))+'부터 해도 좋아요' : '마지막 목욕일을 넣으면 14일 뒤부터 홈에 알려 드려요';
  const hd=document.getElementById('bathHold');
  if(hd) hd.textContent= (h && !today)? '접종 후 쉬는 기간이에요 · '+bathMD(h.from)+'부터 권장' : '';
  const bt=document.getElementById('bathToday');
  if(bt){ bt.disabled=today; bt.textContent= today? '오늘 기록됨' : '오늘 목욕했어요'; }
  const ks=bathKeys(), rec=ks.slice(-BATH.list).reverse();
  const lbl=document.getElementById('bathListLbl'), ls=document.getElementById('bathList');
  if(lbl) lbl.style.display= rec.length? '' : 'none';
  if(ls){
    ls.style.display= rec.length? '' : 'none';
    ls.innerHTML=rec.map(function(k){
      const i=ks.indexOf(k), prev=i>0? ks[i-1] : '', d=new Date(k+'T00:00:00');
      return '<div class="bath-li"><span class="d">'+bathMD(k)+' ('+BATH_DOW[d.getDay()]+')</span><span class="g">'+(prev? bathDiff(prev, k)+'일 간격' : '첫 기록')+'</span>'+
        '<button type="button" data-bdel="'+k+'" aria-label="'+bathMD(k)+' 기록 삭제">삭제</button></div>';
    }).join('');
  }
}
function bathDateAdd(){
  const di=document.getElementById('bathDate'), m=document.getElementById('bathMsg'); if(!di) return;
  const k=di.value||'', tk=todayKey(), bd=(S.profile && S.profile.birth) || '';
  const say=function(t){ if(m) m.textContent=t; };
  if(!/^\d{4}-\d{2}-\d{2}$/.test(k)){ say('날짜를 골라 주세요'); return; }
  if(k>tk){ say('미래 날짜는 기록할 수 없어요'); return; }
  if(bd && k<bd){ say('생일 이전 날짜예요'); return; }
  if(bathLog()[k]){ say('이미 기록된 날이에요'); return; }
  say('');
  bathAdd(k, bathMD(k)+' 목욕 기록했어요');
}
function bathCalDot(ds){ return bathLog()[ds]? '<span class="dot bt"></span>' : ''; }
function bathCalSel(ds, box){
  if(!box || !bathLog()[ds]) return;
  const ks=bathKeys(), i=ks.indexOf(ds), prev=i>0? ks[i-1] : '';
  box.insertAdjacentHTML('beforeend', '<div class="bath-cal"><div class="ev-row" role="button" tabindex="0"><span><span class="ev-tag bt">목욕</span> '+(prev? bathDiff(prev, ds)+'일 간격' : '첫 기록')+'</span><svg class="ico chev" aria-hidden="true"><use href="#i-chev"/></svg></div></div>');
  const r=box.querySelector('.bath-cal .ev-row');
  if(r){ r.addEventListener('click', bathOpen); r.addEventListener('keydown', function(e){ if(e.key==='Enter' || e.key===' '){ e.preventDefault(); bathOpen(); } }); }
}
function bindBath(){
  const row=document.getElementById('bathRow');
  if(row && !row.dataset.bound){
    row.dataset.bound='1';
    row.addEventListener('click', function(e){
      const b=e.target.closest('[data-bath]'); if(!b) return;
      if(b.dataset.bath==='done') bathDone(); else bathOpen();
    });
  }
  const o=document.getElementById('bathOvl'); if(!o || o.dataset.bound) return;
  o.dataset.bound='1';
  o.addEventListener('click', function(e){
    if(e.target===o){ bathHide(); return; }
    const d=e.target.closest('[data-bdel]'); if(d) bathDel(d.dataset.bdel);
  });
  const on=function(id, fn){ const el=document.getElementById(id); if(el) el.addEventListener('click', fn); };
  on('bathToday', function(){ const tk=todayKey(); if(bathLog()[tk]) return; bathHide(); bathAdd(tk, '목욕 기록했어요'); });
  on('bathDateAdd', bathDateAdd);
  on('bathClose', bathHide);
  on('bathGuide', function(){
    bathHide(); goTab('life');
    setTimeout(function(){ const g=document.getElementById('l-groom'); if(!g) return; try{ g.scrollIntoView({behavior:'smooth', block:'start'}); }catch(e){ g.scrollIntoView(); } }, 80);
  });
}

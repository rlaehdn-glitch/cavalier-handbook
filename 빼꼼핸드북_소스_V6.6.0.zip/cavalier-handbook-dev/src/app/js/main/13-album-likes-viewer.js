/* =============== V5.11: 좋아요 — meta/{id}/lk/{기기ID} = 이름 (기기별 키라 두 폰이 동시에 눌러도 안 겹침) =============== */
function albLikes(m){ return (m && m.lk && typeof m.lk==='object') ? m.lk : {}; }
function albLikeCount(m){ return Object.keys(albLikes(m)).length; }
function albLikedByMe(m){ return !!albLikes(m)[DEV_ID]; }
function albLikeNames(m){ const lk=albLikes(m); return Object.keys(lk).map(function(k){ return String(lk[k]||'').trim()||'누군가'; }).join(', '); }
function renderLikeUI(id){
  const m=ALB.meta&&ALB.meta[id]; if(!m) return;
  const n=albLikeCount(m);
  const cell=document.querySelector('#albGrid [data-open="'+id+'"], #albGrid [data-lid="'+id+'"]');
  if(cell){
    let b=cell.querySelector('.alb-lkb');
    if(n){ if(!b){ b=document.createElement('span'); b.className='alb-lkb'; cell.appendChild(b); } b.innerHTML='&#10084; '+n; }
    else if(b) b.remove();
  }
  if(ALB.cur===id){
    const btn=document.getElementById('albLbLike');
    if(btn){ btn.classList.toggle('on', albLikedByMe(m)); btn.innerHTML=(albLikedByMe(m)?'&#10084;':'&#9825;')+(n?' '+n:''); btn.title=n?('좋아요: '+albLikeNames(m)):'좋아요'; }
  }
}
function albHeartPop(){
  const lb=document.getElementById('albLb'); if(!lb) return;
  const el=document.createElement('span'); el.className='alb-heart-pop'; el.innerHTML='&#10084;';
  lb.appendChild(el); setTimeout(function(){ try{ el.remove(); }catch(e){} }, 800);
}
async function albToggleLike(id, pop){
  const m=ALB.meta&&ALB.meta[id]; if(!m || !syncConfigured() || ALB.likeBusy) return;
  const lk=albLikes(m); const was=lk[DEV_ID];
  const nm=(myName()||'나');
  ALB.likeBusy=true;
  if(was){ delete lk[DEV_ID]; } else { lk[DEV_ID]=nm; }
  m.lk=lk; renderLikeUI(id); if(!was && pop) albHeartPop();
  try{
    if(was) await albFetch('meta/'+id+'/lk/'+DEV_ID,'DELETE');
    else await albFetch('meta/'+id+'/lk/'+DEV_ID,'PUT',JSON.stringify(nm));
    await albBumpIdx();
  }catch(e){
    if(was) lk[DEV_ID]=was; else delete lk[DEV_ID];
    m.lk=lk; renderLikeUI(id); albStat('좋아요 저장 실패 — 인터넷 확인');
  }finally{ ALB.likeBusy=false; }
}
function albPhotoIds(){
  if(!ALB.meta) return [];
  return Object.keys(ALB.meta)
    .filter(function(id){ return albIsPhoto(ALB.meta[id]); })
    .sort(function(a,b){ return (ALB.meta[b].at||0)-(ALB.meta[a].at||0); });
}
function albNav(dir){
  if(!ALB.cur) return;
  const ids=albPhotoIds(), i=ids.indexOf(ALB.cur);
  if(i<0) return;
  const n=i+dir;
  if(n<0||n>=ids.length) return;
  albOpen(ids[n]);
}
function albPrefetch(id){
  if(!id || ALB.fulls.has(id)) return;
  albImgSrc('full',id).then(function(v){
    if(v){ if(ALB.fulls.size>10) ALB.fulls.clear(); ALB.fulls.set(id,v); }
  }).catch(function(){});
}
async function albOpen(id){
  ALB.cur=id;
  const m=ALB.meta[id]; if(!m) return;
  const lbWasOpen=document.getElementById('albLb').classList.contains('on');
  document.getElementById('albLb').classList.add('on');
  if(!lbWasOpen) navOpen('albLb', function(){ albClose(true); });   /* V5.9.4 → V6.6: 화면 관리(NAV) 층 — 폰 뒤로가기 = 닫기 */
  const ids=albPhotoIds(), pos=ids.indexOf(id);
  document.getElementById('albLbCnt').textContent = pos>=0 ? (pos+1)+' / '+ids.length : '';
  document.getElementById('albLbPrev').disabled = pos<=0;
  document.getElementById('albLbNext').disabled = pos<0 || pos>=ids.length-1;
  const im=document.getElementById('albLbImg'); im.src='';
  try{ renderLikeUI(id); }catch(e){}   /* V5.11 */
  try{ albLbTagsPaint(id); }catch(e){}   /* V6.5 */
  const lbEl=document.getElementById('albLb'), vd=document.getElementById('albLbVid');
  if(m.t==='r'){
    /* V5.9: 영상 — Worker 경유 스트리밍 재생(구간 탐색 가능) */
    lbEl.classList.add('vid');
    document.getElementById('albLbCap').textContent=(m.d||'')+(m.dur?' · '+mediaDur(m.dur):'')+(m.m?' · '+m.m:'');
    if(vd){
      if(!mediaConfigured()){ document.getElementById('albLbCap').textContent=(m.d||'')+' — 영상 저장소가 연결되지 않아 재생할 수 없습니다.'; return; }
      vd.src=mediaApi('/file/'+m.k);
      try{ vd.load(); }catch(e){}
    }
    return;
  }
  lbEl.classList.remove('vid');
  if(vd){ try{ vd.pause(); }catch(e){} vd.removeAttribute('src'); try{ vd.load(); }catch(e){} }
  document.getElementById('albLbCap').textContent=(m.d||'')+' — 불러오는 중…';
  try{
    let f=ALB.fulls.get(id);
    if(!f){ f=await albImgSrc('full',id); if(ALB.fulls.size>10) ALB.fulls.clear(); ALB.fulls.set(id,f); }
    if(ALB.cur!==id) return; /* 빠르게 넘긴 경우 지난 요청 결과는 버림 */
    im.src=f;
    document.getElementById('albLbCap').textContent=(m.d||'')+(m.m?' · '+m.m:'');
    albPrefetch(ids[pos-1]); albPrefetch(ids[pos+1]); /* 앞뒤 한 장씩 미리 받아 넘김을 끊김 없이 */
  }catch(e){ if(ALB.cur===id) document.getElementById('albLbCap').textContent='불러오기 실패 — 닫고 다시 열어보세요.'; }
}
function albClose(fromBack){
  try{ repHide(); }catch(e){}
  const lbEl=document.getElementById('albLb'); const wasOpen=lbEl.classList.contains('on');
  lbEl.classList.remove('on'); lbEl.classList.remove('vid');
  document.getElementById('albLbImg').src='';
  const vd=document.getElementById('albLbVid'); if(vd){ try{ vd.pause(); }catch(e){} vd.removeAttribute('src'); try{ vd.load(); }catch(e){} }
  ALB.cur=null;
  /* V5.9.4: 닫기 버튼·Esc·삭제로 닫은 경우 라이트박스용 history 항목을 되돌려 다음 뒤로가기가 정상 동작하게 */
  if(wasOpen && fromBack!==true) navClosed('albLb');   /* 닫기 버튼은 click 이벤트가 인자로 들어오므로 === true 로 구분 */
}


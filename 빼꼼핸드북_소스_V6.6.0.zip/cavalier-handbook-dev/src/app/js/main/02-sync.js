/* =============== 기기 간 동기화 (Firebase Realtime DB REST) =============== */
const DEV_ID=(function(){ let d=lsGet('_dev'); if(!d){ d='d'+Math.random().toString(36).slice(2,10); lsSet('_dev',d); } return d; })();
const SYNC={url:'',code:'',on:false,timer:null,pushT:null,lastRemoteAt:0,busy:false,pushing:false,pulling:false,dirty:false,retry:0,pulledOK:false};
function syncPath(){ return SYNC.url.replace(/\/+$/,'')+'/handbook/'+SYNC.code+'.json'; }
function syncConfigured(){ return SYNC.on && SYNC.url && SYNC.code; }
function syncStat(msg){ const el=document.getElementById('syncStat'); if(el) el.textContent=msg; }
function loadSyncCfg(){
  SYNC.url=lsGet('_sync_url')||''; SYNC.code=lsGet('_sync_code')||''; SYNC.on=(lsGet('_sync_on')==='1');
  const u=document.getElementById('syncUrl'), c=document.getElementById('syncCode');
  if(u) u.value=SYNC.url; if(c) c.value=SYNC.code;
  if(!SYNC.on) syncStat(SYNC.url?'동기화 꺼짐 — 이 기기에만 저장됩니다.':'설정 안 됨');
}
async function syncFetch(method, body){
  const ctl=new AbortController(); const to=setTimeout(()=>ctl.abort(), 8000);
  try{
    const opt={method:method, body:body||undefined, signal:ctl.signal};
    if(method==='PUT' && body && body.length<60000) opt.keepalive=true;   /* V5.15: 앱을 닫아도 마지막 업로드는 살아남는다 */
    const r=await fetch(syncPath(), opt);
    if(!r.ok) throw new Error('HTTP '+r.status);
    return await r.json();
  }finally{ clearTimeout(to); }
}
function syncHM(){ return new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}); }
function syncWarnPaint(){
  const el=document.getElementById('syncWarn'); if(!el) return;
  const bad=SYNC.dirty && SYNC.retry>=1;
  el.style.display = bad? 'block' : 'none';
  if(bad) el.textContent='⚠ 기록이 아직 상대 폰에 전달되지 않았습니다 — 인터넷 연결을 확인해주세요. 이 기기에는 저장돼 있고, 연결되면 자동으로 올라갑니다.';
}
function syncPushSoon(){ if(!syncConfigured()) return; SYNC.dirty=true; clearTimeout(SYNC.pushT); SYNC.pushT=setTimeout(syncPushNow, 600); }
/* V5.15: 올리기 실패·충돌은 '버리지 않고' 재시도한다.
   (예전에는 내려받기가 진행 중이면 올리기를 조용히 취소했고, 실패해도 재시도가 없어
    그 기록은 누른 폰에만 남았다가 상대 폰이 올린 상태로 덮여 사라졌다) */
async function syncPushNow(){
  if(!syncConfigured()) return;
  if(SYNC.pushing||SYNC.pulling){ SYNC.dirty=true; clearTimeout(SYNC.pushT); SYNC.pushT=setTimeout(syncPushNow, 1500); return; }
  SYNC.pushing=true;
  try{
    /* V5.15: 올리기 전에 서버본을 먼저 읽어 병합한다(읽기-병합-쓰기).
       그냥 덮어쓰면, 내가 마지막으로 읽은 뒤 상대가 올린 기록이 이 PUT 한 번에 사라진다. */
    const remote=await syncFetch('GET');
    if(remote && typeof remote==='object'){
      if(remote._at) SYNC.lastRemoteAt=remote._at;
      const merged=mergeStates(syncBaseFor(remote), S, remote);
      syncBaseSet(remote);
      if(!sEq(syncStrip(merged), syncStrip(S))){
        S=Object.assign(JSON.parse(JSON.stringify(DEFAULT_S)), merged);
        S._at=Date.now(); S._dev=DEV_ID;
        persistLocal();
        const ae=document.activeElement;
        if(!(ae && (ae.tagName==='INPUT'||ae.tagName==='TEXTAREA'))){ try{ renderAll(); }catch(e){} }
      }
    }
    const snap=JSON.parse(JSON.stringify(S));
    const seq=Math.max(syncSeqGet()+1, Date.now());            /* V6.6: 이 업로드의 기기별 번호 */
    snap._seen=seenMax(S._seen, remote && remote._seen); snap._seen[DEV_ID]=seq;
    await syncFetch('PUT', JSON.stringify(snap));
    lsSet('_sync_seq', String(seq));
    lsSet('_sync_par', JSON.stringify(syncStrip(remote || {})));  /* 이 업로드가 바탕으로 삼은 서버본 — 경쟁이 생기면 병합 기준 */
    S._seen=seenMax(S._seen, snap._seen);
    DIAG.syncOkAt=Date.now();
    SYNC.lastRemoteAt=snap._at||Date.now();
    syncBaseSet(snap);
    if((S._at||0)<=(snap._at||0)){ SYNC.dirty=false; SYNC.retry=0; }
    syncStat('동기화됨 · '+syncHM());
  }catch(e){
    logErr('동기화: 올리기', e);
    SYNC.dirty=true;
    SYNC.retry=Math.min((SYNC.retry||0)+1, 6);
    clearTimeout(SYNC.pushT);
    SYNC.pushT=setTimeout(syncPushNow, Math.min(60000, 2000*Math.pow(2, SYNC.retry-1)));
    syncStat('저장 대기 중 — 연결되면 자동 재시도합니다 ('+SYNC.retry+'회차)');
  }
  finally{ SYNC.pushing=false; syncWarnPaint(); }
}
/* V5.15: 통째 교체 → 3-way 병합.
   서버본을 그대로 덮어쓰면, 그 사이 상대 폰이 누른 기록이 조용히 사라졌다.
   이제 '마지막으로 서버에서 확인한 상태(base)'를 기준으로 양쪽 변경을 합치고,
   한쪽에서 지운 기록만 지운다. */
async function syncPull(){
  if(!syncConfigured()||SYNC.pulling||SYNC.pushing) return;
  const ae=document.activeElement;
  if(ae && (ae.tagName==='INPUT'||ae.tagName==='TEXTAREA')) return;
  if(Date.now()-lastEditAt<2000) return;
  if(v6SheetOpen()) return;   /* V6: 시트가 열려 있는 동안은 화면을 다시 그리지 않는다 */
  SYNC.pulling=true;
  try{
    const remote=await syncFetch('GET');
    SYNC.pulledOK=true;
    if(remote && typeof remote==='object'){
      if(remote._at) SYNC.lastRemoteAt=remote._at;
      const merged=mergeStates(syncBaseFor(remote), S, remote);
      syncBaseSet(remote);                                   /* base = 서버에서 실제로 본 상태만 */
      DIAG.syncOkAt=Date.now();
      const chLocal =!sEq(syncStrip(merged), syncStrip(S));
      const chRemote=!sEq(syncStrip(merged), syncStrip(remote));
      if(chLocal){
        S=Object.assign(JSON.parse(JSON.stringify(DEFAULT_S)), merged);
        persistLocal(); renderAll();
        syncStat('상대 기기 변경 반영됨 · '+syncHM());
      }
      if(chRemote){ S._at=Date.now(); S._dev=DEV_ID; persistLocal(); syncPushSoon(); }
    } else if(remote===null && (S._at||0)>0){
      syncPushSoon();
    }
  }catch(e){ logErr('동기화: 받기', e); /* 다음 주기에 재시도 */ }
  finally{ SYNC.pulling=false; syncWarnPaint(); }
}
/* =============== V5.15: 3-way 병합 엔진 =============== */
function sClone(o){ return JSON.parse(JSON.stringify(o)); }
function sCanon(v){                                     /* 키 순서가 달라도 같은 내용이면 같게 본다 — 헛된 재업로드 방지 */
  if(Array.isArray(v)) return v.map(sCanon);
  if(v && typeof v==='object'){ const o={}; Object.keys(v).sort().forEach(function(k){ o[k]=sCanon(v[k]); }); return o; }
  return v===undefined? null : v;
}
function sEq(a,b){ return JSON.stringify(sCanon(a))===JSON.stringify(sCanon(b)); }
function sObj(v){ return !!v && typeof v==='object' && !Array.isArray(v); }
function syncStrip(o){ const c=sClone(o||{}); delete c._at; delete c._dev; delete c._seen; return c; }
/* V6.6: 두 폰 동시 저장 경쟁(D1) — 업로드마다 문서에 기기별 번호(_seen[기기]=번호)를 남긴다.
   받은 서버본이 내 마지막 업로드를 포함하지 않으면(상대가 내 업로드를 못 보고 그 전 상태로 덮어씀),
   '내 업로드가 바탕으로 삼은 서버본(_sync_par)'을 기준으로 병합한다 → 내 기록을 '상대가 지운 것'으로 오해하지 않고 다시 올린다.
   (V6.5.2까지: 내가 올린 상태를 기준으로 삼아, 상대의 늦은 업로드에 없는 내 기록을 삭제로 처리했다) */
function syncSeqGet(){ return +(lsGet('_sync_seq')||0)||0; }
function syncParGet(){ try{ const r=lsGet('_sync_par'); return r? JSON.parse(r) : null; }catch(e){ return null; } }
function syncBaseFor(remote){
  const mine=syncSeqGet();
  if(!mine || !remote) return syncBaseGet();
  const seen=+(((remote._seen||{})[DEV_ID])||0);
  if(seen>=mine){ if(lsGet('_sync_par')){ try{ localStorage.removeItem('_sync_par'); }catch(e){} } return syncBaseGet(); }   /* 서버본에 내 마지막 업로드가 들어 있음 = 평소(바탕 서버본은 더 필요 없음) */
  logErr('동기화: 동시 저장 감지', '상대 폰이 이 폰의 마지막 업로드를 보기 전 상태로 저장 — 이 폰 기록을 지키며 다시 올림');
  return syncParGet() || undefined;                           /* 바탕 서버본이 없으면 기준 없이 합침(어느 쪽도 지우지 않음) */
}
function seenMax(a, b){ const o={}; [a, b].forEach(function(x){ if(x && typeof x==='object') Object.keys(x).forEach(function(k){ const v=+x[k]||0; if(!(o[k]>=v)) o[k]=v; }); }); return o; }
function seenOff(o){ if(!o || typeof o!=='object' || !('_seen' in o)) return o; const c=Object.assign({}, o); delete c._seen; return c; }
function syncBaseGet(){ try{ const r=lsGet('_sync_base'); return r? JSON.parse(r) : null; }catch(e){ return null; } }
function syncBaseSet(o){ try{ lsSet('_sync_base', JSON.stringify(syncStrip(o))); }catch(e){} }
function mKey(it){
  if(sObj(it)){
    if(it.id!=null) return 'id:'+it.id;
    if(it.o!=null && it.i!=null) return 'oi:'+it.o+'-'+it.i;
    if(it.at!=null) return 'at:'+it.at;
    return 'j:'+JSON.stringify(sCanon(it));
  }
  return 'v:'+String(it);
}
function mIndex(arr){                                  /* 같은 값이 두 건이어도 잃지 않도록 중복까지 센다 */
  const m=new Map();
  (arr||[]).forEach(function(it){ let k=mKey(it), n=1; while(m.has(k+'#'+n)) n++; m.set(k+'#'+n, it); });
  return m;
}
function mergeArr(base, loc, rem, remNewer){
  const B=mIndex(Array.isArray(base)?base:null), L=mIndex(loc), R=mIndex(rem);
  const out=new Map();
  L.forEach(function(v,k){                             /* 양쪽에서 추가된 기록은 둘 다 살린다 */
    /* V5.15.1: 같은 기록이 양쪽에 있으면 '내 것으로 덮기'가 아니라 안쪽 내용까지 합친다.
       (공지 확인 도장·메모 수정처럼 항목 안에서만 바뀌는 값이 사라지던 문제) */
    out.set(k, R.has(k)? merge3(B.has(k)? B.get(k) : undefined, v, R.get(k), remNewer) : v);
  });
  R.forEach(function(v,k){ if(!out.has(k)) out.set(k,v); });
  if(Array.isArray(base)){                             /* 기준본에 있었는데 한쪽에서 사라졌다 = 삭제 */
    B.forEach(function(v,k){ if(!L.has(k) || !R.has(k)) out.delete(k); });
  }
  const arr=Array.from(out.values());
  const all=function(f){ return arr.length>0 && arr.every(f); };
  if(all(function(x){ return sObj(x) && x.at!=null; }))      arr.sort(function(a,b){ return (b.at||0)-(a.at||0); });
  else if(all(function(x){ return sObj(x) && x.o!=null; }))  arr.sort(function(a,b){ return (a.o||0)-(b.o||0); });
  else if(all(function(x){ return sObj(x) && x.d!=null; }))  arr.sort(function(a,b){ return String(a.d).localeCompare(String(b.d)); });
  else if(all(function(x){ return typeof x==='string'; }))   arr.sort();
  return arr;
}
function merge3(base, loc, rem, remNewer){
  if(sEq(loc, rem)) return sClone(loc);
  if(Array.isArray(loc) && Array.isArray(rem)) return mergeArr(base, loc, rem, remNewer);
  if(sObj(loc) && sObj(rem)){
    const b=sObj(base)? base : null, out={}, keys={};
    Object.keys(loc).forEach(function(k){ keys[k]=1; });
    Object.keys(rem).forEach(function(k){ keys[k]=1; });
    Object.keys(keys).forEach(function(k){
      const hasL=Object.prototype.hasOwnProperty.call(loc,k), hasR=Object.prototype.hasOwnProperty.call(rem,k);
      const hasB=!!b && Object.prototype.hasOwnProperty.call(b,k);
      if(hasL && hasR){ out[k]=merge3(hasB? b[k] : undefined, loc[k], rem[k], remNewer); return; }
      if(hasL){ if(hasB && sEq(b[k], loc[k])) return;   /* 상대가 지운 항목 */ out[k]=sClone(loc[k]); return; }
      if(hasB && sEq(b[k], rem[k])) return;             /* 내가 지운 항목 */
      out[k]=sClone(rem[k]);
    });
    return out;
  }
  if(base!==undefined && sEq(loc, base)) return sClone(rem);   /* 나는 그대로 = 상대 변경 채택 */
  if(base!==undefined && sEq(rem, base)) return sClone(loc);   /* 상대는 그대로 = 내 변경 유지 */
  return sClone(remNewer? rem : loc);                          /* 양쪽 동시 변경 = 나중 것 */
}
function mergeStates(base, loc, rem){
  const remNewer=((rem&&rem._at)||0) > ((loc&&loc._at)||0);
  const out=merge3(seenOff(base)||undefined, seenOff(loc)||{}, seenOff(rem)||{}, remNewer);
  out._at=Math.max((loc&&loc._at)||0, (rem&&rem._at)||0);
  out._dev=(loc&&loc._dev)||DEV_ID;
  const sn=seenMax(loc && loc._seen, rem && rem._seen); if(Object.keys(sn).length) out._seen=sn;   /* V6.6: 업로드 번호는 기기별 큰 값 */
  return out;
}

function startSync(){
  clearInterval(SYNC.timer);
  if(!syncConfigured()){ syncStat('설정 안 됨 — 데이터베이스 주소와 가족 코드를 입력하세요.'); return; }
  SYNC.pulledOK=false;
  /* V5.15: 첫 내려받기가 '성공'했고 서버가 비어 있을 때만 올린다.
     (예전에는 첫 GET이 실패해도 이 폰의 옛 상태를 서버에 덮어써서 상대 기록이 통째로 날아갔다) */
  syncPull().then(function(){ if(SYNC.pulledOK && !SYNC.lastRemoteAt) syncPushSoon(); });
  SYNC.timer=setInterval(syncPull, 20000);
  syncStat('동기화 켜짐 — 20초마다 확인합니다.');
}
function bindSync(){
  const on=document.getElementById('syncOn'), off=document.getElementById('syncOff');
  if(!on) return;
  on.addEventListener('click', function(){
    const url=(document.getElementById('syncUrl').value||'').trim();
    const code=(document.getElementById('syncCode').value||'').trim().replace(/[^a-zA-Z0-9_-]/g,'');
    if(!/^https:\/\/.+(firebasedatabase\.app|firebaseio\.com)/.test(url)){ alert('데이터베이스 주소 형식이 아닙니다. https:// 로 시작하는 Firebase Realtime Database 주소를 붙여넣어 주세요.'); return; }
    if(code.length<6){ alert('가족 코드는 영문·숫자 6자 이상으로 정해주세요. 예: dowoo-coco-2026'); return; }
    document.getElementById('syncCode').value=code;
    SYNC.url=url; SYNC.code=code; SYNC.on=true;
    lsSet('_sync_url',url); lsSet('_sync_code',code); lsSet('_sync_on','1');
    try{ chatStart(); }catch(e){}
    startSync();
  });
  off.addEventListener('click', function(){
    SYNC.on=false; lsSet('_sync_on','0'); clearInterval(SYNC.timer);
    syncStat('동기화 꺼짐 — 이 기기에만 저장됩니다.');
  });
  document.addEventListener('visibilitychange', function(){
    if(document.visibilityState==='visible'){ if(SYNC.dirty) syncPushNow(); syncPull(); }
    else { saveFlush(); }                                  /* V5.15: 화면 끄기 직전 대기 중인 기록 확정 */
  });
  window.addEventListener('pagehide', function(){ saveFlush(); });
  window.addEventListener('online', function(){ if(SYNC.dirty) syncPushNow(); syncPull(); });
}


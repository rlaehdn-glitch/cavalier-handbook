/* =============== V6: 실시간 채팅 =============== */
const CHAT={mode:'', app:null, db:null, msgs:{}, meta:{}, lastRead:parseInt(lsGet('_chat_read')||'0',10)||0, unread:0, lastOther:null, atBottom:true, started:false, pollT:null, hbT:null};
function chatPath(p){ return SYNC.url.replace(/\/+$/,'')+'/chat/'+SYNC.code+p+'.json'; }
function chatMe(){ return myName(); }
function chatVisible(){
  const p=document.getElementById('chatPane'); const tab=document.getElementById('tab-notice');
  return !!(p && tab && tab.classList.contains('on') && p.style.display!=='none');
}
function chatStart(){
  if(CHAT.started || !syncConfigured()) return;
  CHAT.started=true;
  if(window.firebase && window.firebase.initializeApp){
    try{
      CHAT.app=firebase.initializeApp({databaseURL:SYNC.url}, 'chat');
      CHAT.db=firebase.database(CHAT.app);
      CHAT.db.ref('chat/'+SYNC.code+'/msgs').limitToLast(300).on('value', function(s){ CHAT.msgs=s.val()||{}; chatOnData(); });
      CHAT.db.ref('chat/'+SYNC.code+'/meta').on('value', function(s){ CHAT.meta=s.val()||{}; chatRenderMeta(); });
      CHAT.mode='rt';
    }catch(e){ CHAT.mode=''; CHAT.db=null; }
  }
  if(!CHAT.mode){
    CHAT.mode='poll';
    chatPoll();
    CHAT.pollT=setInterval(chatPoll, 15000);
  }
  CHAT.hbT=setInterval(chatBeat, 25000);
  chatBeat();
}
async function chatPoll(){
  if(!syncConfigured()) return;
  try{
    const r=await fetch(chatPath('/msgs'));
    if(r.ok){ CHAT.msgs=(await r.json())||{}; chatOnData(); }
    const m=await fetch(chatPath('/meta'));
    if(m.ok){ CHAT.meta=(await m.json())||{}; chatRenderMeta(); }
  }catch(e){}
}
function chatMetaWrite(name, obj){
  if(!syncConfigured() || !name) return;
  if(CHAT.mode==='rt' && CHAT.db){ try{ CHAT.db.ref('chat/'+SYNC.code+'/meta/'+name).update(obj); }catch(e){} }
  else{ try{ fetch(chatPath('/meta/'+encodeURIComponent(name)), {method:'PATCH', body:JSON.stringify(obj)}); }catch(e){} }
}
function chatBeat(){
  const me=chatMe(); if(!me || !syncConfigured()) return;
  const p={seen:Date.now()};
  if(chatVisible()) p.read=Date.now();
  chatMetaWrite(me, p);
}
function chatKeys(){ return Object.keys(CHAT.msgs||{}).sort(); }
function chatOnData(){
  const me=chatMe();
  let un=0, lastOther=null;
  chatKeys().forEach(function(k){
    const m=CHAT.msgs[k]; if(!m) return;
    if(m.by!==me && (m.at||0)>CHAT.lastRead){ un++; lastOther=m; }
  });
  CHAT.lastOther=lastOther;
  if(chatVisible()){ chatMarkRead(); un=0; }
  CHAT.unread=un;
  chatRenderBadge(); renderHomeChat(); chatRender();
}
function chatMarkRead(){
  const ks=chatKeys();
  if(ks.length){
    const last=CHAT.msgs[ks[ks.length-1]].at||Date.now();
    if(last>CHAT.lastRead){ CHAT.lastRead=last; lsSet('_chat_read', String(last)); }
  }
  CHAT.unread=0;
  const me=chatMe();
  if(me) chatMetaWrite(me, {read:Date.now(), seen:Date.now()});
  chatRenderBadge(); renderHomeChat();
}
function theirRead(){
  const me=chatMe(); let t=0;
  Object.keys(CHAT.meta||{}).forEach(function(n){
    if(n!==me && CHAT.meta[n] && (CHAT.meta[n].read||0)>t) t=CHAT.meta[n].read;
  });
  return t;
}
function chatRenderMeta(){
  const el=document.getElementById('chPres');
  if(el){
    const me=chatMe(); let on=null;
    Object.keys(CHAT.meta||{}).forEach(function(n){
      if(n!==me && CHAT.meta[n] && Date.now()-(CHAT.meta[n].seen||0)<60000) on=n;
    });
    el.textContent = on? '🟢 '+on+' 접속 중' : '';
  }
  chatRender();
}
function chatRender(){
  const box=document.getElementById('chMsgs'); if(!box) return;
  if(!syncConfigured()){ box.innerHTML='<p class="muted small" style="text-align:center; margin:22px 0;">설정에서 동기화를 켜면 채팅이 활성화됩니다.</p>'; return; }
  const ks=chatKeys();
  if(!ks.length){ box.innerHTML='<p class="muted small" style="text-align:center; margin:22px 0;">첫 메시지를 보내보세요 🐾</p>'; return; }
  const me=chatMe(); const tr=theirRead();
  let readKey='';
  ks.forEach(function(k){ const m=CHAT.msgs[k]; if(m && m.by===me && (m.at||0)<=tr) readKey=k; });
  let html='', prevDay='', prevBy='', prevAt=0;
  const DOW=['일','월','화','수','목','금','토'];
  ks.forEach(function(k){
    const m=CHAT.msgs[k]; if(!m || !m.t) return;
    const dt=new Date(m.at||0);
    const day=m.at? (dt.getMonth()+1)+'월 '+dt.getDate()+'일 ('+DOW[dt.getDay()]+')' : '';
    if(day && day!==prevDay){ html+='<div class="ch-day">'+day+'</div>'; prevDay=day; prevBy=''; }
    const mine=m.by===me;
    const grp=(m.by===prevBy && (m.at-prevAt)<60000);
    html+='<div class="ch-m '+(mine?'me':'them')+'" data-id="'+k+'"'+(mine?' data-mine="1"':'')+'>'
      +((!mine && !grp)? '<div class="who">'+esc(m.by||'?')+'</div>':'')
      +'<div class="bb">'+esc(m.t)+'</div>'
      +'<div class="tm">'+(mine && k===readKey? '<span class="rd">읽음</span> · ':'')+String(dt.getHours()).padStart(2,'0')+':'+String(dt.getMinutes()).padStart(2,'0')+'</div>'
    +'</div>';
    prevBy=m.by; prevAt=m.at||0;
  });
  box.innerHTML=html;
  chatBindBubbles(box);
  if(CHAT.atBottom){ box.scrollTop=box.scrollHeight; chatHideNew(); }
  else{ const nb=document.getElementById('chNew'); if(nb && ks.length) nb.style.display='block'; }
}
function chatHideNew(){ const nb=document.getElementById('chNew'); if(nb) nb.style.display='none'; }
function chatBindBubbles(box){
  box.querySelectorAll('.ch-m[data-mine]').forEach(function(el){
    let t=null;
    const start=function(){ clearTimeout(t); t=setTimeout(function(){ chatDelete(el.dataset.id); }, 600); };
    const stop=function(){ clearTimeout(t); };
    el.addEventListener('touchstart', start, {passive:true});
    el.addEventListener('touchend', stop); el.addEventListener('touchmove', stop);
    el.addEventListener('mousedown', start); el.addEventListener('mouseup', stop); el.addEventListener('mouseleave', stop);
    el.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  });
}
async function chatDelete(id){
  const m=CHAT.msgs[id];
  if(!m || m.by!==chatMe()) return;
  if(!(await askConfirm('이 메시지를 삭제할까요? 두 폰 모두에서 사라집니다.'))) return;
  if(CHAT.mode==='rt' && CHAT.db){ try{ CHAT.db.ref('chat/'+SYNC.code+'/msgs/'+id).remove(); }catch(e){} }
  else{
    fetch(chatPath('/msgs/'+id), {method:'DELETE'}).catch(function(){});
    delete CHAT.msgs[id];
    chatOnData();
  }
}
async function chatSend(){
  const inp=document.getElementById('cmInput');
  const t=(inp.value||'').trim();
  if(!t) return;
  if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; }
  const me=await ntcRequireName(); if(!me) return;
  const msg={by:me, t:t.slice(0,1000), at:Date.now()};
  inp.value=''; chSendState();
  CHAT.atBottom=true;
  if(CHAT.mode==='rt' && CHAT.db){
    try{ CHAT.db.ref('chat/'+SYNC.code+'/msgs').push(msg); }catch(e){ logErr('채팅 보내기', e); alert('전송 실패 — 잠시 후 다시 시도하세요.'); }
  }else{
    try{
      const r=await fetch(chatPath('/msgs'), {method:'POST', body:JSON.stringify(msg)});
      const j=await r.json();
      if(j && j.name){ CHAT.msgs[j.name]=msg; chatOnData(); }
    }catch(e){ alert('전송 실패 — 네트워크를 확인하세요.'); }
  }
  chatMarkRead();
  chatTrim();
}
function chatTrim(){
  const ks=chatKeys();
  if(ks.length<=320) return;
  const del=ks.slice(0, ks.length-300);
  if(CHAT.mode==='rt' && CHAT.db){
    const up={}; del.forEach(function(k){ up[k]=null; });
    try{ CHAT.db.ref('chat/'+SYNC.code+'/msgs').update(up); }catch(e){}
  }else{
    del.forEach(function(k){ fetch(chatPath('/msgs/'+k), {method:'DELETE'}).catch(function(){}); delete CHAT.msgs[k]; });
  }
}
function chSendState(){
  const b=document.getElementById('cmSend'), i=document.getElementById('cmInput');
  if(b && i) b.disabled = !(i.value||'').trim();
}
function chatSeg(which){
  const c=document.getElementById('segChat'); if(!c) return;
  c.classList.toggle('on', which==='chat');
  document.getElementById('segNtc').classList.toggle('on', which==='ntc');
  document.getElementById('chatPane').style.display = which==='chat'? 'block':'none';
  document.getElementById('ntcPane').style.display = which==='ntc'? 'block':'none';
  if(which==='chat'){
    chatMarkRead();
    chatRender();
    setTimeout(function(){ const b=document.getElementById('chMsgs'); if(b) b.scrollTop=b.scrollHeight; }, 40);
  }
}
function chatTabOpen(){
  chatStart();
  const n=(S.ntc||[])[0]; const me=myName();
  const needNtc = !!(n && !(me && n.by===me) && !(me && n.ack && n.ack[me]) && !ntcSeenGet()[n.id]);
  const dot=document.getElementById('segNtcDot');
  if(dot) dot.style.display = needNtc? 'inline':'none';
  chatSeg(needNtc? 'ntc':'chat');
}
function chatRenderBadge(){
  const b=document.getElementById('bnChatBadge'); if(!b) return;
  if(CHAT.unread>0 && !chatVisible()){
    b.style.display='inline-flex';
    b.textContent = CHAT.unread>9? '9+' : String(CHAT.unread);
  }else{
    b.style.display='none';
  }
}
function renderHomeChat(){
  const el=document.getElementById('homeChat'); if(!el) return;
  if(CHAT.unread>0 && CHAT.lastOther && !chatVisible()){
    const m=CHAT.lastOther;
    el.innerHTML='<div class="hn hc"><div class="h"><span>💬 '+esc(m.by||'')+(CHAT.unread>1? ' · 새 메시지 '+CHAT.unread+'개':'')+'</span><button class="btn sm" id="hcGo" type="button">답장</button></div><div class="b hc-b">'+esc(m.t)+'</div></div>';
    const g=document.getElementById('hcGo');
    if(g) g.addEventListener('click', function(){ goTab('notice'); chatSeg('chat'); });
  }else{
    el.innerHTML='';
  }
}
function bindChat(){
  const sc=document.getElementById('segChat'); if(!sc) return;
  sc.addEventListener('click', function(){ chatSeg('chat'); });
  document.getElementById('segNtc').addEventListener('click', function(){ chatSeg('ntc'); });
  const inp=document.getElementById('cmInput');
  inp.addEventListener('input', chSendState);
  inp.addEventListener('keydown', function(e){ if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); chatSend(); } });
  document.getElementById('cmSend').addEventListener('click', chatSend);
  document.querySelectorAll('.ch-chips button').forEach(function(b){
    b.addEventListener('click', function(){
      const k=this.dataset.ck;
      const txt = k==='warn'? '⚠️ 특이사항: ' : ntcSmartTpl(k, {meal:'🍚 ', walk:'🐕 ', potty:'💩 ', kg:'🏫 '}[k]);
      inp.value = inp.value? inp.value.replace(/\s+$/,'')+'\n'+txt : txt;
      chSendState(); inp.focus();
    });
  });
  const box=document.getElementById('chMsgs');
  box.addEventListener('scroll', function(){
    CHAT.atBottom = box.scrollTop+box.clientHeight >= box.scrollHeight-30;
    if(CHAT.atBottom){ chatHideNew(); if(chatVisible()) chatMarkRead(); }
  });
  document.getElementById('chNew').addEventListener('click', function(){
    CHAT.atBottom=true;
    box.scrollTop=box.scrollHeight;
    chatHideNew();
    chatMarkRead();
  });
}


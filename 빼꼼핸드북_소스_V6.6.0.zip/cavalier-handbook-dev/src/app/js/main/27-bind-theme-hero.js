/* =============== V6: 바인딩 · 스크롤 =============== */
function bindV6(){
  const act=document.querySelector('.tab-panel.on');
  document.body.setAttribute('data-tab', act? act.id.replace('tab-','') : 'home');
  const us=document.getElementById('uiSheet');
  if(us){
    us.addEventListener('click', function(e){ if(e.target===us) uiSheetClose({ok:false}); });
    document.getElementById('uiNo').addEventListener('click', function(){ uiSheetClose({ok:false}); });
  }
  const ro=document.getElementById('repOvl');
  if(ro){
    ro.addEventListener('click', function(e){ if(e.target===ro) repHide(); });
    document.getElementById('repOk').addEventListener('click', repConfirm);
    document.getElementById('repNo').addEventListener('click', repHide);
  }
  const ko=document.getElementById('kgOvl');
  if(ko){
    ko.addEventListener('click', function(e){ if(e.target===ko) kgHide(); });
    document.getElementById('kgSave').addEventListener('click', kgSave);
    document.getElementById('kgDel').addEventListener('click', kgDelete);
    document.getElementById('kgCancel').addEventListener('click', kgHide);
  }
  const tu=document.getElementById('uiToastU');
  if(tu) tu.addEventListener('click', function(){ const f=TOAST.fn; TOAST.fn=null; document.getElementById('uiToast').classList.remove('on'); if(f) f(); });
  const nc=document.getElementById('nowCard'); if(nc) nc.addEventListener('click', nowTap);
  const mo=document.getElementById('albLbMore'); if(mo) mo.addEventListener('click', lbMore);
  const hs=document.getElementById('hxSet'); if(hs) hs.addEventListener('click', function(){ goTab('settings'); });
  bindKgCfg();
  try{ if(typeof bindBath==='function') bindBath(); }catch(e){ console.error('bath bind', e); }   /* V6.4 */
  try{ bindTheme(); }catch(e){ console.error('theme', e); }
  let lastY=window.scrollY||0, ticking=false;
  window.addEventListener('scroll', function(){
    if(ticking) return; ticking=true;
    requestAnimationFrame(function(){
      const y=window.scrollY||0;
      const hero=document.getElementById('hxHero');
      const thr=(document.body.getAttribute('data-tab')==='home' && hero)? Math.max(48, hero.offsetTop+hero.offsetHeight-64) : 48;
      document.body.classList.toggle('scrolled', y>thr);
      if(y>lastY+8 && y>140) document.body.classList.add('bn-min');
      else if(y<lastY-8 || y<80) document.body.classList.remove('bn-min');
      lastY=y; ticking=false;
    });
  }, {passive:true});
  document.addEventListener('keydown', function(e){
    if(e.key!=='Escape') return;
    if(us && us.classList.contains('on')){ uiSheetClose({ok:false}); return; }
    repHide(); kgHide();
  });
}

/* =============== V6.0.2: 화면 모드 — 자동(기기·앱 설정 따름) / 라이트 / 다크, 기기별 저장 =============== */
function themeGet(){ const t=lsGet('_theme'); return (t==='light' || t==='dark')? t : 'auto'; }
function themeSysDark(){ try{ return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); }catch(e){ return false; } }
function themeApply(){
  const t=themeGet(), r=document.documentElement;
  if(t==='auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', t);
  document.querySelectorAll('meta[name="theme-color"]').forEach(function(m){
    if(m.dataset.c0===undefined){ m.dataset.c0=m.getAttribute('content')||''; m.dataset.m0=m.getAttribute('media')||''; }
    if(t==='auto'){ m.setAttribute('content', m.dataset.c0); if(m.dataset.m0) m.setAttribute('media', m.dataset.m0); }
    else{ m.removeAttribute('media'); m.setAttribute('content', t==='dark'? '#000000' : '#F2F2F7'); }
  });
  document.querySelectorAll('#themeSeg [data-th]').forEach(function(b){ const on=b.dataset.th===t; b.classList.toggle('on', on); b.setAttribute('aria-checked', on? 'true' : 'false'); });
  const info=document.getElementById('themeInfo');
  if(info) info.textContent = t==='auto'
    ? '자동 — 지금 이 기기는 '+(themeSysDark()? '다크' : '라이트')+'로 인식됩니다. 폰은 라이트인데 다크로 보이면, 링크를 연 앱(카톡 등)의 다크 설정을 따르는 것이니 라이트를 고르세요.'
    : (t==='light'? '라이트로 고정' : '다크로 고정')+' — 이 기기에만 적용됩니다. 다른 폰은 각자 설정합니다.';
}
function bindTheme(){
  const seg=document.getElementById('themeSeg');
  if(seg) seg.addEventListener('click', function(e){
    const b=e.target.closest('[data-th]'); if(!b) return;
    if(b.dataset.th==='auto'){ try{ localStorage.removeItem('_theme'); }catch(x){} } else lsSet('_theme', b.dataset.th);
    themeApply();
  });
  try{ const mq=window.matchMedia('(prefers-color-scheme: dark)'); if(mq.addEventListener) mq.addEventListener('change', themeApply); else if(mq.addListener) mq.addListener(themeApply); }catch(e){}
  themeApply();
}

/* =============== V6.0.4: 대표사진 히어로 — 썸네일 먼저, 원본 화질로 교체 =============== */
const HERO={id:'', url:'', busy:''};
const REPF={busy:'', wait:false, fail:''};
const HERO_CK='_hero_v1';
/* V6.0.6: 대표사진 — 앨범 정보가 오기 전엔 찾지 않고 기다린다(옛 저장소로 가서 포기하던 문제) */
function repFetch(){
  const id=(S.rep && S.rep.id)||''; if(!id || REPF.busy===id) return;
  if(typeof syncConfigured==='function' && syncConfigured() && !ALB.meta){ REPF.wait=true; return; }
  REPF.busy=id;
  albImgSrc('th', id).then(function(u){
    REPF.busy='';
    if(!S.rep || S.rep.id!==id) return;
    if(u){ REPF.fail=''; applyRepDraw(u); heroCachePut(id, u, false); }
    else{ REPF.fail=id; heroSync(''); }
  }).catch(function(){ REPF.busy=''; if(S.rep && S.rep.id===id){ REPF.fail=id; heroSync(''); } });
}
function repOnMeta(){
  REPF.wait=false;
  if(S.rep && S.rep.id){ if(REPF.fail===S.rep.id) REPF.fail=''; applyRep(); }
}
/* V6.0.6: 이 폰에 대표사진을 작게 저장 → 다음에 앱을 열면 기다림 없이 바로 표시 */
function heroCacheGet(id){ try{ const o=JSON.parse(lsGet(HERO_CK)||'null'); return (o && o.id===id && o.du)? o.du : ''; }catch(e){ return ''; } }
function heroCacheClear(){ try{ if(lsGet(HERO_CK)) localStorage.removeItem(HERO_CK); }catch(e){} }
function heroCachePut(id, src, hi){
  if(!id || !src) return;
  try{ const o=JSON.parse(lsGet(HERO_CK)||'null'); if(o && o.id===id && (o.hi || !hi)) return; }catch(e){}
  const im=new Image();
  im.onload=function(){
    try{
      const nw=im.naturalWidth||0, nh=im.naturalHeight||0; if(!nw || !nh) return;
      const W=Math.min(1080, nw), H=Math.round(nh*W/nw);
      const cv=document.createElement('canvas'); cv.width=W; cv.height=H;
      const cx=cv.getContext('2d'); if(!cx) return;
      cx.drawImage(im, 0, 0, W, H);
      let du=cv.toDataURL('image/jpeg', 0.82); if(du.length>700000) du=cv.toDataURL('image/jpeg', 0.66);
      if(du.length>900000) return;
      if(S.rep && S.rep.id===id) lsSet(HERO_CK, JSON.stringify({id:id, hi:!!hi, du:du, at:Date.now()}));
    }catch(e){}
  };
  im.src=src;
}
/* 히어로: 사진 없음(미지정) · 불러오는 중 · 불러오기 실패를 구분, 원본 화질로 교체 */
function heroSync(th){
  const hero=document.getElementById('hxHero'), img=document.getElementById('hpImg'); if(!hero || !img) return;
  const id=(S.rep && S.rep.id)||'';
  const failed=!!(id && !th && REPF.fail===id);
  hero.classList.toggle('noph', !th);
  hero.classList.toggle('unset', !id);
  hero.classList.toggle('repfail', failed);
  const hint=hero.querySelector('.hx-ph-hint');
  if(hint) hint.textContent = failed? '대표 사진을 불러오지 못했어요 — 앨범에서 다시 지정해 주세요' : '앨범 사진의 ⋯ 메뉴에서 대표 사진을 정해 주세요';
  if(!id){ heroCacheClear(); return; }
  if(!th) return;
  if(HERO.id===id && HERO.url){ if(img.getAttribute('src')!==HERO.url) img.src=HERO.url; return; }
  if(HERO.busy===id) return;
  if(typeof syncConfigured==='function' && !syncConfigured()) return;
  if(!ALB.meta) return;                                   /* 앨범 정보 도착 후(repOnMeta) 원본으로 교체 */
  HERO.busy=id;
  albImgSrc('full', id).then(function(u){
    if(!u || !S.rep || S.rep.id!==id){ HERO.busy=''; return; }
    const pre=new Image();
    pre.onload=function(){ HERO.busy=''; if(S.rep && S.rep.id===id){ HERO.id=id; HERO.url=u; img.src=u; heroCachePut(id, u, true); } };
    pre.onerror=function(){ HERO.busy=''; };
    pre.src=u;
  }).catch(function(){ HERO.busy=''; });
}

/* =============== V6.0.5: R2 사진 이름 자동 확인 ===============
   문제: R2 파일 이름이 사진마다 기록되지 않고, 공용 '이름 방식(P2S)' 하나로 매번 다시 계산됐다.
   앱을 연 직후 방식 정보를 받기 전에 올린 사진, 또는 방식이 바뀌기 전 사진은 다른 이름으로 찾다가 404 → 깨진 그림.
   해결: 사진마다 실제로 열리는 이름을 찾아(기록된 방식 → 직전에 맞은 방식 → 공용 방식 → 나머지 → 파이어베이스 사본) 쓰고,
   찾은 방식은 meta/{id}/ps 에 기록해 두 폰이 다음부터 바로 연다. 새로 올리는 사진은 처음부터 ps를 기록한다. */
const P2ID=new Map(), P2FULL=new Map(), P2WAIT=new Map(), ALBERR=new Map();
let P2PREF='';
function p2SchemeById(sid){ for(let i=0;i<P2SCHEMES.length;i++){ if(P2SCHEMES[i].id===sid) return P2SCHEMES[i]; } return null; }
function p2Order(id){
  const m=(ALB.meta||{})[id]||{}, out=[];
  const add=function(sid){ if(sid && out.indexOf(sid)<0 && p2SchemeById(sid)) out.push(sid); };
  add(m.ps); add(P2PREF); add(P2S); P2SCHEMES.forEach(function(x){ add(x.id); });
  return out;
}
async function p2Get(key, ms){
  const ctl=new AbortController(); const to=setTimeout(function(){ ctl.abort(); }, ms||15000);
  try{ return await fetch(mediaApi('/file/'+key), {signal:ctl.signal}); } finally{ clearTimeout(to); }
}
function p2Cache(kind, key, url){
  const map = kind==='full'? P2FULL : P2BLOB, max = kind==='full'? 24 : 600;
  if(map.size>=max){ const old=map.keys().next().value; try{ URL.revokeObjectURL(map.get(old)); }catch(e){} map.delete(old); }
  map.set(key, url);
}
function p2Remember(id, sid){
  P2PREF=sid;
  const m=(ALB.meta||{})[id]; if(!m || m.ps===sid) return;
  m.ps=sid;
  if(syncConfigured()) albFetch('meta/'+id+'/ps','PUT',JSON.stringify(sid)).catch(function(){});
}
function p2Src(kind,id){
  const ck=kind+':'+id;
  const hk=P2ID.get(ck);
  if(hk){ const u=(kind==='full'? P2FULL : P2BLOB).get(hk); if(u) return Promise.resolve(u); }
  if(P2WAIT.has(ck)) return P2WAIT.get(ck);
  const pr=(async function(){
    const order=p2Order(id), seen=[];
    for(let i=0;i<order.length;i++){
      const sc=p2SchemeById(order[i]); const key=sc.f(kind,id);
      try{
        const r=await p2Get(key, kind==='full'? 30000 : 15000);
        if(!r.ok){ seen.push(r.status); continue; }
        const b=await r.blob();
        if(!b || !b.size){ seen.push('빈 파일'); continue; }
        const url=URL.createObjectURL(new Blob([b], {type:'image/jpeg'}));
        p2Cache(kind, key, url); P2ID.set(ck, key); p2Remember(id, sc.id); ALBERR.delete(id);
        return url;
      }catch(e){ seen.push(e && e.name==='AbortError'? '시간 초과' : '연결 실패'); }
    }
    try{ const du=await albFetch(kind+'/'+id); if(du){ ALBERR.delete(id); return du; } }catch(e){}
    const why = seen.indexOf(404)>-1? '404' : String(seen[0]||'오류');
    ALBERR.set(id, why);
    throw new Error('R2 '+why);
  })();
  P2WAIT.set(ck, pr);
  pr.then(function(){ P2WAIT.delete(ck); try{ albErrPaint(); }catch(e){} }, function(){ P2WAIT.delete(ck); try{ albErrPaint(); }catch(e){} });
  return pr;
}
async function p2Blob(kind,id){
  const u=await p2Src(kind,id);
  const r=await fetch(u); if(!r.ok) throw new Error('HTTP '+r.status);
  return r.blob();
}
async function p2DeleteAll(id){
  const m=(ALB.meta||{})[id]||{};
  if(!m.ps){ try{ await p2Src('th', id); }catch(e){ if(!/404/.test(String(e&&e.message))) throw e; } }
  const sid=((ALB.meta||{})[id]||{}).ps; if(!sid) return;   /* 어디에도 파일이 없으면 지울 것도 없음 */
  const sc=p2SchemeById(sid);
  await mediaFetch(mediaApi('/file/'+sc.f('full',id)), {method:'DELETE'}, 20000);
  try{ await mediaFetch(mediaApi('/file/'+sc.f('th',id)), {method:'DELETE'}, 20000); }catch(e){}
}
function albErrNote(id, e){ if(!ALBERR.has(id)) ALBERR.set(id, String(e&&e.message||e||'오류').replace(/^R2 /,'')); albErrPaint(); }
function albErrPaint(){
  const el=document.getElementById('albErr'); if(!el) return;
  const n=ALBERR.size;
  if(!n){ el.style.display='none'; return; }
  const c404=Array.from(ALBERR.values()).filter(function(v){ return v==='404'; }).length;
  el.style.display='';
  el.textContent='사진 '+n+'장을 불러오지 못했어요'+(c404? ' — 저장소에 파일이 없음(404) '+c404+'장' : ' — '+Array.from(ALBERR.values())[0])+'. 인터넷 연결을 확인하고 앨범을 다시 열어 보세요.';
}


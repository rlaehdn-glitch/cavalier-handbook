/* =============== V2: 서재 메타 + 내비게이션 =============== */
const LIB_META=[
  ['stats','📊','기록 통계','지난주 대비 · 기준일 전/후 · 항목별 그래프 · 체중 성장', false],
  ['prep','01','분양 준비','계약·보상기간·용품·첫 2주 로드맵', true],
  ['health','02','건강·병원','접종 스케줄·카발리에 4대 질환', false],
  ['money','03','보험·비용','펫보험 비교 7항목·비용 총정리', false],
  ['food','04','사료·간식','급여량·교체 7일 법칙·금지 음식', false],
  ['walk','05','산책·훈련·짖음','배변·크레이트·사회화·짖음 예방', false],
  ['work','06','직장인 플랜','낮 공백 해법·분리불안 6단계', false],
  ['neuter','07','중성화','여아 시기 판단·수술·발정 관리', false],
  ['shop','09','구매 가이드','전 품목 추천 제품·구매 링크', false],
  ['place','10','삼송 동네','병원·유치원·미용·동반 카페', false],
  ['emerg','11','응급 대처','골든타임 매뉴얼·CPR', false],
  ['behav','12','행동 사전','카밍 시그널·문제행동 A-Z', false],
  ['life','13','생활·법규','계절 관리·과태료·이동·위생', false],
  ['index','14','자료실','주제별 영상·참고문헌', false],
  ['notice','💬','채팅 · 공지','실시간 대화 + 인수인계 게시판', false]
];
const LIB_TABS=LIB_META.map(function(x){ return x[0]; });
const BNAV_KEYS={home:1, cal:1, record:1, album:1, lib:1};

let NAV_HIST=['home'];
const MAIN_TITLES={home:'홈', cal:'달력', record:'기록', album:'앨범', lib:'서재', settings:'설정'};
function tabTitle(id){
  const m=LIB_META.find(function(x){ return x[0]===id; });
  return m ? (/^\d/.test(m[1])? m[1]+' '+m[2] : m[2]) : (MAIN_TITLES[id]||'');
}
const SCROLL_POS={};
function goTab(id, silent){
  if(!document.getElementById('tab-'+id)) id='home';
  document.body.setAttribute('data-tab', id);   /* V6: 상단 바 표시 전환 */
  const cur=document.querySelector('.tab-panel.on');
  if(cur) SCROLL_POS[cur.id.replace('tab-','')]=window.scrollY||0;
  document.querySelectorAll('.tab-panel').forEach(function(p){ p.classList.toggle('on', p.id==='tab-'+id); });
  const bkey = BNAV_KEYS[id] ? id : (id==='stats' ? 'record' : (LIB_TABS.indexOf(id)>-1 ? 'lib' : 'home'));
  document.querySelectorAll('.bn-btn').forEach(function(b){ b.classList.toggle('on', b.dataset.tab===bkey); });
  const bb=document.getElementById('libBack');
  if(bb){
    if(id==='home'){ bb.style.display='none'; }
    else{ bb.style.display='flex'; document.getElementById('libBackT').textContent=tabTitle(id); }
  }
  const keep=(LIB_TABS.indexOf(id)>-1 || id==='lib') && SCROLL_POS[id];
  window.scrollTo({top: keep? SCROLL_POS[id] : 0});
  if(id==='album'){ try{ albumOnOpen(); }catch(e){} }
  else{ try{ albSelEnd(); }catch(e){} }   /* V6.5: 앨범을 떠나면 여러 장 선택 끝 */
  if(id!=='home'){ try{ camStop(); }catch(e){} } else { try{ camCheck(); }catch(e){} }   /* V5.10 */
  if(id==='lib'){ try{ renderLib(); }catch(e){} }
  if(id==='stats'){ try{ renderStats(); }catch(e){} }
  if(id==='record'){ try{ renderWeight(); }catch(e){} }   /* V6.1 */
  if(id==='notice'){ try{ chatTabOpen(); }catch(e){} }
  if(id==='settings'){ try{ diagOnOpen(); }catch(e){} }   /* V6.6 진단 */
  if(!silent){
    if(NAV_HIST[NAV_HIST.length-1]!==id){ NAV_HIST.push(id); if(NAV_HIST.length>30) NAV_HIST.shift(); }
    navHistPush(function(){ return {tab:id, d:((history.state && history.state.d)||0)+1, ly:NAV.layers.length}; }, '#'+id);
  }
}
function navBack(){
  /* V6.0.4: 앱이 쌓은 화면이 뒤에 있으면 폰 뒤로가기와 똑같이 되돌아간다(새 항목을 쌓지 않음) */
  const st=history.state;
  if(st && st.d>0){ navHistBack(1, false); return; }
  /* 바로가기·새로고침으로 들어와 되돌아갈 화면이 없으면 상위 화면으로 — history는 늘리지 않는다 */
  const cur=document.querySelector('.tab-panel.on');
  const id=cur ? cur.id.replace('tab-','') : 'home';
  const up = id==='stats' ? 'record' : ((LIB_TABS.indexOf(id)>-1) ? 'lib' : 'home');
  NAV_HIST=['home']; if(up!=='home') NAV_HIST.push(up);
  goTab(up, true);
  try{ history.replaceState({tab:up, d:0, ly:0}, '', '#'+up); }catch(e){}
}
/* =============== V6.6: 화면 관리(NAV) — 폰 뒤로가기를 한 곳에서 처리 ===============
   탭 = 기록(history) 1칸씩. 그 위에 겹치는 화면(시트·확인창·사진 확대·산책 화면)은 '층'으로 쌓는다.
   - 층을 열면 기록 1칸(ly = 그때 층 수)을 더하고, 폰 뒤로가기는 맨 위 층부터 닫는다.
   - 앱 안 닫기 버튼으로 닫으면 층을 내리고 기록 1칸을 되돌린다(그때 오는 popstate는 무시).
   - 쇼츠는 자기 화면 순서를 직접 관리하고, 층이 없을 때만 넘겨받는다(window.SHORTS.onPop).
   새 화면을 만들 때: 열 때 navOpen(id, 닫는함수), 앱 안에서 닫을 때 navClosed(id). class 'on'으로 열고 닫는 시트는
   NAV_SHEETS에 id만 추가하면 자동으로 따라간다. (이전: 탭·사진 확대·산책·쇼츠가 각자 기록을 쌓고, 시트는 관리 없음)
   기록 칸을 넣고 빼는 일은 앱·쇼츠 모두 navHistPush / navHistBack 두 함수로만 한다(아래 '문지기'). */
const NAV={layers:[], closing:0, pend:0, afterQ:[], pushQ:[], dead:new Set(), seq:0, chk:null, needChk:false, wd:null};
const NAV_SHEETS=['uiSheet', 'qeOvl', 'wtOvl', 'sosOvl', 'ntcOvl', 'repOvl', 'kgOvl', 'bathOvl'];
function navTabNow(){ return document.body.getAttribute('data-tab') || 'home'; }
function navIsOpen(id){ return NAV.layers.some(function(l){ return l.id===id; }); }

/* ---- 문지기: history.back()/go()는 바로 끝나지 않고 잠시 뒤 popstate로 끝난다. 그 사이에 pushState를 하면
   브라우저가 새 칸을 잃는다(실측: 쇼츠 시트를 닫자마자 앱 확인창을 열면 확인창이 곧바로 닫혀 링크 붙여넣기가 안 됨).
   그래서 되돌리기가 진행 중(NAV.pend>0)일 때 들어온 칸 넣기는 popstate가 온 뒤 순서대로 넣는다.
   state 자리에 함수를 주면 넣는 순간에 만들고, null을 돌려주면(그 사이 닫힌 화면) 넣지 않는다. ---- */
function navHistPush(state, url){
  if(NAV.pend>0 || NAV.pushQ.length){ NAV.pushQ.push([state, url]); return; }
  navPushNow(state, url);
}
function navPushNow(state, url){
  const s=(typeof state==='function')? state() : state; if(!s) return;
  try{ history.pushState(s, '', url || location.hash || '#home'); }catch(e){ logErr('화면 기록 넣기', e); }
}
/* 기록 n칸 되돌리기. silent=true: 앱 안에서 이미 닫은 화면의 칸 — 그때 오는 popstate는 화면을 바꾸지 않는다 */
function navHistBack(n, silent){
  NAV.pend++; if(silent) NAV.closing++;
  clearTimeout(NAV.wd); NAV.wd=setTimeout(navHistSettle, 1500);   /* popstate가 끝내 안 오면(더 되돌릴 칸 없음 등) 미뤄 둔 일을 마저 한다 */
  try{ if((n||1)===1) history.back(); else history.go(-n); }
  catch(e){ NAV.pend=Math.max(0, NAV.pend-1); if(silent) NAV.closing=Math.max(0, NAV.closing-1); navHistSettle(); }
}
function navHistSettle(){
  clearTimeout(NAV.wd); NAV.wd=null; NAV.pend=0;
  const q=NAV.pushQ.splice(0); q.forEach(function(p){ navPushNow(p[0], p[1]); });
  if(NAV.needChk){ NAV.needChk=false; navCheckTop(); }
}

function navOpen(id, close){
  if(navIsOpen(id)) return;
  const nid='n'+(++NAV.seq)+'.'+Date.now().toString(36);
  const l={id:id, close:close, nid:nid};
  NAV.layers.push(l);
  navHistPush(function(){ const i=NAV.layers.indexOf(l); if(i<0) return null; return {tab:navTabNow(), d:((history.state && history.state.d)||0)+1, ly:i+1, nid:nid}; });
}
/* 앱 안에서 닫힘 — 그 층의 기록 칸은 '지난 칸'으로 표시. 맨 위에 그대로 있으면 바로 1칸 되돌리고,
   그 사이 다른 화면이 칸을 쌓았으면 남겨 두었다가 폰 뒤로가기 때 건너뛴다(순서가 꼬여 엉뚱한 칸을 지우지 않게). */
function navClosed(id, after){
  const i=NAV.layers.findIndex(function(l){ return l.id===id; }); if(i<0) return;
  const l=NAV.layers.splice(i, 1)[0];
  NAV.dead.add(l.nid);
  if(after) NAV.afterQ.push(after);
  if(NAV.chk) return;
  NAV.chk=setTimeout(function(){ NAV.chk=null; navCheckTop(); }, 0);
}
/* 맨 위 칸이 지난 칸이면 1칸 되돌린다. 되돌리기가 진행 중이면 기록 위치가 아직 옛것이므로 끝난 뒤에 본다 */
function navCheckTop(){
  if(NAV.pend>0){ NAV.needChk=true; return; }
  const st=history.state||{};
  if(st.nid && NAV.dead.has(st.nid)) navHistBack(1, true);
  else navRunAfter();
}
function navRunAfter(){ const q=NAV.afterQ.splice(0); q.forEach(function(f){ try{ f(); }catch(e){ logErr('화면 닫은 뒤', e); } }); }
function navSwap(from, to, close){
  const l=NAV.layers.find(function(x){ return x.id===from; });
  if(!l){ navOpen(to, close); return; }
  l.id=to; l.close=close;
}
function navHideSheet(id){
  if(id==='uiSheet'){ try{ uiSheetClose({ok:false}); }catch(e){} return; }
  const el=document.getElementById(id); if(el) el.classList.remove('on');
}
/* 시트(class 'on')를 지켜보다가 열리면 층 추가, 앱 안에서 닫히면 층 제거 */
function navInit(){
  if(typeof MutationObserver!=='function') return;
  const ob=new MutationObserver(function(list){
    const seen={};
    list.forEach(function(m){
      const el=m.target, id=el.id; if(seen[id]) return; seen[id]=1;
      const on=el.classList.contains('on'), has=navIsOpen(id);
      if(on && !has) navOpen(id, function(){ navHideSheet(id); });
      else if(!on && has) navClosed(id);
    });
  });
  NAV_SHEETS.forEach(function(id){ const el=document.getElementById(id); if(el) ob.observe(el, {attributes:true, attributeFilter:['class']}); });
}
window.addEventListener('popstate', function(e){
  if(NAV.pend>0) NAV.pend--;
  try{ navOnPop(e); }catch(er){ logErr('뒤로가기', er); }
  if(NAV.pend===0) navHistSettle();   /* 미뤄 둔 칸 넣기·맨 위 확인을 마저 한다 */
});
function navOnPop(e){
  const st=e.state||{};
  if(st.nid && NAV.dead.has(st.nid)){ navHistBack(1, false); return; }               /* 이미 닫힌 화면의 칸 = 건너뜀 */
  if(NAV.closing>0){ NAV.closing--; navRunAfter(); return; }                          /* 앱이 스스로 되돌린 칸 */
  const target=typeof st.ly==='number'? st.ly : 0;
  if(NAV.layers.length>target){                                                       /* 맨 위 층부터 닫기 */
    while(NAV.layers.length>target){ const l=NAV.layers.pop(); NAV.dead.add(l.nid); try{ l.close(true); }catch(er){ logErr('뒤로가기: '+l.id, er); } }
    return;
  }
  try{ if(window.SHORTS && window.SHORTS.onPop(e)) return; }catch(er){ logErr('뒤로가기: 쇼츠', er); }   /* V6.5: 쇼츠 화면 한 장씩 */
  const t=st.tab || (location.hash||'').slice(1);
  if(!t || !document.getElementById('tab-'+t)) return; /* 장내 앵커 등 탭이 아닌 해시는 무시 */
  if(NAV_HIST.length>1) NAV_HIST.pop();
  goTab(t, true);
}
function bindNav(){
  document.querySelectorAll('.bn-btn').forEach(function(b){ b.addEventListener('click', function(){ goTab(b.dataset.tab); }); });
  const bp=document.getElementById('abPhoto'); if(bp) bp.addEventListener('click', function(){ goTab('home'); });
  const bi=document.getElementById('abInfo'); if(bi) bi.addEventListener('click', function(){ goTab('home'); });
  const lb=document.getElementById('libBackBtn'); if(lb) lb.addEventListener('click', navBack);
  const hp=document.getElementById('hpBtn'); if(hp) hp.addEventListener('click', function(){ goTab('album'); });   /* V6.0.4: 홈 대표사진 → 앨범 */
  const db=document.getElementById('ddayBanner'); if(db) db.addEventListener('click', function(){ const ev=nearestEvent(); goTab('cal'); if(ev) goCalDate(ev.d); });
}


/* =============== V4: 산책 토글 + 통합 취소 =============== */

/* =============== V5: 수면 토글 — 취침 1탭, 기상 1탭. 자정 넘김은 기상일에 저장 =============== */

/* =============== V4.1: 스탬프 탭 → 확인 후 삭제 =============== */
/* V5.5: 스탬프 펼침 상태 (세션 한정 — 새로고침 시 접힘) */
const QL_OPEN={};
/* ===== V5.6: 퀵액션 기록 수정 시트 ===== */
const QE={mode:'', k:'', i:-1, amt:'', day:''};
/* V6.2.1: 진행 중 기록 — 시작 시각만 수정 · 진행 취소. 유치원(kcur)도 같은 시트로(하원은 하원 버튼). */
const QE_CUR={
  wcur:{k:'walkCur',  t:'🐕 산책 진행 중',    l:'시작 시각', x:'진행 취소', q:'진행 중인 산책을 취소할까요? 이번 산책은 기록되지 않습니다.'},
  scur:{k:'sleepCur', t:'😴 수면 진행 중',    l:'취침 시각', x:'진행 취소', q:'진행 중인 수면 기록을 취소할까요? 이번 수면은 저장되지 않습니다.'},
  acur:{k:'awayCur',  t:'🚪 외출 진행 중',    l:'외출 시각', x:'진행 취소', q:'이 외출 기록을 취소할까요? 시간이 저장되지 않습니다.'},
  kcur:{k:'kgCur',    t:'🎒 유치원 등원 중',  l:'등원 시각', x:'등원 취소', q:'진행 중인 등원을 취소할까요? 이번 등원은 기록되지 않습니다.'}
};
function qeTimeStr(v){ return /^\d\d:\d\d$/.test(v||'')? v+':00' : null; }
function qeSortCount(arr){ arr.sort(function(a,b){ a=String(a).split('|')[0]; b=String(b).split('|')[0]; return a<b? -1 : a>b? 1 : 0; }); }
function qeApplyHM(baseMs, hm){ const d=new Date(baseMs); const p=hm.split(':'); d.setHours(parseInt(p[0],10), parseInt(p[1],10), 0, 0); return d.getTime(); }
function qeShow(){ const ov=document.getElementById('qeOvl'); if(ov) ov.classList.add('on'); }
function qeHide(){ const ov=document.getElementById('qeOvl'); if(ov) ov.classList.remove('on'); }
function qeAmtPaint(){
  document.querySelectorAll('#qeAmt button').forEach(function(b){ b.classList.toggle('on', b.dataset.qa===QE.amt); });
}
function qeOpen(mode, k, i){
  QE.mode=mode; QE.k=k||''; QE.i=(i==null? -1 : i); QE.amt='';
  const T=document.getElementById('qeTitle'), t1=document.getElementById('qeT1'), t2=document.getElementById('qeT2'),
        l1=document.getElementById('qeLbl1'), l2=document.getElementById('qeLbl2'),
        am=document.getElementById('qeAmt'), hint=document.getElementById('qeHint'),
        del=document.getElementById('qeDel');
  if(!T) return;
  t2.style.display='none'; l2.style.display='none'; am.style.display='none';
  hint.textContent=''; del.textContent='삭제';
  const key=todayKey(); QE.day=key;   /* V6.6: 연 날짜를 기억 — 자정을 넘겨 저장·삭제해도 이 날 기록에 적용 */
  if(mode==='count'){
    const NM={poo:'💩 대변', pee:'💧 소변', diar:'💦 설사', meal:'🍚 식사'};
    T.textContent=(NM[k]||'')+' 기록 수정';
    l1.textContent='시각';
    const raw=String(qlNorm(key)[k][QE.i]||'');
    t1.value=raw.split('|')[0].slice(0,5);
    if(k==='poo'){ am.style.display='flex'; QE.amt=raw.split('|')[1]||'m'; qeAmtPaint(); }
    if(k==='meal') hint.textContent='시각을 고치면 다음 끼니 안내·공복 경고가 새 시각 기준으로 다시 계산됩니다.';
  }else if(mode==='walk' || mode==='sleep' || mode==='away'){
    const log=(mode==='walk'? S.walkLog : (mode==='sleep'? S.sleepLog : S.awayLog))||{};
    const s=(log[key]||[])[QE.i]; if(!s) return;
    T.textContent=(mode==='walk'? '🐕 산책' : (mode==='sleep'? '😴 수면' : '🚪 외출'))+' 기록 수정';
    l1.textContent='시작'; l2.textContent='종료';
    t1.value=fmtHM(s.o); t2.value=fmtHM(s.i);
    t2.style.display=''; l2.style.display='';
    if(d2s(new Date(s.o))!==d2s(new Date(s.i))) hint.textContent='자정을 넘긴 기록 — 시작은 전날, 종료는 오늘 날짜로 저장됩니다.';
  }else if(QE_CUR[mode]){
    const C=QE_CUR[mode], cur=S[C.k]; if(!cur) return;
    T.textContent= mode==='kcur'? '🎒 '+kgName()+' 등원 중' : C.t;
    l1.textContent=C.l;
    t1.value=fmtHM(cur);
    del.textContent=C.x;
    hint.textContent= mode==='kcur'? '등원 시각만 고칩니다. 하원은 하원 버튼으로 기록하세요. 등원 취소를 누르면 이번 등원은 저장되지 않습니다.'
      : C.l+'만 고칩니다. '+C.x+'를 누르면 이번 기록은 저장되지 않습니다.';
  }
  qeShow();
}
function qeSave(){
  const key=QE.day||todayKey(), now=Date.now();
  const v1=document.getElementById('qeT1').value, v2=document.getElementById('qeT2').value;
  if(QE.mode==='count'){
    const hm=qeTimeStr(v1); if(!hm){ alert('시각을 입력해주세요.'); return; }
    if(new Date(key+'T'+hm).getTime()>now){ alert('미래 시각으로는 저장할 수 없습니다.'); return; }
    const arr=qlNorm(key)[QE.k];
    if(QE.i<0 || QE.i>=arr.length){ qeHide(); return; }
    arr[QE.i]=hm + (QE.k==='poo'? '|'+(QE.amt||'m') : '');
    qeSortCount(arr);
  }else if(QE.mode==='walk' || QE.mode==='sleep' || QE.mode==='away'){
    if(!/^\d\d:\d\d$/.test(v1) || !/^\d\d:\d\d$/.test(v2)){ alert('시작·종료 시각을 모두 입력해주세요.'); return; }
    const log=(QE.mode==='walk'? S.walkLog : (QE.mode==='sleep'? S.sleepLog : S.awayLog))||{};
    const list=log[key]||[]; const s=list[QE.i]; if(!s){ qeHide(); return; }
    const no=qeApplyHM(s.o, v1), ni=qeApplyHM(s.i, v2);
    if(no>=ni){ alert('시작이 종료보다 늦을 수 없습니다.'); return; }
    if(ni>now || no>now){ alert('미래 시각으로는 저장할 수 없습니다.'); return; }
    s.o=no; s.i=ni;
    list.sort(function(a,b){ return a.o-b.o; });
  }else if(QE_CUR[QE.mode]){
    if(!/^\d\d:\d\d$/.test(v1)){ alert('시각을 입력해주세요.'); return; }
    const C=QE_CUR[QE.mode], cur=S[C.k]; if(!cur){ qeHide(); return; }
    const nc=qeApplyHM(cur, v1);
    if(nc>now){ alert('미래 시각으로는 저장할 수 없습니다.'); return; }
    S[C.k]=nc;
  }
  saveState(); renderQlog(); if(typeof renderAway==='function') renderAway(); qeHide();
}
async function qeDelete(){
  const key=QE.day||todayKey();
  if(QE.mode==='count'){
    const NM={poo:'대변', pee:'소변', diar:'설사', meal:'식사'};
    if(!(await askConfirm((NM[QE.k]||'')+' 기록을 삭제할까요?'))) return;
    qlNorm(key)[QE.k].splice(QE.i,1);
  }else if(QE.mode==='walk'){
    if(!(await askConfirm('산책 기록을 삭제할까요?'))) return;
    ((S.walkLog||{})[key]||[]).splice(QE.i,1);
  }else if(QE.mode==='sleep'){
    if(!(await askConfirm('수면 기록을 삭제할까요?'))) return;
    ((S.sleepLog||{})[key]||[]).splice(QE.i,1);
  }else if(QE.mode==='away'){
    if(!(await askConfirm('외출 기록을 삭제할까요?'))) return;
    ((S.awayLog||{})[key]||[]).splice(QE.i,1);
  }else if(QE_CUR[QE.mode]){
    const C=QE_CUR[QE.mode];
    if(!(await askConfirm(C.q))) return;
    S[C.k]=0;
  }
  saveState(); renderQlog(); if(typeof renderAway==='function') renderAway(); qeHide();
}
function bindQe(){
  const ov=document.getElementById('qeOvl'); if(!ov) return;
  document.getElementById('qeSave').addEventListener('click', qeSave);
  document.getElementById('qeDel').addEventListener('click', qeDelete);
  document.getElementById('qeCancel').addEventListener('click', qeHide);
  ov.addEventListener('click', function(e){ if(e.target===ov) qeHide(); });
  document.getElementById('qeAmt').addEventListener('click', function(e){
    const b=e.target.closest('button[data-qa]'); if(!b) return;
    QE.amt=b.dataset.qa; qeAmtPaint();
  });
}

/* 장내 앵커: 주소를 건드리지 않고 스크롤만 */
function bindAnchors(){
  document.addEventListener('click', function(e){
    const a=e.target.closest('a[href^="#"]');
    if(!a) return;
    const id=(a.getAttribute('href')||'').slice(1);
    e.preventDefault();
    if(!id) return;
    const el=document.getElementById(id);
    if(el && el.scrollIntoView){
      try{ el.scrollIntoView({behavior:'smooth', block:'start'}); }
      catch(_e){ el.scrollIntoView(); }
    }
  });
}


/* =============== V5 헬퍼 =============== */
/* S1: 검색 위치 점프 + 하이라이트 */
let LIB_HL=null;
function libClearHl(){
  if(LIB_HL && LIB_HL.parentNode){
    const p=LIB_HL.parentNode;
    p.replaceChild(document.createTextNode(LIB_HL.textContent), LIB_HL);
    p.normalize();
  }
  LIB_HL=null;
}
function libJump(id, kw){
  libClearHl();
  const sec=document.getElementById('tab-'+id); if(!sec || !kw) return;
  const low=kw.toLowerCase();
  const walker=document.createTreeWalker(sec, NodeFilter.SHOW_TEXT, null);
  let node;
  while((node=walker.nextNode())){
    const tag=node.parentNode && node.parentNode.tagName;
    if(tag==='SCRIPT' || tag==='STYLE') continue;
    const idx=node.textContent.toLowerCase().indexOf(low);
    if(idx===-1) continue;
    try{
      const target=node.splitText(idx);
      target.splitText(kw.length);
      const mk=document.createElement('mark');
      mk.className='lib-hl';
      target.parentNode.replaceChild(mk, target);
      mk.appendChild(target);
      LIB_HL=mk;
      mk.scrollIntoView({behavior:'smooth', block:'center'});
    }catch(e){}
    return;
  }
}
/* F1: 식사 텀 */
function lastMealTs(){
  const tk=todayKey();
  const q=qlNorm(tk);
  let d=tk, arr=q.meal;
  if(!arr.length){
    const y=addD(new Date(tk+'T00:00:00'), -1);
    d=d2s(y);
    const s=(S.qlog||{})[d];
    arr=(s && Array.isArray(s.meal))? s.meal : [];
    if(!arr.length) return null;
  }
  const t=String(arr[arr.length-1]||'');
  if(!/^\d\d:\d\d/.test(t)) return null;
  return new Date(d+'T'+(t.length===5? t+':00' : t)).getTime();
}
function mgSet(el, cls, text){                                       /* V5.16: 줄 끝에 '기준 ›' — 누르면 08장 급여 기준 카드 */
  el.className='mg-line '+cls; el.textContent=text;
  const go=document.createElement('span'); go.className='mg-go'; go.textContent='· 기준 ›'; el.appendChild(go);
}
function renderMealGap(){
  const el=document.getElementById('mealGap'); if(!el) return;
  const hr=new Date().getHours();
  const lm=lastMealTs();
  const fd=feedCalc();
  const per=feedMealTxt(fd);                                         /* V6.2: 현재 급여량(+조정) 또는 공식 범위 */
  const g=feedGap();                                                  /* V5.17: 월령·끼니 수 기준 */
  if(hr>=22 || hr<6){ mgSet(el,'mg-night','🌙 야간 — 아침 첫 식사는 06~08시'+per); return; }
  if(!lm){ mgSet(el,'mg-warn','⚠ 식사 기록 없음 — 공복 한계 '+feedGapTxt(g.limit)+per); return; }
  const gap=Date.now()-lm;
  if(gap>g.limit*3600000){
    mgSet(el,'mg-warn','⚠ 마지막 식사 후 '+fmtDur(gap)+' — 공복 '+feedGapTxt(g.limit)+' 초과'+((g.mo!=null && g.mo<6)? ', 저혈당 주의' : '')+per);
  }else{
    const next=lm+g.est*3600000;
    const nh=new Date(next).getHours();
    if(nh>=22 || nh<6){
      /* V5.1: 다음 끼니가 야간(22~06시)에 걸림 → 새벽 급여 안내 대신 하루 마감 처리 */
      const lmH=new Date(lm).getHours();
      const mo=(typeof ageMo==='function')? ageMo() : null;
      const eaten=qlNorm(todayKey()).meal.length;
      const fm=feedCfg().meals||4;
      if(mo!=null && mo<6 && lmH<19){
        mgSet(el,'mg-warn','⚠ 마지막 '+fmtHM(lm)+' — 이대로 자면 야간 공복이 길어져요. 취침 전(21시 전후) 한 끼 더 권장'+per);
      }else{
        mgSet(el,'mg-ok','✓ 오늘 식사 마감 ('+eaten+'/'+fm+'끼 · 마지막 '+fmtHM(lm)+') — 다음은 내일 아침 06~08시'+per);
      }
      return;
    }
    mgSet(el,'mg-ok','✓ 다음 식사 ~'+fmtHM(next)+' (마지막 '+fmtHM(lm)+')'+per);
  }
}
/* F2: 급여 기준·권장량 (V6.2 — V5.16 계산기 개편)
   ■ 공식 범위: 하루 kcal = RER(70×kg^0.75) × 배수 × 체형 보정 × (1−간식 비율) → 사료 g = kcal ÷ (사료 kcal/kg ÷ 1000)
     · 하한 배수 = AAHA 2021 — 4개월 미만 ×3.0 · 4~12개월 ×2.0 · 성견 중성화 전 ×1.6 / 후 ×1.4
     · 상한 배수 = 영국 수의간호 기준 — 성견 대비 50% 이하 ×3.0 → 80% ×2.0(중성화 ×1.8), 사이는 직선(계단 없음) · 성견 ×1.8 / ×1.6
     · 생후 300~365일은 성장기 배수에서 성견 배수로 직선 전환
   ■ 예상 성견 체중: 자동(기본) = 최근 7주 체중(하루 평균)에 로지스틱 성장곡선 W = A / (1 + e^(−r(t−t0))) 적합.
     r(주당 성장률)은 소·중형견 문헌 범위 0.09~0.19(Posada 2014)로 제한. 범위 = 프로파일 우도 95%(독립 관측 수 = 측정한 주 수).
     출생일과 무관하게 체중 추세만 쓴다. '직접 입력'을 고르면 그 값을 쓴다.
   ■ 판정(현재 급여량을 넣었을 때): ① 체형 마름/과체중 → ±10% (체형 판정일 뒤에 급여량을 바꿨으면 반영된 것으로 보고 다시 권하지 않음)
     ② 최근 2주 증체가 직전 2주의 절반 미만 · 1.5배 초과 · 감소 → 갈비뼈 재확인 표시 ③ 공식 범위 ±10% 밖 → 표시.
     ②③과 체중·체형 기록 경과는 양을 바꾸지 않고 확인만 요청한다. */
const FEED_BCS={thin:{adj:1.10, t:'마름'}, ok:{adj:1.0, t:'이상'}, heavy:{adj:0.90, t:'과체중'}};
const FEED_R=[0.09, 0.19];        /* 로지스틱 성장률(주당) 탐색 범위 — 소·중형견 0.091~0.189 (Posada 2014) */
const FEED_WIN=49;                /* 성견 체중 추정에 쓰는 최근 기록 기간(일) */
let FEED_EST_CACHE={k:null, v:null};
/* V5.17: 공복 기준 — limit=월령별 최대 공복(시간), est=다음 끼니 예상 간격(깨어있는 16시간 ÷ (끼니−1), 단 limit 이내) */
const FEED_MEALTIME={p4:'07:00 · 11:30 · 16:00 · 20:30', p6:'06:30 · 13:30 · 21:00', p12:'07:00 · 13:30 · 20:00', ad:'07:00 · 19:30'};
function feedGap(){
  const mo=(typeof ageMo==='function')? ageMo() : null;
  const m=feedCfg().meals||4;
  const limit = (mo==null)? 5 : (mo<4? 5 : (mo<6? 7.5 : (mo<12? 9 : 12)));
  return {limit:limit, est:Math.min(limit, 16/Math.max(1,m-1)), mo:mo};
}
function feedGapTxt(h){ return (h===Math.round(h))? (h+'시간') : (Math.floor(h)+'시간 '+Math.round((h%1)*60)+'분'); }
function feedCfg(){ return Object.assign({}, DEFAULT_S.feed, S.feed||{}); }     /* 옛 저장본(kcal·meals만)도 기본값으로 채워 읽음 */
function feedSet(k, v){ S.feed=feedCfg(); S.feed[k]=v; saveState(); renderFeed(); renderMealGap(); }
function feedAgeDays(){ if(!S.profile.birth) return null; return Math.floor((new Date()-new Date(S.profile.birth+'T00:00:00'))/86400000); }
function feedMD(k){ k=String(k||''); return parseInt(k.slice(5,7),10)+'/'+parseInt(k.slice(8,10),10); }
/* 기준 체중 — 성장기는 최신 기록일 기준 최근 10일 최고값(0.1kg 측정 오차로 값이 오르내리지 않게), 12개월부터는 최신값 */
function feedBaseWeight(days){
  const lw=latestWeight(); if(!lw) return null;
  let best=lw;
  if(days<365){
    const lim=d2s(addD(new Date(lw.d+'T00:00:00'), -10));
    S.weight.forEach(function(w){ if(w.d>=lim && w.d<=lw.d && parseFloat(w.kg)>parseFloat(best.kg)) best=w; });
  }
  return {kg:parseFloat(best.kg), d:best.d, hi:best!==lw};
}

/* ---------- 예상 성견 체중 — 로지스틱 성장곡선 적합 ---------- */
function feedAdultEst(){
  const pts=stWtPts();
  const key=pts.map(function(p){ return p.d+':'+p.kg; }).join('|');
  if(FEED_EST_CACHE.k===key) return FEED_EST_CACHE.v;
  let v;
  try{ v=feedAdultFit(pts); }catch(e){ console.error(e); v={ok:false, why:'계산 오류'}; }
  FEED_EST_CACHE={k:key, v:v};
  return v;
}
function feedAdultFit(pts){
  if(!pts.length) return {ok:false, why:'체중 기록이 없습니다'};
  const last=pts[pts.length-1].d, by={};
  pts.forEach(function(p){ if(stDiff(p.d, last)<=FEED_WIN){ (by[p.d]=by[p.d]||[]).push(p.kg); } });
  const keys=Object.keys(by).sort();
  if(keys.length<4) return {ok:false, why:'최근 7주 체중 '+keys.length+'회 — 4회 이상 필요'};
  const span=stDiff(keys[0], last);
  if(span<21) return {ok:false, why:'기록 기간 '+span+'일 — 21일 이상 필요'};
  const t=keys.map(function(k){ return stDiff(keys[0], k)/7; });
  const w=keys.map(function(k){ return stSum(by[k])/by[k].length; });
  const lw=w.map(Math.log), n=t.length;
  const wmax=Math.max.apply(null, w), A0=wmax*1.01, AMAX=Math.max(15, wmax*4);
  const RS=[]; for(let i=0;i<=20;i++) RS.push(FEED_R[0]+(FEED_R[1]-FEED_R[0])*i/20);
  let best=null; const prof=[];
  for(let A=A0; A<=AMAX; A*=1.005){
    const lA=Math.log(A), z=w.map(function(x){ return Math.log(A/x-1); });
    let bs=Infinity, br=0, ba=0;
    for(let j=0;j<RS.length;j++){
      const r=RS[j]; let a=0;
      for(let i=0;i<n;i++) a+=z[i]+r*t[i];
      a/=n;
      let sse=0;
      for(let i=0;i<n;i++){ const e=lw[i]-lA+Math.log(1+Math.exp(a-r*t[i])); sse+=e*e; }
      if(sse<bs){ bs=sse; br=r; ba=a; }
    }
    prof.push([A, bs]);
    if(!best || bs<best.sse) best={A:A, sse:bs, r:br, a:ba};
  }
  const wk={}; t.forEach(function(x){ wk[Math.floor(x)]=1; });
  const neff=Math.max(3, Math.min(n, Object.keys(wk).length));
  const thr=Math.max(best.sse, 1e-12)*Math.exp(3.84/neff);
  let lo=Infinity, hi=0;
  prof.forEach(function(q){ if(q[1]<=thr){ if(q[0]<lo) lo=q[0]; if(q[0]>hi) hi=q[0]; } });
  const top=hi*1.005>AMAX;
  const rel=(hi-lo)/best.A;
  const r1=function(x){ return Math.round(x*10)/10; };
  return {ok:true, A:r1(best.A), lo:r1(lo), hi:top? null : r1(hi),
          grade:(top || rel>0.35)? '낮음' : (rel>0.15? '보통' : '높음'), n:n, span:span, r:best.r};
}

function feedKg1(x){ return (Math.round(x*10)/10).toFixed(1); }
function feedEstTxt(e){ return e.hi==null? (feedKg1(e.lo)+'kg 이상 (상한 미정 — 계산엔 하한 사용)') : (feedKg1(e.A)+'kg ('+feedKg1(e.lo)+'~'+feedKg1(e.hi)+')'); }
/* ---------- 배수 범위 — 계단 없이 연속 ---------- */
function feedMults(kg, days, adult, neut){
  const adLo=neut? 1.4 : 1.6, adHi=neut? 1.6 : 1.8, m80=neut? 1.8 : 2.0;
  const gLo= days<122? 3.0 : 2.0;
  let p=null, gHi=gLo;
  if(adult>0){ p=kg/adult; gHi= p<=0.5? 3.0 : (p>=0.8? m80 : 3.0-(p-0.5)/0.3*(3.0-m80)); }
  let lo=Math.min(gLo, gHi), hi=Math.max(gLo, gHi), phase='grow';
  if(days>=365){ lo=adLo; hi=adHi; phase='adult'; }
  else if(days>=300){ const f=(days-300)/65; lo=lo+(adLo-lo)*f; hi=hi+(adHi-hi)*f; phase='ramp'; }
  return {lo:lo, hi:hi, p:p, phase:phase};
}

/* ---------- 성장 속도 — 최근 2주 vs 직전 2주 (성견: 4주 변화율) ---------- */
function feedGrowth(days){
  const pts=stWtPts(); if(!pts.length) return {st:'na', txt:'체중 기록 없음'};
  const last=pts[pts.length-1].d;
  const sp=function(a){ return a.length>=2? stDiff(a[0].d, a[a.length-1].d) : 0; };
  const gd=function(a){ const s=stSlope(a); return s==null? null : s/7*1000; };      /* g/일 */
  const f=function(x){ return (x>=0? '+' : '−')+Math.abs(Math.round(x))+'g/일'; };
  if(days>=365){
    const a=stWtIn(stAdd(last,-28), last);
    if(sp(a)<14) return {st:'na', txt:'4주 안에 14일 이상 간격으로 2회 측정 필요'};
    const pct=gd(a)*28/1000/pts[pts.length-1].kg*100;
    const st= pct>3? 'fast' : (pct<-3? 'drop' : 'ok');
    return {st:st, txt:'4주 '+(pct>=0? '+' : '−')+Math.abs(pct).toFixed(1)+'%', lab:{ok:'유지', fast:'증가', drop:'감소'}[st]};
  }
  const rec=stWtIn(stAdd(last,-14), last), prev=stWtIn(stAdd(last,-28), stAdd(last,-14));
  if(sp(rec)<7) return {st:'na', txt:'최근 2주에 7일 이상 간격으로 2회 측정 필요'};
  const gr=gd(rec), gp= sp(prev)>=7? gd(prev) : null;
  let st='ok';
  if(gr<-5) st='drop';
  else if(gp!=null && gp>=8){ const q=gr/gp; if(q<0.5) st='slow'; else if(q>1.5) st='fast'; }
  else if(days<300 && gr<3) st='slow';
  return {st:st, rec:gr, prev:gp, txt:f(gr), sub: gp!=null? '직전 2주 '+f(gp) : '직전 2주 기록 부족',
          lab:{ok:'정상', slow:'둔화', fast:'가속', drop:'감소'}[st]};
}

/* ---------- 계산 ---------- */
function feedCalc(){
  const days=feedAgeDays(); if(days==null) return null;
  const bw=feedBaseWeight(days); if(!bw || !(bw.kg>0)) return null;
  const c=feedCfg(), lw=latestWeight(), est=feedAdultEst();
  let adult=0, src='';
  if(c.adultMode==='manual'){ if(c.adult>0){ adult=c.adult; src='manual'; } }
  else if(est && est.ok){ adult= est.hi==null? est.lo : est.A; src='auto'; }   /* 상한이 안 잡히면 하한(보수적)으로 계산 */
  const m=feedMults(bw.kg, days, adult, !!c.neut);
  const bcs=FEED_BCS[c.bcs]? c.bcs : 'ok', bc=FEED_BCS[bcs];
  const rer=70*Math.pow(bw.kg, 0.75);
  const fk=(c.kcal>0)? c.kcal : 4000;                                  /* kcal 누락·0 시 NaN 방지 */
  const treat=Math.min(50, Math.max(0, +c.treat||0));
  const kLo=Math.round(rer*m.lo*bc.adj), kHi=Math.round(rer*m.hi*bc.adj);
  const g=function(k){ return Math.round(k*(1-treat/100)/(fk/1000)); };
  const meals=c.meals||4, gLo=g(kLo), gHi=g(kHi);
  const cur=(c.vetG>0)? Math.round(c.vetG) : 0;
  const wAge=lw? stDiff(lw.d, todayKey()) : 0;
  const fd={days:days, bw:bw, rer:rer, mult:m, kLo:kLo, kHi:kHi, gLo:gLo, gHi:gHi, meals:meals,
    perLo:Math.round(gLo/meals), perHi:Math.round(gHi/meals),
    cur:cur, curPer:cur? Math.round(cur/meals) : 0, curAt:c.vetAt||'',
    adult:adult, src:src, est:est, bcs:bcs, bcsAt:c.bcsAt||'', neut:!!c.neut, treat:treat, kcal:fk,
    gr:feedGrowth(days), lw:lw, wAge:wAge, stale: days<365? wAge>=8 : wAge>=35};
  fd.verdict=feedVerdict(fd);
  return fd;
}
/* ---------- 판정 — 현재 급여량 기준 ---------- */
function feedVerdict(fd){
  if(!fd.cur) return null;
  const notes=[]; let act='keep', g=fd.cur, why='';
  if(fd.bcs!=='ok'){
    if(fd.curAt && fd.bcsAt && fd.curAt>fd.bcsAt) notes.push('체형('+FEED_BCS[fd.bcs].t+') 조정을 '+feedMD(fd.curAt)+'에 반영 — 2주 뒤 갈비뼈를 다시 판정');
    else{
      act= fd.bcs==='heavy'? 'down' : 'up';
      g=Math.round(fd.cur*(fd.bcs==='heavy'? 0.9 : 1.1));
      why= fd.bcs==='heavy'? '갈비뼈를 눌러야 만져짐' : '갈비뼈·등뼈가 도드라짐';
    }
  }
  if(fd.gr.st==='drop') notes.push('체중 감소 — 갈비뼈를 확인하고, 1주 더 이어지면 병원');
  else if(fd.gr.st==='slow') notes.push('증체 둔화 — 갈비뼈가 도드라지면 체형을 \'마름\'으로');
  else if(fd.gr.st==='fast') notes.push('증체 가속 — 갈비뼈를 눌러야 만져지면 체형을 \'과체중\'으로');
  if(act==='keep'){
    if(fd.cur<fd.gLo*0.9) notes.push('공식 하한보다 '+Math.round((1-fd.cur/fd.gLo)*100)+'% 적음 — 성장·체형이 정상이면 유지');
    else if(fd.cur>fd.gHi*1.1) notes.push('공식 상한보다 '+Math.round((fd.cur/fd.gHi-1)*100)+'% 많음 — 체형 확인');
  }
  if(fd.stale) notes.push('체중을 '+fd.wAge+'일 전에 쟀습니다 — 다시 재야 판정이 맞습니다');
  const bAge= fd.bcsAt? stDiff(fd.bcsAt, todayKey()) : null;
  if(bAge==null) notes.push('체형 판정 전 — 갈비뼈를 만져보고 고르세요');
  else if(bAge>=14) notes.push('체형 판정 '+bAge+'일 경과 — 다시 만져보세요');
  return {act:act, g:g, per:Math.round(g/fd.meals), why:why, notes:notes};
}
/* 홈 식사 줄 끝에 붙는 급여량 */
function feedMealTxt(fd){
  if(!fd) return '';
  if(fd.cur){ const v=fd.verdict; return ' · '+fd.curPer+'g/끼'+((v && v.act!=='keep')? ' → '+v.per+'g' : ''); }
  return ' · 권장 '+(fd.perLo===fd.perHi? '약 '+fd.perLo : fd.perLo+'~'+fd.perHi)+'g/끼';
}

/* ---------- 화면 ---------- */
function feedRangeTxt(a, b, u){ return a===b? ('약 '+a+u) : (a+'~'+b+u); }
function renderFeed(){
  const out=document.getElementById('fdOut'); if(!out) return;
  const c=feedCfg();
  const setV=function(id, v){ const el=document.getElementById(id); if(el && document.activeElement!==el) el.value=v; };
  const auto= c.adultMode!=='manual';
  setV('fdKcal', c.kcal||4000); setV('fdMeals', String(c.meals||4)); setV('fdAdult', c.adult>0? c.adult : '');
  setV('fdAdultMode', auto? 'auto' : 'manual');
  setV('fdBcs', FEED_BCS[c.bcs]? c.bcs : 'ok'); setV('fdNeut', c.neut? '1' : '0'); setV('fdTreat', String(c.treat||0));
  setV('fdVet', c.vetG>0? c.vetG : ''); setV('fdVetAt', c.vetAt||'');
  const man=document.getElementById('fdAdult'); if(man) man.hidden=auto;
  const mo=ageMo();
  const mh=document.getElementById('fdMealsHint');
  if(mh){                                                             /* V5.17: 권장 횟수 + 권장 시각 + 공복 한계 */
    if(mo==null) mh.textContent='';
    else{
      const gp=feedGap();
      const rec = mo<4? {n:'4회', t:FEED_MEALTIME.p4} : (mo<6? {n:'3~4회', t:FEED_MEALTIME.p6} : (mo<12? {n:'2~3회', t:FEED_MEALTIME.p12} : {n:'2회', t:FEED_MEALTIME.ad}));
      mh.textContent='이 월령 권장: '+rec.n+' · '+rec.t+' (공복 한계 '+feedGapTxt(gp.limit)+')';
    }
  }
  const bh=document.getElementById('fdBcsHint');
  if(bh){
    const ago=c.bcsAt? stDiff(c.bcsAt, todayKey()) : null;
    bh.textContent = ago==null? '아직 판정 전 — 갈비뼈를 만져보고 고르세요' : ('마지막 판정 '+feedMD(c.bcsAt)+(ago>=7? ' · '+ago+'일 경과 — 다시 만져보세요' : (ago? ' · '+ago+'일 전' : ' · 오늘')));
  }
  const kh=document.getElementById('fdKcalHint');
  if(kh){
    const fk=c.kcal||4000;
    kh.textContent= fk===3735? '3,735는 이전 사료(로얄캐닌 미니 인도어 퍼피) 값 — 지금 사료 봉지 값으로 바꾸세요' : '봉지 뒷면 대사에너지(ME) 값';
    kh.classList.toggle('lv-watch', fk===3735);
  }
  const est=feedAdultEst();
  const ah=document.getElementById('fdAdultHint');
  if(ah){
    const et= est.ok? (feedEstTxt(est)+' · 신뢰도 '+est.grade) : est.why;
    ah.textContent= auto? (est.ok? '최근 7주 체중 '+est.n+'회로 성장곡선 적합 — '+et : et) : ('직접 입력값 사용 · 자동 추정 '+(est.ok? et : '불가 — '+est.why));
  }
  const kv=document.getElementById('fdKv'), stg=document.getElementById('fdStage');
  const fd=feedCalc();
  if(!fd){
    out.textContent='체중과 생년월일을 입력하면 계산됩니다.';
    if(kv) kv.innerHTML='';
    if(stg){ stg.textContent=''; stg.style.display='none'; }
    return;
  }
  const v=fd.verdict, rng=feedRangeTxt(fd.gLo, fd.gHi, 'g');
  if(fd.cur){
    const vd= v.act==='keep'? (v.notes.length? '<span class="fd-vd chk">유지 · 확인</span>' : '<span class="fd-vd ok">유지</span>')
      : '<span class="fd-vd act">'+(v.act==='up'? '+10%' : '−10%')+' → '+v.g+'g</span>';
    const pos= fd.cur<fd.gLo*0.9? '공식 범위('+rng+')보다 '+Math.round((1-fd.cur/fd.gLo)*100)+'% 적음'
      : (fd.cur<fd.gLo? '공식 범위('+rng+') 하한 근처'
      : (fd.cur>fd.gHi*1.1? '공식 범위('+rng+')보다 '+Math.round((fd.cur/fd.gHi-1)*100)+'% 많음'
      : (fd.cur>fd.gHi? '공식 범위('+rng+') 상한 근처' : '공식 범위('+rng+') 안')));
    out.innerHTML='<div class="fd-head"><div class="fd-amt"><b>'+fd.cur+'g</b><span>/일 · 끼당 '+fd.curPer+'g</span></div>'+vd+'</div>'
      +'<p class="fd-sub">현재 급여량 · '+pos+'</p>';
  }else{
    out.innerHTML='<div class="fd-head"><div class="fd-amt"><b>'+rng+'</b><span>/일 · 끼당 '+feedRangeTxt(fd.perLo, fd.perHi, 'g')+'</span></div></div>'
      +'<p class="fd-sub">공식 범위 — 아래 현재 급여량을 넣으면 유지·조정을 판정합니다</p>';
  }
  if(kv){
    const mon=Math.floor(fd.days/30.44), dd=fd.days-Math.round(mon*30.44);
    const ml= fd.mult.lo===fd.mult.hi? '×'+fd.mult.lo.toFixed(1) : '×'+fd.mult.lo.toFixed(1)+'~'+fd.mult.hi.toFixed(1);
    const row=function(k, val, sub){ return '<div><dt>'+k+'</dt><dd>'+val+(sub? '<small>'+sub+'</small>' : '')+'</dd></div>'; };
    let h=row('공식 범위', rng, ml+' · '+feedRangeTxt(fd.kLo, fd.kHi, 'kcal')+(fd.treat? ' · 간식 '+fd.treat+'% 차감' : '')+(fd.bcs!=='ok'? ' · 체형 '+(fd.bcs==='heavy'? '−' : '+')+'10% 반영' : ''));
    h+=row('체중', fd.bw.kg.toFixed(2)+'kg', feedMD(fd.bw.d)+(fd.bw.hi? ' · 최근 10일 최고' : '')+' · 생후 '+mon+'개월 '+Math.max(0,dd)+'일'+(fd.stale? ' · <em class="lv-watch">'+fd.wAge+'일 전 측정</em>' : ''));
    if(fd.mult.phase==='adult') h+=row('성견', '유지기', (fd.neut? '중성화 후' : '중성화 전')+' · AAHA 성견 배수');
    else if(fd.adult) h+=row('예상 성견', feedKg1(fd.adult)+'kg'+((fd.src==='auto' && fd.est.hi==null)? ' 이상' : ''),
      (fd.src==='auto'? (fd.est.hi==null? '상한 미정 · 계산엔 하한 사용' : feedKg1(fd.est.lo)+'~'+feedKg1(fd.est.hi)+'kg')+' · 신뢰도 '+fd.est.grade : '직접 입력')+' · 지금 '+Math.round(fd.mult.p*100)+'%');
    else h+=row('예상 성견', '추정 전', (fd.src===''&& feedCfg().adultMode==='manual'? '직접 입력값 없음' : (fd.est.why||''))+' — 상한 없이 AAHA 기준만');
    const gs=fd.gr, lvc={ok:'lv-ok', slow:'lv-watch', fast:'lv-watch', drop:'lv-warn'}[gs.st]||'lv-na';
    h+=row('성장', gs.st==='na'? '판정 보류' : gs.txt, gs.st==='na'? gs.txt : ((fd.stale && fd.lw? feedMD(fd.lw.d)+'까지 · ' : '')+(gs.sub? gs.sub+' · ' : '')+'<em class="'+lvc+'">'+gs.lab+'</em>'));
    h+=row('체형', FEED_BCS[fd.bcs].t, fd.bcsAt? feedMD(fd.bcsAt)+' 판정' : '판정 전');
    kv.innerHTML=h;
  }
  if(stg){
    const lines=[];
    if(v && v.act!=='keep') lines.push('<b>'+v.why+' → '+fd.cur+'g에서 '+v.g+'g (끼당 '+v.per+'g)</b> · '+(v.act==='down'? '줄인' : '늘린')+' 뒤 아래 현재 급여량 칸에 '+v.g+' 입력');
    if(v) v.notes.forEach(function(t){ lines.push(t); });
    else if(fd.stale) lines.push('체중을 '+fd.wAge+'일 전에 쟀습니다 — 다시 재면 범위가 맞춰집니다');
    if(fd.mult.phase==='ramp') lines.push('10~12개월 — 성견 배수로 넘어가는 중 (생후 365일 완료)');
    stg.className='feed-stage'+((v && (v.act!=='keep' || v.notes.length)) || fd.stale? ' warn' : '');
    stg.innerHTML= lines.length? '<ul>'+lines.map(function(t){ return '<li>'+t+'</li>'; }).join('')+'</ul>' : '';
    stg.style.display= lines.length? '' : 'none';
  }
}
function bindFeed(){
  const on=function(id, fn){ const el=document.getElementById(id); if(el) el.addEventListener('change', fn); };
  on('fdKcal', function(){ const v=parseInt(this.value,10); if(v>=2500 && v<=6000) feedSet('kcal', v); else renderFeed(); });
  on('fdMeals', function(){ feedSet('meals', parseInt(this.value,10)||4); });
  on('fdAdultMode', function(){ feedSet('adultMode', this.value==='manual'? 'manual' : 'auto'); });
  on('fdAdult', function(){ const v=parseFloat(String(this.value).replace(',','.')); feedSet('adult', (v>=1 && v<=60)? Math.round(v*10)/10 : 0); });
  on('fdBcs', function(){ S.feed=feedCfg(); S.feed.bcs=FEED_BCS[this.value]? this.value : 'ok'; S.feed.bcsAt=todayKey(); saveState(); renderFeed(); renderMealGap(); });
  on('fdNeut', function(){ feedSet('neut', this.value==='1'? 1 : 0); });
  on('fdTreat', function(){ feedSet('treat', parseInt(this.value,10)||0); });
  on('fdVet', function(){                                            /* 현재 급여량 — 바꾸면 시작일을 오늘로 */
    const v=parseInt(this.value,10);
    S.feed=feedCfg(); S.feed.vetG=(v>0)? v : 0; S.feed.vetAt=(v>0)? todayKey() : '';
    saveState(); renderFeed(); renderMealGap();
  });
  on('fdVetAt', function(){ feedSet('vetAt', this.value||''); });
  const now=document.getElementById('fdBcsNow');
  if(now) now.addEventListener('click', function(){ S.feed=feedCfg(); S.feed.bcsAt=todayKey(); saveState(); renderFeed(); renderMealGap(); });
  /* 홈 식사 줄 → 08장 급여 기준 카드로 이동 */
  const mg=document.getElementById('mealGap');
  if(mg){
    const go=function(){
      goTab('record');
      setTimeout(function(){
        const cd=document.getElementById('feedCard'); if(!cd) return;
        try{ cd.scrollIntoView({behavior:'smooth', block:'start'}); }catch(e){}
        cd.classList.remove('feed-flash'); void cd.offsetWidth; cd.classList.add('feed-flash');
      }, 80);
    };
    mg.addEventListener('click', go);
    mg.addEventListener('keydown', function(e){ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); go(); } });
  }
}

/* =============== V2: SOS =============== */
function bindSOS(){
  const ov=document.getElementById('sosOvl'); if(!ov) return;
  document.getElementById('sosBtn').addEventListener('click', function(){
    const m=[];
    if(S.vet.main) m.push('단골 메모: '+S.vet.main);
    if(S.vet.e24) m.push('24시 메모: '+S.vet.e24);
    const el=document.getElementById('sosMemo');
    if(m.length){ el.textContent=m.join('\n'); el.style.display='block'; }
    else{ el.style.display='none'; }
    ov.classList.add('on');
  });
  document.getElementById('sosClose').addEventListener('click', function(){ ov.classList.remove('on'); });
  document.getElementById('sosEmerg').addEventListener('click', function(){ ov.classList.remove('on'); goTab('emerg'); });
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.classList.remove('on'); });
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') ov.classList.remove('on'); });
}

/* =============== V2: 대시보드 =============== */
function latestWeight(){
  if(!S.weight.length) return null;
  return [...S.weight].sort(function(a,b){ return a.d.localeCompare(b.d); }).pop();
}
function applyRep(){
  const id=(S.rep && S.rep.id)||'';
  let th=(S.rep && S.rep.th)||'';
  if(th.indexOf('blob:')===0) th='';                                   /* 세션 한정 주소는 다음 접속에 깨진다 */
  const mu=(typeof mediaUrl==='function')? mediaUrl() : '';
  if(th && mu && th.indexOf(mu)===0) th='';                            /* 저장소 직접 주소(옛 방식)는 이름이 틀릴 수 있어 다시 찾는다 */
  if(!th && id){ const c=heroCacheGet(id); if(c) th=c; }               /* V6.0.6: 이 폰에 저장해 둔 대표사진 → 바로 표시 */
  applyRepDraw(th);
}
function applyRepDraw(th){
  if(!th && S.rep && S.rep.id) repFetch();   /* V6.0.6: 앨범 정보 도착 전엔 기다렸다가 맞는 저장소에서 */
  [['abImg','abPaw'],['hpImg','hpPaw']].forEach(function(pair){
    const img=document.getElementById(pair[0]), paw=document.getElementById(pair[1]);
    if(!img) return;
    if(th){ img.src=th; img.style.display='block'; if(paw) paw.style.display='none'; }
    else{ img.style.display='none'; if(paw) paw.style.display='inline'; }
  });
  try{ heroSync(th); }catch(e){}
}
function nearestEvent(){
  if(!S.profile.birth) return null;
  const now=new Date(); now.setHours(0,0,0,0);
  const tk=todayKey(); const to=addD(now,90);
  /* V5.7: 접종 지연 우선 표시 제거 — 배너는 구충·마일스톤·내 일정 기준으로만 */
  let evs=autoEventsRange(now,to).filter(function(e){ return e.cls==='a' && e.t.indexOf('보상')===-1; });
  (S.events||[]).forEach(function(e){ if(e.d>=tk) evs.push({d:e.d, t:e.t, cls:'u'}); });
  evs.sort(function(a,b2){ return a.d.localeCompare(b2.d); });
  return evs.length ? {d:evs[0].d, t:evs[0].t, late:false} : null;
}
function renderDday(){
  const el=document.getElementById('ddayBanner'); if(!el) return;
  const ev=nearestEvent();
  if(!ev){ el.className=''; return; }
  const now=new Date(); now.setHours(0,0,0,0);
  const dd=Math.round((new Date(ev.d+'T00:00:00')-now)/86400000);
  document.getElementById('ddNum').textContent = ev.late ? '지연' : (dd===0 ? 'D-DAY' : 'D-'+dd);
  document.getElementById('ddTitle').textContent = ev.t;
  document.getElementById('ddDate').textContent = ev.d.slice(5).replace('-','/') + (ev.late ? ' — 병원 예약이 필요합니다' : '');
  el.className = 'vis' + (ev.late ? ' late' : (dd<=1 ? ' urgent' : ''));
}
function renderHomeNotice(){
  const el=document.getElementById('homeNotice'); if(!el) return;
  const list=S.ntc||[];
  if(!list.length){
    el.innerHTML='';   /* V6: 공지가 없으면 홈에 아무것도 두지 않는다 */
  }else{
    const n=list[0]; const me=myName();
    const mine = me && n.by===me;
    const needAck = !mine && !(me && n.ack && n.ack[me]);
    el.innerHTML='<div class="hn"><div class="h"><span>📢 '+esc(n.by||'공지')+' · '+(n.ed? '✏️ '+ntcFmt(n.ed) : ntcFmt(n.at))+'</span>'
      +(needAck?'<button class="btn sm" id="hnAck" type="button">✓ 확인</button>':'<button class="btn sm ghost" id="hnEdit" type="button">게시판 '+list.length+'건</button>')
      +'</div><div class="b">'+esc(n.text)+'</div>'
      +'<div class="m">'+ntcAckLine(n)+'</div></div>';
  }
  const e1=document.getElementById('hnEdit'); if(e1) e1.addEventListener('click', function(){ goTab('notice'); });
  const e3=document.getElementById('hnAck'); if(e3) e3.addEventListener('click', function(){ if(S.ntc&&S.ntc[0]) ntcAck(S.ntc[0].id); });
}
function renderHomeWt(){
  const el=document.getElementById('homeWt'); if(!el) return;
  const lw=latestWeight();
  if(lw){ el.style.display='inline-flex'; el.textContent=lw.kg+'kg'; el.title=lw.d.slice(5).replace('-','/')+' 기록 · 눌러서 체중 입력'; }
  else{ el.style.display='none'; }
}
/* V5: 대변 양 (소/중/대) — 방금 기록에 선택 부여, 미선택 시 '중' */
const QL_AMT_NM={s:'소', m:'중', l:'대'};
let POO_AMT_T=null;
function pooAmtAsk(){
  const el=document.getElementById('pooAmt'); if(!el) return;
  el.innerHTML='<span>💩 양은?</span><button type="button" data-pa="s">소</button><button type="button" data-pa="m">중</button><button type="button" data-pa="l">대</button><span style="font-weight:400;" class="muted small">안 누르면 \'중\'</span>';
  el.style.display='flex';
  clearTimeout(POO_AMT_T);
  POO_AMT_T=setTimeout(function(){ el.style.display='none'; }, 12000);
}
function bindPooAmt(){
  const el=document.getElementById('pooAmt'); if(!el) return;
  el.addEventListener('click', function(e){
    const b=e.target.closest('button[data-pa]'); if(!b) return;
    const q=qlNorm(todayKey());
    if(q.poo.length){
      const last=String(q.poo[q.poo.length-1]||'');
      q.poo[q.poo.length-1]=last.split('|')[0]+'|'+b.dataset.pa;
      saveState();
    }
    el.style.display='none'; clearTimeout(POO_AMT_T);
    renderQlog();
  });
}
function renderAppbar(){
  const nm=document.getElementById('abName'), sb=document.getElementById('abSub');
  if(!nm) return;
  nm.textContent=S.profile.name||'빼꼼';
  if(S.profile.birth){
    const b=new Date(S.profile.birth+'T00:00:00');
    const days=Math.max(0, Math.floor((new Date()-b)/86400000));
    const mo=Math.floor(days/30.44);
    let t='생후 '+mo+'개월';
    if(S.profile.home){
      const h=new Date(S.profile.home+'T00:00:00');
      const dn=Math.max(0, Math.floor((new Date()-h)/86400000));
      t+=' · 함께 D+'+dn;
    }
    sb.textContent=t;
  }else{
    sb.textContent='설정에서 생년월일 입력';
  }
  applyRep();
}
function renderDash(){ renderAppbar(); renderHomeWt(); renderDday(); renderHomeNotice(); renderQlog(); }


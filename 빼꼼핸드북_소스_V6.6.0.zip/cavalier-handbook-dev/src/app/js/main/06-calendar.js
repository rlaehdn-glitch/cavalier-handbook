/* =============== 관리 달력 (정비 알림) =============== */
let calY=(new Date()).getFullYear(), calM=(new Date()).getMonth(), calSel=todayKey();
/* 계약서 명시 2차 접종 예정일. 병원에서 일정이 바뀌면 이 값만 고치면 3~7차가 함께 밀립니다. */
const VAX_ANCHOR='2026-08-02';
const VAX_PLAN=[
 {id:'v1', seq:1, wk:7,  t:'접종 1차 (종합) — 켄넬 완료'},
 {id:'v2', seq:2, wk:9,  t:'접종 2차 (종합+코로나)'},
 {id:'v3', seq:3, wk:11, t:'접종 3차 (종합+코로나)'},  /* V5.8: 실제 기록(08.21) 반영 — 코로나 2차였음, 켄넬코프 아님 */
 {id:'v4', seq:4, wk:13, t:'접종 4차 (종합)'},         /* V5.8: 켄넬코프 병행 여부 미확정 → 종합만 표기 */
 {id:'v5', seq:5, wk:15, t:'접종 5차 (종합+인플루)'},
 {id:'v6', seq:6, wk:17, t:'접종 6차 (인플루+광견병)'},
 {id:'v7', seq:7, wk:19, t:'항체가 검사'}
];
/* 입양일 기준 이벤트 */
const HOME_EVENTS=[[15,'★ 분양 보상기간(15일) 만료 — 바크바크 계약']];
const MILESTONES=[[98,'사회화 골든타임 마감 (14주)'],[183,'중성화 상담 권장 시점 (6개월)'],[304,'성견 사료 전환 검토 (10개월)']];
function d2s(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function addD(base,n){const d=new Date(base.getTime()); d.setDate(d.getDate()+n); return d;}
function autoEventsRange(from,to){
  const out=[]; const tk=todayKey();
  const b=S.profile.birth? new Date(S.profile.birth+'T00:00:00') : null;
  if(!b) return out;
  VAX_PLAN.forEach(v=>{
    const st=S.vax[v.id]||{};
    if(st.done){ if(st.date){ const dd=new Date(st.date+'T00:00:00'); if(dd>=from&&dd<=to) out.push({d:d2s(dd), t:v.t+' — 완료', cls:'d'}); } }
    /* V5.7: 미완료 접종의 자동 '예정/지연' 이벤트 생성 중단 — 실제 병원 예약은 '내 일정'으로 관리, 완료 체크 시에만 달력에 기록 */
  });
  const hw=S.vax.v8||{};
  const anchor = hw.date? parseInt(hw.date.slice(8,10),10) : (S.profile.home? parseInt(S.profile.home.slice(8,10),10) : b.getDate());
  const hwStart=addD(b,56);
  let cur=new Date(from.getFullYear(), from.getMonth(), 1);
  while(cur<=to){
    const dim=new Date(cur.getFullYear(),cur.getMonth()+1,0).getDate();
    const dd=new Date(cur.getFullYear(),cur.getMonth(),Math.min(anchor,dim));
    if(dd>=from&&dd<=to&&dd>=hwStart) out.push({d:d2s(dd), t:'심장사상충·구충 예방일', cls:'a'});
    cur=new Date(cur.getFullYear(),cur.getMonth()+1,1);
  }
  MILESTONES.forEach(ms=>{ const dd=addD(b,ms[0]); if(dd>=from&&dd<=to) out.push({d:d2s(dd), t:ms[1], cls:'a'}); });
  if(S.profile.home){
    const hb=new Date(S.profile.home+'T00:00:00');
    HOME_EVENTS.forEach(function(ev){ const dd=addD(hb,ev[0]); if(dd>=from&&dd<=to) out.push({d:d2s(dd), t:ev[1], cls:'a'}); });
  }
  for(let age=1; age<=20; age++){
    const bd=new Date(b.getFullYear()+age, b.getMonth(), b.getDate());
    if(bd>=from&&bd<=to) out.push({d:d2s(bd), t:age+'번째 생일 — 연간검진·심장청진·보강접종', cls:'a'});
  }
  return out;
}
function eventsForMonth(y,m){
  const from=new Date(y,m,1), to=new Date(y,m,new Date(y,m+1,0).getDate(),23,59,59);
  const evs=autoEventsRange(from,to);
  const mk=y+'-'+String(m+1).padStart(2,'0');
  (S.events||[]).forEach(function(e,i){
    if(!e.d) return;
    const base=new Date(e.d+'T00:00:00');
    const push=function(ds){ evs.push({d:ds, t:e.t, cls:'u', idx:i, c:e.c||'', tm:e.tm||'', rep:e.rep||''}); };
    if(!e.rep){ if(e.d.slice(0,7)===mk) push(e.d); return; }
    if(base>to) return;
    if(e.rep==='w'){
      let cur=new Date(Math.max(base.getTime(), from.getTime()));
      const wd=base.getDay();
      cur.setDate(cur.getDate()+((wd-cur.getDay())+7)%7);
      while(cur<=to){ if(cur>=base) push(d2s(cur)); cur=addD(cur,7); }
    }else if(e.rep==='m'){
      const dim=new Date(y,m+1,0).getDate();
      const dd=new Date(y,m,Math.min(base.getDate(),dim));
      if(dd>=base && dd<=to) push(d2s(dd));
    }
  });
  /* V6: 유치원 다녀온 날 */
  Object.keys(S.kgLog||{}).forEach(function(k){ if(k.slice(0,7)!==mk) return; (S.kgLog[k]||[]).forEach(function(s){ evs.push({d:k, t:kgName()+' '+fmtHM(s.o)+'–'+fmtHM(s.i)+' · '+fmtDur(s.i-s.o)+(s.f? ' · 식사 '+s.f : '')+(s.m? ' · '+s.m : ''), cls:'k'}); }); });
  return evs;
}
function renderCal(){
  const dowEl=document.getElementById('calDow'); if(!dowEl) return;
  dowEl.innerHTML=['일','월','화','수','목','금','토'].map(function(d,i){return '<div class="cal-dow'+(i===0?' sun':'')+'">'+d+'</div>';}).join('');
  document.getElementById('calTitle').textContent=calY+'년 '+(calM+1)+'월';
  const evs=eventsForMonth(calY,calM);
  const byDay={}; evs.forEach(e=>{ (byDay[e.d]=byDay[e.d]||[]).push(e); });
  const first=new Date(calY,calM,1).getDay(), dim=new Date(calY,calM+1,0).getDate();
  let html='';
  for(let i=0;i<first;i++) html+='<div class="cal-cell empty"></div>';
  const tk=todayKey();
  for(let d=1; d<=dim; d++){
    const ds=calY+'-'+String(calM+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');
    const dow=(first+d-1)%7;
    const cls=['cal-cell']; if(dow===0)cls.push('sun'); if(ds===tk)cls.push('today'); if(ds===calSel)cls.push('sel');
    const dots=(byDay[ds]||[]).slice(0,4).map(e=>'<span class="dot '+e.cls+'"></span>').join('')+(typeof wgCalDot==='function'? wgCalDot(ds) : '')+(typeof bathCalDot==='function'? bathCalDot(ds) : '');   /* V6.3 · V6.4 */
    html+='<div class="'+cls.join(' ')+'" data-d="'+ds+'"><span class="dn">'+d+'</span><div class="dots">'+dots+'</div></div>';
  }
  const grid=document.getElementById('calGrid');
  grid.innerHTML=html;
  grid.querySelectorAll('.cal-cell[data-d]').forEach(c=>c.addEventListener('click',function(){ calSel=this.dataset.d; renderCal(); }));
  renderSel(byDay); renderUpcoming();
}
function renderSel(byDay){
  const t=document.getElementById('selTitle'), box=document.getElementById('selEvents');
  const p=calSel.split('-');
  const dt=new Date(parseInt(p[0],10), parseInt(p[1],10)-1, parseInt(p[2],10));
  t.textContent=parseInt(p[1],10)+'월 '+parseInt(p[2],10)+'일 ('+['일','월','화','수','목','금','토'][dt.getDay()]+')';
  const evs=(byDay&&byDay[calSel])||[];
  const TAGN={a:'알림',l:'지연',d:'완료',u:'내 일정',k:'유치원'};
  const CATI={h:'🏥',g:'✂️',s:'🏫',b:'🎂',o:'📌'};
  box.innerHTML=evs.length? evs.map(function(e){
    let left='<span class="ev-tag '+e.cls+'">'+TAGN[e.cls]+'</span> ';
    if(e.cls==='u'){
      left+=(CATI[e.c]||'📌')+' '+(e.tm? '<strong>'+esc(e.tm)+'</strong> ':'')+esc(e.t)+(e.rep? ' <span class="muted small">('+(e.rep==='w'?'매주':'매월')+')</span>':'');
    }else{
      left+=esc(e.t);
    }
    let right='';
    if(e.cls==='u') right='<button class="del" data-i="'+e.idx+'" aria-label="삭제">✕</button>';
    if(e.vid && (e.cls==='a'||e.cls==='l')) right='<button class="btn sm" data-vx="'+e.vid+'">✓ 완료</button>';
    return '<div class="ev-row"><span>'+left+'</span>'+right+'</div>';
  }).join('') : '<p class="muted small" style="margin:6px 0;">일정 없음 — 아래에서 추가.</p>';
  box.querySelectorAll('.del').forEach(function(b){ b.addEventListener('click',async function(){
    const i=parseInt(this.dataset.i,10);
    const e=S.events[i];
    if(e && e.rep && !(await askConfirm('반복 일정입니다. 전체 반복을 삭제할까요?'))) return;
    S.events.splice(i,1); saveState(); renderCal();
  }); });
  box.querySelectorAll('[data-vx]').forEach(function(b){ b.addEventListener('click',function(){
    S.vax[this.dataset.vx]={done:true, date:calSel};
    saveState(); renderAll();
  }); });
  try{ if(typeof wgCalSel==='function') wgCalSel(calSel, box); }catch(e){ console.error(e); }   /* V6.3 */
  try{ if(typeof bathCalSel==='function') bathCalSel(calSel, box); }catch(e){ console.error(e); }   /* V6.4 */
}
function renderUpcoming(){
  const el=document.getElementById('upList'); if(!el) return;
  if(!S.profile.birth){ el.innerHTML='<p class="muted small">설정에서 생년월일을 입력하면 알림이 자동 생성됩니다.</p>'; return; }
  const now=new Date(); now.setHours(0,0,0,0);
  const to=addD(now,60); const tk=todayKey(); const toS=d2s(to);
  let evs=autoEventsRange(now,to).filter(function(e){ return e.cls!=='d' && e.cls!=='l'; });
  /* V5.7: 접종 지연 자동 주입 제거 — 내 일정 기반 운영 */
  const overdue=[];
  (S.events||[]).forEach(function(e){
    if(!e.d) return;
    const base=new Date(e.d+'T00:00:00');
    const push=function(ds){ if(ds>=tk && ds<=toS) evs.push({d:ds, t:(e.tm? e.tm+' ':'')+e.t, cls:'u'}); };
    if(!e.rep){ push(e.d); return; }
    if(e.rep==='w'){
      let cur=new Date(Math.max(base.getTime(), now.getTime()));
      const wd=base.getDay();
      cur.setDate(cur.getDate()+((wd-cur.getDay())+7)%7);
      while(cur<=to){ if(cur>=base) push(d2s(cur)); cur=addD(cur,7); }
    }else if(e.rep==='m'){
      for(let k=0;k<3;k++){
        const y2=now.getFullYear(), m2=now.getMonth()+k;
        const dim=new Date(y2,m2+1,0).getDate();
        const dd=new Date(y2,m2,Math.min(base.getDate(),dim));
        if(dd>=base) push(d2s(dd));
      }
    }
  });
  evs.sort(function(a,b2){return a.d.localeCompare(b2.d);});
  const all=overdue.concat(evs).slice(0,8);
  el.innerHTML= all.length? all.map(function(e){
    const dd=Math.round((new Date(e.d+'T00:00:00')-now)/86400000);
    const dl= e.cls==='l'? '지연' : (dd===0?'오늘':'D-'+dd);
    return '<div class="up-item up-go" data-d="'+e.d+'"><span class="up-d"'+(e.cls==='l'?' style="color:var(--red);"':'')+'>'+dl+'</span><span>'+esc(e.t)+' <span class="muted small">('+e.d.slice(5)+')</span></span></div>';
  }).join('') : '<p class="muted small">향후 60일 내 알림 없음.</p>';
  el.querySelectorAll('.up-go').forEach(function(r){ r.addEventListener('click',function(){ goCalDate(this.dataset.d); }); });
}
function bindCal(){
  const p=document.getElementById('calPrev'); if(!p) return;
  p.addEventListener('click',function(){ calM--; if(calM<0){calM=11;calY--;} renderCal(); animCal(); });
  document.getElementById('calNext').addEventListener('click',function(){ calM++; if(calM>11){calM=0;calY++;} renderCal(); animCal(); });
  document.getElementById('calToday').addEventListener('click',function(){ const n=new Date(); calY=n.getFullYear(); calM=n.getMonth(); calSel=todayKey(); renderCal(); animCal(); });
  document.getElementById('cvAdd').addEventListener('click',function(){
    const v=document.getElementById('cvTitle').value.trim();
    if(!v){ alert('일정 내용을 입력하세요.'); return; }
    if(!S.events) S.events=[];
    S.events.push({d:calSel, t:v, c:document.getElementById('cvCat').value, tm:document.getElementById('cvTime').value, rep:document.getElementById('cvRep').value});
    document.getElementById('cvTitle').value='';
    document.getElementById('cvTime').value='';
    document.getElementById('cvRep').value='';
    saveState(); renderCal();
  });
}

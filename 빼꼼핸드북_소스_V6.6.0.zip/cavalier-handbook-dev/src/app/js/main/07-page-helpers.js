/* =============== 페이지 이동 (이전 장 / 다음 장) =============== */
const TAB_ORDER=[['prep','01 분양 준비'],['health','02 건강·병원'],['money','03 보험·비용'],['food','04 사료·간식'],['walk','05 산책·훈련·짖음'],['work','06 직장인 플랜'],['neuter','07 중성화'],['shop','09 구매 가이드'],['place','10 삼송 동네 가이드'],['emerg','11 응급 대처'],['behav','12 행동 사전'],['life','13 생활·계절·법규'],['index','14 인덱스·자료실']];
function buildPagers(){
  TAB_ORDER.forEach(function(tb,i){
    const sec=document.getElementById('tab-'+tb[0]); if(!sec) return;
    const div=document.createElement('div'); div.className='pager';
    const prev=i>0?TAB_ORDER[i-1]:null, next=i<TAB_ORDER.length-1?TAB_ORDER[i+1]:null;
    div.innerHTML=(prev?'<button class="pg" data-go="'+prev[0]+'">← '+prev[1]+'</button>':'<span></span>')
                 +(next?'<button class="pg" data-go="'+next[0]+'">'+next[1]+' →</button>':'<span></span>');
    div.querySelectorAll('.pg').forEach(function(bt){ bt.addEventListener('click',function(){ goTab(this.dataset.go); }); });
    sec.appendChild(div);
  });
}
/* =============== 구매·지도 링크 빌더 =============== */
function buildLinks(){
  const map={c:'https://search.naver.com/search.naver?query=', n:'https://search.naver.com/search.naver?query=', s:'https://search.naver.com/search.naver?query=', m:'https://map.naver.com/p/search/'};
  document.querySelectorAll('a.lnk[data-q]').forEach(function(a){
    a.href=map[a.dataset.s||'n']+encodeURIComponent(a.dataset.q);
    a.target='_blank'; a.rel='noopener';
  });
}

/* =============== 모바일 표 라벨 주입 =============== */
function mobileTables(){
  document.querySelectorAll('.tw table').forEach(function(tb){
    const heads=[].map.call(tb.querySelectorAll('thead th'), function(th){ return th.textContent.trim(); });
    tb.querySelectorAll('tbody tr').forEach(function(tr){
      [].forEach.call(tr.children, function(td,i){ td.setAttribute('data-label', heads[i]||''); });
    });
  });
}
/* =============== 스크롤 등장 애니메이션 =============== */
const REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
function initReveal(){
  const els=document.querySelectorAll('.card, .box, .tw, .trainer, .age-nav, .cal-wrap, h3.sec, ul.ck');
  els.forEach(function(el){ el.classList.add('rv'); });
  if(REDUCED || !('IntersectionObserver' in window)){ els.forEach(function(el){ el.classList.add('vis'); }); return; }
  const io=new IntersectionObserver(function(entries){
    entries.filter(function(e){ return e.isIntersecting; }).forEach(function(en,i){
      en.target.style.transitionDelay=Math.min(i*60,240)+'ms';
      en.target.classList.add('vis');
      io.unobserve(en.target);
      setTimeout(function(){ en.target.style.transitionDelay=''; }, 800);
    });
  }, {threshold:.08, rootMargin:'0px 0px -6% 0px'});
  els.forEach(function(el){ io.observe(el); });
}
/* =============== 맨 위로 버튼 =============== */
function initTopBtn(){
  const b=document.createElement('button');
  b.id='topBtn'; b.setAttribute('aria-label','맨 위로'); b.textContent='↑';
  document.body.appendChild(b);
  window.addEventListener('scroll', function(){ b.classList.toggle('show', window.scrollY>500); }, {passive:true});
  b.addEventListener('click', function(){ window.scrollTo({top:0, behavior: REDUCED?'auto':'smooth'}); });
}
/* =============== 달력 전환 애니메이션 =============== */
function animCal(){
  if(REDUCED) return;
  const g=document.getElementById('calGrid'); if(!g) return;
  g.classList.remove('cal-anim'); void g.offsetWidth; g.classList.add('cal-anim');
}


/* =============== V6: 공통 UI — 시트 · 알림 · 토스트 =============== */
const UI={res:null};
function uiSheetOpen(o){
  return new Promise(function(resolve){
    const ov=document.getElementById('uiSheet'); if(!ov){ resolve({ok:false}); return; }
    if(UI.res){ const pr=UI.res; UI.res=null; try{ pr({ok:false}); }catch(e){} }
    UI.res=resolve;
    ov.classList.toggle('center', !!o.center);
    document.getElementById('uiT').textContent=o.title||'';
    const m=document.getElementById('uiM'); m.textContent=o.msg||''; m.style.display=o.msg? '' : 'none';
    const inp=document.getElementById('uiIn'); inp.style.display=o.input? '' : 'none';
    if(o.input){ inp.value=o.value||''; inp.placeholder=o.ph||''; }
    const acts=document.getElementById('uiActs'); acts.innerHTML=''; acts.classList.toggle('list', !!o.list);
    (o.actions||[]).forEach(function(a, idx){
      const b=document.createElement('button'); b.type='button';
      b.className='sh-b1'+(a.destr? ' destr' : '');
      b.textContent=a.label; if(a.disabled) b.disabled=true;
      b.addEventListener('click', function(){ uiSheetClose({ok:true, idx:idx, value:inp.value}); });
      acts.appendChild(b);
    });
    const no=document.getElementById('uiNo'); no.textContent=o.cancel||'취소'; no.style.display=o.noCancel? 'none' : '';
    ov.classList.add('on');
    if(o.input) setTimeout(function(){ try{ inp.focus(); }catch(e){} }, 80);
  });
}
function uiSheetClose(r){
  const ov=document.getElementById('uiSheet'); if(ov) ov.classList.remove('on');
  const f=UI.res; UI.res=null; if(f) f(r||{ok:false});
}
function uiConfirm(o){
  if(typeof o==='string') o={msg:o};
  return uiSheetOpen({title:o.title||'', msg:o.msg||'', actions:[{label:o.ok||'확인', destr:!!o.destr}], cancel:o.cancel||'취소'})
    .then(function(r){ return !!(r && r.ok); });
}
function uiAlert(msg){ return uiSheetOpen({center:true, msg:String(msg==null? '' : msg), actions:[{label:'확인'}], noCancel:true}); }
function uiPrompt(title, val){
  return uiSheetOpen({title:title, input:true, value:val, actions:[{label:'저장'}], cancel:'취소'})
    .then(function(r){ return (r && r.ok)? String(r.value||'') : null; });
}
function uiActions(title, items){
  return uiSheetOpen({title:title||'', list:true, actions:items}).then(function(r){ return (r && r.ok)? r.idx : -1; });
}
const TOAST={t:null, fn:null};
function uiToast(msg, undoFn){
  const el=document.getElementById('uiToast'); if(!el) return;
  document.getElementById('uiToastT').textContent=msg;
  const u=document.getElementById('uiToastU'); u.style.display=undoFn? '' : 'none';
  TOAST.fn=undoFn||null;
  el.classList.add('on'); clearTimeout(TOAST.t);
  TOAST.t=setTimeout(function(){ el.classList.remove('on'); TOAST.fn=null; }, undoFn? 5000 : 2600);
}
/* V6.6: 확인창 한 벌 — 예전 confirm() 문구 규칙 그대로(삭제 / 기록 취소 / 계속 · 닫기). 기다렸다가 true/false */
function askConfirm(msg){
  const m=String(msg==null? '' : msg);
  const destr=/삭제|지웁|취소할까요/.test(m);
  const okL=/삭제/.test(m)? '삭제' : (/취소할까요/.test(m)? '기록 취소' : '계속');
  return uiSheetOpen({msg:m, actions:[{label:okL, destr:destr}], cancel:'닫기'}).then(function(r){ return !!(r && r.ok); });
}
function v6SheetOpen(){ return !!document.querySelector('.sheet-ovl.on, #qeOvl.on, #wtOvl.on'); }   /* V6.6: 빠른 수정·체중 시트가 열린 동안에도 다시 그리지 않음(고치던 줄이 밀리지 않게) */

/* 브라우저 기본 알림창 → 앱 안 시트. 확인은 askConfirm, 입력은 uiPrompt만 쓴다(기본 confirm()·prompt()는 구조 검사가 0개로 지킴).
   V6.6: 예전 confirm() 가로채기(탭을 한 번 더 재생하던 방식)는 호출이 0개가 되어 삭제 */
window.alert=function(msg){ uiAlert(msg); };

/* =============== V6: 시간 표기 =============== */
function fmtClock(ms){ const m=Math.max(0, Math.round(ms/60000)); return Math.floor(m/60)+':'+String(m%60).padStart(2,'0'); }
function sumSegs(arr){ let m=0; (arr||[]).forEach(function(s){ m+=Math.max(0, s.i-s.o); }); return m; }


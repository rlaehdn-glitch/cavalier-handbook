/* =============== Tabs =============== */
/* goTab v2는 아래 V2 블록에 정의됨 */

/* =============== 월령 스테이지 =============== */
const STAGES = [
 {min:0, max:7, name:'가정 대기기 (생후 8주 미만)', tasks:['아직 모견 곁에 있어야 할 시기 — 8주 미만 인도는 거절(01장)','용품 준비·집 안전화·브리더 검증 체크리스트 진행','단골 병원·24시 병원 정해서 설정에 저장']},
 {min:8, max:11, name:'적응 · 1차 접종기 (2~3개월)', tasks:['데려온 지 3일 내 첫 건강검진(분변 포함)','이상 없으면 그 주에 펫보험 가입 완료(03장 — 타이밍이 전부)','접종 스케줄 개시(02장 표에 날짜 기록)','배변·크레이트 훈련 시작, 밥·잠 시간 고정','실내 사회화(소리 둔감화) + 안고 나가는 구경 산책','짧은 단독 시간 연습 시작 — 같은 집 다른 방부터(06장)','낮 케어 계획 가동(연차·가족·펫시터) — 월령+1시간 룰']},
 {min:12, max:15, name:'사회화 골든타임 막바지 (3~4개월)', tasks:['사회화 체크리스트 집중 소화(05장) — 14주 전이 가장 효율 높음','접종 이어가기 + 이름 반응·앉아 완성','출근 신호 둔감화 훈련(열쇠·신발) 병행','동물등록(2개월 이상 의무) 완료 확인']},
 {min:16, max:25, name:'이갈이 · 기초 훈련기 (4~6개월)', tasks:['접종 완료 + 항체가검사 → 본격 바닥 산책 개시','산책량 = 월령×5분×2회 (예: 5개월=25분씩)','이갈이 입질 대응(05장) — 손 무는 습관 여기서 결정','기본 명령어 8종 진도 나가기(05장 체크리스트)','유치원 등원 검토(접종 완료 후) — 사회화+낮 공백 해소','6개월 검진 때 중성화 시기 상담 — 첫 발정 전 목표(07장)']},
 {min:26, max:39, name:'사춘기 · 발정/중성화 검토기 (6~9개월)', tasks:['중성화 실행 창 — 첫 발정 전 목표, 주치의와 확정(발정이 먼저 오면 종료 후 2~3개월 뒤로)','"말 안 듣는 시기" 정상 — 규칙을 바꾸지 말고 버티기','단독 시간 계단식 확장 계속(06장 5단계)','중성화 후 급여량 10~20% 조정 상담(04장)']},
 {min:40, max:51, name:'성견 전환기 (9~12개월)', tasks:['성견 사료 전환 상담(10~12개월, 7일 교체법)','산책 성견 수준(하루 40~60분)으로 확대','평일 타임테이블(06장) 완전 정착']},
 {min:52, max:99999, name:'성견기 (12개월~)', tasks:['매년: 보강접종 + 심장 청진 검진 — 카발리에 관리의 핵심(02장)','매월: 심장사상충 예방 + 체중 기록(08장)','가끔 잘 때 호흡수 세기(분당 30회 미만이 대체적 정상 기준)','주말에도 짧은 단독 시간 유지 — 월요일 격차 방지','7세부터 연 1~2회 심화 검진으로 상향']}
];
/* 계약서 기준 초기값 — 비어 있는 항목만 채웁니다 */
const CONTRACT={name:'빼꼼', birth:'2026-05-20', home:'2026-07-25', reg:'410160013217268'};
function seedProfile(){
  let ch=false;
  ['name','birth','home','reg'].forEach(function(k){
    if(!S.profile[k]){ S.profile[k]=CONTRACT[k]; ch=true; }
  });
  if(S._seed!==1){ if(!S.vax.v1) S.vax.v1={}; S.vax.v1.done=true; S._seed=1; ch=true; }
  /* V6.1: 전/후 비교 기준일 — 한 번만 등록(지워도 다시 생기지 않음). 고정 id라 두 폰이 같이 등록해도 하나로 합쳐짐 */
  if(S._mk!==1){
    if(!S.marks || typeof S.marks!=='object' || Array.isArray(S.marks)) S.marks={};
    if(!S.marks['m-meal3']) S.marks['m-meal3']={t:'하루 3끼 전환', s:'2026-09-14'};
    if(!S.marks['m-orijen']) S.marks['m-orijen']={t:'사료 교체 (오리젠)', s:'2026-09-23', e:'2026-10-02'};
    S._mk=1; ch=true;
  }
  /* V5.2: 시드는 사용자 편집이 아니므로 _at을 찍지 않는다 —
     캐시 삭제 후 빈 상태가 "최신"으로 둔갑해 서버 기록을 못 받아오거나 덮어쓰는 사고 방지 */
  if(ch) persistLocal();
}
function renderHome(){
  const nameEl=document.getElementById('homeName'), ageEl=document.getElementById('homeAge'),
        stEl=document.getElementById('homeStage'), tkEl=document.getElementById('stageTasks');
  if(!nameEl || !ageEl) return;
  nameEl.textContent = S.profile.name ? S.profile.name : '이름 미등록';
  if(!S.profile.birth){ ageEl.textContent='설정에서 생년월일을 입력하세요'; if(stEl) stEl.textContent='이번 단계'; if(tkEl) tkEl.innerHTML=''; return; }
  const b=new Date(S.profile.birth+'T00:00:00'), now=new Date();
  const days=Math.max(0, Math.floor((now-b)/86400000));
  const weeks=Math.floor(days/7);
  let t='생후 '+weeks+'주';
  if(S.profile.home){ const dn=Math.max(0, Math.floor((now-new Date(S.profile.home+'T00:00:00'))/86400000)); t+=' · 함께 D+'+dn; }
  ageEl.textContent=t;
  const st = STAGES.find(s=>weeks>=s.min && weeks<=s.max) || STAGES[STAGES.length-1];
  if(stEl) stEl.textContent=st.name;
  if(tkEl) tkEl.innerHTML='<ul class="ls">'+st.tasks.map(x=>'<li>'+x+'</li>').join('')+'</ul>';
}

/* =============== 일일 루틴 =============== */
const DAILY_ITEMS=['아침 산책 + 배변','아침 급여 + 물 교체','출근 전 노즈워크·콩 세팅 (부재 준비)','저녁 산책 + 배변','저녁 급여','훈련 5~10분 (명령어 1개)','빗질·몸 상태 확인 (귀·눈·걸음)','양치'];
function renderDaily(){
  const ul=document.getElementById('dailyList');
  if(!ul) return;
  const key=todayKey();
  const st=S.daily[key]||{};
  document.getElementById('dailyDate').textContent=key+' (오늘)';
  ul.innerHTML=DAILY_ITEMS.map((t,i)=>{
    const c=st['i'+i]?'checked':''; const d=st['i'+i]?'done':'';
    return '<li><input type="checkbox" id="d'+i+'" '+c+'><label for="d'+i+'" class="'+d+'">'+t+'</label></li>';
  }).join('');
  DAILY_ITEMS.forEach((t,i)=>{
    document.getElementById('d'+i).addEventListener('change', e=>{
      if(!S.daily[key]) S.daily[key]={};
      S.daily[key]['i'+i]=e.target.checked;
      saveState(); renderDaily();
    });
  });
  const n=DAILY_ITEMS.filter((t,i)=>st['i'+i]).length;
  document.getElementById('dailyCount').textContent=n+' / '+DAILY_ITEMS.length;
  document.getElementById('dailyBar').style.width=Math.round(n/DAILY_ITEMS.length*100)+'%';
}

/* =============== 범용 체크리스트 (준비·사회화·명령어) =============== */
function bindChecklists(){
  document.querySelectorAll('ul.ck[data-store]').forEach(ul=>{
    ul.querySelectorAll('input[type=checkbox]').forEach(cb=>{
      const key=ul.dataset.store+':'+cb.id;
      if(S.checks[key]) { cb.checked=true; const lb=ul.querySelector('label[for="'+cb.id+'"]'); if(lb) lb.classList.add('done'); }
      cb.addEventListener('change', ()=>{
        S.checks[key]=cb.checked; if(!cb.checked) delete S.checks[key];
        const lb=ul.querySelector('label[for="'+cb.id+'"]'); if(lb) lb.classList.toggle('done', cb.checked);
        saveState();
      });
    });
  });
}

/* =============== 접종 표 =============== */
function bindVax(){
  document.querySelectorAll('#vaxTable tr[data-vx]').forEach(tr=>{
    const id=tr.dataset.vx, done=tr.querySelector('.vx-done'), date=tr.querySelector('.vx-date');
    const v=S.vax[id]||{};
    done.checked=!!v.done; if(v.date) date.value=v.date;
    const upd=()=>{ S.vax[id]={done:done.checked, date:date.value}; saveState(); renderCal(); };
    done.addEventListener('change',upd); date.addEventListener('change',upd);
  });
}

/* =============== 프로필·병원 메모 =============== */
function bindProfile(){
  const map={pfName:'name', pfBirth:'birth', pfHome:'home', pfReg:'reg'};
  Object.keys(map).forEach(id=>{
    const el=document.getElementById(id);
    el.value=S.profile[map[id]]||'';
    el.addEventListener('input', ()=>{ S.profile[map[id]]=el.value; saveState(); renderHome(); renderCal(); });
  });
  const vm=document.getElementById('vetMain'), v2=document.getElementById('vet24');
  vm.value=S.vet.main||''; v2.value=S.vet.e24||'';
  vm.addEventListener('input',()=>{S.vet.main=vm.value; saveState();});
  v2.addEventListener('input',()=>{S.vet.e24=v2.value; saveState();});
}


/* =============== 체중 =============== */
function renderWeight(){
  const list=document.getElementById('wList'), svg=document.getElementById('wChart');
  const data=[...S.weight].sort((a,b)=>a.d.localeCompare(b.d));
  list.innerHTML = data.length? data.slice().reverse().map((w,ri)=>{
    const i=data.length-1-ri;
    return '<div class="log-item"><span>'+esc(w.d)+' — <strong>'+esc(w.kg)+'kg</strong></span><button class="del" data-i="'+i+'" aria-label="삭제">✕</button></div>';
  }).join('') : '<p class="muted small" style="margin-top:8px;">아직 기록이 없습니다. 첫 검진 때 잰 체중부터 입력해보세요.</p>';
  list.querySelectorAll('.del').forEach(b=>b.addEventListener('click',()=>{ 
    const sorted=[...S.weight].sort((a,b)=>a.d.localeCompare(b.d));
    const target=sorted[parseInt(b.dataset.i)];
    S.weight=S.weight.filter(w=>w!==target);
    saveState(); afterWeight();
  }));
  /* V6.1: 날짜 간격 축 · 테마 색 · 실제 폭 기준 글자 — 통계 화면과 같은 그리기 */
  try{ stDrawWt(svg, {all:true, h:180}); }catch(e){ console.error(e); }
}
function bindWeight(){
  document.getElementById('wDate').value=todayKey();
  document.getElementById('wAdd').addEventListener('click',()=>{
    const d=document.getElementById('wDate').value, kg=document.getElementById('wKg').value;
    if(!d||!kg){ alert('날짜와 체중을 입력하세요.'); return; }
    const v=Math.round(parseFloat(String(kg).replace(',','.'))*100)/100;   /* V5.16: 0.01kg 단위 */
    if(!(v>0.2 && v<30)){ alert('0.2~30 사이 숫자를 입력하세요.'); return; }
    S.weight=S.weight.filter(w=>w.d!==d);
    S.weight.push({d, kg:String(v)});
    document.getElementById('wKg').value='';
    saveState(); afterWeight();
  });
}
/* V5.16: 체중이 바뀌면 그래프·홈 체중·급여 권장량을 함께 갱신 */
function afterWeight(){ renderWeight(); try{ renderQlog(); renderHomeWt(); renderFeed(); renderMealGap(); }catch(e){} }

/* =============== 병원 방문 =============== */
function renderVisits(){
  const el=document.getElementById('vList');
  const data=[...S.visits].sort((a,b)=>b.d.localeCompare(a.d));
  el.innerHTML=data.length? data.map((v)=>{
    const idx=S.visits.indexOf(v);
    return '<div class="log-item"><span><strong>'+esc(v.d)+'</strong> · <span class="tag">'+esc(v.t)+'</span> '+esc(v.m)+'</span><button class="del" data-i="'+idx+'" aria-label="삭제">✕</button></div>';
  }).join('') : '<p class="muted small" style="margin-top:8px;">기록이 없습니다.</p>';
  el.querySelectorAll('.del').forEach(b=>b.addEventListener('click',()=>{ S.visits.splice(parseInt(b.dataset.i),1); saveState(); renderVisits(); }));
}
function bindVisits(){
  document.getElementById('vDate').value=todayKey();
  document.getElementById('vAdd').addEventListener('click',()=>{
    const d=document.getElementById('vDate').value, t=document.getElementById('vType').value, m=document.getElementById('vMemo').value.trim();
    if(!d){ alert('날짜를 입력하세요.'); return; }
    S.visits.push({d,t,m}); document.getElementById('vMemo').value='';
    saveState(); renderVisits();
  });
}

/* =============== 지출 =============== */
function renderExpenses(){
  const el=document.getElementById('eList');
  const data=[...S.expenses].sort((a,b)=>b.d.localeCompare(a.d));
  el.innerHTML=data.length? data.slice(0,50).map((v)=>{
    const idx=S.expenses.indexOf(v);
    return '<div class="log-item"><span><strong>'+esc(v.d)+'</strong> · <span class="tag y">'+esc(v.c)+'</span> '+Number(v.a).toLocaleString()+'원 <span class="muted small">'+esc(v.m||'')+'</span></span><button class="del" data-i="'+idx+'" aria-label="삭제">✕</button></div>';
  }).join('') : '<p class="muted small" style="margin-top:8px;">기록이 없습니다.</p>';
  el.querySelectorAll('.del').forEach(b=>b.addEventListener('click',()=>{ S.expenses.splice(parseInt(b.dataset.i),1); saveState(); renderExpenses(); }));
  const ym=todayKey().slice(0,7);
  const tot=S.expenses.filter(e=>e.d && e.d.startsWith(ym)).reduce((s,e)=>s+Number(e.a||0),0);
  document.getElementById('eMonth').textContent=tot.toLocaleString()+'원';
}
function bindExpenses(){
  document.getElementById('eDate').value=todayKey();
  document.getElementById('eAdd').addEventListener('click',()=>{
    const d=document.getElementById('eDate').value, c=document.getElementById('eCat').value,
          a=document.getElementById('eAmt').value, m=document.getElementById('eMemo').value.trim();
    if(!d||!a){ alert('날짜와 금액을 입력하세요.'); return; }
    S.expenses.push({d,c,a:Number(a),m}); document.getElementById('eAmt').value=''; document.getElementById('eMemo').value='';
    saveState(); renderExpenses();
  });
}

/* =============== 백업 =============== */
/* V6.6: 가져오기 — 텍스트 내보내기(기록 그대로)와 '전체 기록 파일로 저장' 파일({app, exported, data}) 둘 다 읽는다.
   기본은 '합치기'(지금 기록은 그대로, 백업에만 있는 기록을 더함). '백업 시점으로 되돌리기'는 한 번 더 확인하고,
   지우기 전에 지금 상태를 파일로 먼저 저장한다. 끝나면 5초 동안 '되돌리기'.
   (V6.5.2까지: 파일 내용을 붙여넣으면 빈 기록으로 덮어써 두 폰의 기록이 모두 지워졌다) */
const IO_KEYS=['qlog', 'weight', 'walkLog', 'sleepLog', 'awayLog', 'kgLog', 'events', 'ntc', 'visits', 'expenses', 'profile', 'bathLog'];
function ioParse(text){
  let p; try{ p=JSON.parse(String(text||'').trim()); }catch(e){ return {err:'형식이 올바르지 않습니다. 내보내기 텍스트나 백업 파일 내용을 그대로 붙여넣어 주세요.'}; }
  let at='';
  if(p && typeof p==='object' && p.app==='cavalier-handbook' && p.data && typeof p.data==='object'){ at=p.exported||''; p=p.data; }
  if(!p || typeof p!=='object' || Array.isArray(p) || !IO_KEYS.some(function(k){ return k in p; })) return {err:'빼꼼 핸드북 기록이 아닙니다. 내보내기 텍스트나 \'전체 기록 파일로 저장\' 파일을 넣어 주세요.'};
  return {data:p, at:at || (p._at? new Date(p._at).toISOString() : '')};
}
function ioCount(o){
  const n=function(v){ return Array.isArray(v)? v.length : (v && typeof v==='object')? Object.keys(v).length : 0; };
  return '빠른 기록 '+n(o.qlog)+'일 · 산책 '+n(o.walkLog)+'일 · 수면 '+n(o.sleepLog)+'일 · 체중 '+n(o.weight)+'건 · 일정 '+n(o.events)+'건';
}
function ioDownload(obj, suffix){
  const data=JSON.stringify({app:'cavalier-handbook', exported:new Date().toISOString(), data:obj}, null, 1);
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([data], {type:'application/json'}));
  a.download='빼꼼기록_'+todayKey().replace(/-/g,'')+(suffix||'')+'.json';
  document.body.appendChild(a); a.click();
  setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); }, 800);
}
async function ioImport(text){
  const r=ioParse(text); if(r.err){ uiAlert(r.err); return; }
  const when=r.at? r.at.slice(0, 16).replace('T', ' ') : '시각 정보 없음';
  const pick=await uiSheetOpen({title:'백업 가져오기', msg:'백업('+when+'): '+ioCount(r.data)+'\n\n합치기 — 지금 기록은 그대로 두고 백업에만 있는 기록을 더합니다.\n되돌리기 — 백업 시점으로 돌아갑니다. 그 뒤에 남긴 기록은 두 폰 모두에서 지워집니다.',
    actions:[{label:'합치기 (권장)'}, {label:'백업 시점으로 되돌리기', destr:true}], cancel:'취소'});
  if(!pick || !pick.ok) return;
  const before=sClone(S);
  if(pick.idx===1){
    if(!(await uiConfirm({title:'정말 되돌릴까요?', msg:'백업 이후의 기록이 두 폰 모두에서 지워집니다.\n지금 상태는 먼저 파일로 저장해 둡니다.', ok:'되돌리기', destr:true}))) return;
    try{ ioDownload(before, '_되돌리기전'); }catch(e){ logErr('가져오기: 이전 상태 저장', e); }
    S=Object.assign(sClone(DEFAULT_S), r.data);
  }else{
    S=Object.assign(sClone(DEFAULT_S), mergeStates(undefined, S, r.data));   /* 기준본 없이 합침 = 어느 쪽 기록도 지우지 않음 */
  }
  saveState(); renderAll();
  uiToast(pick.idx===1? '백업 시점으로 되돌렸어요' : '백업을 합쳤어요', function(){ S=Object.assign(sClone(DEFAULT_S), before); saveState(); renderAll(); uiToast('가져오기 전으로 되돌렸어요'); });
}
function bindIO(){
  document.getElementById('expBtn').addEventListener('click',()=>{
    document.getElementById('ioArea').value=JSON.stringify(S);
    document.getElementById('ioArea').select();
  });
  document.getElementById('impBtn').addEventListener('click',()=>{ ioImport(document.getElementById('ioArea').value); });
  const fb=document.getElementById('impFileBtn'), fi=document.getElementById('impFile');
  if(fb && fi){
    fb.addEventListener('click', function(){ fi.value=''; fi.click(); });
    fi.addEventListener('change', function(){
      const f=fi.files && fi.files[0]; if(!f) return;
      const rd=new FileReader();
      rd.onload=function(){ ioImport(String(rd.result||'')); };
      rd.onerror=function(){ uiAlert('파일을 읽지 못했습니다.'); };
      rd.readAsText(f);
    });
  }
}

/* =============== Storage badge =============== */
function renderStorage(){
  const el=document.getElementById('storageState');
  el.innerHTML = storageOK
    ? '<span class="storage-badge ok">✓ 자동 저장 작동 중 — 기록이 유지됩니다</span>'
    : '<span class="storage-badge no">저장 비활성 — 미리보기 환경입니다. 파일을 브라우저로 열면 자동 저장됩니다.</span>';
}


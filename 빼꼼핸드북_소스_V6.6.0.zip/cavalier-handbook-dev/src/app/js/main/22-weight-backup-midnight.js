/* R2: 체중 시트 */
function bindWt(){
  const ov=document.getElementById('wtOvl'); if(!ov) return;
  document.getElementById('wtCancel').addEventListener('click', function(){ ov.classList.remove('on'); });
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.classList.remove('on'); });
  document.getElementById('wtSave').addEventListener('click', function(){
    const kg=parseFloat(String(document.getElementById('wtInput').value).replace(',','.'));
    if(!(kg>0.2 && kg<30)){ alert('0.2~30 사이 숫자를 입력하세요.'); return; }
    S.weight=S.weight.filter(function(x){ return x.d!==todayKey(); });
    S.weight.push({d:todayKey(), kg:String(Math.round(kg*100)/100)});
    ov.classList.remove('on');
    saveState(); afterWeight();
  });
}
/* H2: 템플릿 스마트 채움 */
function ntcSmartTpl(k, fallback){
  const tk=todayKey(); const q=qlNorm(tk);
  const hm=function(t){ return String(t||'').slice(0,5); };
  if(k==='meal' && q.meal.length){
    return '🍚 오늘 급여 '+q.meal.length+'회 ('+q.meal.map(hm).join(' · ')+'). 다음 __:__';
  }
  if(k==='walk'){
    const wl=(S.walkLog||{})[tk]||[];
    if(wl.length){
      let m=0; wl.forEach(function(s){ m+=Math.max(0,s.i-s.o); });
      return '🐕 산책 '+wl.length+'회 · 총 '+fmtDur(m)+' ('+wl.map(function(s){ return fmtHM(s.o)+'→'+fmtHM(s.i); }).join(', ')+')';
    }
  }
  if(k==='potty' && (q.poo.length||q.pee.length||q.diar.length)){
    return '💩 오늘 대변 '+q.poo.length+' · 소변 '+q.pee.length+' · 설사 '+q.diar.length+(q.diar.length? ' — 상태 확인 필요':' — 상태 정상');
  }
  if(k==='kg'){
    if(S.kgCur) return '🏫 '+kgName()+' '+fmtHM(S.kgCur)+' 등원 — 하원 전';
    const kl=(S.kgLog||{})[tk]||[];
    if(kl.length){ const s=kl[kl.length-1]; return '🏫 '+kgName()+' '+fmtHM(s.o)+' 등원 → '+fmtHM(s.i)+' 하원 ('+fmtDur(s.i-s.o)+')'+(s.f? ' · 식사 '+s.f : '')+(s.m? ' · '+s.m : ''); }
  }
  return fallback;
}
/* D1: 백업 */
function bindBackup(){
  const b=document.getElementById('bkupBtn'); if(!b) return;
  b.addEventListener('click', function(){
    try{ ioDownload(S, ''); }catch(e){ logErr('파일 백업', e); alert('백업 생성에 실패했습니다: '+e.message); }
  });
}
/* 자정 리셋 */
let DAY_KEY=todayKey();
function bindMidnight(){
  setInterval(function(){
    if(todayKey()!==DAY_KEY){
      DAY_KEY=todayKey();
      try{ renderAll(); }catch(e){}
    }
  }, 60000);
}


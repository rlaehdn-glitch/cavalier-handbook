
/* =============== V6.6: 오류 기록함 · 진단 화면 =============== */
/* 오류 기록함 — 조용히 넘기던 실패 중 '데이터에 닿는 것'과 화면 오류를 이 폰에 최근 50건 남긴다(_errlog).
   같은 곳·같은 내용이 이어지면 한 줄에 횟수만 올린다. 설정 > 진단에서 보고 복사할 수 있다. */
const DIAG={log:null, max:50, syncOkAt:0, verWarned:false, peers:null, peersAt:0};
function errLog(){
  if(DIAG.log) return DIAG.log;
  try{ const a=JSON.parse(lsGet('_errlog')||'[]'); DIAG.log=Array.isArray(a)? a : []; }catch(e){ DIAG.log=[]; }
  return DIAG.log;
}
function logErr(where, e){
  try{
    const m=String((e && (e.message || (e.reason && e.reason.message) || e.reason)) || e || '').slice(0, 300);
    const L=errLog(), last=L[L.length-1], now=Date.now();
    if(last && last.w===where && last.m===m){ last.n=(last.n||1)+1; last.t=now; }
    else{ L.push({t:now, w:String(where).slice(0, 60), m:m, v:APP_VER}); while(L.length>DIAG.max) L.shift(); }
    try{ localStorage.setItem('_errlog', JSON.stringify(L)); }catch(x){}
    try{ console.warn('[빼꼼] '+where+': '+m); }catch(x){}
    if(document.getElementById('diagBody') && document.querySelector('#tab-settings.on')) renderDiag();
  }catch(x){}
}
window.addEventListener('error', function(ev){ if(ev && (ev.error || ev.message)) logErr('화면 오류', ev.error || ev.message); });
window.addEventListener('unhandledrejection', function(ev){ logErr('처리 안 된 오류', ev && ev.reason); });

/* 단계별 보호 — 하나가 실패해도 다음 단계는 계속(시작 순서·화면 그리기) */
function safely(where, fn){ try{ return fn(); }catch(e){ logErr(where, e); } }

/* 이 폰 저장 실패 경고(R1) — 저장이 다시 되면 자동으로 사라짐 */
function lsWarnPaint(bad){
  const el=document.getElementById('lsWarn'); if(!el) return;
  el.style.display=bad? 'block' : 'none';
  if(bad) el.textContent='⚠ 이 폰 저장공간이 가득 차 기록을 이 폰에 저장하지 못했습니다. 동기화가 켜져 있으면 서버에는 올라갑니다. 설정 > 진단에서 저장공간을 확인해 주세요.';
}

/* 바이트·크기 표기 */
function byteLen(s){ try{ return new Blob([s]).size; }catch(e){ return String(s).length; } }
function diagBytes(n){ return n>=1048576? (n/1048576).toFixed(1)+'MB' : n>=1024? Math.round(n/1024)+'KB' : n+'B'; }
function verOfBuild(n){ n=+n||0; if(n>=600) return 'V'+Math.floor(n/100)+'.'+(Math.floor(n/10)%10)+'.'+(n%10); return n? 'V5.15.1 이하' : '알 수 없음'; }
function lsUsage(){
  const cat={'기록 본문':0, '동기화 기준본':0, '산책 경로 캐시':0, '대표사진':0, '오류 기록':0, '그 밖':0}; let total=0;
  try{
    for(let i=0; i<localStorage.length; i++){
      const k=localStorage.key(i), v=localStorage.getItem(k)||'', b=(k.length+v.length)*2;   /* 브라우저는 글자당 2바이트로 계산 */
      total+=b;
      const c= k==='ckcs-data'? '기록 본문' : k==='_sync_base'? '동기화 기준본' : /^_wg_/.test(k)? '산책 경로 캐시' : k===HERO_CK? '대표사진' : k==='_errlog'? '오류 기록' : '그 밖';
      cat[c]+=b;
    }
  }catch(e){}
  return {total:total, cat:cat};
}
async function diagPeers(force){
  if(!syncConfigured()) return null;
  if(!force && DIAG.peers && Date.now()-DIAG.peersAt<60000) return DIAG.peers;
  try{ DIAG.peers=(await albFetch('ver'))||{}; DIAG.peersAt=Date.now(); }catch(e){ logErr('진단: 상대 폰 확인', e); }
  return DIAG.peers;
}
function diagShortsLine(){
  const sv=window.SHORTS && window.SHORTS.v;
  if(!sv) return '아직 안 불러옴 — 앨범에서 쇼츠를 열면 확인됩니다';
  return sv===APP_VER? 'V'+sv+' (같음)' : '⚠ V'+sv+' — index.html(V'+APP_VER+')과 다릅니다. GitHub에 두 파일을 모두 올렸는지 확인하세요';
}
/* index.html과 shorts.js 버전이 다르면 한 번 알림(R4) */
function verCheckShorts(){
  const sv=window.SHORTS && window.SHORTS.v; if(!sv || sv===APP_VER) return;
  logErr('버전 불일치', 'index.html V'+APP_VER+' / shorts.js V'+sv);
  if(DIAG.verWarned) return; DIAG.verWarned=true;
  uiAlert('쇼츠 파일 버전이 다릅니다.\nindex.html V'+APP_VER+' · shorts.js V'+sv+'\nGitHub에 두 파일을 모두 올린 뒤 새로고침해 주세요.');
}
function diagText(){
  const u=lsUsage(), raw=JSON.stringify(S), sz=byteLen(raw);
  const lines=['빼꼼 핸드북 진단 · '+new Date().toLocaleString('ko-KR'),
    '앱: V'+APP_VER+' · '+APP_DATE+' (빌드 '+PVER+')',
    '쇼츠 파일: '+diagShortsLine(),
    '이 폰: '+(myName()||'이름 없음')+' · 기기 '+DEV_ID,
    '동기화: '+(syncConfigured()? '켜짐' : '꺼짐')+(DIAG.syncOkAt? ' · 마지막 성공 '+fmtHM(DIAG.syncOkAt) : '')+(SYNC.dirty? ' · 올릴 기록 대기 중' : ''),
    '기록 문서: '+diagBytes(sz)+' — 20초마다 받으면 앱을 켜 둔 1시간에 약 '+diagBytes(sz*180),
    '이 폰 저장공간: '+diagBytes(u.total)+' 사용 (브라우저 한도 약 5MB) — '+Object.keys(u.cat).filter(function(k){ return u.cat[k]; }).map(function(k){ return k+' '+diagBytes(u.cat[k]); }).join(' · ')];
  const pv=DIAG.peers||{};
  Object.keys(pv).filter(function(k){ return k!==DEV_ID && pv[k] && pv[k].at; }).sort(function(a,b){ return pv[b].at-pv[a].at; }).slice(0, 4).forEach(function(k){
    const r=pv[k]; lines.push('다른 기기: '+(r.n||k)+' · '+verOfBuild(r.v)+' · '+new Date(r.at).toLocaleString('ko-KR', {month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit'})+' 접속');
  });
  const L=errLog();
  lines.push('최근 오류: '+(L.length? L.length+'건' : '없음'));
  L.slice().reverse().slice(0, 20).forEach(function(x){ lines.push('  '+new Date(x.t).toLocaleString('ko-KR', {month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit'})+' · '+x.w+' · '+x.m+(x.n>1? ' (×'+x.n+')' : '')+(x.v && x.v!==APP_VER? ' [V'+x.v+']' : '')); });
  return lines.join('\n');
}
function renderDiag(){
  const el=document.getElementById('diagBody'); if(!el) return;
  const t=diagText().split('\n');
  el.innerHTML=t.slice(1).map(function(l){ const i=l.indexOf(': '); return (l.indexOf('  ')===0)? '<li class="dg-err">'+esc(l.trim())+'</li>' : (i>0? '<div class="dg-row"><span>'+esc(l.slice(0, i))+'</span><b>'+esc(l.slice(i+2))+'</b></div>' : '<div class="dg-row">'+esc(l)+'</div>'); }).join('').replace(/(<li class="dg-err">[\s\S]*<\/li>)/, '<ul class="dg-errs">$1</ul>');
  const n=document.getElementById('diagErrN'); if(n) n.textContent=errLog().length? errLog().length+'건' : '';
}
function bindDiag(){
  const cp=document.getElementById('diagCopy'), cl=document.getElementById('diagClear');
  if(cp) cp.addEventListener('click', function(){
    const txt=diagText();
    const done=function(){ uiToast('진단 내용을 복사했어요. 대화창에 붙여넣어 보내 주세요.'); };
    try{ if(navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(txt).then(done, function(){ diagCopyFallback(txt); done(); }); return; } }catch(e){}
    diagCopyFallback(txt); done();
  });
  if(cl) cl.addEventListener('click', async function(){
    if(!(await uiConfirm({msg:'오류 기록을 지울까요? 기록장 데이터는 그대로입니다.', ok:'지우기'}))) return;
    DIAG.log=[]; try{ localStorage.removeItem('_errlog'); }catch(e){} renderDiag();
  });
}
function diagCopyFallback(t){ try{ const ta=document.createElement('textarea'); ta.value=t; ta.setAttribute('readonly', ''); ta.style.cssText='position:fixed;top:-100px;opacity:0;'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }catch(e){} }
function diagOnOpen(){ renderDiag(); diagPeers(false).then(function(){ renderDiag(); }); }

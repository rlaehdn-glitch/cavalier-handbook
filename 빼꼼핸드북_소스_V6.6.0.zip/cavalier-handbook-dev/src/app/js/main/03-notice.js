/* =============== 오늘의 공지 (교대 인수인계 팝업) =============== */
const NTC={shownAt:0, shownId:'', show:10, editId:''};
function ntcFmt(ts){ if(!ts) return ''; const d=new Date(ts); return (d.getMonth()+1)+'/'+d.getDate()+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'); }
function renderNotice(){
  const feed=document.getElementById('ntcFeed');
  if(feed){
    const me=myName();
    const list=S.ntc||[];
    const shown=list.slice(0, NTC.show||10);
    feed.innerHTML = shown.length? shown.map(function(n){
      if(NTC.editId===n.id){
        return '<div class="nt-card cur"><div class="nt-h"><span class="nt-by">✏️ 공지 수정</span><span class="nt-t">'+esc(n.by||'')+'</span></div>'
          +'<div class="nt-ed"><textarea id="ntcEditTa">'+esc(n.text)+'</textarea>'
          +'<div class="nt-edrow"><button class="btn sm" data-nsv="'+n.id+'">저장</button><button class="btn sm ghost" data-ncx="1">취소</button></div>'
          +'<p class="muted small" style="margin:7px 0 0;">저장하면 상대 폰에 팝업이 다시 뜹니다 (읽음 초기화).</p></div></div>';
      }
      const mine = me && n.by===me;
      const needAck = !mine && !(me && n.ack && n.ack[me]);
      return '<div class="nt-card'+(n===list[0]?' cur':'')+'">'
        +'<div class="nt-h"><span class="nt-by">'+esc(n.by||'작성자 미입력')+(mine?' <span class="nt-me">나</span>':'')+'</span><span class="nt-t">'+(n.ed? '✏️ 수정 '+ntcFmt(n.ed) : ntcFmt(n.at))+'</span></div>'
        +'<div class="nt-b">'+esc(n.text)+'</div>'
        +'<div class="nt-f"><span class="nt-ack">'+ntcAckLine(n)+'</span>'
        +(needAck?'<button class="btn sm" data-ack="'+n.id+'">✓ 확인</button>':'')
        +'<button class="btn sm ghost" data-ned="'+n.id+'">수정</button>'
        +'<button class="btn sm ghost" data-ndel="'+n.id+'">삭제</button></div>'
      +'</div>';
    }).join('') : '<p class="muted small">아직 공지가 없습니다. 위에서 첫 공지를 남겨보세요.</p>';
    const more=document.getElementById('ntcMore');
    if(more) more.style.display = list.length>shown.length ? 'inline-block' : 'none';
    feed.querySelectorAll('[data-ack]').forEach(function(b){ b.addEventListener('click', function(){ ntcAck(this.dataset.ack); }); });
    feed.querySelectorAll('[data-ned]').forEach(function(b){ b.addEventListener('click', function(){ NTC.editId=this.dataset.ned; renderNotice(); }); });
    feed.querySelectorAll('[data-ncx]').forEach(function(b){ b.addEventListener('click', function(){ NTC.editId=''; renderNotice(); }); });
    feed.querySelectorAll('[data-nsv]').forEach(function(b){ b.addEventListener('click', function(){
      const id=this.dataset.nsv;
      const ta=document.getElementById('ntcEditTa');
      const v=(ta && ta.value || '').trim();
      if(!v){ alert('내용을 입력하세요.'); return; }
      const n=(S.ntc||[]).find(function(x){ return x.id===id; }); if(!n) return;
      n.text=v; n.ed=Date.now(); n.ack={};
      n.id='n'+n.ed;
      ntcSeenSet(n.id); NTC.shownId=n.id;
      if(n===S.ntc[0]) S.notice={text:v, by:n.by||'', at:n.at, day:todayKey()};
      NTC.editId='';
      saveState(); renderNotice(); renderHomeNotice();
    }); });
    feed.querySelectorAll('[data-ndel]').forEach(function(b){ b.addEventListener('click', async function(){
      if(!(await askConfirm('이 공지를 삭제할까요? 두 폰 모두에서 사라집니다.'))) return;
      const id=this.dataset.ndel;
      const victim=(S.ntc||[]).find(function(x){ return x.id===id; });
      S.ntc=S.ntc.filter(function(x){ return x.id!==id; });
      if(victim && S.notice && S.notice.at===victim.at){ S.notice={text:'',by:'',at:0,day:''}; }
      saveState(); renderNotice(); renderHomeNotice();
    }); });
  }
  const by=document.getElementById('ntcBy');
  if(by && document.activeElement!==by && !by.value) by.value=myName();
  maybeShowNoticePopup();
}
function maybeShowNoticePopup(){
  const list=S.ntc||[]; if(!list.length) return;
  const n=list[0];
  const me=myName();
  if(me && n.by===me) return;
  if(me && n.ack && n.ack[me]) return;
  if(ntcSeenGet()[n.id]) return;
  if(NTC.shownId===n.id) return;
  const ovl=document.getElementById('ntcOvl'); if(!ovl) return;
  document.getElementById('ntcPopMeta').textContent=(n.ed? '✏️ 수정된 공지 · ':'')+(n.by? n.by+' · ':'')+ntcFmt(n.ed||n.at);
  document.getElementById('ntcPopBody').textContent=n.text;
  ovl.dataset.nid=n.id;
  ovl.classList.add('on');
  NTC.shownId=n.id;
}
function bindNotice(){
  const save=document.getElementById('ntcSave'); if(!save) return;
  save.addEventListener('click', function(){
    const t=(document.getElementById('ntcText').value||'').trim();
    const by=(document.getElementById('ntcBy').value||'').trim();
    if(!t){ alert('내용을 입력하세요.'); return; }
    if(!by){ alert('내 이름을 입력하세요.'); return; }
    lsSet('_ntc_by', by);
    const at=Date.now();
    const n={id:'n'+at, text:t, by:by, at:at, ack:{}};
    S.ntc=S.ntc||[]; S.ntc.unshift(n);
    while(S.ntc.length>40) S.ntc.pop();
    S.notice={text:t, by:by, at:at, day:todayKey()};
    ntcSeenSet(n.id); NTC.shownId=n.id;
    document.getElementById('ntcText').value='';
    saveState(); renderNotice(); renderHomeNotice();
    const st=document.getElementById('ntcStat'); if(st) st.textContent='등록됨 — 상대 폰에는 열 때 즉시, 켜져 있으면 20초 안에 팝업.';
  });
  document.querySelectorAll('.nt-tpl').forEach(function(b){
    b.addEventListener('click', function(){
      const ta=document.getElementById('ntcText');
      const add=ntcSmartTpl(this.dataset.k, this.dataset.t);
      ta.value = ta.value ? (ta.value.replace(/\s+$/,'')+'\n'+add) : add;
      ta.focus();
    });
  });
  const more=document.getElementById('ntcMore');
  if(more) more.addEventListener('click', function(){ NTC.show+=10; renderNotice(); });
  document.getElementById('ntcPrev').addEventListener('click', function(){
    const t=(document.getElementById('ntcText').value||'').trim() || ((S.ntc&&S.ntc[0]&&S.ntc[0].text)||'');
    if(!t){ alert('미리 볼 내용이 없습니다.'); return; }
    const by=(document.getElementById('ntcBy').value||'').trim();
    document.getElementById('ntcPopMeta').textContent=(by?by+' · ':'')+'미리보기';
    document.getElementById('ntcPopBody').textContent=t;
    const ovl=document.getElementById('ntcOvl'); ovl.dataset.nid=''; ovl.classList.add('on');
  });
  document.getElementById('ntcClose').addEventListener('click', function(){ document.getElementById('ntcOvl').classList.remove('on'); });
  document.getElementById('ntcAck').addEventListener('click', async function(){
    const ovl=document.getElementById('ntcOvl');
    const id=ovl.dataset.nid;
    if(id){ if(!(await ntcAck(id))) return; }
    ovl.classList.remove('on');
  });
  document.getElementById('ntcOvl').addEventListener('click', function(e){ if(e.target===this) this.classList.remove('on'); });
}


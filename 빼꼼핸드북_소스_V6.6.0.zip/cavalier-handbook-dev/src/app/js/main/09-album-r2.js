/* =============== V5.12: 사진 저장소 이관 (파이어베이스 base64 → R2 바이너리) ===============
   meta[id].p2=1 이면 그 사진의 원본·썸네일이 R2에 있음. 없으면 기존 파이어베이스.
   화면 코드는 albImgSrc() 한 곳만 거치므로 표시·정렬·메모·좋아요는 전부 그대로다.
   상대 폰이 구버전이면 p2 를 모르기 때문에, 두 폰 모두 이 빌드일 때만 전환한다. */
const PVER=__APP_BUILD__;   /* V6.6: 빌드 번호 = VERSION에서 자동(6.6.0 → 660). 기기 보고(ver)·상대 폰 구버전 확인용 */
const PMIG={run:false, stop:false, gate:null};
const P2SCHEMES=[
  {id:'d', name:'영상과 같은 형식 (v/… .mp4)',  ct:'video/mp4',  f:function(k,id){ return 'v/'+id+(k==='th'?'t':'')+'.mp4'; }},
  {id:'c', name:'영상 폴더 · jpg (v/… .jpg)',   ct:'image/jpeg', f:function(k,id){ return 'v/'+id+(k==='th'?'t':'')+'.jpg'; }},
  {id:'a', name:'사진 폴더 (pf/… .jpg)',        ct:'image/jpeg', f:function(k,id){ return (k==='th'?'pt/':'pf/')+id+'.jpg'; }},
  {id:'b', name:'사진 폴더 · mp4 (p/… .mp4)',   ct:'video/mp4',  f:function(k,id){ return 'p/'+id+(k==='th'?'t':'')+'.mp4'; }},
  {id:'e', name:'폴더 없이 (… .jpg)',           ct:'image/jpeg', f:function(k,id){ return id+(k==='th'?'t':'')+'.jpg'; }}
];
const P2PROBE='/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCAACAAIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDoqKKK5Tc//9k=';
let P2S=P2SCHEMES[0].id;
function albP2Scheme(){ for(let i=0;i<P2SCHEMES.length;i++){ if(P2SCHEMES[i].id===P2S) return P2SCHEMES[i]; } return P2SCHEMES[0]; }
function albP2Key(kind,id){ return albP2Scheme().f(kind,id); }
function albP2Ct(){ return albP2Scheme().ct; }
async function albP2Load(){ try{ const v=await albFetch('p2s'); if(v && typeof v==='string'){ P2S=v; } }catch(e){} }
/* 1장 시험 — 아주 작은 더미 파일로 어떤 키 방식이 통하는지 실측하고, 통하는 방식을 두 폰 공용으로 저장 */
async function albMigTest(){
  if(!mediaConfigured()){ alert('영상 저장소가 연결되어 있지 않습니다.'); return; }
  const log=[];
  function out(){ const e=document.getElementById('p2Stat'); if(e) e.innerHTML=log.join('<br>'); }
  log.push('① 저장소 연결 확인…'); out();
  try{ await mediaFetch(mediaApi('/ping'),{method:'GET'},15000); log.push('　→ 정상'); }
  catch(e){ log.push('　→ <b>실패: '+esc(String(e&&e.message||e))+'</b>'); out(); return; }
  out();
  const ids=albMigTodo();
  if(ids.length){
    log.push('② 기존 사진 읽기…'); out();
    try{
      const fu=await albFetch('full/'+ids[0]);
      if(!fu) throw new Error('내용 없음(null)');
      const b=albDataBlob(fu);
      log.push('　→ 정상 · 원본 '+Math.round(String(fu).length/1024)+'KB → 변환 '+Math.round(b.size/1024)+'KB');
    }catch(e){ log.push('　→ <b>실패: '+esc(String(e&&e.message||e))+'</b>'); out(); return; }
    out();
  }
  const probe=albDataBlob('data:image/jpeg;base64,'+P2PROBE);
  const pid=albNewId();   /* 실제 사진 ID와 같은 형식 — 밑줄 금지 */
  let win=null;
  for(let i=0;i<P2SCHEMES.length;i++){
    const s=P2SCHEMES[i], key=s.f('full',pid);
    log.push('③-'+(i+1)+' '+esc(s.name)+' …'); out();
    try{
      await mediaFetch(mediaApi('/put',{key:key, ct:s.ct}), {method:'PUT', body:probe}, 60000);
      const url=mediaApi('/file/'+key);
      const r=await fetch(url);
      if(!r.ok) throw new Error('올린 뒤 다시 못 읽음 HTTP '+r.status);
      await new Promise(function(res,rej){                                        /* 브라우저가 사진으로 실제 표시하는지까지 확인 */
        const im=new Image(); const t=setTimeout(function(){ rej(new Error('사진으로 표시 안 됨(시간초과)')); }, 15000);
        im.onload=function(){ clearTimeout(t); (im.naturalWidth>0)?res():rej(new Error('사진으로 표시 안 됨')); };
        im.onerror=function(){ clearTimeout(t); rej(new Error('사진으로 표시 안 됨(이 방식은 화면에서 깨집니다)')); };
        im.src=url;
      });
      log.push('　→ <b>성공 · 업로드·재생 모두 정상</b>'); out();
      try{ await mediaFetch(mediaApi('/file/'+key),{method:'DELETE'},15000); }catch(e){}
      win=s; break;
    }catch(e){
      log.push('　→ 실패: '+esc(String(e&&e.message||e))); out();
      try{ await mediaFetch(mediaApi('/file/'+key),{method:'DELETE'},10000); }catch(e2){}
    }
  }
  if(!win){ log.push('<b>다섯 방식 모두 실패 — Worker 코드 수정이 필요합니다. 이 화면을 그대로 전달해주세요.</b>'); out(); return; }
  P2S=win.id;
  try{ await albFetch('p2s','PUT',JSON.stringify(P2S)); }catch(e){}
  log.push('<b>→ 이 방식으로 설정 완료. 이제 "R2로 옮기기"를 누르세요.</b>');
  out(); renderMigPanel();
}
function albIsP2(id){ const m=ALB.meta&&ALB.meta[id]; return !!(m&&m.p2); }
/* V5.14: 사진이 영상 형식(v/… .mp4)으로 저장돼 있으면 서버가 video/mp4 로 내려준다.
   크롬은 내용을 보고 사진으로 표시하지만 사파리(아이폰)는 형식만 보고 거부한다.
   → 파일을 받아 사진 형식으로 바꿔서 화면에 넣는다. 저장된 데이터는 그대로, 화면에서만 교정. */
const P2BLOB=new Map(), P2BLOBMAX=320;
function albImgSrc(kind,id){
  if(albIsP2(id)){
    if(!mediaConfigured()) return Promise.reject(new Error('저장소 미연결'));
    return p2Src(kind,id);   /* V6.0.5: 사진마다 실제로 열리는 이름을 찾아 씀 */
  }
  return albFetch(kind+'/'+id);
}
function albDataU8(du){
  const i=String(du||'').indexOf(',');
  if(i<0) throw new Error('형식 오류');
  const bin=atob(String(du).slice(i+1)), n=bin.length, u8=new Uint8Array(n);
  for(let j=0;j<n;j++) u8[j]=bin.charCodeAt(j);
  return u8;
}
function albDataBlob(du){
  const i=String(du||'').indexOf(',');
  const ct=(String(du).slice(0,Math.max(i,0)).match(/data:([^;]+)/)||[])[1]||'image/jpeg';
  return new Blob([albDataU8(du)],{type:ct});
}
/* --- 기기 빌드 번호 보고 / 상대 폰 구버전 감지 --- */
async function albVerBeat(){
  if(!syncConfigured()) return;
  try{ await albFetch('ver/'+DEV_ID,'PUT',JSON.stringify({v:PVER, at:Date.now(), n:(myName()||'')})); }catch(e){}
}
async function albMigGate(){
  const CUT=Date.now()-14*86400000;
  let vers={}, cmeta={};
  try{ vers=(await albFetch('ver'))||{}; }catch(e){}
  try{ const r=await fetch(chatPath('/meta')); cmeta=(await r.json())||{}; }catch(e){}
  const newNames={}; let meOk=false;
  Object.keys(vers).forEach(function(k){
    const r=vers[k]||{};
    if(!r.at || r.at<CUT || (r.v||0)<PVER) return;
    if(k===DEV_ID) meOk=true;
    if(r.n) newNames[r.n]=1;
  });
  const stale=[];
  Object.keys(cmeta).forEach(function(nm){
    const r=cmeta[nm]||{};
    if(!r.seen || r.seen<CUT) return;
    if(nm===myName()) return;
    if(!newNames[nm]) stale.push(nm);
  });
  return {meOk:meOk, stale:stale, ready:(meOk && stale.length===0)};
}
function albMigTodo(){ return ALB.meta? Object.keys(ALB.meta).filter(function(id){ return albIsPhoto(ALB.meta[id]) && !ALB.meta[id].p2; }) : []; }
function albMigDone(){ return ALB.meta? Object.keys(ALB.meta).filter(function(id){ return albIsPhoto(ALB.meta[id]) && ALB.meta[id].p2; }) : []; }
function albP2On(){ return mediaConfigured() && PMIG.gate && PMIG.gate.ready; }
function p2Stat(t){ const e=document.getElementById('p2Stat'); if(e) e.textContent=t; }
function p2Prog(v){
  const b=document.getElementById('p2Prog'), i=document.getElementById('p2ProgBar'); if(!b||!i) return;
  if(v===null){ b.classList.remove('on'); i.style.width='0'; return; }
  b.classList.add('on'); i.style.width=Math.round(v*100)+'%';
}
function renderMigPanel(){
  const box=document.getElementById('p2Box'); if(!box) return;
  const todo=albMigTodo().length, done=albMigDone().length;
  box.style.display = (mediaConfigured() && (todo||done)) ? 'block' : 'none';
  const g=document.getElementById('p2Gate');
  if(g){
    const gt=PMIG.gate;
    g.innerHTML = !gt ? '기기 확인 중…'
      : gt.ready ? '✅ 두 폰 모두 최신 버전 — 옮겨도 상대 화면이 그대로입니다. (남은 사진 '+todo+'장)'
      : !gt.meOk ? '이 폰 정보를 아직 못 올렸습니다. 잠시 후 새로고침해주세요.'
      : '⏳ '+esc(gt.stale.join(', '))+' 폰이 아직 이전 버전입니다. 그 폰에서 핸드북을 한 번 열어 새로고침하면 자동으로 풀립니다. (남은 사진 '+todo+'장)';
  }
  const fc=document.getElementById('p2Force');
  const run=document.getElementById('p2Run'), cl=document.getElementById('p2Clean'), st=document.getElementById('p2Stop');
  const allow=(PMIG.gate&&PMIG.gate.ready)||(fc&&fc.checked);
  if(run){ run.disabled=!allow||PMIG.run||!todo; run.textContent='R2로 옮기기'+(todo?(' ('+todo+')'):''); }
  if(cl){ cl.disabled=!allow||PMIG.run||!!todo||!done; }
  if(st) st.style.display=PMIG.run?'inline-flex':'none';
}
async function albMigRefresh(){ try{ PMIG.gate=await albMigGate(); }catch(e){ PMIG.gate=null; } renderMigPanel(); }
async function albMigRun(){
  if(PMIG.run) return;
  if(!mediaConfigured()){ alert('영상 저장소(R2)가 연결되어 있지 않습니다. 위 칸에서 먼저 연결해주세요.'); return; }
  const todo=albMigTodo();
  if(!todo.length){ p2Stat('옮길 사진이 없습니다.'); return; }
  if(!(await askConfirm('사진 '+todo.length+'장을 R2로 옮깁니다.\n앨범 화면은 그대로이고, 원본은 아직 지우지 않습니다.\n도중에 끊겨도 다시 누르면 이어서 진행됩니다.\n\n시작할까요?'))) return;
  PMIG.run=true; PMIG.stop=false; renderMigPanel();
  let wl=null; try{ if(navigator.wakeLock) wl=await navigator.wakeLock.request('screen'); }catch(e){}
  let ok=0, fail=0, err='';
  try{
    for(let i=0;i<todo.length;i++){
      if(PMIG.stop) break;
      const id=todo[i];
      p2Stat('옮기는 중 '+(i+1)+'/'+todo.length+' — 화면을 끄지 마세요'); p2Prog(i/todo.length);
      try{
        const fu=await albFetch('full/'+id);
        if(!fu){ fail++; continue; }
        let th=null; try{ th=await albFetch('th/'+id); }catch(e){}
        const fb=albDataBlob(fu);
        await mediaUpload(fb, albP2Key('full',id), albP2Ct());
        let tb=null;
        if(th){ tb=albDataBlob(th); await mediaUpload(tb, albP2Key('th',id), albP2Ct()); }
        const m=Object.assign({}, ALB.meta[id]||{});
        m.p2=1; m.ps=albP2Scheme().id; m.s=fb.size+(tb?tb.size:0);
        await albFetch('meta/'+id,'PUT',JSON.stringify(m));
        ALB.meta[id]=m; ALB.thumbs.delete(id); ALB.fulls.delete(id);
        ok++;
      }catch(e){ fail++; if(!err) err=String(e&&e.message||e); }
    }
    try{ await albBumpIdx(); }catch(e){}
  }finally{
    PMIG.run=false; p2Prog(null); try{ if(wl) wl.release(); }catch(e){}
    renderAlbum();
    p2Stat('옮김 '+ok+'장'+(fail?(' · 실패 '+fail+'장 — 원인: '+err):'')+(albMigTodo().length?'':' · 앨범이 정상인지 확인한 뒤 "파이어베이스 정리"를 눌러주세요'));
    renderMigPanel();
  }
}
async function albMigClean(){
  if(PMIG.run) return;
  if(albMigTodo().length){ alert('아직 옮기지 않은 사진이 있습니다. "R2로 옮기기"를 먼저 끝내주세요.'); return; }
  const ids=albMigDone();
  if(!ids.length){ p2Stat('정리할 것이 없습니다.'); return; }
  p2Stat('R2 보관 상태 확인 중…');
  const pick=[ids[0], ids[Math.floor(ids.length/2)], ids[ids.length-1]];
  for(let i=0;i<pick.length;i++){
    try{ await p2Blob('full', pick[i]); }
    catch(e){ p2Stat('확인 실패 — 정리를 중단했습니다. ('+String(e&&e.message||e)+')'); return; }
  }
  if(!(await askConfirm('R2 보관 확인됐습니다.\n파이어베이스에 남은 사본 '+ids.length+'장을 지웁니다. 앨범 화면은 그대로입니다.\n\n계속할까요?'))) { p2Stat(''); return; }
  PMIG.run=true; PMIG.stop=false; renderMigPanel();
  let ok=0, fail=0;
  try{
    for(let i=0;i<ids.length;i++){
      if(PMIG.stop) break;
      p2Stat('정리 중 '+(i+1)+'/'+ids.length); p2Prog(i/ids.length);
      try{ await albFetch('full/'+ids[i],'DELETE'); await albFetch('th/'+ids[i],'DELETE'); ok++; }catch(e){ fail++; }
    }
    try{ await albBumpIdx(); }catch(e){}
  }finally{
    PMIG.run=false; p2Prog(null); renderAlbum();
    p2Stat('정리 완료 '+ok+'장'+(fail?(' · 실패 '+fail+'장'):'')+' — 파이어베이스 사진 용량이 비워졌습니다.');
    renderMigPanel();
  }
}
function bindMig(){
  const r=document.getElementById('p2Run'); if(!r) return;
  r.addEventListener('click', albMigRun);
  const tb=document.getElementById('p2Test'); if(tb) tb.addEventListener('click', albMigTest);
  try{ bindBackup(); }catch(e){}
  document.getElementById('p2Clean').addEventListener('click', albMigClean);
  document.getElementById('p2Stop').addEventListener('click', function(){ PMIG.stop=true; p2Stat('중단 요청 — 현재 장이 끝나면 멈춥니다.'); });
  document.getElementById('p2Force').addEventListener('change', renderMigPanel);
}

/* =============== V2: 사진 스트립 / 앨범 강화 =============== */
function stripThumb(id, img){
  if(ALB.thumbs.has(id)){ img.src=ALB.thumbs.get(id); return; }
  albImgSrc('th',id).then(function(v){ if(v){ ALB.thumbs.set(id,v); img.src=v; } }).catch(function(){ img.classList.add('err'); });
}
function renderStrip(){
  const el=document.getElementById('photoStrip'); if(!el) return;
  if(!syncConfigured() || !ALB.meta) return;
  const ids=Object.keys(ALB.meta)
    .filter(function(id){ return albIsPhoto(ALB.meta[id]); })
    .sort(function(a,b){ return (ALB.meta[b].at||0)-(ALB.meta[a].at||0); })
    .slice(0,4);
  if(!ids.length){ el.innerHTML='<p class="muted small" style="margin:0;">아직 사진이 없습니다. 앨범에서 첫 장을 올려보세요.</p>'; return; }
  el.innerHTML=ids.map(function(id){ return '<div class="sc" data-id="'+id+'"><img alt=""></div>'; }).join('');
  el.querySelectorAll('.sc').forEach(function(c){
    stripThumb(c.dataset.id, c.querySelector('img'));
    c.addEventListener('click', function(){ goTab('album'); });
  });
}
function albMilestoneList(){
  const out=[];
  if(S.profile.home) out.push({d:S.profile.home, t:'🏠 집에 온 날'});
  if(S.profile.birth){
    const b=new Date(S.profile.birth+'T00:00:00');
    out.push({d:d2s(addD(b,100)), t:'🎉 100일'});
    out.push({d:d2s(addD(b,365)), t:'🎂 첫 생일'});
  }
  Object.keys(S.vax||{}).forEach(function(k){
    const v=S.vax[k];
    if(v && v.done && v.date){
      const p=VAX_PLAN.find(function(x){ return x.id===k; });
      if(p) out.push({d:v.date, t:'💉 '+p.t.split('—')[0].trim()});
    }
  });
  return out;
}
function albAgeIdx(dstr){
  if(!S.profile.birth || !dstr) return null;
  const b=new Date(S.profile.birth+'T00:00:00'), d=new Date(dstr+'T00:00:00');
  return Math.max(0, Math.floor((d-b)/86400000/30.44));
}
function albAgeHead(idx){
  const ms=albMilestoneList()
    .filter(function(m){ return albAgeIdx(m.d)===idx; })
    .map(function(m){ return '<span class="ms">'+esc(m.t)+' '+m.d.slice(5).replace('-','/')+'</span>'; })
    .join('');
  return '<div class="alb-age"><b>생후 '+idx+'개월</b>'+ms+'</div>';
}
function renderCompare(){
  const el=document.getElementById('albCompare'); if(!el || !ALB.meta) return;
  const ids=Object.keys(ALB.meta)
    .filter(function(id){ return albIsPhoto(ALB.meta[id]); })
    .sort(function(a,b){ return (ALB.meta[a].at||0)-(ALB.meta[b].at||0); });
  if(ids.length<2){ el.className=''; el.innerHTML=''; return; }
  const f=ids[0], l=ids[ids.length-1];
  el.className='vis';
  el.innerHTML='<div class="alb-sec-t">처음 · 최근 비교</div>'
              +'<div class="cmp" data-id="'+f+'"><img alt=""><span>처음 · '+esc((ALB.meta[f].d||'').slice(5).replace('-','/'))+'</span></div>'
              +'<div class="cmp" data-id="'+l+'"><img alt=""><span>최근 · '+esc((ALB.meta[l].d||'').slice(5).replace('-','/'))+'</span></div>';
  el.querySelectorAll('.cmp').forEach(function(c){
    stripThumb(c.dataset.id, c.querySelector('img'));
    c.addEventListener('click', function(){ albOpen(c.dataset.id); });
  });
}

/* =============== V2: 지출 차트 =============== */
function renderEChart(){
  const svg=document.getElementById('eChart'); if(!svg) return;
  const now=new Date(); const mons=[];
  for(let i=5;i>=0;i--){
    const d=new Date(now.getFullYear(), now.getMonth()-i, 1);
    mons.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'));
  }
  const sums=mons.map(function(m){
    return S.expenses.filter(function(e){ return e.d && e.d.startsWith(m); })
      .reduce(function(s,e){ return s+Number(e.a||0); }, 0);
  });
  if(!sums.some(function(v){ return v>0; })){ svg.style.display='none'; return; }
  svg.style.display='block';
  const max=Math.max.apply(null, sums.concat([1]));
  const bw=70, gap=(640-40-bw*6)/5;
  let out='';
  sums.forEach(function(v,i){
    const h=Math.round((v/max)*92);
    const x=Math.round(20+i*(bw+gap)); const y=118-h;
    out+='<rect x="'+x+'" y="'+y+'" width="'+bw+'" height="'+Math.max(h,2)+'" rx="6" fill="'+(i===5?'#8A3324':'#D8C9AE')+'"/>';
    if(v>0){
      const lbl = v>=10000 ? Math.round(v/10000)+'만' : Math.round(v/1000)+'천';
      out+='<text x="'+(x+bw/2)+'" y="'+(y-6)+'" text-anchor="middle" font-size="11" fill="#6E6254">'+lbl+'</text>';
    }
    out+='<text x="'+(x+bw/2)+'" y="140" text-anchor="middle" font-size="11" fill="#6E6254">'+mons[i].slice(5)+'월</text>';
  });
  svg.innerHTML=out;
}

/* =============== V2: 서재 =============== */
let LIB_IDX=null;
function buildLibIdx(){
  LIB_IDX=LIB_META.map(function(m){
    const sec=document.getElementById('tab-'+m[0]);
    return {id:m[0], num:m[1], title:m[2], txt: sec ? sec.textContent.replace(/\s+/g,' ') : ''};
  });
}
function renderLib(){
  const rec=document.getElementById('libRec'), list=document.getElementById('libList');
  if(!list) return;
  let chips=[];
  if(S.profile.birth){
    const days=Math.floor((new Date()-new Date(S.profile.birth+'T00:00:00'))/86400000);
    const m=Math.floor(days/30.44);
    if(m<3) chips=[['health','02 접종 진행 중'],['money','03 펫보험 — 심잡음 발견 전 가입'],['walk','05 배변·사회화 골든타임'],['work','06 낮 공백 플랜']];
    else if(m<6) chips=[['walk','05 입질(이갈이) 대응'],['health','02 접종 마무리·항체검사'],['food','04 급여량 조정']];
    else if(m<10) chips=[['neuter','07 중성화 상담 시기'],['health','02 정기검진'],['food','04 사료']];
    else if(m<13) chips=[['food','04 성견 사료 전환'],['neuter','07 중성화'],['health','02 검진']];
    else chips=[['health','02 연간검진·심장청진'],['life','13 계절 관리'],['behav','12 행동 사전']];
    const mon=new Date().getMonth()+1;
    if(mon>=6 && mon<=8) chips.unshift(['life','13 ☀️ 여름 더위·열사병 관리']);
    if(mon===12 || mon<=2) chips.unshift(['life','13 ❄️ 겨울 관리']);
  }else{
    chips=[['settings','생년월일부터 입력하세요 (설정)']];
  }
  rec.innerHTML=chips.slice(0,4).map(function(c){ return '<button type="button" data-go="'+c[0]+'">'+esc(c[1])+'</button>'; }).join('');
  rec.querySelectorAll('button').forEach(function(b){ b.addEventListener('click', function(){ goTab(b.dataset.go); }); });
  list.innerHTML=LIB_META.map(function(m){
    return '<div class="lib-row" data-go="'+m[0]+'"><span class="no">'+esc(m[1])+'</span><span class="tt"><b>'+esc(m[2])+(m[4]?' <span class="lib-done">완료</span>':'')+'</b><span>'+esc(m[3])+'</span></span><span class="go">›</span></div>';
  }).join('');
  list.querySelectorAll('.lib-row').forEach(function(r){ r.addEventListener('click', function(){ goTab(r.dataset.go); }); });
}
function bindLib(){
  const q=document.getElementById('libQ'); if(!q) return;
  let t=null;
  q.addEventListener('input', function(){
    clearTimeout(t);
    t=setTimeout(function(){
      const res=document.getElementById('libRes');
      const kw=q.value.trim();
      if(kw.length<2){ res.innerHTML=''; return; }
      if(!LIB_IDX) buildLibIdx();
      const low=kw.toLowerCase();
      const hits=[];
      LIB_IDX.forEach(function(x){
        const pos=x.txt.toLowerCase().indexOf(low);
        if(pos>-1){
          const s=Math.max(0,pos-24);
          hits.push({id:x.id, num:x.num, title:x.title, snip:(s>0?'…':'')+x.txt.slice(s, pos+kw.length+42)+'…'});
        }
      });
      res.innerHTML = hits.length
        ? hits.slice(0,8).map(function(h){ return '<div class="lr-item" data-go="'+h.id+'"><div class="t">'+esc(h.num)+' '+esc(h.title)+'</div><div class="s">'+esc(h.snip)+'</div></div>'; }).join('')
        : '<p class="muted small">"'+esc(kw)+'" 검색 결과가 없습니다. 우측 하단 🐾 AI 상담에 물어보세요.</p>';
      res.querySelectorAll('.lr-item').forEach(function(r){ r.addEventListener('click', function(){ const id=r.dataset.go; goTab(id); setTimeout(function(){ libJump(id, kw); }, 90); }); });
    }, 200);
  });
}


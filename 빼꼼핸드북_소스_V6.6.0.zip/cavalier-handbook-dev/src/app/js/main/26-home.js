/* =============== V6: 홈 — 퀵 기록 · 오늘 목록 · 리본 · 지금 카드 =============== */
function renderQlog(){
  const p=document.getElementById('qlPooN'); if(!p) return;
  const tk=todayKey(), q=qlNorm(tk), now=Date.now();
  const setT=function(id, v){ const e=document.getElementById(id); if(e) e.textContent=v; };
  setT('qlPooN', q.poo.length); setT('qlPeeN', q.pee.length); setT('qlDiarN', q.diar.length); setT('qlMealN', q.meal.length);
  const lw=latestWeight(); setT('qlWtV', lw? lw.kg+'kg' : '—');
  const tile=function(id, cur, logArr, idleNm, liveNm, tId, nId){
    const b=document.getElementById(id); if(!b) return;
    if(cur){ b.classList.add('walking'); setT(tId, liveNm); setT(nId, '⏱'+fmtClock(now-cur)); }
    else{ b.classList.remove('walking'); setT(tId, idleNm); const m=sumSegs(logArr); setT(nId, m? fmtClock(m) : '—'); }
  };
  tile('qlWalk', S.walkCur, (S.walkLog||{})[tk], '산책', '산책 중', 'qlWalkT', 'qlWalkN');
  tile('qlSleep', S.sleepCur, (S.sleepLog||{})[tk], '수면', '자는 중', 'qlSleepT', 'qlSleepN');
  tile('qlKg', S.kgCur, (S.kgLog||{})[tk], '유치원', '유치원 중', 'qlKgT', 'qlKgN');
  tile('qlAway', S.awayCur, (S.awayLog||{})[tk], '외출', '혼자 중', 'qlAwayT', 'qlAwayN');
  const ab=document.getElementById('qlAway');
  if(ab){ const dim=!!S.kgCur && !S.awayCur; ab.classList.toggle('dim', dim); if(dim) setT('qlAwayN', '유치원'); }
  try{ renderTimeline(); }catch(e){ console.error(e); }
  try{ renderRibbon(); }catch(e){ console.error(e); }
  try{ renderNow(); }catch(e){ console.error(e); }
  renderMealGap();
  try{ syncWarnPaint(); }catch(e){}
  try{ statsRefresh(); }catch(e){}   /* V6.1: 통계 화면이 열려 있을 때만 다시 계산 */
  try{ if(typeof bathPaint==='function') bathPaint(); }catch(e){ console.error(e); }   /* V6.4 */
  try{ if(typeof wgHomePaint==='function') wgHomePaint(); }catch(e){ console.error(e); }   /* V6.3 */
}
function qlBump(k, delta){
  const tk=todayKey(); const q=qlNorm(tk);
  let added='';
  if(delta>0){
    const n=new Date();
    added=String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0')+':'+String(n.getSeconds()).padStart(2,'0');
    q[k].push(added);
  }else{
    q[k].pop();
  }
  /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
  saveState(); renderQlog();
  if(delta>0){
    const el=document.getElementById({poo:'qlPooN', pee:'qlPeeN', diar:'qlDiarN', meal:'qlMealN'}[k]);
    if(el){ el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
    if(k==='poo') pooAmtAsk();
    const NM={poo:'대변', pee:'소변', diar:'설사', meal:'식사'};
    uiToast(NM[k]+' '+added.slice(0,5)+' 기록', function(){
      const a=qlNorm(tk)[k];
      for(let j=a.length-1;j>=0;j--){ if(String(a[j]).split('|')[0]===added){ a.splice(j,1); break; } }
      if(k==='poo'){ const pa=document.getElementById('pooAmt'); if(pa) pa.style.display='none'; }
      saveState(); renderQlog();
    });
  }
}
function walkToggle(){
  if(typeof wgIntercept==='function' && wgIntercept()) return;   /* V6.3: 지도 기록 중이면 산책 화면에서 끝내기 */
  if(S.walkCur){
    const key=todayKey(); S.walkLog=S.walkLog||{};
    const seg={o:S.walkCur, i:Date.now()};
    (S.walkLog[key]=S.walkLog[key]||[]).push(seg); S.walkCur=0;
    /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
    saveState(); renderQlog();
    uiToast('산책 '+fmtDur(seg.i-seg.o)+' 기록', function(){
      const a=(S.walkLog||{})[key]||[]; const ix=a.findIndex(function(x){ return x.o===seg.o && x.i===seg.i; });
      if(ix>-1){ a.splice(ix,1); if(!S.walkCur) S.walkCur=seg.o; saveState(); renderQlog(); }
    });
  }else{
    S.walkCur=Date.now(); const st=S.walkCur; saveState(); renderQlog();
    uiToast('산책 시작 '+fmtHM(st), function(){ if(S.walkCur===st){ S.walkCur=0; saveState(); renderQlog(); } });
  }
}
async function sleepToggle(){
  if(S.sleepCur){
    const dur=Date.now()-S.sleepCur;
    if(dur>16*3600000 && !(await askConfirm('수면이 '+fmtDur(dur)+'로 기록됩니다. 기상 버튼을 잊으셨다면 닫기를 누른 뒤 오늘 목록의 "자는 중" 줄에서 취소하세요. 그래도 저장할까요?'))) return;
    const key=todayKey(); S.sleepLog=S.sleepLog||{};
    const seg={o:S.sleepCur, i:Date.now()};
    (S.sleepLog[key]=S.sleepLog[key]||[]).push(seg); S.sleepCur=0;
    /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
    saveState(); renderQlog();
    uiToast('기상 · 수면 '+fmtDur(seg.i-seg.o), function(){
      const a=(S.sleepLog||{})[key]||[]; const ix=a.findIndex(function(x){ return x.o===seg.o && x.i===seg.i; });
      if(ix>-1){ a.splice(ix,1); if(!S.sleepCur) S.sleepCur=seg.o; saveState(); renderQlog(); }
    });
  }else{
    S.sleepCur=Date.now(); const st=S.sleepCur; saveState(); renderQlog();
    uiToast('취침 '+fmtHM(st), function(){ if(S.sleepCur===st){ S.sleepCur=0; saveState(); renderQlog(); } });
  }
}
const TL={all:false};
function tlItems(){
  const tk=todayKey(), q=qlNorm(tk), out=[], now=Date.now();
  const NM={poo:'대변', pee:'소변', diar:'설사', meal:'식사'};
  ['poo','pee','diar','meal'].forEach(function(k){
    q[k].forEach(function(t,i){
      const parts=String(t||'').split('|'); const hm=String(parts[0]||'').slice(0,5);
      if(!/^\d\d:\d\d$/.test(hm)) return;
      let lbl=NM[k]; if(k==='poo' && parts[1] && QL_AMT_NM[parts[1]]) lbl+=' · '+QL_AMT_NM[parts[1]];
      out.push({t:new Date(tk+'T'+hm+':00').getTime(), hm:hm, c:k, lbl:lbl, dur:'', attr:'data-qk="'+k+'" data-qi="'+i+'"'});
    });
  });
  const seg=function(arr, c, nm, attr){
    (arr||[]).forEach(function(s,i){
      out.push({t:s.i, hm:fmtHM(s.o)+'–'+fmtHM(s.i), c:c, lbl:nm+(s.f? ' · 식사 '+s.f : '')+(s.m? ' · '+s.m : ''), dur:fmtDur(s.i-s.o), attr:attr+'="'+i+'"'});
    });
  };
  seg((S.walkLog||{})[tk], 'walk', '산책', 'data-wk');
  seg((S.sleepLog||{})[tk], 'sleep', '수면', 'data-sk');
  seg((S.awayLog||{})[tk], 'away', '혼자', 'data-ak');
  seg((S.kgLog||{})[tk], 'kg', kgName(), 'data-kk');
  const cur=function(v, c, nm, attr){ if(v) out.push({t:now+1, hm:fmtHM(v)+'–', c:c, lbl:nm, dur:fmtDur(now-v), attr:attr+'="1"', live:true}); };
  cur(S.walkCur, 'walk', '산책 중', 'data-wcur');
  cur(S.sleepCur, 'sleep', '자는 중', 'data-scur');
  cur(S.awayCur, 'away', '혼자 있는 중', 'data-acur');
  cur(S.kgCur, 'kg', kgName()+' 등원 중', 'data-kcur');
  out.sort(function(a,b){ return b.t-a.t; });
  return out;
}
function renderTimeline(){
  const el=document.getElementById('qlStamps'); if(!el) return;
  const it=tlItems();
  if(!it.length){ el.innerHTML='<p class="tl-empty">아직 오늘 기록이 없어요. 위 버튼을 누르면 지금 시각으로 저장돼요.</p>'; return; }
  const show=TL.all? it : it.slice(0,4);
  el.innerHTML=show.map(function(x){
    return '<button type="button" class="tl-row'+(x.live? ' live' : '')+'" '+x.attr+' style="--c:var(--c-'+x.c+')"><span class="tl-dot"></span><span class="tl-hm">'+x.hm+'</span><span class="tl-l">'+esc(x.lbl)+'</span><span class="tl-d">'+(x.dur||'')+'</span></button>';
  }).join('') + (it.length>4? '<button type="button" class="tl-more" data-tlall="1">'+(TL.all? '접기' : '오늘 기록 '+it.length+'건 모두 보기')+'</button>' : '');
}
function qlChipTap(e){
  if(e.target.closest('[data-tlall]')){ TL.all=!TL.all; renderTimeline(); return; }
  const r=e.target.closest('.tl-row'); if(!r) return;
  const d=r.dataset;
  if(d.qk!==undefined) qeOpen('count', d.qk, parseInt(d.qi,10));
  else if(d.wk!==undefined) qeOpen('walk', '', parseInt(d.wk,10));
  else if(d.wcur!==undefined) qeOpen('wcur');
  else if(d.sk!==undefined) qeOpen('sleep', '', parseInt(d.sk,10));
  else if(d.scur!==undefined) qeOpen('scur');
  else if(d.ak!==undefined) qeOpen('away', '', parseInt(d.ak,10));
  else if(d.acur!==undefined) qeOpen('acur');
  else if(d.kk!==undefined) kgOpen('edit', todayKey(), parseInt(d.kk,10));
  else if(d.kcur!==undefined) qeOpen('kcur');
}
function renderRibbon(){
  const svg=document.getElementById('ribSvg'); if(!svg) return;
  const tk=todayKey(), d0=new Date(tk+'T00:00:00').getTime(), D=86400000, now=Date.now();
  const X=function(ms){ return Math.max(0, Math.min(1000, (ms-d0)/D*1000)); };
  let h='<rect x="0" y="14" width="1000" height="20" class="rb-tr"/><rect x="0" y="38" width="1000" height="7" class="rb-tr2"/>';
  const bar=function(o, i, c, y, hh, live){ const a=X(o), b=X(i); if(b-a<=0) return; h+='<rect x="'+a.toFixed(1)+'" y="'+y+'" width="'+Math.max(3, b-a).toFixed(1)+'" height="'+hh+'" class="rb-'+c+(live? ' rb-live' : '')+'"/>'; };
  const segs=function(arr, c, y, hh){ (arr||[]).forEach(function(s){ bar(s.o, s.i, c, y, hh, false); }); };
  segs((S.sleepLog||{})[tk], 'sleep', 14, 20); segs((S.walkLog||{})[tk], 'walk', 14, 20); segs((S.kgLog||{})[tk], 'kg', 14, 20);
  segs((S.awayLog||{})[tk], 'away', 38, 7);
  if(S.sleepCur) bar(S.sleepCur, now, 'sleep', 14, 20, true);
  if(S.walkCur) bar(S.walkCur, now, 'walk', 14, 20, true);
  if(S.kgCur) bar(S.kgCur, now, 'kg', 14, 20, true);
  if(S.awayCur) bar(S.awayCur, now, 'away', 38, 7, true);
  const q=qlNorm(tk);
  ['meal','poo','pee','diar'].forEach(function(k){
    q[k].forEach(function(t){
      const hm=String(t||'').slice(0,5); if(!/^\d\d:\d\d$/.test(hm)) return;
      const x=X(new Date(tk+'T'+hm+':00').getTime());
      h+='<rect x="'+(x-3).toFixed(1)+'" y="1" width="6" height="10" class="rb-'+k+'"/>';
    });
  });
  const nx=X(now); h+='<rect x="'+(nx-1.5).toFixed(1)+'" y="10" width="3" height="36" class="rb-now"/>';
  svg.innerHTML=h;
  const lg=document.getElementById('ribLg'); if(!lg) return;
  const it=[]; const add=function(c, nm, arr, cur){ const m=sumSegs(arr)+(cur? now-cur : 0); if(m>0) it.push('<span style="--c:var(--c-'+c+')"><i></i>'+nm+' '+fmtClock(m)+'</span>'); };
  add('sleep','수면',(S.sleepLog||{})[tk],S.sleepCur); add('walk','산책',(S.walkLog||{})[tk],S.walkCur);
  add('kg',kgName(),(S.kgLog||{})[tk],S.kgCur); add('away','혼자',(S.awayLog||{})[tk],S.awayCur);
  const ev=[]; if(q.meal.length) ev.push(['meal','식사',q.meal.length]); if(q.poo.length) ev.push(['poo','대변',q.poo.length]); if(q.pee.length) ev.push(['pee','소변',q.pee.length]); if(q.diar.length) ev.push(['diar','설사',q.diar.length]);
  ev.forEach(function(x){ it.push('<span style="--c:var(--c-'+x[0]+')"><i></i>'+x[1]+' '+x[2]+'</span>'); });
  lg.innerHTML=it.join('');
}
function renderNow(){
  const el=document.getElementById('nowAct'); if(!el) return;
  const rows=[], now=Date.now();
  const ED={kcur:'등원 수정', wcur:'시작 수정', scur:'취침 수정', acur:'외출 수정'};   /* V6.2.1 */
  const row=function(c, ic, title, sub, btn, act, edit){
    rows.push('<div class="now-row" style="--c:var(--c-'+c+')"><button type="button" class="now-main" data-nedit="'+edit+'"><span class="now-ic"><svg class="ico"><use href="#'+ic+'"/></svg></span><span class="now-tx"><b>'+title+'</b><span class="now-sb">'+sub.split(' · ').map(function(x){ return '<i>'+x+'</i>'; }).join('')+'</span></span></button><button type="button" class="now-ed" data-nedit="'+edit+'">'+ED[edit]+'</button><button type="button" class="now-btn" data-nact="'+act+'">'+btn+'</button></div>');
  };
  if(S.kgCur) row('kg', 'i-bag', esc(kgName())+' 등원 중', fmtHM(S.kgCur)+' 등원 · '+fmtDur(now-S.kgCur)+'째'+kgPassTxt(), '하원', 'kg', 'kcur');
  if(S.walkCur) row('walk', 'i-paw', '산책 중', fmtHM(S.walkCur)+' 시작 · '+fmtDur(now-S.walkCur)+'째', '종료', 'walk', 'wcur');
  if(S.sleepCur) row('sleep', 'i-moon', '자는 중', fmtHM(S.sleepCur)+' 취침 · '+fmtDur(now-S.sleepCur)+'째', '기상', 'sleep', 'scur');
  if(S.awayCur){
    row('away', 'i-door', '혼자 있는 중', fmtHM(S.awayCur)+' 외출 · '+fmtDur(now-S.awayCur)+'째', '귀가', 'away', 'acur');
    if(now-S.awayCur>12*3600000) rows.push('<div class="now-warn">12시간이 넘었어요. 귀가 버튼을 잊으셨나요? <button type="button" class="lnk" data-nact="awayx">이 외출 취소</button></div>');
  }
  el.innerHTML=rows.join('');
}
function nowTap(e){
  const a=e.target.closest('[data-nact]');
  if(a){
    const k=a.dataset.nact;
    if(k==='kg') kgOpen('end');
    else if(k==='walk') walkToggle();
    else if(k==='sleep') sleepToggle();
    else if(k==='away') awayEnd(false);
    else if(k==='awayx'){
      uiConfirm({msg:'이 외출 기록을 취소할까요? 시간이 저장되지 않습니다.', ok:'외출 취소', destr:true}).then(function(ok){ if(!ok) return; S.awayCur=0; saveState(); renderQlog(); });
    }
    return;
  }
  const ed=e.target.closest('[data-nedit]');
  if(ed) qeOpen(ed.dataset.nedit);                                   /* V6.2.1: 유치원도 등원 시각 수정 시트 — 하원은 하원 버튼 */
}
function openWtSheet(){
  const ov=document.getElementById('wtOvl'), inp=document.getElementById('wtInput'); if(!ov || !inp) return;
  const lw=latestWeight();
  inp.value = lw? lw.kg : '';
  const pv=document.getElementById('wtPrev'); if(pv) pv.textContent = lw? '최근: '+lw.kg+'kg ('+lw.d.slice(5).replace('-','/')+')' : '첫 체중 기록입니다.';
  ov.classList.add('on');
  setTimeout(function(){ try{ inp.focus(); inp.select(); }catch(e){} }, 60);
}
function bindQlog(){
  const on=function(id, fn){ const el=document.getElementById(id); if(el) el.addEventListener('click', fn); return el; };
  if(!document.getElementById('qlPoo')) return;
  on('qlPoo', function(){ qlBump('poo',1); });
  on('qlPee', function(){ qlBump('pee',1); });
  on('qlDiar', function(){ qlBump('diar',1); });
  on('qlMeal', async function(){
    const lm=lastMealTs();
    if(lm && (Date.now()-lm) < 2*3600000){
      if(!(await askConfirm('마지막 식사가 '+fmtDur(Date.now()-lm)+' 전입니다. 중복 급여일 수 있어요. 그래도 기록할까요?'))) return;
    }
    qlBump('meal',1);
  });
  on('qlWalk', walkToggle); on('qlSleep', sleepToggle); on('qlKg', kgTap); on('qlAway', awayTap);
  on('qlStats', function(){ goTab('stats'); }); on('ribStats', function(){ goTab('stats'); });
  on('qlWt', openWtSheet); on('homeWt', openWtSheet);
  on('qlPhoto', function(){ goTab('album'); if(syncConfigured()){ setTimeout(function(){ const f=document.getElementById('albFile'); if(f) f.click(); }, 400); } });
  const st=document.getElementById('qlStamps'); if(st) st.addEventListener('click', qlChipTap);
  /* V5.4: 홈캠(헤이홈 앱) — OS별 링크 */
  const cb=document.getElementById('qlCam'); if(cb){
    const ua=navigator.userAgent||'';
    if(/android/i.test(ua)){ cb.href='intent://#Intent;package=com.goqual;S.browser_fallback_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.goqual;end'; }
    else if(/iphone|ipad|ipod/i.test(ua)){ cb.href='https://apps.apple.com/kr/app/id1435783535'; }
    else{ cb.href='https://play.google.com/store/apps/details?id=com.goqual'; cb.target='_blank'; }
  }
  setInterval(function(){ if(v6SheetOpen()) return; if(S.walkCur||S.sleepCur||S.awayCur||S.kgCur) renderQlog(); }, 30000);
}

/* =============== V6: 대표사진 — 확인 시트 + 되돌리기 =============== */
const REP={id:'', th:''};
function bindRep(){
  const b=document.getElementById('albLbRep'); if(!b) return;
  b.addEventListener('click', function(){ if(ALB.cur) repAsk(ALB.cur); });
}
async function repAsk(id){
  if(S.rep && S.rep.id===id){ uiToast('이미 대표 사진이에요'); return; }
  let th=ALB.thumbs.get(id);
  if(!th){ try{ th=await albImgSrc('th', id); if(th) ALB.thumbs.set(id, th); }catch(e){} }
  if(!th){ uiAlert('사진을 아직 불러오지 못했습니다. 잠시 후 다시 눌러주세요.'); return; }
  REP.id=id; REP.th=th;
  const put=function(elId, src){ const el=document.getElementById(elId); if(!el) return; el.innerHTML= src? '<img alt="" src="'+String(src).replace(/"/g,'&quot;')+'">' : '<span>🐾</span>'; };
  put('repNew', th); put('repOld', '');
  document.getElementById('repOvl').classList.add('on');
  if(S.rep && S.rep.id){
    let cur=ALB.thumbs.get(S.rep.id)||'';
    if(!cur && S.rep.th && String(S.rep.th).indexOf('blob:')!==0) cur=S.rep.th;
    if(!cur){ try{ cur=await albImgSrc('th', S.rep.id); }catch(e){} }
    if(REP.id===id) put('repOld', cur);
  }
}
function repHide(){ const o=document.getElementById('repOvl'); if(o) o.classList.remove('on'); }
function repConfirm(){
  if(!REP.id){ repHide(); return; }
  const prev=S.rep? JSON.parse(JSON.stringify(S.rep)) : {id:'', th:''};
  const th=REP.th;
  S.rep={id:REP.id, th:(String(th).indexOf('blob:')===0 ? '' : th)};
  saveState(); applyRepDraw(th); repHide(); REP.id='';
  uiToast('대표 사진을 바꿨어요', function(){ S.rep=prev; saveState(); applyRep(); });
}
function lbMore(){
  if(!ALB.cur) return;
  const isRep=!!(S.rep && S.rep.id===ALB.cur);
  const items=[
    {label: isRep? '현재 대표 사진' : '대표 사진으로 설정', disabled:isRep, k:'albLbRep'},
    {label:'메모 수정', k:'albLbMemo'},
    {label:'삭제', destr:true, k:'albLbDel'}
  ];
  uiActions('', items).then(function(ix){ if(ix<0) return; const b=document.getElementById(items[ix].k); if(b) b.click(); });
}


/* =============== V5.9: 영상 파일 저장소 (Cloudflare Worker + R2) =============== */
const MEDIA={PART:10*1024*1024, SINGLE_MAX:20*1024*1024, WARN:500*1024*1024, up:false};
function albIsPhoto(m){ return !!m && m.t!=='v' && m.t!=='r'; }
function mediaUrl(){ return String((S.media&&S.media.url)||'').trim().replace(/\/+$/,''); }
function mediaConfigured(){ return !!mediaUrl() && !!syncConfigured(); }
function mediaApi(path, params){
  let q='fam='+encodeURIComponent(SYNC.code);
  Object.keys(params||{}).forEach(function(k){ q+='&'+k+'='+encodeURIComponent(params[k]); });
  return mediaUrl()+path+'?'+q;
}
function mediaDur(sec){ sec=Math.max(0,Math.round(sec||0)); const m=Math.floor(sec/60), s=sec%60; return m+':'+String(s).padStart(2,'0'); }
function mediaExt(file){
  const n=String((file&&file.name)||'').toLowerCase(); const m=n.match(/\.(mp4|mov|m4v|webm|3gp)$/);
  if(m) return m[1];
  const t=String((file&&file.type)||'').toLowerCase();
  if(t.indexOf('webm')>-1) return 'webm'; if(t.indexOf('quicktime')>-1) return 'mov'; if(t.indexOf('3gpp')>-1) return '3gp';
  return 'mp4';
}
/* 조각 계획: 20MB 이하 한 번에, 초과 시 10MB 조각(마지막만 작을 수 있음) */
function mediaPlan(size, part){
  part=part||MEDIA.PART;
  if(size<=MEDIA.SINGLE_MAX) return {mode:'single', parts:1, part:size};
  return {mode:'multi', parts:Math.ceil(size/part), part:part};
}
async function mediaFetch(url, opts, ms){
  const ctl=new AbortController(); const to=setTimeout(function(){ ctl.abort(); }, ms||30000);
  try{
    const r=await fetch(url, Object.assign({}, opts||{}, {signal:ctl.signal}));
    let j=null; try{ j=await r.json(); }catch(e){}
    if(!r.ok || !j || j.ok===false) throw new Error((j&&j.error)||('HTTP '+r.status));
    return j;
  }finally{ clearTimeout(to); }
}
async function mediaUpload(file, key, ct, onProg){
  const plan=mediaPlan(file.size);
  if(plan.mode==='single'){
    await mediaFetch(mediaApi('/put',{key:key, ct:ct}), {method:'PUT', body:file}, 240000);
    if(onProg) onProg(1); return;
  }
  const cr=await mediaFetch(mediaApi('/create',{key:key, ct:ct}), {method:'POST'}, 30000);
  const parts=[];
  try{
    for(let i=0;i<plan.parts;i++){
      const chunk=file.slice(i*plan.part, Math.min(file.size,(i+1)*plan.part));
      let res=null;
      for(let tr=0;;tr++){
        try{ res=await mediaFetch(mediaApi('/part',{key:key, uploadId:cr.uploadId, n:i+1}), {method:'PUT', body:chunk}, 180000); break; }
        catch(e){ if(tr>=2) throw e; }
      }
      parts.push({partNumber:i+1, etag:res.etag});
      if(onProg) onProg((i+1)/plan.parts);
    }
    await mediaFetch(mediaApi('/complete',{key:key, uploadId:cr.uploadId}), {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({parts:parts})}, 60000);
  }catch(e){
    try{ await mediaFetch(mediaApi('/abort',{key:key, uploadId:cr.uploadId}), {method:'POST'}, 15000); }catch(e2){}
    throw e;
  }
}
/* V5.9.3: 썸네일 추출 공통 — 파일(blob) 또는 저장소 URL(cross-origin). 아이폰 사파리는 탐색만으로 프레임이 안 나올 수 있어 재생 폴백 포함.
   실패해도 업로드는 진행(th:0)하고, 다른 기기에서 앨범을 열 때 albRepairThumbs()가 채워 넣음 */
function videoThumbFrom(src, maxSide, q, remote){
  return new Promise(function(res, rej){
    const v=document.createElement('video');
    v.muted=true; v.playsInline=true; v.preload='auto'; if(remote) v.crossOrigin='anonymous';
    let done=false, sought=false; const timers=[];
    function cleanup(){ timers.forEach(clearTimeout); try{ v.pause(); }catch(e){} v.removeAttribute('src'); try{ v.load(); }catch(e){} }
    function finish(){
      if(done) return; done=true;
      try{
        const W=v.videoWidth||0, H=v.videoHeight||0; if(!W||!H) throw new Error('nosize');
        const sc=Math.min(1, maxSide/Math.max(W,H));
        const c=document.createElement('canvas'); c.width=Math.max(1,Math.round(W*sc)); c.height=Math.max(1,Math.round(H*sc));
        c.getContext('2d').drawImage(v,0,0,c.width,c.height);
        const out={data:c.toDataURL('image/jpeg', q), dur:(isFinite(v.duration)&&v.duration>0)?v.duration:0};
        cleanup(); res(out);
      }catch(e){ cleanup(); rej(e); }
    }
    function seek(){ if(sought) return; sought=true; try{ v.currentTime=Math.min(0.5, ((isFinite(v.duration)&&v.duration>0)?v.duration:1)/2); }catch(e){ finish(); } }
    v.addEventListener('loadedmetadata', seek);
    v.addEventListener('loadeddata', seek);
    v.addEventListener('seeked', finish);
    v.addEventListener('timeupdate', function(){ if(!done && !v.seeking && v.currentTime>0.05 && v.readyState>=2) finish(); });
    v.addEventListener('error', function(){ cleanup(); rej(new Error('decode')); });
    timers.push(setTimeout(function(){ if(done) return; try{ const p=v.play(); if(p&&p.catch) p.catch(function(){}); }catch(e){} }, 2500));   /* 아이폰 폴백 */
    timers.push(setTimeout(function(){ if(!done){ if(v.readyState>=2) finish(); else { cleanup(); rej(new Error('timeout')); } } }, 15000));
    v.src=src;
  });
}
function videoThumb(file, maxSide, q){
  const url=URL.createObjectURL(file);
  return videoThumbFrom(url, maxSide, q, false).then(function(r){ URL.revokeObjectURL(url); return r; }, function(e){ URL.revokeObjectURL(url); throw e; });
}
/* 썸네일 없는 영상(th:0)을 보는 쪽 기기에서 채워 넣기 — 올린 폰에서 추출에 실패한 경우(아이폰 등) 대비. 한 번에 3개, 같은 세션에서 실패한 건 재시도 안 함 */
async function albRepairThumbs(){
  if(!mediaConfigured() || !ALB.meta || ALB.repairing) return;
  ALB.repairTried=ALB.repairTried||{};
  const ids=Object.keys(ALB.meta).filter(function(id){ const m=ALB.meta[id]; return m && m.t==='r' && !m.th && m.k && !ALB.repairTried[id]; }).slice(0,3);
  if(!ids.length) return;
  ALB.repairing=true; let changed=false;
  try{
    for(let i=0;i<ids.length;i++){
      const id=ids[i], m=ALB.meta[id]; ALB.repairTried[id]=1;
      try{
        const t=await videoThumbFrom(mediaApi('/file/'+m.k), 360, 0.7, true);
        await albFetch('th/'+id,'PUT',JSON.stringify(t.data));
        m.th=1; m.s=t.data.length; if(!m.dur && t.dur) m.dur=Math.round(t.dur);
        await albFetch('meta/'+id,'PUT',JSON.stringify(m));
        ALB.thumbs.set(id,t.data); changed=true;
      }catch(e){}
    }
    if(changed){ await albBumpIdx(); renderAlbum(); }
  }finally{ ALB.repairing=false; }
}
function albProg(p){
  const box=document.getElementById('albProg'), bar=document.getElementById('albProgBar'); if(!box||!bar) return;
  if(p===null){ box.classList.remove('on'); bar.style.width='0'; return; }
  box.classList.add('on'); bar.style.width=Math.round(p*100)+'%';
}
function ytId(u){
  const m=/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/))([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])/.exec(String(u||''));
  return m ? m[1] : '';
}
function renderMediaCfg(){
  const sum=document.getElementById('mediaSum'), inp=document.getElementById('mediaUrl'); if(!sum) return;
  const u=mediaUrl();
  sum.innerHTML = u ? '&#127909; 영상 저장소 연결됨' : '&#127909; 영상 저장소 연결 — 설정 안 됨';
  if(inp && document.activeElement!==inp && !inp.value) inp.value=u;
  const b=document.getElementById('albVidUp'); if(b) b.classList.toggle('off', !u);
  const st=document.getElementById('albStore');
  if(st){
    const s=ALB.store||{bytes:0,fbb:0,p2b:0,vb:0};
    st.innerHTML = (s.fbb>0 || !u)
      ? ('사진 저장 '+(s.fbb/1048576).toFixed(1)+'MB / 1,000MB'
         +(u ? ' · 영상 저장 '+((s.vb+s.p2b)/1048576).toFixed(0)+'MB / 10,000MB' : ' · <b>영상 저장소 미연결</b> — 오른쪽 ⚙ 에서 연결'))
      : ('사진·영상 저장 '+((s.vb+s.p2b)/1048576).toFixed(0)+'MB / 10,000MB');
    try{ renderMigPanel(); }catch(e){}
  }
}
async function mediaConnect(){
  const inp=document.getElementById('mediaUrl'), st=document.getElementById('mediaStat');
  const u=String(inp.value||'').trim().replace(/\/+$/,'');
  if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요. 영상 저장소는 같은 가족 코드로 잠깁니다.'); return; }
  if(!/^https:\/\/.+/.test(u)){ alert('주소는 https:// 로 시작해야 합니다. Cloudflare Worker 화면의 주소를 그대로 붙여넣어 주세요.'); return; }
  st.textContent='확인 중…';
  const prev=(S.media&&S.media.url)||'';
  S.media=S.media||{}; S.media.url=u;
  try{
    await mediaFetch(mediaApi('/ping'), {method:'GET'}, 15000);
    saveState(); renderMediaCfg();
    st.textContent='연결됨 — 이제 "영상 올리기"를 쓸 수 있습니다. (상대 폰은 동기화 후 자동 반영)';
    if(!prev) document.getElementById('mediaCfg').open=false;
  }catch(e){
    S.media.url=prev;
    const msg=String(e&&e.message||e);
    st.textContent = /가족 코드/.test(msg) ? '가족 코드가 다릅니다 — Worker의 FAM 값을 핸드북 가족 코드와 똑같이 넣어주세요.'
                   : /MEDIA|FAM/.test(msg) ? 'Worker 설정 누락: '+msg
                   : '연결 실패 — 주소를 확인해주세요. ('+msg+')';
    renderMediaCfg();
  }
}
async function albVideoUpload(file){
  if(!file) return;
  if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; }
  if(!mediaConfigured()){ document.getElementById('mediaCfg').open=true; alert('영상 저장소가 아직 연결되지 않았습니다. 아래 "영상 저장소 연결"에 Worker 주소를 넣어주세요.'); return; }
  if(MEDIA.up){ alert('이미 올리는 중입니다. 끝난 뒤 다시 시도해주세요.'); return; }
  if(file.size>MEDIA.WARN && !(await askConfirm('영상이 '+Math.round(file.size/1048576)+'MB로 큽니다. 와이파이에서 올리는 걸 권장합니다. 계속할까요?'))) return;
  MEDIA.up=true; let wl=null;
  try{ if(navigator.wakeLock) wl=await navigator.wakeLock.request('screen'); }catch(e){}
  const ext=mediaExt(file), ct=(file.type&&/^video\//.test(file.type))?file.type:'video/mp4';
  const id=albNewId();
  const key='v/'+id+'.'+ext;
  let th=null, dur=0;
  try{
    albStat('썸네일 만드는 중…');
    try{ const t=await videoThumb(file,360,0.7); th=t.data; dur=t.dur; }catch(e){ th=null; }
    albStat('영상 올리는 중 0% — 화면을 끄지 마세요'); albProg(0);
    await mediaUpload(file, key, ct, function(p){ albStat('영상 올리는 중 '+Math.round(p*100)+'% — 화면을 끄지 마세요'); albProg(p); });
    albStat('마무리 중…');
    if(th) await albFetch('th/'+id,'PUT',JSON.stringify(th));
    const meta={t:'r', d:todayKey(), m:'', at:Date.now(), s:th?th.length:0, vs:file.size, k:key, ct:ct, dur:Math.round(dur||0), th:th?1:0};
    try{ const sd=await vidShotDate(file); if(sd) meta.sd=sd; }catch(e){}   /* V6.5 */
    await albFetch('meta/'+id,'PUT',JSON.stringify(meta));
    await albBumpIdx();
    ALB.meta=ALB.meta||{}; ALB.meta[id]=meta; if(th) ALB.thumbs.set(id,th);
    albProg(null); renderAlbum();
    if(!th) setTimeout(function(){ albRepairThumbs(); }, 500);   /* V5.9.3: 올린 폰에서 실패하면 저장본으로 재시도 */
  }catch(e){
    albProg(null);
    try{ await mediaFetch(mediaApi('/file/'+key), {method:'DELETE'}, 15000); }catch(e2){}
    albStat('영상 업로드 실패 — '+String(e&&e.message||e));
    alert('영상 업로드에 실패했습니다. 인터넷 확인 후 다시 시도해주세요.\n('+String(e&&e.message||e)+')');
    renderAlbumHead();
  }finally{ MEDIA.up=false; try{ if(wl) wl.release(); }catch(e){} }
}

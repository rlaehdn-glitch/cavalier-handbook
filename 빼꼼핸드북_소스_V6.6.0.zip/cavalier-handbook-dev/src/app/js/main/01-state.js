/* =============== State =============== */
const APP_VER='__APP_VER__', APP_DATE='__APP_DATE__';   /* V6.6: 앱 버전 — dev/VERSION 한 곳에서 빌드할 때 채움 */
const DEFAULT_S = {profile:{name:'',birth:'',home:'',reg:''}, vet:{main:'',e24:''}, checks:{}, vax:{}, daily:{}, weight:[], visits:[], expenses:[], events:[], qlog:{}, awayCur:0, awayLog:{}, walkCur:0, walkLog:{}, sleepCur:0, sleepLog:{}, feed:{kcal:4000, meals:4, adult:0, adultMode:'auto', bcs:'ok', bcsAt:'', neut:0, treat:0, vetG:0, vetAt:''}, ntc:[], rep:{id:'',th:''}, notice:{text:'',by:'',at:0,day:''}, media:{url:''}, kgCur:0, kgLog:{}, kgCfg:{name:'도그스테이', pass:0, from:''}, marks:{}};
let S = JSON.parse(JSON.stringify(DEFAULT_S));
let storageOK = false, artOK = false, saveTimer = null, lastEditAt = 0;

function esc(s){return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function todayKey(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}

function lsGet(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
function lsSet(k,v){ try{ localStorage.setItem(k,v); return true; }catch(e){ return false; } }
async function loadState(){
  artOK = (typeof window.storage!=='undefined' && window.storage && typeof window.storage.get==='function');
  let raw=null;
  if(artOK){
    try{ const r=await window.storage.get('ckcs-data'); if(r && r.value) raw=r.value; }catch(e){ /* 첫 실행 */ }
  }
  if(!raw) raw=lsGet('ckcs-data');
  if(raw){ try{ const p=JSON.parse(raw); S=Object.assign(JSON.parse(JSON.stringify(DEFAULT_S)), p); }catch(e){} }
  storageOK = artOK || lsSet('__probe','1');
}
function persistLocal(){
  const raw=JSON.stringify(S);
  let ok=lsSet('ckcs-data', raw);
  if(!ok){   /* V6.6(R1): 저장공간 부족 — 다시 받을 수 있는 것(산책 경로 캐시·대표사진·동기화 임시본)부터 비우고 재시도, 그래도 안 되면 경고 */
    try{ if(typeof wgCacheSave==='function') wgCacheSave(wgCacheAll(), 2); }catch(e){}
    try{ localStorage.removeItem('_hero_v1'); localStorage.removeItem('_sync_par'); }catch(e){}
    ok=lsSet('ckcs-data', raw);
    if(!ok) logErr('이 폰 저장', '저장공간 부족 — 기록 '+Math.round(raw.length/1024)+'KB를 이 폰에 저장하지 못함');
  }
  try{ lsWarnPaint(!ok); }catch(e){}
  if(artOK){ try{ window.storage.set('ckcs-data', raw); }catch(e){ console.error('save fail', e); } }
}
function saveCommit(){
  clearTimeout(saveTimer); saveTimer=null;
  // 오래된 일일 체크 정리(최근 90일만 유지)
  const keys=Object.keys(S.daily).sort();
  while(keys.length>90){ delete S.daily[keys.shift()]; }
  S._at=Date.now(); S._dev=DEV_ID;
  persistLocal();
  syncPushSoon();
}
function saveState(){
  clearTimeout(saveTimer);
  lastEditAt=Date.now();
  saveTimer=setTimeout(saveCommit, 500);
}
/* V5.15: 화면을 끄거나 앱을 닫을 때 — 대기 중인 저장·업로드를 즉시 확정한다.
   (예전에는 탭 직후 폰을 잠그면 500ms 저장 타이머가 얼어 기록 자체가 남지 않았다) */
function saveFlush(){
  if(saveTimer) saveCommit();
  if(SYNC.dirty || SYNC.pushT){ clearTimeout(SYNC.pushT); SYNC.pushT=null; try{ syncPushNow(); }catch(e){} }
}


/* =============== Init =============== */
/* V6.6: 화면 그리기·시작 순서를 단계별로 보호 — 한 단계가 실패해도 오류 기록함에 남기고 다음 단계(동기화 시작 등)는 계속한다. */
const RENDERS=[['프로필', function(){ seedProfile(); }], ['홈', function(){ renderHome(); }], ['오늘 루틴', function(){ renderDaily(); }], ['체중', function(){ renderWeight(); }],
  ['병원', function(){ renderVisits(); }], ['지출', function(){ renderExpenses(); }], ['저장 상태', function(){ renderStorage(); }], ['달력', function(){ renderCal(); }],
  ['공지', function(){ renderNotice(); }], ['대시보드', function(){ renderDash(); }], ['지출 그래프', function(){ renderEChart(); }], ['서재', function(){ renderLib(); }],
  ['외출', function(){ renderAway(); }], ['급여', function(){ renderFeed(); }], ['홈 채팅', function(){ renderHomeChat(); }], ['유치원 설정', function(){ kgCfgPaint(); }],
  ['영상 저장소', function(){ renderMediaCfg(); }], ['홈캠', function(){ camCheck(); }], ['입력칸', renderInputs]];
function renderAll(){ RENDERS.forEach(function(r){ safely('화면: '+r[0], r[1]); }); }
/* 가져오기·동기화 뒤 입력칸·체크리스트를 기록과 맞춘다 */
function renderInputs(){
  const map={pfName:'name', pfBirth:'birth', pfHome:'home', pfReg:'reg'};
  Object.keys(map).forEach(id=>{ document.getElementById(id).value=S.profile[map[id]]||''; });
  document.getElementById('vetMain').value=S.vet.main||''; document.getElementById('vet24').value=S.vet.e24||'';
  document.querySelectorAll('ul.ck[data-store]').forEach(ul=>{
    ul.querySelectorAll('input[type=checkbox]').forEach(cb=>{
      const key=ul.dataset.store+':'+cb.id; cb.checked=!!S.checks[key];
      const lb=ul.querySelector('label[for="'+cb.id+'"]'); if(lb) lb.classList.toggle('done', !!S.checks[key]);
    });
  });
  document.querySelectorAll('#vaxTable tr[data-vx]').forEach(tr=>{
    const v=S.vax[tr.dataset.vx]||{};
    tr.querySelector('.vx-done').checked=!!v.done;
    tr.querySelector('.vx-date').value=v.date||'';
  });
}
const BINDS=[['체크리스트', bindChecklists], ['접종', bindVax], ['프로필', bindProfile], ['체중', bindWeight], ['병원', bindVisits], ['지출', bindExpenses], ['백업 텍스트', bindIO],
  ['달력', bindCal], ['장 이동', buildPagers], ['구매 링크', buildLinks], ['표', mobileTables], ['스크롤 효과', initReveal], ['맨 위로', initTopBtn], ['동기화 설정', loadSyncCfg],
  ['동기화', bindSync], ['앨범', bindAlbum], ['홈캠', bindCam], ['공지', bindNotice], ['화면 이동', bindNav], ['응급', bindSOS], ['빠른 기록', bindQlog], ['서재', bindLib],
  ['대표사진', bindRep], ['외출', bindAway], ['통계', bindStats], ['체중 시트', bindWt], ['급여', bindFeed], ['파일 백업', bindBackup], ['자정', bindMidnight], ['채팅', bindChat],
  ['장 안 링크', bindAnchors], ['대변 양', bindPooAmt], ['빠른 수정', bindQe], ['사진 이관', bindMig], ['공지 정리', ntcMigrate], ['V6 화면', bindV6], ['앨범 백업', bindAlbBackup],
  ['화면 관리', navInit], ['진단', bindDiag]];
document.addEventListener('DOMContentLoaded', async ()=>{
  try{ await loadState(); }catch(e){ logErr('시작: 기록 읽기', e); }
  BINDS.forEach(function(b){ safely('시작: '+b[0], b[1]); });
  ['vDate','eDate'].forEach(function(i){ const el=document.getElementById(i); if(el && !el.value) el.value=todayKey(); });
  renderAll();
  safely('시작: 첫 화면', function(){
    const h0=(location.hash||'').slice(1);
    if(h0 && h0!=='home' && document.getElementById('tab-'+h0)){ goTab(h0, true); NAV_HIST=['home', h0]; }
    history.replaceState({tab:(h0 && document.getElementById('tab-'+h0)) ? h0 : 'home', d:((history.state && history.state.d)||0), ly:0}, '', location.hash||'#home');
  });
  if(SYNC.on) safely('시작: 동기화', startSync);
  if(syncConfigured()){
    safely('시작: 앨범', function(){ albumPull(true); });
    safely('시작: 채팅', chatStart);
    safely('시작: 기기 보고', function(){ albVerBeat(); albP2Load(); setTimeout(function(){ safely('사진 이관 확인', albMigRefresh); }, 1500); });   /* V5.12 */
  }
  safely('시작: 산책 지도', walkInit);   /* V6.3 */
});

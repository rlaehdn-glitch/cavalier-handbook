/* =============== 15 성장 앨범 =============== */
const ALB={meta:null, thumbs:new Map(), fulls:new Map(), shown:24, lastRev:null, busy:false, cur:null, filter:'all', store:null, repairing:false, repairTried:{}, likeBusy:false};
function albPath(p){ return SYNC.url.replace(/\/+$/,'')+'/handbook/'+SYNC.code+'-album/'+p+'.json'; }
/* V6.6: 앨범 항목 ID 한 곳(사진·영상·유튜브·산책 중 사진 — 예전엔 같은 식이 5곳에 따로) */
function albNewId(){ return 'a'+Date.now().toString(36)+Math.random().toString(36).slice(2,6); }
async function albFetch(p, method, body){
  const ctl=new AbortController(); const to=setTimeout(function(){ ctl.abort(); }, 20000);
  try{
    const r=await fetch(albPath(p), {method:method||'GET', body:body||undefined, signal:ctl.signal});
    if(!r.ok) throw new Error('HTTP '+r.status);
    return await r.json();
  }finally{ clearTimeout(to); }
}
function albStat(msg){ const el=document.getElementById('albStat'); if(el) el.textContent=msg; }
function renderAlbumHead(){
  if(!ALB.meta) return;
  let p=0,v=0,fbb=0,p2b=0,vb=0;
  Object.values(ALB.meta).forEach(function(m){
    if(m.t==='v'||m.t==='r'){ v++; vb+=(m.vs||0); }        /* 영상 썸네일(m.s)은 수십 KB 고정 — 사진 용량 집계에서 제외 */
    else { p++; if(m.p2) p2b+=(m.s||0); else fbb+=(m.s||0); }
  });
  albStat('사진 '+p+' · 영상 '+v);
  ALB.store={bytes:fbb+p2b, fbb:fbb, p2b:p2b, vb:vb};
  renderMediaCfg();
  try{ shBadge(); }catch(e){}   /* V6.5 */
}
function albumOnOpen(){
  const gate=document.getElementById('albGate'), main=document.getElementById('albMain');
  if(!gate) return;
  try{ renderMediaCfg(); }catch(e){}
  if(syncConfigured()){ gate.style.display='none'; main.style.display='block'; albumPull(true); }
  else{ gate.style.display='block'; main.style.display='none'; }
}
async function albumPull(force){
  if(!syncConfigured()||ALB.busy) return;
  ALB.busy=true;
  try{
    const idx=await albFetch('idx');
    const rev=(idx&&idx.rev)||0;
    if(force || rev!==ALB.lastRev || !ALB.meta){
      const meta=await albFetch('meta');
      ALB.meta=meta||{}; ALB.lastRev=rev;
      renderAlbum();
      try{ repOnMeta(); }catch(e){}   /* V6.0.6: 앨범 정보가 오면 대표사진 다시 */
      setTimeout(function(){ albRepairThumbs(); }, 300);   /* V5.9.3 */
    }
  }catch(e){ logErr('앨범 불러오기', e); albStat('불러오기 실패 — 인터넷 확인 후 "새로고침"을 눌러주세요.'); }
  finally{ ALB.busy=false; }
}
const albThIO=('IntersectionObserver' in window)? new IntersectionObserver(function(es){
  es.forEach(function(en){
    if(!en.isIntersecting) return;
    const img=en.target, id=img.dataset.aid;
    albThIO.unobserve(img);
    albImgSrc('th',id).then(function(v){ if(v){ ALB.thumbs.set(id,v); img.src=v; img.classList.add('ld'); } }).catch(function(e){ img.classList.add('err'); albErrNote(id, e); });
  });
},{rootMargin:'250px'}) : null;
function renderAlbum(){
  renderAlbumHead(); renderCompare(); renderStrip();
  const grid=document.getElementById('albGrid'); if(!grid||!ALB.meta) return;
  /* V5.9.2: 보기 필터(전체·사진·영상) */
  const f=ALB.filter||'all';
  const ids=Object.keys(ALB.meta)
    .filter(function(id){ const m=ALB.meta[id]; return f==='all' || (f==='p' ? albIsPhoto(m) : f==='l' ? albLikeCount(m)>0 : (m.t==='r'||m.t==='v')); })
    .sort(function(a,b){ return (ALB.meta[b].at||0)-(ALB.meta[a].at||0); });
  const show=ids.slice(0,ALB.shown);
  let out='', lastMon='';
  show.forEach(function(id){
    const m=ALB.meta[id]; const d=m.d||'';
    const gk = S.profile.birth ? albAgeIdx(d) : d.slice(0,7);
    if(gk!==null && gk!=='' && gk!==lastMon){
      lastMon=gk;
      out+= S.profile.birth ? albAgeHead(gk) : '<div class="alb-mon">'+esc(String(gk).replace('-','년 '))+'월</div>';
    }
    const dd=esc(d.slice(5).replace('-','.'));
    const memo = m.m ? '<span class="m">'+esc(m.m)+'</span>' : '';
    const lc=albLikeCount(m), lkb = lc ? '<span class="alb-lkb">&#10084; '+lc+'</span>' : '';   /* V5.11 */
    if(m.t==='v'){
      /* V5.9.2: 유튜브 링크 — 영상 ID를 읽어 썸네일 표시, 누르면 유튜브로 */
      const yid=ytId(m.u);
      out+='<a class="alb-cell'+(yid?'':' alb-vid')+(ALB.selOn?' alb-nosel':'')+'" data-lid="'+id+'" href="'+esc(m.u||'#')+'" target="_blank" rel="noopener">'
        +(yid?'<img class="alb-th ld" src="https://i.ytimg.com/vi/'+yid+'/mqdefault.jpg" loading="lazy" alt="">':'<span class="alb-play">&#9654;</span><span class="alb-vm">'+esc(m.m||'유튜브')+'</span>')
        +'<span class="alb-badge">&#9654; 유튜브</span>'+lkb+'<span class="alb-d">'+(yid?memo:'')+dd+'</span></a>';
    }else if(m.t==='r'){
      /* V5.9: R2 영상 — 썸네일은 사진과 같은 th/ 경로, 탭하면 라이트박스에서 재생 */
      out+='<div class="alb-cell alb-rv'+albSelCls(id)+'" data-open="'+id+'">'+(m.th?'<img class="alb-th" data-aid="'+id+'" alt="">':'')
        +'<span class="alb-badge">&#9654; '+(m.dur?mediaDur(m.dur):'영상')+'</span>'+lkb+albUseB(m)+'<span class="alb-d">'+memo+dd+'</span><span class="alb-ck"></span></div>';
    }else{
      out+='<div class="alb-cell'+albSelCls(id)+'" data-open="'+id+'"><img class="alb-th" data-aid="'+id+'" alt="">'+lkb+albUseB(m)+'<span class="alb-d">'+dd+'</span><span class="alb-ck"></span></div>';
    }
  });
  const empty = f==='l' ? '아직 좋아요가 없습니다. 사진을 크게 열고 ♡ 를 누르거나, 사진을 두 번 톡톡 두드려 보세요.'
              : f==='v' ? '아직 영상이 없습니다. 위의 🎬 영상 버튼으로 첫 영상을 올려보세요.'
              : f==='p' ? '아직 사진이 없습니다. 위의 📷 사진 버튼으로 첫 장을 남겨보세요.'
              : '아직 사진이 없습니다. 위의 📷 사진 버튼으로 첫 장을 남겨보세요.';
  grid.innerHTML = out || '<p class="alb-empty">'+empty+'</p>';
  document.getElementById('albMore').style.display = ids.length>ALB.shown ? 'inline-block' : 'none';
  grid.querySelectorAll('img.alb-th[data-aid]').forEach(function(img){   /* V5.9.2: 유튜브 썸네일(외부 src)은 제외 */
    const id=img.dataset.aid;
    if(ALB.thumbs.has(id)){ img.src=ALB.thumbs.get(id); img.classList.add('ld'); }
    else if(albThIO){ albThIO.observe(img); }
    else{ albImgSrc('th',id).then(function(v){ if(v){ img.src=v; img.classList.add('ld'); ALB.thumbs.set(id,v); } }).catch(function(e){ img.classList.add('err'); albErrNote(id, e); }); }
  });
}
function albCompress(file, maxSide, q){
  return new Promise(function(res, rej){
    const url=URL.createObjectURL(file);
    const img=new Image();
    img.onload=function(){
      try{
        const sc=Math.min(1, maxSide/Math.max(img.width,img.height));
        const w=Math.max(1,Math.round(img.width*sc)), h=Math.max(1,Math.round(img.height*sc));
        const c=document.createElement('canvas'); c.width=w; c.height=h;
        c.getContext('2d').drawImage(img,0,0,w,h);
        URL.revokeObjectURL(url);
        res(c.toDataURL('image/jpeg', q));
      }catch(e){ rej(e); }
    };
    img.onerror=function(){ URL.revokeObjectURL(url); rej(new Error('decode')); };
    img.src=url;
  });
}
async function albBumpIdx(){
  try{ const rev=Date.now(); await albFetch('idx','PUT',JSON.stringify({rev:rev})); ALB.lastRev=rev; }catch(e){}
}
function bindAlbum(){
  const f=document.getElementById('albFile'); if(!f) return;
  document.getElementById('albGoSync').addEventListener('click', function(){ goTab('settings'); });
  f.addEventListener('change', async function(){
    const files=Array.prototype.slice.call(this.files,0,10);
    this.value='';
    if(!files.length) return;
    if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; }
    const newIds=[];   /* V6.5: 올린 사진 → 장면 태그 시트 */
    for(let i=0;i<files.length;i++){
      albStat('올리는 중 '+(i+1)+'/'+files.length+'… (화면을 닫지 마세요)');
      try{
        const sd=await albShotDate(files[i]);   /* V6.5: 압축하면 촬영 정보가 지워지므로 먼저 읽음 */
        let fu=await albCompress(files[i],1280,0.72);
        if(fu.length>1200000) fu=await albCompress(files[i],1280,0.55);
        const th=await albCompress(files[i],360,0.7);
        const id=albNewId();
        let meta;
        if(albP2On()){
          /* V5.12: 두 폰 모두 신버전 → R2에 바이너리로. base64 33% 군살이 빠진다 */
          const fb=albDataBlob(fu), tb=albDataBlob(th);
          await mediaUpload(fb, albP2Key('full',id), albP2Ct());
          await mediaUpload(tb, albP2Key('th',id), albP2Ct());
          meta={t:'p', d:todayKey(), m:'', at:Date.now(), s:fb.size+tb.size, p2:1, ps:albP2Scheme().id};
          if(sd) meta.sd=sd;
          await albFetch('meta/'+id,'PUT',JSON.stringify(meta));
          ALB.meta=ALB.meta||{}; ALB.meta[id]=meta; ALB.thumbs.set(id,th); newIds.push(id);
        }else{
          await albFetch('full/'+id,'PUT',JSON.stringify(fu));
          await albFetch('th/'+id,'PUT',JSON.stringify(th));
          meta={t:'p', d:todayKey(), m:'', at:Date.now(), s:fu.length+th.length};
          if(sd) meta.sd=sd;
          await albFetch('meta/'+id,'PUT',JSON.stringify(meta));
          ALB.meta=ALB.meta||{}; ALB.meta[id]=meta; ALB.thumbs.set(id,th); newIds.push(id);
        }
      }catch(e){ alert((i+1)+'번째 사진 업로드에 실패했습니다. 인터넷 확인 후 다시 시도해주세요.'); break; }
    }
    await albBumpIdx();
    renderAlbum();
    if(newIds.length) shLoad().then(function(sx){ sx.tagSheet(newIds, {auto:true}); }).catch(function(){});   /* V6.5: SH-00-3 */
  });
  document.getElementById('albVidBtn').addEventListener('click', function(){
    const fm=document.getElementById('albVidForm');
    fm.style.display = fm.style.display==='none' ? 'block' : 'none';
  });
  document.getElementById('albVidAdd').addEventListener('click', async function(){
    if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; }
    const u=(document.getElementById('albVidUrl').value||'').trim();
    const mm=(document.getElementById('albVidMemo').value||'').trim();
    if(!/^https?:\/\//.test(u)){ alert('링크는 https:// 로 시작해야 합니다. 유튜브 공유 버튼에서 복사한 주소를 붙여넣어 주세요.'); return; }
    const id=albNewId();
    const meta={t:'v', d:todayKey(), m:mm, u:u, at:Date.now(), s:0};
    try{
      await albFetch('meta/'+id,'PUT',JSON.stringify(meta));
      await albBumpIdx();
      ALB.meta=ALB.meta||{}; ALB.meta[id]=meta;
      document.getElementById('albVidUrl').value=''; document.getElementById('albVidMemo').value='';
      document.getElementById('albVidForm').style.display='none';
      renderAlbum();
    }catch(e){ alert('저장 실패 — 인터넷 확인 후 다시 시도해주세요.'); }
  });
  document.getElementById('albRefresh').addEventListener('click', function(){ albumPull(true); });
  /* V5.9.2: 상단 타일·필터·설정 */
  const pb=document.getElementById('albPhotoBtn');
  if(pb) pb.addEventListener('click', function(){ if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; } f.click(); });
  const vc=document.getElementById('albVidClose');
  if(vc) vc.addEventListener('click', function(){ document.getElementById('albVidForm').style.display='none'; });
  const sb=document.getElementById('albSetBtn'), cfg=document.getElementById('mediaCfg');
  if(sb && cfg) sb.addEventListener('click', function(){ cfg.open=!cfg.open; if(cfg.open){ const i=document.getElementById('mediaUrl'); if(i && !i.value) i.value=mediaUrl(); } });
  const fl=document.getElementById('albFilter');
  if(fl) fl.addEventListener('click', function(ev){
    const c=ev.target.closest('.alb-chip'); if(!c) return;
    ALB.filter=c.dataset.f||'all'; ALB.shown=24;
    fl.querySelectorAll('.alb-chip').forEach(function(x){ x.classList.toggle('on', x===c); });
    renderAlbum();
  });
  /* V5.9: 영상 파일 업로드 · 저장소 연결 */
  const vb=document.getElementById('albVidUp'), vf=document.getElementById('albVidFile');
  if(vb && vf){
    vb.addEventListener('click', function(){
      if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; }
      if(!mediaConfigured()){ document.getElementById('mediaCfg').open=true; alert('영상 저장소가 아직 연결되지 않았습니다. 아래 "영상 저장소 연결"에 Worker 주소를 넣어주세요.'); return; }
      vf.click();
    });
    vf.addEventListener('change', function(){ const f=this.files&&this.files[0]; this.value=''; if(f) albVideoUpload(f); });
  }
  const ms=document.getElementById('mediaSave'); if(ms) ms.addEventListener('click', mediaConnect);
  document.getElementById('albMore').addEventListener('click', function(){ ALB.shown+=24; renderAlbum(); });
  document.getElementById('albGrid').addEventListener('click', function(ev){
    if(ALB.selOn){   /* V6.5: 여러 장 선택 */
      const c=ev.target.closest('[data-open],[data-lid]');
      if(c){ ev.preventDefault(); if(c.dataset.open) albSelToggle(c.dataset.open); else uiToast('유튜브 링크는 쇼츠에 넣을 수 없어요'); }
      return;
    }
    const cell=ev.target.closest('[data-open]');
    if(cell) albOpen(cell.dataset.open);
  });
  /* V6.5: 쇼츠 — 타일 · 선택 · 확대 화면 */
  const sxb=document.getElementById('albSxBtn'); if(sxb) sxb.addEventListener('click', function(){ if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; } albSelEnd(); shCall(function(sx){ sx.open('rec'); }); });
  const slb=document.getElementById('albSelB'); if(slb) slb.addEventListener('click', function(){ if(ALB.selOn) albSelEnd(); else albSelStart(); });
  const slg=document.getElementById('albSelGo'); if(slg) slg.addEventListener('click', function(){ const ids=(ALB.selOrder||[]).slice(); if(ids.length<2) return; albSelEnd(); shCall(function(sx){ sx.fromIds(ids); }); });
  const lbs=document.getElementById('albLbSx'); if(lbs) lbs.addEventListener('click', function(){ const id=ALB.cur; if(id) shCall(function(sx){ sx.fromPhoto(id); }); });
  const lbt=document.getElementById('albLbTags'); if(lbt) lbt.addEventListener('click', function(ev){ if(!ev.target.closest('button')) return; const id=ALB.cur; if(id) shCall(function(sx){ sx.tagSheet([id], {after:function(){ albLbTagsPaint(id); }}); }); });
  document.getElementById('albLbClose').addEventListener('click', albClose);
  /* V5.11: 좋아요 — 버튼, 사진 두 번 탭, PC 더블클릭 */
  document.getElementById('albLbLike').addEventListener('click', function(){ if(ALB.cur) albToggleLike(ALB.cur, true); });
  let lbTapAt=0;
  document.getElementById('albLbImg').addEventListener('touchend', function(e){
    const t=e.changedTouches&&e.changedTouches[0]; if(!t) return;
    if(Math.abs(t.clientX-swX)>12 || Math.abs(t.clientY-swY)>12){ lbTapAt=0; return; }
    const now=Date.now();
    if(now-lbTapAt<320){ lbTapAt=0; if(ALB.cur){ const m=ALB.meta[ALB.cur]; if(m && !albLikedByMe(m)) albToggleLike(ALB.cur, true); else albHeartPop(); } }
    else lbTapAt=now;
  }, {passive:true});
  document.getElementById('albLbImg').addEventListener('dblclick', function(){ if(ALB.cur) albToggleLike(ALB.cur, true); });
  document.getElementById('albLbMemo').addEventListener('click', async function(){
    if(!ALB.cur) return;
    const m=ALB.meta[ALB.cur];
    const v=await uiPrompt('사진 메모', m.m||'');
    if(v===null) return;
    m.m=v.trim();
    try{ await albFetch('meta/'+ALB.cur,'PUT',JSON.stringify(m)); await albBumpIdx(); }catch(e){ alert('저장 실패'); }
    document.getElementById('albLbCap').textContent=(m.d||'')+(m.m?' · '+m.m:'');
    renderAlbum();
  });
  document.getElementById('albLbDel').addEventListener('click', async function(){
    if(!ALB.cur) return;
    if(!(await askConfirm('이 항목을 앨범에서 삭제할까요? 두 폰 모두에서 사라지며 되돌릴 수 없습니다.'))) return;
    const id=ALB.cur;
    const mm=ALB.meta[id]||{};
    if(mm.t==='r'){
      /* V5.9: 영상 파일(R2) 먼저 삭제 — 실패하면 메타를 남겨 고아 파일 방지 */
      if(!mediaConfigured()){ alert('영상 저장소가 연결되지 않아 삭제할 수 없습니다.'); return; }
      try{ await mediaFetch(mediaApi('/file/'+mm.k), {method:'DELETE'}, 20000); }
      catch(e){ alert('영상 파일 삭제 실패 — 인터넷 확인 후 다시 시도해주세요. ('+String(e&&e.message||e)+')'); return; }
    }
    if(mm.p2){
      /* V5.12: R2 보관 사진 — 파일 먼저 삭제, 실패하면 메타를 남겨 고아 파일 방지 */
      if(!mediaConfigured()){ alert('사진 저장소가 연결되지 않아 삭제할 수 없습니다.'); return; }
      try{
        await p2DeleteAll(id);   /* V6.0.5: 실제 저장된 이름으로 삭제 */
      }catch(e){ alert('사진 파일 삭제 실패 — 인터넷 확인 후 다시 시도해주세요. ('+String(e&&e.message||e)+')'); return; }
    }
    try{
      await albFetch('meta/'+id,'DELETE');
      await albFetch('th/'+id,'DELETE');
      await albFetch('full/'+id,'DELETE');
      await albBumpIdx();
      delete ALB.meta[id]; ALB.thumbs.delete(id); ALB.fulls.delete(id);
      albClose(); renderAlbum();
    }catch(e){ alert('삭제 실패 — 인터넷 확인 후 다시 시도해주세요.'); }
  });
  document.getElementById('albLbPrev').addEventListener('click', function(){ albNav(-1); });
  document.getElementById('albLbNext').addEventListener('click', function(){ albNav(1); });
  const lb=document.getElementById('albLb');
  let swX=0, swY=0, swOn=false;
  lb.addEventListener('touchstart', function(e){
    if(e.touches.length!==1){ swOn=false; return; }
    swOn=true; swX=e.touches[0].clientX; swY=e.touches[0].clientY;
  }, {passive:true});
  lb.addEventListener('touchend', function(e){
    if(!swOn) return; swOn=false;
    if(e.target && e.target.closest && e.target.closest('button')) return;
    const t=e.changedTouches[0], dx=t.clientX-swX, dy=t.clientY-swY;
    if(Math.abs(dx)>55 && Math.abs(dx)>Math.abs(dy)*1.4) albNav(dx<0 ? 1 : -1);
  }, {passive:true});
  document.addEventListener('keydown', function(e){
    if(!lb.classList.contains('on')) return;
    if(e.key==='ArrowLeft') albNav(-1);
    else if(e.key==='ArrowRight') albNav(1);
    else if(e.key==='Escape') albClose();
  });
  setInterval(function(){
    const p=document.getElementById('tab-album');
    if(p && p.classList.contains('on') && document.visibilityState==='visible') albumPull(false);
  }, 25000);
}

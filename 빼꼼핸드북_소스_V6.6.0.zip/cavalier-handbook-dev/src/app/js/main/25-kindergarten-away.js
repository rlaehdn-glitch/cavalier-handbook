/* =============== V6: 유치원 (등원·하원) =============== */
function kgName(){ return String(((S.kgCfg||{}).name)||'').trim() || '유치원'; }
function kgDay(k){ const l=(S.kgLog||{})[k]; return Array.isArray(l)? l : []; }
function kgVisitsSince(from){
  let n=0;
  Object.keys(S.kgLog||{}).forEach(function(k){ if(!from || k>=from) n+=kgDay(k).length; });
  if(S.kgCur && (!from || d2s(new Date(S.kgCur))>=from)) n++;
  return n;
}
function kgPassLeft(){
  const c=S.kgCfg||{}; const p=parseInt(c.pass,10)||0; if(!p) return null;
  const used=kgVisitsSince(c.from||'');
  return {total:p, used:used, left:p-used};
}
function kgPassTxt(){ const pl=kgPassLeft(); return pl? ' · 회차권 '+Math.max(0,pl.left)+'회 남음' : ''; }
const KG_MT={2:['07:00','19:00'], 3:['06:30','13:30','21:00'], 4:['06:30','11:30','16:30','21:00'], 5:['06:30','10:30','14:00','17:30','21:00']};
function kgMealSuggest(o, i){
  const n=parseInt((S.feed||{}).meals,10)||3; const list=KG_MT[n]||KG_MT[3];
  const day=d2s(new Date(o));
  for(let j=0;j<list.length;j++){ const t=new Date(day+'T'+list[j]+':00').getTime(); if(t>=o && t<=i) return list[j]; }
  return '';
}
function kgStart(){
  const go=function(){
    S.kgCur=Date.now(); const st=S.kgCur;
    saveState(); renderQlog();
    uiToast(kgName()+' 등원 '+fmtHM(st), function(){ if(S.kgCur===st){ S.kgCur=0; saveState(); renderQlog(); } });
  };
  if(S.awayCur){
    uiConfirm({msg:'혼자 있는 시간이 기록 중이에요.\n지금 시각으로 귀가 처리하고 등원을 기록할게요.', ok:'등원 기록'})
      .then(function(ok){ if(!ok) return; awayEnd(true); go(); });
    return;
  }
  go();
}
function kgTap(){ if(S.kgCur) kgOpen('end'); else kgStart(); }
const KG={mode:'', key:'', i:-1};
function kgOpen(mode, key, i){
  const $=function(id){ return document.getElementById(id); };
  if(!$('kgOvl')) return;
  KG.mode=mode; KG.key=key||todayKey(); KG.i=(i==null? -1 : i);
  const t1=$('kgT1'), t2=$('kgT2'), dt=$('kgDate'), memo=$('kgMemo'), meal=$('kgMeal'), mealT=$('kgMealT'), del=$('kgDel'), save=$('kgSave'), hint=$('kgHint');
  $('kgSub').textContent=kgName();
  dt.max=todayKey(); hint.textContent=''; meal.checked=false; memo.value=''; mealT.value='';
  $('kgDateRow').style.display = mode==='add'? '' : 'none';
  $('kgMealRow').style.display = mode==='edit'? 'none' : '';
  if(mode==='end'){
    if(!S.kgCur) return;
    $('kgTitle').textContent='하원 기록';
    t1.value=fmtHM(S.kgCur); t2.value=fmtHM(Date.now());
    del.textContent='등원 취소'; del.style.display=''; save.textContent='하원 기록';
    mealT.value=kgMealSuggest(S.kgCur, Date.now())||'13:30';
    const sg=kgMealSuggest(S.kgCur, Date.now());
    if(sg) hint.textContent=sg+' 끼니가 유치원 시간에 있었어요. 유치원에서 먹었다면 켜 주세요 — 공복 계산에 반영됩니다.';
  }else if(mode==='edit'){
    const s=kgDay(KG.key)[KG.i]; if(!s) return;
    $('kgTitle').textContent='유치원 기록 수정';
    $('kgSub').textContent=kgName()+' · '+KG.key.slice(5).replace('-','/');
    t1.value=fmtHM(s.o); t2.value=fmtHM(s.i); memo.value=s.m||'';
    del.textContent='삭제'; del.style.display=''; save.textContent='저장';
    if(s.f) hint.textContent='유치원 식사 '+s.f+' — 식사 시각은 홈 오늘 목록에서 고칠 수 있어요.';
  }else{
    $('kgTitle').textContent='지난 등원 추가';
    dt.value=d2s(addD(new Date(), -1)); t1.value='13:00'; t2.value='17:00'; mealT.value='13:30';
    del.style.display='none'; save.textContent='추가';
    hint.textContent='알림장·카톡 날짜를 보고 넣어 주세요. 달력·통계·회차권에 함께 반영됩니다.';
  }
  $('kgOvl').classList.add('on');
}
function kgHide(){ const o=document.getElementById('kgOvl'); if(o) o.classList.remove('on'); }
function kgAfter(){ saveState(); kgHide(); renderQlog(); try{ renderCal(); }catch(e){} try{ statsRefresh(); }catch(e){} try{ kgCfgPaint(); }catch(e){} }
function kgSave(){
  const $=function(id){ return document.getElementById(id); };
  const v1=$('kgT1').value, v2=$('kgT2').value, now=Date.now();
  if(!/^\d\d:\d\d$/.test(v1) || !/^\d\d:\d\d$/.test(v2)){ uiAlert('등원·하원 시각을 모두 입력해주세요.'); return; }
  const memo=String($('kgMemo').value||'').trim().slice(0,200);
  const mealOn=$('kgMeal').checked && KG.mode!=='edit';
  const mt=$('kgMealT').value;
  if(mealOn && !/^\d\d:\d\d$/.test(mt)){ uiAlert('식사 시각을 입력해주세요.'); return; }
  let key, o, i, list=null, seg=null;
  if(KG.mode==='end'){
    if(!S.kgCur){ kgHide(); return; }
    o=qeApplyHM(S.kgCur, v1); i=qeApplyHM(now, v2); key=d2s(new Date(o));
  }else if(KG.mode==='edit'){
    list=kgDay(KG.key); seg=list[KG.i]; if(!seg){ kgHide(); return; }
    o=qeApplyHM(seg.o, v1); i=qeApplyHM(seg.i, v2); key=KG.key;
  }else{
    const d=$('kgDate').value;
    if(!/^\d{4}-\d\d-\d\d$/.test(d)){ uiAlert('날짜를 입력해주세요.'); return; }
    if(d>todayKey()){ uiAlert('미래 날짜는 추가할 수 없습니다.'); return; }
    key=d; o=new Date(d+'T'+v1+':00').getTime(); i=new Date(d+'T'+v2+':00').getTime();
  }
  if(o>=i){ uiAlert('등원이 하원보다 늦을 수 없습니다.'); return; }
  if(o>now || i>now+60000){ uiAlert('미래 시각으로는 저장할 수 없습니다.'); return; }
  if(mealOn){ const mm=new Date(key+'T'+mt+':00').getTime(); if(mm>now+60000){ uiAlert('식사 시각이 미래입니다.'); return; } }
  S.kgLog=S.kgLog||{};
  if(KG.mode==='edit'){
    seg.o=o; seg.i=i; if(memo) seg.m=memo; else delete seg.m;
    list.sort(function(a,b){ return a.o-b.o; });
    kgAfter(); uiToast('유치원 기록을 고쳤어요');
    return;
  }
  const ns={o:o, i:i}; if(memo) ns.m=memo;
  const mealStr=mealOn? mt+':00' : '';
  if(mealOn){ ns.f=mt; const q=qlNorm(key); q.meal.push(mealStr); qeSortCount(q.meal); }
  (S.kgLog[key]=S.kgLog[key]||[]).push(ns);
  S.kgLog[key].sort(function(a,b){ return a.o-b.o; });
  const ks=Object.keys(S.kgLog).sort(); while(ks.length>400){ delete S.kgLog[ks.shift()]; }
  const wasCur=(KG.mode==='end')? S.kgCur : 0, mode=KG.mode;
  if(mode==='end') S.kgCur=0;
  kgAfter();
  const undo=function(){
    const a=kgDay(key); const ix=a.findIndex(function(x){ return x.o===o && x.i===i; });
    if(ix>-1) a.splice(ix,1);
    if(mealStr){ const q=qlNorm(key); const mi=q.meal.lastIndexOf(mealStr); if(mi>-1) q.meal.splice(mi,1); }
    if(mode==='end' && !S.kgCur) S.kgCur=wasCur;
    kgAfter();
  };
  uiToast(mode==='end'? ('하원 · '+fmtDur(i-o)+(mealOn? ' · 식사 '+mt : '')) : (key.slice(5).replace('-','/')+' 등원 추가'), undo);
}
function kgDelete(){
  if(KG.mode==='end'){
    uiConfirm({msg:'이번 등원 기록을 취소할까요? 저장되지 않습니다.', ok:'등원 취소', destr:true}).then(function(ok){
      if(!ok) return;
      const st=S.kgCur; S.kgCur=0; kgAfter();
      uiToast('등원 기록을 취소했어요', function(){ if(!S.kgCur){ S.kgCur=st; kgAfter(); } });
    });
  }else if(KG.mode==='edit'){
    const key=KG.key, idx=KG.i;
    uiConfirm({msg:'이 유치원 기록을 삭제할까요?', ok:'삭제', destr:true}).then(function(ok){
      if(!ok) return;
      const a=kgDay(key); const s=a[idx]; if(!s) return;
      a.splice(idx,1); kgAfter();
      uiToast('삭제했어요', function(){ S.kgLog=S.kgLog||{}; (S.kgLog[key]=S.kgLog[key]||[]).push(s); S.kgLog[key].sort(function(x,y){ return x.o-y.o; }); kgAfter(); });
    });
  }
}
function kgCfgPaint(){
  const c=S.kgCfg||{};
  const n=document.getElementById('kgName'), p=document.getElementById('kgPass'), f=document.getElementById('kgFrom'), inf=document.getElementById('kgPassInfo');
  if(n && document.activeElement!==n) n.value=c.name||'';
  if(p && document.activeElement!==p) p.value=c.pass? c.pass : '';
  if(f && document.activeElement!==f) f.value=c.from||'';
  if(inf){
    const pl=kgPassLeft();
    inf.textContent = pl? ('남은 횟수 '+Math.max(0,pl.left)+'회 — '+(c.from? c.from.slice(5).replace('-','/')+' 이후 ' : '전체 기간 ')+pl.used+'회 등원')
      : '회차권 횟수를 넣으면 시작일 이후 등원으로 남은 횟수를 계산합니다. 월정액이면 비워두세요.';
  }
}
function bindKgCfg(){
  const upd=function(){
    const n=document.getElementById('kgName'), p=document.getElementById('kgPass'), f=document.getElementById('kgFrom');
    S.kgCfg=S.kgCfg||{};
    S.kgCfg.name=String(n.value||'').trim().slice(0,30);
    S.kgCfg.pass=Math.max(0, Math.min(500, parseInt(p.value,10)||0));
    S.kgCfg.from=f.value||'';
    saveState(); kgCfgPaint(); renderQlog();
  };
  ['kgName','kgPass','kgFrom'].forEach(function(id){ const el=document.getElementById(id); if(el) el.addEventListener('change', upd); });
}

/* =============== V6: 외출(혼자) — 타일 1칸 =============== */
function awayStart(){
  S.awayCur=Date.now(); const st=S.awayCur;
  saveState(); renderQlog();
  uiToast('외출 '+fmtHM(st)+' — 혼자 시간 기록 시작', function(){ if(S.awayCur===st){ S.awayCur=0; saveState(); renderQlog(); } });
}
function awayEnd(silent){
  if(!S.awayCur) return null;
  const key=todayKey(); S.awayLog=S.awayLog||{};
  const seg={o:S.awayCur, i:Date.now()};
  (S.awayLog[key]=S.awayLog[key]||[]).push(seg);
  S.awayCur=0;
  /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
  saveState(); renderQlog(); try{ renderAway(); }catch(e){}
  if(!silent) uiToast('귀가 · 혼자 '+fmtDur(seg.i-seg.o), function(){
    const a=(S.awayLog||{})[key]||[]; const ix=a.findIndex(function(x){ return x.o===seg.o && x.i===seg.i; });
    if(ix>-1){ a.splice(ix,1); if(!S.awayCur) S.awayCur=seg.o; saveState(); renderQlog(); }
  });
  return seg;
}
function awayTap(){
  if(S.kgCur && !S.awayCur){ uiToast(kgName()+'에 있는 동안은 혼자 시간이 아니에요'); return; }
  if(S.awayCur) awayEnd(false); else awayStart();
}


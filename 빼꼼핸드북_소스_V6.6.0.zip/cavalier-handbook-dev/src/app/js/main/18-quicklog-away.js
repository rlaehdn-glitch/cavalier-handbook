/* =============== V3: 공지 v2 헬퍼 + 달력 이동 =============== */
function myName(){ return (lsGet('_ntc_by')||'').trim(); }
/* V6.6: 이름 묻기도 앱 시트로(브라우저 기본 입력창 대신). 기다렸다가 이름을 돌려준다 — 부르는 곳은 await */
async function ntcRequireName(){
  let n=myName();
  if(!n){ n=String((await uiPrompt('이름을 입력하세요 (예: 도우)', ''))||'').trim(); if(n) lsSet('_ntc_by', n); }
  return n;
}
function ntcSeenGet(){ try{ return JSON.parse(lsGet('_ntc_seen')||'{}'); }catch(e){ return {}; } }
function ntcSeenSet(id){ const s=ntcSeenGet(); s[id]=1; const k=Object.keys(s); while(k.length>60){ delete s[k.shift()]; } lsSet('_ntc_seen', JSON.stringify(s)); }
function ntcMigrate(){
  if(!Array.isArray(S.ntc)) S.ntc=[];
  if(S.ntcMig) return;
  const o=S.notice||{};
  if(o.text && o.text.trim() && o.at && !S.ntc.some(function(n){ return n.at===o.at; })){
    S.ntc.unshift({id:'n'+o.at, text:o.text, by:o.by||'', at:o.at, ack:{}});
  }
  S.ntcMig=1;
}
async function ntcAck(id){
  const me=await ntcRequireName(); if(!me) return false;
  const n=(S.ntc||[]).find(function(x){ return x.id===id; }); if(!n) return false;
  n.ack=n.ack||{}; n.ack[me]=Date.now();
  ntcSeenSet(id);
  saveState(); renderNotice(); renderHomeNotice();
  return true;
}
function ntcAckLine(n){
  const ks=Object.keys(n.ack||{});
  return ks.length? '✓ '+ks.map(function(k){ return esc(k)+' '+ntcFmt(n.ack[k]); }).join(' · ')+' 확인' : '아직 확인 전';
}
function goCalDate(ds){
  const p=ds.split('-');
  calY=parseInt(p[0],10); calM=parseInt(p[1],10)-1; calSel=ds;
  renderCal();
  const w=document.querySelector('.cal-wrap'); if(w && w.scrollIntoView){ try{ w.scrollIntoView({behavior:'smooth', block:'start'}); }catch(e){} }
}

/* =============== V3.1: 빠른기록 타임스탬프 =============== */
function qlNorm(key){
  S.qlog=S.qlog||{};
  const q=S.qlog[key]=S.qlog[key]||{};
  ['poo','pee','diar','meal'].forEach(function(x){
    if(typeof q[x]==='number'){ const n=q[x]; q[x]=[]; for(let i=0;i<n;i++) q[x].push(''); }
    if(!Array.isArray(q[x])) q[x]=[];
  });
  return q;
}

/* =============== V3.3: 혼자 시간 + 증상 기록 =============== */
function fmtHM(ms){ const d=new Date(ms); return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'); }
function fmtDur(ms){ const m=Math.max(0,Math.round(ms/60000)); const h=Math.floor(m/60), r=m%60; return h? (h+'시간'+(r?' '+r+'분':'')) : (r+'분'); }
function awayToday(){
  const key=todayKey();
  let total=0, cnt=0;
  (((S.awayLog||{})[key])||[]).forEach(function(s){ total+=Math.max(0,s.i-s.o); cnt++; });
  return {total:total, cnt:cnt, ongoing: S.awayCur? (Date.now()-S.awayCur) : 0};
}
function renderAway(){
  const st=document.getElementById('awStat'); if(!st) return;
  const out=document.getElementById('awOut'), inn=document.getElementById('awIn');
  const a=awayToday();
  if(S.awayCur){
    out.disabled=true; inn.disabled=false;
    const over = a.ongoing > 12*3600000;
    st.innerHTML='🔴 <strong>'+fmtDur(a.ongoing)+'째 혼자</strong> <span class="ql-chip" role="button" id="awCurChip" style="cursor:pointer;">'+fmtHM(S.awayCur)+' 외출 ✎</span>'+(a.total? ' · 오늘 누적 '+fmtDur(a.total+a.ongoing):'')
      +(over? '<br><span class="mg-warn">귀가 버튼을 잊으셨나요? 아래에서 정리하세요.</span><div class="aw-fix"><button class="btn sm" id="awFixIn" type="button">지금 귀가로 기록</button><button class="btn sm ghost" id="awFixX" type="button">이 외출 취소</button></div>' : '');
    const f1=document.getElementById('awFixIn');
    if(f1) f1.addEventListener('click', function(){ document.getElementById('awIn').click(); });
    const f2=document.getElementById('awFixX');
    if(f2) f2.addEventListener('click', async function(){
      if(!(await askConfirm('이 외출 기록을 취소할까요? 시간이 저장되지 않습니다.'))) return;
      S.awayCur=0; saveState(); renderAway();
    });
  }else{
    out.disabled=false; inn.disabled=true;
    /* V5.6b: 오늘 외출 구간 칩 — 탭하면 수정 시트 */
    const segs=(((S.awayLog||{})[todayKey()])||[]).map(function(s,i){
      return '<span class="ql-chip" role="button" data-ak="'+i+'" style="cursor:pointer;">'+fmtHM(s.o)+'→'+fmtHM(s.i)+' · '+fmtDur(s.i-s.o)+'</span>';
    }).join('');
    st.innerHTML= a.cnt? '🟢 지금 함께 · 오늘 혼자 합계 <strong>'+fmtDur(a.total)+'</strong> ('+a.cnt+'회)<div style="display:flex; flex-wrap:wrap; gap:5px; margin-top:6px;">'+segs+'</div>' : '🟢 지금 함께 · 오늘 혼자 둔 기록 없음';
  }
  try{ statsRefresh(); }catch(e){}
}
function bindAway(){
  const out=document.getElementById('awOut'); if(!out) return;
  out.addEventListener('click', function(){ S.awayCur=Date.now(); saveState(); renderAway(); });
  document.getElementById('awIn').addEventListener('click', function(){
    if(!S.awayCur) return;
    const key=todayKey();
    S.awayLog=S.awayLog||{};
    (S.awayLog[key]=S.awayLog[key]||[]).push({o:S.awayCur, i:Date.now()});
    S.awayCur=0;
    /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
    saveState(); renderAway();
  });
  /* V5.6b: 외출 칩 탭 → 수정 시트 (aw-fix 버튼은 자체 리스너라 간섭 없음) */
  const stEl=document.getElementById('awStat');
  if(stEl) stEl.addEventListener('click', function(e){
    if(e.target.closest('#awCurChip')){ qeOpen('acur'); return; }
    const seg=e.target.closest('[data-ak]');
    if(seg){ qeOpen('away','',parseInt(seg.dataset.ak,10)); }
  });
  setInterval(function(){ if(S.awayCur) renderAway(); }, 30000);
}


/* =============== V6.5: 쇼츠 — 앨범 연결 (SH-00) ===============
   쇼츠 화면·영상 만들기는 shorts.js(별도 파일)에 있고, 앨범을 열 때 한 번 불러온다. 본체에는 입구·표시·촬영 시각만 둔다. */
const SH_VER=APP_VER;   /* V6.6: 버전은 VERSION 파일 한 곳 — index.html·shorts.js가 같은 값 */
let SHL=null;
function shLoad(){
  if(window.SHORTS) return Promise.resolve(window.SHORTS);
  if(SHL) return SHL;
  SHL=new Promise(function(res, rej){
    const sc=document.createElement('script'); sc.src='shorts.js?v='+SH_VER; sc.async=true;
    sc.onload=function(){ if(window.SHORTS){ try{ verCheckShorts(); }catch(e){} res(window.SHORTS); } else { SHL=null; rej(new Error('load')); } };   /* V6.6: 두 파일 버전 확인 */
    sc.onerror=function(){ SHL=null; try{ sc.remove(); }catch(e){} rej(new Error('load')); };
    document.head.appendChild(sc);
  });
  return SHL;
}
function shCall(fn){ shLoad().then(fn, function(){ uiToast('쇼츠 기능을 불러오지 못했어요 — 인터넷 확인 후 다시 시도해 주세요'); }); }
let SHB_T=null;
function shBadge(){
  clearTimeout(SHB_T);
  SHB_T=setTimeout(function(){
    if(!syncConfigured() || !ALB.meta) return;
    shLoad().then(function(sx){ return sx.badge(); }).then(function(n){
      const e=document.getElementById('albSxN'); if(!e) return;
      e.textContent = n? n+'편' : ''; e.classList.toggle('on', !!n);
    }).catch(function(){});
  }, 700);
}
function shCool(){ try{ const c=window.SHORTS && window.SHORTS._D && window.SHORTS._D.cfg; if(c && c.cool!=null) return +c.cool; }catch(e){} return 30; }
function albDayDiff(a, b){ return Math.round((new Date(String(b).slice(0,10)+'T00:00:00')-new Date(String(a).slice(0,10)+'T00:00:00'))/86400000); }
function albUseB(m){
  if(!m || !(m.su>0)) return '';
  const cool = m.sl && albDayDiff(m.sl, todayKey()) < shCool();
  return '<span class="alb-use'+(cool?' cool':'')+'">쇼츠 '+m.su+'회</span>';
}
function albSelCls(id){ return (ALB.sel && ALB.sel[id]) ? ' alb-on' : ''; }
function albSelPaint(){
  const n=(ALB.selOrder||[]).length;
  const t=document.getElementById('albSelN'); if(t) t.textContent = n? n+'장 선택됨' : '쇼츠로 만들 사진을 고르세요';
  const g=document.getElementById('albSelGo'); if(g) g.disabled = n<2;
  const b=document.getElementById('albSelB'); if(b) b.textContent = ALB.selOn? '취소' : '선택';
}
function albSelStart(){
  if(!syncConfigured()){ alert('설정에서 동기화를 먼저 켜주세요.'); return; }
  const ap=document.getElementById('tab-album'); if(ap && !ap.classList.contains('on')) goTab('album');
  ALB.selOn=true; ALB.sel={}; ALB.selOrder=[];
  document.body.classList.add('alb-sel'); albSelPaint(); renderAlbum();
}
function albSelEnd(){
  if(!ALB.selOn) return;
  ALB.selOn=false; ALB.sel={}; ALB.selOrder=[];
  document.body.classList.remove('alb-sel'); albSelPaint(); renderAlbum();
}
function albSelToggle(id){
  const m=ALB.meta && ALB.meta[id]; if(!m || m.t==='v') return;
  ALB.sel=ALB.sel||{}; ALB.selOrder=ALB.selOrder||[];
  if(ALB.sel[id]){ delete ALB.sel[id]; ALB.selOrder=ALB.selOrder.filter(function(x){ return x!==id; }); }
  else{ ALB.sel[id]=1; ALB.selOrder.push(id); }
  const cell=document.querySelector('#albGrid [data-open="'+id+'"]'); if(cell) cell.classList.toggle('alb-on', !!ALB.sel[id]);
  albSelPaint();
}
const ALB_SEASON=['겨울','겨울','봄','봄','봄','여름','여름','여름','가을','가을','가을','겨울'];
function albLbTagsPaint(id){
  const box=document.getElementById('albLbTags'), sxb=document.getElementById('albLbSx');
  const m=ALB.meta && ALB.meta[id];
  if(sxb) sxb.hidden = !m || m.t==='v';
  if(!box) return;
  if(!m || m.t==='v'){ box.innerHTML=''; return; }
  const d=String(m.sd||m.d||''), mo=+d.slice(5,7), out=[];
  if(mo) out.push(ALB_SEASON[mo-1]);
  String(m.ts||'').split(',').map(function(x){ return x.trim(); }).filter(Boolean).forEach(function(x){ out.push(x); });
  if(m.tm) out.push(m.tm);
  box.innerHTML = out.map(function(x){ return '<span>'+esc(x)+'</span>'; }).join('') + '<button type="button">'+((m.ts||m.tm)? '태그 수정' : '장면 태그 추가')+'</button>';
}
/* 촬영 시각 — 사진: JPEG EXIF DateTimeOriginal · 영상: mvhd 생성 시각. 없으면 파일 수정 시각(지금과 2분 이상 차이 날 때만) */
function albLocalISO(d){ return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')+'T'+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0'); }
function albLmISO(file){
  try{ const lm=file && file.lastModified, now=Date.now(); if(lm && now-lm>120000 && now-lm<6*365*86400000) return albLocalISO(new Date(lm)); }catch(e){}
  return '';
}
function albExifDate(dv){
  try{
    if(dv.byteLength<12 || dv.getUint16(0)!==0xFFD8) return '';
    let off=2;
    while(off+10<dv.byteLength){
      const mk=dv.getUint16(off); if((mk&0xFF00)!==0xFF00) return '';
      if(mk===0xFFDA || mk===0xFFD9) return '';
      const len=dv.getUint16(off+2);
      if(mk===0xFFE1 && dv.getUint32(off+4)===0x45786966){
        const t0=off+10, le=dv.getUint16(t0)===0x4949;
        const u16=function(o){ return dv.getUint16(t0+o, le); }, u32=function(o){ return dv.getUint32(t0+o, le); };
        const str=function(o, n){ let s=''; for(let i=0;i<n-1 && t0+o+i<dv.byteLength;i++){ const c=dv.getUint8(t0+o+i); if(!c) break; s+=String.fromCharCode(c); } return s; };
        const scan=function(ifd, want){ const out={}; const n=u16(ifd); for(let i=0;i<n && i<400;i++){ const e=ifd+2+i*12, tag=u16(e), type=u16(e+2), cnt=u32(e+4); if(want.indexOf(tag)<0) continue; if(type===2) out[tag]= cnt>4? str(u32(e+8), cnt) : str(e+8, cnt); else if(type===4) out[tag]=u32(e+8); } return out; };
        const a=scan(u32(4), [0x8769, 0x0132]);
        let dt='';
        if(a[0x8769]){ const b=scan(a[0x8769], [0x9003, 0x9004]); dt=b[0x9003]||b[0x9004]||''; }
        if(!dt) dt=a[0x0132]||'';
        const m=/^(\d{4}):(\d{2}):(\d{2}) (\d{2}):(\d{2}):(\d{2})/.exec(dt);
        return (m && m[1]>'1990')? m[1]+'-'+m[2]+'-'+m[3]+'T'+m[4]+':'+m[5]+':'+m[6] : '';
      }
      off+=2+len;
    }
  }catch(e){}
  return '';
}
async function albShotDate(file){
  try{ const s=albExifDate(new DataView(await file.slice(0, 262144).arrayBuffer())); if(s) return s; }catch(e){}
  return albLmISO(file);
}
function albMvhd(dv){
  try{
    for(let i=4;i+24<dv.byteLength;i++){
      if(dv.getUint32(i)!==0x6D766864) continue;   /* 'mvhd' */
      const ver=dv.getUint8(i+4);
      let sec = ver===1 ? (dv.getUint32(i+8)*4294967296 + dv.getUint32(i+12)) : dv.getUint32(i+8);
      const ms=(sec-2082844800)*1000;
      if(ms>Date.UTC(2015,0,1) && ms<Date.now()+86400000) return albLocalISO(new Date(ms));
      return '';
    }
  }catch(e){}
  return '';
}
async function vidShotDate(file){
  try{
    const H=2*1048576;
    let s=albMvhd(new DataView(await file.slice(0, Math.min(file.size, H)).arrayBuffer()));
    if(!s && file.size>H) s=albMvhd(new DataView(await file.slice(Math.max(H, file.size-8*1048576)).arrayBuffer()));
    if(s) return s;
  }catch(e){}
  return albLmISO(file);
}


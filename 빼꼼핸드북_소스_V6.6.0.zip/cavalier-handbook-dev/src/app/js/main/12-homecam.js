/* =============== V5.10: 홈캠 — 집 PC go2rtc ← 영상 저장소 Worker(/cam/*) 중계 =============== */
const CAM={state:'idle', el:null, checked:0, online:false, streams:[], hd:false, shown:false};
function camApi(path, params){ return mediaApi('/cam'+path, params); }       /* 영상 저장소와 같은 Worker·같은 가족 코드 */
function camSrc(){ return (CAM.hd && CAM.streams.indexOf('cam_hd')>-1) ? 'cam_hd' : 'cam'; }
function camStat(t){ const s=document.getElementById('camStat'); if(s) s.textContent=t; }
async function camCheck(force){
  const wrap=document.getElementById('camWrap'); if(!wrap) return;
  if(!mediaConfigured()){ wrap.style.display='none'; return; }
  if(!force && CAM.checked && (Date.now()-CAM.checked)<5*60*1000) return;   /* 5분 캐시 */
  CAM.checked=Date.now();
  try{
    const j=await mediaFetch(camApi('/ping'), {method:'GET'}, 12000);
    if(!j || typeof j.online==='undefined'){ wrap.style.display='none'; CAM.online=false; return; }   /* 구버전 Worker 등 → 숨김 */
    CAM.online=!!j.online; CAM.streams=j.streams||[]; CAM.shown=true;
    wrap.style.display='block';
    camStat(CAM.online ? '연결됨' : ('오프라인 — '+(j.error||'집 PC 확인')));
    if(CAM.online && CAM.state==='idle') camSnap();
  }catch(e){
    const msg=String(e&&e.message||e);
    CAM.online=false;
    if(CAM.shown){ camStat('확인 실패 — '+msg); }          /* 이미 쓰던 카드면 상태만 표시 */
    else { wrap.style.display='none'; }                     /* 홈캠 미설정·구버전 Worker·404 → 카드 숨김 */
  }
}
function camSnap(){
  const img=document.getElementById('camSnap'); if(!img || !mediaConfigured() || CAM.state==='live') return;
  img.onload=function(){ img.style.display='block'; };
  img.onerror=function(){ img.style.display='none'; };
  img.src=camApi('/snap',{src:camSrc(), t:Date.now()});
}
function camPlay(){
  if(!mediaConfigured() || CAM.state==='live') return;
  if(!CAM.online){ alert('홈캠 서버(집 PC)에 연결되지 않습니다. PC가 켜져 있고 go2rtc와 Tailscale이 실행 중인지 확인해주세요.'); return; }
  if(!window.customElements || !customElements.get('video-stream')){ alert('이 브라우저는 실시간 재생을 지원하지 않습니다.'); return; }
  const box=document.getElementById('camBox'); if(!box) return;
  const el=document.createElement('video-stream');
  el.mode='mse,hls,mp4';            /* 터널은 TCP만 통과 → WebRTC 제외. 안드로이드·아이폰17+ MSE, 구형 아이폰 HLS */
  el.visibilityCheck=true;          /* 화면 꺼짐·백그라운드 시 자동 끊김 */
  el.src=camApi('/ws',{src:camSrc()});
  box.appendChild(el); CAM.el=el; CAM.state='live';
  document.getElementById('camOvl').classList.add('off');
  document.getElementById('camSnap').style.display='none';
  document.getElementById('camLive').style.display='inline-block';
  document.getElementById('camStop').style.display='inline-flex';
  document.getElementById('camFullBtn').style.display='inline-block';
  camStat('실시간');
}
function camStop(){
  if(CAM.el){ try{ CAM.el.ondisconnect(); }catch(e){} try{ CAM.el.remove(); }catch(e){} CAM.el=null; }
  if(CAM.state==='idle') return;
  CAM.state='idle';
  const ovl=document.getElementById('camOvl'); if(ovl) ovl.classList.remove('off');
  ['camLive','camStop','camFullBtn'].forEach(function(id){ const e=document.getElementById(id); if(e) e.style.display='none'; });
  if(CAM.online){ camStat('연결됨'); camSnap(); }
}
function camFull(){
  const v=CAM.el&&CAM.el.video; if(!v) return;
  try{ if(v.requestFullscreen) v.requestFullscreen(); else if(v.webkitEnterFullscreen) v.webkitEnterFullscreen(); }catch(e){}
}
function bindCam(){
  const p=document.getElementById('camPlay'); if(!p) return;
  p.addEventListener('click', camPlay);
  document.getElementById('camStop').addEventListener('click', camStop);
  document.getElementById('camSnapBtn').addEventListener('click', function(){ if(CAM.state==='live') return; camCheck(true); camSnap(); });
  document.getElementById('camFullBtn').addEventListener('click', camFull);
  document.getElementById('camHd').addEventListener('change', function(){ CAM.hd=this.checked; if(CAM.state==='live'){ camStop(); camPlay(); } else camSnap(); });
}

/* ---------- 산책 중 기록 버튼 (대변·소변·사진) ---------- */
function wgMark(k){
  const c=WG.cur; if(!c || c.ending) return;
  const at=Date.now();
  try{ qlBump(k, 1); }catch(e){ console.error(e); }
  const p=c.pos;
  c.pins.push({k:k, at:at, lat:p? p[0] : null, lng:p? p[1] : null});
  wgPersist(true); wgLivePins(); wgPaintLive();
}
function wgPhoto(){
  const c=WG.cur; if(!c || c.ending) return;
  if(!syncConfigured()){ uiAlert('사진은 동기화를 켠 뒤 앨범에 올라가요.\n설정에서 동기화를 먼저 켜 주세요.'); return; }
  const p=c.pos; WG.camAt={at:Date.now(), lat:p? p[0] : null, lng:p? p[1] : null};
  const inp=document.getElementById('wgCam'); if(inp) inp.click();
}
async function wgAlbUpload(file, memo){           /* 15장 앨범 사진 올리기와 같은 경로·형식 */
  let fu=await albCompress(file, 1280, 0.72); if(fu.length>1200000) fu=await albCompress(file, 1280, 0.55);
  const th=await albCompress(file, 360, 0.7);
  const id=albNewId();
  let meta;
  if(albP2On()){
    const fb=albDataBlob(fu), tb=albDataBlob(th);
    await mediaUpload(fb, albP2Key('full', id), albP2Ct()); await mediaUpload(tb, albP2Key('th', id), albP2Ct());
    meta={t:'p', d:todayKey(), m:memo||'', at:Date.now(), s:fb.size+tb.size, p2:1, ps:albP2Scheme().id};
  }else{
    await albFetch('full/'+id, 'PUT', JSON.stringify(fu)); await albFetch('th/'+id, 'PUT', JSON.stringify(th));
    meta={t:'p', d:todayKey(), m:memo||'', at:Date.now(), s:fu.length+th.length};
  }
  await albFetch('meta/'+id, 'PUT', JSON.stringify(meta));
  ALB.meta=ALB.meta||{}; ALB.meta[id]=meta; ALB.thumbs.set(id, th);
  try{ await albBumpIdx(); }catch(e){}
  try{ renderAlbum(); }catch(e){}
  return id;
}
async function wgPhotoUp(file){
  const at=WG.camAt||{at:Date.now(), lat:null, lng:null}; WG.camAt=null;
  uiToast('사진 올리는 중… 화면을 닫지 마세요');
  try{
    const id=await wgAlbUpload(file, '산책 중 · '+fmtHM(at.at));
    const c=WG.cur;
    if(c){ c.photos.push({id:id, at:at.at, lat:at.lat, lng:at.lng}); wgPersist(true); wgLivePins(); wgPaintLive(); }
    uiToast('사진 저장 · 앨범과 산책 지도에 표시돼요');
  }catch(e){ uiToast('사진을 올리지 못했어요 · 인터넷 확인 후 앨범에서 다시 올려 주세요'); }
}

/* ---------- 산책 후 상태 체크 ---------- */
function wgChkOpen(){
  wgEnsureDom();
  WG.ck={};
  const nm=(S.profile && S.profile.name)? S.profile.name : '';
  const sub=document.getElementById('wgChkSub'); if(sub) sub.textContent=(nm? nm+' ' : '')+'상태를 골라 주세요 · 이상한 점만 골라도 돼요';
  wgChkPaint();
  document.getElementById('wgChk').classList.add('on');
}
function wgChkClose(){ const el=document.getElementById('wgChk'); if(el) el.classList.remove('on'); }
function wgChkPaint(){
  const box=document.getElementById('wgCkBox'); if(!box) return;
  box.innerHTML=WG_CK.map(function(r){
    return '<div class="wg-ck-row"><b>'+r.nm+'</b><div class="wg-ck-ops">'+r.ops.map(function(o){
      const on=WG.ck[r.k]===o[0];
      return '<button type="button" class="wg-op'+(on? ' on' : '')+(on && o[2]? ' bad' : '')+'" data-ck="'+r.k+'" data-v="'+o[0]+'" aria-pressed="'+on+'">'+o[1]+'</button>';
    }).join('')+'</div></div>';
  }).join('');
}
function wgAllOk(){
  const c=WG.cur;
  WG.ck={m:'g', b:'n', c:'n', a:'n'};
  if(c && c.pins.some(function(x){ return x.k==='poo'; })) WG.ck.p='n';
  wgChkPaint();
}

/* ---------- 산책 요약 ---------- */
function wgShowSum(id, fromScr){
  wgEnsureDom();
  WG.sumId=id;
  const scr=document.getElementById('wgScr');
  if(scr && scr.classList.contains('on')){ scr.classList.remove('on'); WG.scrOpen=false; }
  wgBodyCls();
  wgPocketOff();
  if(fromScr) wgHistSwap('scr', 'sum'); else wgHistPush('sum');
  wgSumPaint(id);
  document.getElementById('wgSum').classList.add('on');
  try{ wgHomePaint(); }catch(e){}
}
function wgSumPaint(id){
  const box=document.getElementById('wgSumBody'); if(!box) return;
  const s=wgSegById(id), p=wgCacheGet(id);
  if(!s){ box.innerHTML='<p class="sh-m">기록을 찾지 못했어요.</p>'; return; }
  box.innerHTML=wgSegHtml(s, p, true);
}
function wgSumClose(keepHist, fromPop){
  const el=document.getElementById('wgSum'); if(!el || !el.classList.contains('on')) return;
  el.classList.remove('on'); WG.sumId=null;
  if(keepHist) return;
  if(!fromPop) wgHistBack('sum');
}
function wgStatBox(lbl, val){ return '<div class="wg-st"><b>'+val+'</b><span>'+lbl+'</span></div>'; }
function wgVdRow(x){ return '<div class="wg-vd-r"><i class="'+(x.lv==='bad'? 'bad' : (x.lv==='warn'? 'warn' : (x.lv==='ok'? 'ok' : '')))+'"></i><div><b>'+esc(x.h)+' · '+esc(x.b)+'</b>'+(x.s? '<span>'+esc(x.s)+'</span>' : '')+'</div></div>'; }
/* 요약·상세 공용 본문 */
function wgSegHtml(s, p, compact){
  const dur=(s.i-s.o)/1000;
  let h='';
  if(compact) h+='<div class="wg-ttl"><b>'+fmtHM(s.o)+'–'+fmtHM(s.i)+'</b><span>'+wgDateLbl(s.o)+'</span></div>';
  if(compact && p && p.segs && p.segs.length){ const segs=p.segs.map(wgDec).filter(function(x){ return x.length; }); if(segs.length) h+='<div class="wg-route">'+wgRouteSvg(segs, 360, 170, {pad:18, sw:4})+'</div>'; }
  const mvDist=Math.max(0, (s.d||0)-(s.dg||0));
  h+='<div class="wg-grid">'+wgStatBox('걸은 시간', wgMin(dur))+wgStatBox('거리'+(s.dg? ' (추정 포함)' : ''), s.d!=null? wgKm(s.d)+'<small>km</small>' : '—')+
     wgStatBox('평균 속도 · 이동 중', s.mv? wgKmh(mvDist, s.mv)+'<small>km/h</small>' : '—')+wgStatBox('킁킁·쉼', s.sn!=null? wgMin(s.sn) : '—');
  if(s.g) h+=wgStatBox('오르막', s.el!=null? '+'+s.el+'<small>m</small>' : '—')+wgStatBox('날씨', s.tf!=null? '체감 '+wgT(s.tf) : '—');
  h+='</div>';
  if(p && p.ele && p.ele.prof && p.ele.prof.length>1) h+='<div class="wg-elev"><p>고도 '+p.ele.lo+'~'+p.ele.hi+'m · 오르막 +'+p.ele.g+'m · 내리막 −'+p.ele.l+'m</p>'+wgElevSvg(p.ele.prof, 300, 70)+'</div>';
  if(s.g || s.ck) h+='<div class="wg-vd">'+wgJudgeSeg(s, p).map(wgVdRow).join('')+'</div>';
  if(s.gs) h+='<p class="wg-foot">기록 공백 '+wgMin(s.gs)+' — 화면이 꺼졌거나 다른 앱을 쓴 구간이에요. 그 구간은 직선거리 '+wgKm(s.dg||0)+'km로 추정해 거리에 넣었어요.</p>';
  if(p && p.tr) h+='<p class="wg-foot">집 근처 경로는 저장하지 않았어요 (거리·시간에는 포함).</p>';
  if(s.man) h+='<p class="wg-foot">직접 입력한 기록이에요.</p>';
  else if(!s.g) h+='<p class="wg-foot">산책 버튼으로 시간만 잰 기록이에요.</p>';
  if(s.g) h+='<p class="wg-foot">날씨·고도: Open-Meteo.com · Copernicus DEM GLO-90'+(p && p.by? ' · 기록 '+esc(p.by) : '')+'</p>';
  return h;
}

/* ---------- 홈 카드 ---------- */
function wgHomeEnsure(){
  if(document.getElementById('wgHome')) return true;
  const anchor=document.getElementById('bathRow') || document.getElementById('pooAmt') || document.querySelector('#tab-home .ql-v6');   /* V6.4: 목욕 줄 아래 */
  if(!anchor) return false;
  const d=document.createElement('div'); d.className='card wg-home'; d.id='wgHome';
  anchor.insertAdjacentElement('afterend', d);
  d.addEventListener('click', function(e){
    const b=e.target.closest('[data-wg]'); if(!b) return;
    const a=b.dataset.wg;
    if(a==='start') wgStart(); else if(a==='open') wgOpenScr(); else if(a==='hub') wgHubOpen('list');
  });
  return true;
}
function wgHomePaint(){
  if(!wgHomeEnsure()) return;
  const el=document.getElementById('wgHome'), rec=wgRec(), tk=todayKey(), now=Date.now(), c=WG.cur;
  const segs=((S.walkLog||{})[tk]||[]).filter(function(s){ return s && +s.i>+s.o; });
  let ms=sumSegs(segs), m=segs.reduce(function(a, s){ return a+(+s.d||0); }, 0);
  if(S.walkCur && S.walkCur<now) ms+=now-S.walkCur;
  if(c && !c.ending) m+=wgDistLive();
  const dayMin=ms/60000, pct=rec? dayMin/rec.day : 0, over=rec? (dayMin-rec.day)/rec.day : 0;
  let title, sub, btn='', act='', soft=false;
  const g=S.walkGps;
  if(c && !c.ending){
    const live=WG.watchId!=null;
    title=live? '<span class="wg-live"></span>지도 기록 중' : '지도 기록 대기 중';
    sub=wgClock(wgElapsed(now))+' · '+wgKm(wgDistLive())+'km'; btn=live? '열기' : '이어서'; act='open'; soft=true;
  }else if(S.walkCur && g && g.d && g.d!==DEV_ID){ title='다른 폰에서 지도 기록 중'; sub=(g.n? esc(g.n)+' · ' : '')+fmtDur(now-S.walkCur)+'째'; }
  else if(S.walkCur){ title='산책 중 · 시간만 기록'; sub=fmtDur(now-S.walkCur)+'째'; btn='지도 켜기'; act='start'; }
  else{ title='산책 지도'; sub=segs.length? '오늘 '+fmtDur(ms)+(m>0? ' · '+wgKm(m)+'km' : '') : '오늘 산책 기록 없음'; btn='시작'; act='start'; }
  const recT=rec? '1회 권장 '+rec.per+'분 · 하루 '+rec.day+'분' : '생년월일을 넣으면 권장 시간이 보여요';
  el.innerHTML='<button type="button" class="wg-h-main" data-wg="hub" aria-label="산책 기록 보기"><span class="wg-ring">'+wgRingSvg(pct, over, 52, 6, '<i><svg viewBox="0 0 24 24"><use href="#i-paw"/></svg></i>')+'</span>'+
    '<span class="wg-h-tx"><b>'+title+'</b><span id="wgHomeSub">'+sub+'</span><span class="wg-h-rec">'+recT+'</span></span></button>'+
    (btn? '<button type="button" class="wg-h-go'+(soft? ' soft' : '')+'" data-wg="'+act+'">'+btn+'</button>' : '');
}
function wgHomePaintLive(){ const s=document.getElementById('wgHomeSub'), c=WG.cur; if(s && c && !c.ending) s.textContent=wgClock(wgElapsed())+' · '+wgKm(wgDistLive())+'km'; }

/* ---------- 산책 기록 (허브) ---------- */
function wgWalks(days){
  const from=d2s(new Date(Date.now()-(days-1)*86400000)), out=[];
  Object.keys(S.walkLog||{}).forEach(function(k){
    if(k<from) return;
    ((S.walkLog||{})[k]||[]).forEach(function(s){ if(s && +s.i>+s.o) out.push({k:k, s:s}); });
  });
  out.sort(function(a, b){ return b.s.o-a.s.o; });
  return out;
}
function wgWeek(){
  const it=wgWalks(7); let min=0, m=0;
  it.forEach(function(x){ min+=(x.s.i-x.s.o)/60000; m+=(+x.s.d||0); });
  return {n:it.length, min:min, m:m};
}
function wgStreak(){
  const has=function(k){ const a=(S.walkLog||{})[k]; return Array.isArray(a) && a.some(function(s){ return s && +s.i>+s.o; }); };
  let d=new Date(); if(!has(d2s(d))) d=new Date(d.getTime()-86400000);
  let n=0; while(has(d2s(d)) && n<400){ n++; d=new Date(d.getTime()-86400000); }
  return n;
}
function wgHubOpen(tab, swapFromSum){
  wgEnsureDom();
  const el=document.getElementById('wgHub');
  if(tab) WG.hubTab=tab;
  if(!el.classList.contains('on')){
    if(!WG.hist.length) WG.scrollY=window.scrollY||0;
    el.classList.add('on');
    if(swapFromSum) wgHistSwap('sum', 'hub'); else wgHistPush('hub');
  }
  wgHubPaint();
  wgQFlush();
}
function wgHubClose(fromPop){
  const el=document.getElementById('wgHub'); if(!el || !el.classList.contains('on')) return;
  el.classList.remove('on');
  if(WG.maps.wgHubMap){ try{ WG.maps.wgHubMap.remove(); }catch(e){} delete WG.maps.wgHubMap; }
  if(!fromPop) wgHistBack('hub');
}
function wgHubPaint(){
  const box=document.getElementById('wgHubIn'); if(!box) return;
  const wk=wgWeek(), streak=wgStreak();
  let h='<h1 class="wg-big">산책</h1>';
  h+='<div class="wg-week">'+wgStatBox('최근 7일', wk.n+'<small>회</small>')+wgStatBox('걸은 시간', stDurS(wk.min))+wgStatBox('지도 기록 거리', wgKm(wk.m)+'<small>km</small>')+'</div>';
  if(streak>1) h+='<p class="wg-note" style="margin:-4px 4px 12px;">'+streak+'일 연속 산책했어요</p>';
  h+='<div class="seg3 wg-seg" role="tablist">'+[['list','기록'],['map','지도'],['crit','기준·설정']].map(function(t){ return '<button type="button" role="tab" data-wgtab="'+t[0]+'" class="'+(WG.hubTab===t[0]? 'on' : '')+'" aria-selected="'+(WG.hubTab===t[0])+'">'+t[1]+'</button>'; }).join('')+'</div>';
  h+='<div id="wgHubBody"></div>';
  box.innerHTML=h;
  if(WG.maps.wgHubMap){ try{ WG.maps.wgHubMap.remove(); }catch(e){} delete WG.maps.wgHubMap; }
  if(WG.hubTab==='map') wgHubMap(); else if(WG.hubTab==='crit') wgHubCrit(); else wgHubList();
}
function wgHubTap(e){
  const t=e.target.closest('[data-wgtab]'); if(t){ WG.hubTab=t.dataset.wgtab; wgHubPaint(); return; }
  const r=e.target.closest('.wg-row[data-wgk]'); if(r){ wgDetOpen(r.dataset.wgk, +r.dataset.wgo, true); return; }
}
function wgRowSub(s){
  const a=[fmtDur(s.i-s.o)];
  if(s.d!=null) a.push(wgKm(s.d)+'km');
  if(s.sn) a.push('킁킁 '+fmtDur(s.sn*1000));
  if(s.man) a.push('직접 입력'); else if(!s.g) a.push('시간만');
  return a.join(' · ');
}
function wgHubList(){
  const body=document.getElementById('wgHubBody'); if(!body) return;
  const items=wgWalks(60);
  if(!items.length){ body.innerHTML='<div class="wg-empty"><b>아직 산책 기록이 없어요</b>홈의 산책 지도 카드에서 시작을 누르면 경로가 여기에 쌓여요.</div>'; return; }
  let h='', day='';
  items.forEach(function(it){
    const s=it.s, dk=d2s(new Date(s.o));
    if(dk!==day){ if(day) h+='</div>'; day=dk; h+='<div class="wg-day">'+wgDateLbl(s.o)+'</div><div class="wg-list">'; }
    const pv=wgSegLv(s);
    h+='<button type="button" class="wg-row" data-wgk="'+it.k+'" data-wgo="'+s.o+'"><span class="wg-thumb"'+(s.g? ' data-wgth="'+esc(s.g)+'"' : '')+'>'+(s.g? '' : '<svg class="ico"><use href="#i-paw"/></svg>')+'</span>'+
       '<span class="wg-row-tx"><b>'+fmtHM(s.o)+'–'+fmtHM(s.i)+'</b><span>'+wgRowSub(s)+'</span></span>'+(pv? '<span class="wg-pill '+pv[0]+'">'+pv[1]+'</span>' : '')+'</button>';
  });
  body.innerHTML=h+'</div>';
  wgThumbs(body);
}
async function wgThumbs(root){
  const els=Array.prototype.slice.call(root.querySelectorAll('[data-wgth]'));
  let fetched=0;
  for(const el of els){
    const id=el.getAttribute('data-wgth');
    let p=wgCacheGet(id);
    if(!p && syncConfigured() && fetched<12){ fetched++; p=await wgFetchTrack(id); }
    if(!el.isConnected) return;
    if(p && p.segs){ const segs=p.segs.map(wgDec).filter(function(x){ return x.length; }); if(segs.length) el.innerHTML=wgRouteSvg(segs, 54, 54, {pad:6, sw:2.6, r:2.6}); }
    if(!el.innerHTML) el.innerHTML='<svg class="ico"><use href="#i-paw"/></svg>';
  }
}
async function wgHubMap(){
  const body=document.getElementById('wgHubBody'); if(!body) return;
  const items=wgWalks(90).filter(function(x){ return x.s.g; }).slice(0, 60);
  if(!items.length){ body.innerHTML='<div class="wg-empty"><b>지도 기록이 아직 없어요</b>지도로 기록한 산책 경로가 이 지도에 겹쳐서 쌓여요.</div>'; return; }
  body.innerHTML='<div class="wg-hmap" id="wgHubMap"><div class="wg-mapmsg">경로를 모으는 중…</div></div><p class="wg-note" id="wgHubMapN"></p>';
  const tracks=[]; let km=0;
  for(const it of items){ let p=wgCacheGet(it.s.g); if(!p && syncConfigured()) p=await wgFetchTrack(it.s.g); if(p){ tracks.push(p); km+=(+it.s.d||0); } }
  if(WG.hubTab!=='map' || !document.getElementById('wgHubMap')) return;
  const n=document.getElementById('wgHubMapN'); if(n) n.textContent='최근 90일 지도 기록 '+tracks.length+'회 · '+wgKm(km)+'km — 자주 걸은 길일수록 진하게 보여요.';
  wgDrawMap('wgHubMap', tracks, {heat:true});
}
function wgHubCrit(){
  const body=document.getElementById('wgHubBody'); if(!body) return;
  const rec=wgRec(), cfg=wgCfg();
  const rule=function(b, s){ return '<div class="wg-rule"><b>'+b+'</b><span>'+s+'</span></div>'; };
  const num=function(id, lbl, v, st){ return '<div><label class="wg-fl" for="'+id+'">'+lbl+'</label><input type="number" id="'+id+'" value="'+v+'" step="'+(st||1)+'" inputmode="decimal"></div>'; };
  let h='<div class="wg-crit">';
  h+='<div class="card"><div class="ct">판정 기준</div>'+
    rule('시간', rec? '1회 권장 <em>'+rec.per+'분</em> · 하루 <em>'+rec.day+'분</em> 이내 — '+esc(rec.why)+'. 통계·05장과 같은 기준이고 월령에 맞춰 자동으로 바뀌어요.' : '설정에서 생년월일을 입력하면 계산돼요.')+
    rule('날씨', '체감 <em>'+cfg.heatWarn+'℃</em> 이상 더위 주의 · <em>'+cfg.heatDanger+'℃</em> 이상 위험 · <em>'+cfg.coldWarn+'℃</em> 이하 추위 주의. 캐벌리어는 주둥이가 짧은 편이라 더위·습도에 약해요(05장).')+
    rule('속도', '시속 <em>'+cfg.runKmh+'km</em> 이상이 <em>'+cfg.runSec+'초</em> 넘게 이어지면 뛰기 구간으로 표시해요. 성장기에는 과한 뜀박질을 피해요(05장).')+
    rule('상태', '병원 확인: 기침 · 절뚝임 · 설사 · 쉬어도 헐떡임+처짐<br>지켜보기: 처짐 · 쉬어도 헐떡임 · 무른 변')+
    rule('GPS', '오차 <em>'+cfg.acc+'m</em> 넘는 위치는 버리고, 시속 25km 넘게 튄 점은 뺍니다. 30초 넘게 위치가 끊기면 공백으로 표시하고 직선거리로 추정해요.')+
    '<p class="wg-note">날씨·속도 기준은 보수적으로 잡은 기본값이에요. 아래에서 바꿀 수 있고, 판단은 수의사 진료가 우선이에요.</p></div>';
  h+='<div class="card"><div class="ct">기준값 바꾸기</div><div class="wg-f2">'+num('wgCfHw','더위 주의 (체감 ℃)',cfg.heatWarn)+num('wgCfHd','더위 위험 (체감 ℃)',cfg.heatDanger)+num('wgCfCw','추위 주의 (체감 ℃)',cfg.coldWarn)+
    num('wgCfAcc','GPS 최대 오차 (m)',cfg.acc)+num('wgCfRk','뛰기 속도 (km/h)',cfg.runKmh, 0.5)+num('wgCfRs','뛰기 지속 (초)',cfg.runSec, 10)+'</div>'+
    '<button type="button" class="sh-b1" id="wgCfSave">기준 저장</button><button type="button" class="sh-cancel" id="wgCfReset">기본값으로</button></div>';
  h+='<div class="card"><div class="ct">집 근처 가리기</div>'+
    '<label class="wg-sw"><span>집 주변 경로는 저장하지 않기</span><input type="checkbox" class="sw" id="wgHomeSw"'+(cfg.hideHome && cfg.home? ' checked' : '')+(cfg.home? '' : ' disabled')+'></label>'+
    '<label class="wg-fl" for="wgHomeR">가리는 반경</label><select id="wgHomeR">'+[100,200,300,500].map(function(r){ return '<option value="'+r+'"'+(+cfg.homeR===r? ' selected' : '')+'>'+r+'m</option>'; }).join('')+'</select>'+
    '<button type="button" class="btn ghost sm" id="wgHomeSet" style="margin-top:12px;">지금 위치를 집으로 설정</button>'+
    '<p class="wg-note" id="wgHomeSt">'+(cfg.home? '설정됨 · 정확한 집 위치 대신 집 근처 임의 지점을 기준으로 저장했어요.' : '아직 설정 안 됨 · 집에서 위 버튼을 눌러 주세요.')+'</p>'+
    '<p class="wg-note">거리·시간은 전체 경로로 계산하고, 저장할 때만 반경 안 지점을 뺍니다. 두 폰에 같이 적용돼요.</p></div>';
  h+='<div class="card"><div class="ct">경로 저장 위치</div><p class="wg-note" style="margin:0;">'+(syncConfigured()
    ? '경로는 기존 기록과 같은 가족 동기화 저장소에 따로 저장돼요. 데이터베이스 주소와 가족 코드를 둘 다 알아야 열 수 있고, 두 값은 핸드북 공개 주소에 들어 있지 않아요(각 폰에만 저장). 가족 코드는 다른 사람에게 알려주지 마세요.'
    : '동기화가 꺼져 있어 경로는 이 폰에만 저장돼요.')+'</p></div>';
  h+='<p class="wg-foot">지도 © OpenStreetMap contributors · 날씨·고도 Open-Meteo.com (고도 Copernicus DEM GLO-90)</p></div>';
  body.innerHTML=h;
  const on=function(id, ev, fn){ const el=document.getElementById(id); if(el) el.addEventListener(ev, fn); };
  on('wgCfSave', 'click', function(){
    const g=function(id){ const v=parseFloat((document.getElementById(id)||{}).value); return isFinite(v)? v : null; };
    const hw=g('wgCfHw'), hd=g('wgCfHd'), cw=g('wgCfCw'), acc=g('wgCfAcc'), rk=g('wgCfRk'), rs=g('wgCfRs');
    if([hw,hd,cw,acc,rk,rs].some(function(v){ return v==null; })){ uiAlert('빈칸 없이 숫자로 입력해 주세요.'); return; }
    if(hd<=hw){ uiAlert('더위 위험 온도는 더위 주의보다 높아야 해요.'); return; }
    if(cw>=hw){ uiAlert('추위 주의 온도는 더위 주의보다 낮아야 해요.'); return; }
    if(acc<10 || acc>200 || rk<3 || rk>25 || rs<10 || rs>600){ uiAlert('범위를 확인해 주세요.\nGPS 오차 10~200m · 뛰기 속도 3~25km/h · 뛰기 지속 10~600초'); return; }
    wgCfgSet({heatWarn:hw, heatDanger:hd, coldWarn:cw, acc:Math.round(acc), runKmh:rk, runSec:Math.round(rs)});
    uiToast('기준을 저장했어요'); wgHubCrit();
  });
  on('wgCfReset', 'click', function(){ wgCfgSet({heatWarn:WG_DEF.heatWarn, heatDanger:WG_DEF.heatDanger, coldWarn:WG_DEF.coldWarn, acc:WG_DEF.acc, runKmh:WG_DEF.runKmh, runSec:WG_DEF.runSec}); uiToast('기본값으로 되돌렸어요'); wgHubCrit(); });
  on('wgHomeSw', 'change', function(){ wgCfgSet({hideHome:!!this.checked}); uiToast(this.checked? '집 근처 가리기 켜짐' : '집 근처 가리기 꺼짐'); });
  on('wgHomeR', 'change', function(){
    const r=+this.value, c2=wgCfg();
    wgCfgSet({homeR:r});
    const st=document.getElementById('wgHomeSt');
    if(st && c2.home && r<(+c2.homeRset||0)) st.textContent='반경을 줄였어요 · 집에서 \'지금 위치를 집으로 설정\'을 한 번 더 눌러야 적용돼요(그 전까지는 '+c2.homeRset+'m 유지).';
  });
  on('wgHomeSet', 'click', wgHomeSet);
}
function wgHomeSet(){
  const st=document.getElementById('wgHomeSt');
  if(!navigator.geolocation){ if(st) st.textContent='이 화면에서는 위치를 쓸 수 없어요.'; return; }
  if(st) st.textContent='위치를 확인하는 중…';
  navigator.geolocation.getCurrentPosition(function(pos){
    const co=pos.coords, cfg=wgCfg(), R=+cfg.homeR||200;
    if(!(co.accuracy<=100)){ if(st) st.textContent='위치 오차가 커요(±'+Math.round(co.accuracy||0)+'m). 창가에서 다시 눌러 주세요.'; return; }
    const ang=Math.random()*2*Math.PI, dist=R*(0.2+Math.random()*0.25);
    const dLa=dist*Math.cos(ang)/111320, dLo=dist*Math.sin(ang)/(111320*Math.cos(co.latitude*Math.PI/180));
    wgCfgSet({home:{lat:Math.round((co.latitude+dLa)*1e4)/1e4, lng:Math.round((co.longitude+dLo)*1e4)/1e4}, homeRset:R, hideHome:true});
    uiToast('집 근처 가리기를 켰어요'); wgHubCrit();
  }, function(e){ if(st) st.textContent=(e && e.code===1)? '위치 권한이 꺼져 있어요.' : '위치를 찾지 못했어요. 잠시 후 다시 눌러 주세요.'; }, {enableHighAccuracy:true, timeout:15000, maximumAge:0});
}

/* ---------- 산책 상세 ---------- */
function wgSegFind(k, o){ return ((S.walkLog||{})[k]||[]).find(function(s){ return s && s.o===o; })||null; }
async function wgDetOpen(k, o, fromHub){
  const s=wgSegFind(k, o); if(!s) return;
  wgEnsureDom();
  const el=document.getElementById('wgDet');
  WG.det={k:k, o:o};
  if(!el.classList.contains('on')){ if(!WG.hist.length) WG.scrollY=window.scrollY||0; el.classList.add('on'); wgHistPush('det'); }
  const xt=document.getElementById('wgDetXT'); if(xt) xt.textContent=fromHub? '산책' : '닫기';
  document.getElementById('wgDetT').textContent=wgDateLbl(s.o);
  const pg=document.getElementById('wgDetPage'); if(pg) pg.scrollTop=0;
  let p=s.g? wgCacheGet(s.g) : null;
  wgDetPaint(s, p);
  if(s.g && !p && syncConfigured()){ p=await wgFetchTrack(s.g); if(p && WG.det && WG.det.o===o && WG.det.k===k) wgDetPaint(s, p); else if(!p) wgDetNoTrack(); }
}
function wgDetNoTrack(){ const m=document.querySelector('#wgDetMap .wg-mapmsg'); if(m) m.textContent='경로를 불러오지 못했어요 · 인터넷 연결을 확인해 주세요'; }
function wgDetPaint(s, p){
  const box=document.getElementById('wgDetIn'); if(!box) return;
  if(WG.maps.wgDetMap){ try{ WG.maps.wgDetMap.remove(); }catch(e){} delete WG.maps.wgDetMap; }
  let h='<div class="wg-ttl"><b>'+fmtHM(s.o)+'–'+fmtHM(s.i)+'</b><span>'+(p && p.by? esc(p.by)+' 기록' : '')+'</span></div>';
  if(s.g) h+='<div class="wg-dmap" id="wgDetMap"><div class="wg-mapmsg">'+(p? '' : (syncConfigured()? '경로를 불러오는 중…' : '이 폰에 경로가 없어요'))+'</div></div>';
  h+=wgSegHtml(s, p, false);
  if(p && p.photos && p.photos.length) h+='<div class="wg-photos">'+p.photos.map(function(x){ return '<img alt="산책 사진" data-wgph="'+esc(x.id)+'">'; }).join('')+'</div>';
  h+='<button type="button" class="wg-del" id="wgDetDel">이 산책 기록 삭제</button>';
  box.innerHTML=h;
  const del=document.getElementById('wgDetDel'); if(del) del.addEventListener('click', function(){ wgDelete(s); });
  if(s.g && p) wgDrawMap('wgDetMap', [p], {});
  box.querySelectorAll('img[data-wgph]').forEach(function(img){
    const id=img.getAttribute('data-wgph');
    if(ALB.thumbs && ALB.thumbs.has(id)){ img.src=ALB.thumbs.get(id); return; }
    try{ albImgSrc('th', id).then(function(v){ if(v){ ALB.thumbs.set(id, v); img.src=v; } }).catch(function(){ img.style.display='none'; }); }catch(e){ img.style.display='none'; }
  });
}
function wgDetClose(fromPop){
  const el=document.getElementById('wgDet'); if(!el || !el.classList.contains('on')) return;
  el.classList.remove('on'); WG.det=null;
  if(WG.maps.wgDetMap){ try{ WG.maps.wgDetMap.remove(); }catch(e){} delete WG.maps.wgDetMap; }
  if(!fromPop) wgHistBack('det');
}
async function wgDelete(s){
  const ok=await uiConfirm({title:'이 산책 기록을 삭제할까요?', msg:fmtHM(s.o)+'–'+fmtHM(s.i)+' · '+fmtDur(s.i-s.o)+(s.g? '\n경로도 함께 지워져요. 앨범 사진은 그대로 남아요.' : ''), ok:'삭제', destr:true});
  if(!ok) return;
  Object.keys(S.walkLog||{}).forEach(function(k){
    const a=S.walkLog[k]; if(!Array.isArray(a)) return;
    const n=a.filter(function(x){ return x!==s; });
    if(n.length!==a.length){ if(n.length) S.walkLog[k]=n; else delete S.walkLog[k]; }
  });
  if(s.g){
    wgCacheDel(s.g); wgQSet(wgQ().filter(function(x){ return x!==s.g; }));
    if(syncConfigured()){ const qd=wgQDel(); if(qd.indexOf(s.g)<0){ qd.push(s.g); lsSet(WG_K.qdel, JSON.stringify(qd)); } wgQFlush(); }
  }
  saveState(); try{ renderQlog(); }catch(e){} try{ renderCal(); }catch(e){}
  wgDetClose();
  const hub=document.getElementById('wgHub'); if(hub && hub.classList.contains('on')) wgHubPaint();
  uiToast('산책 기록을 삭제했어요');
}

/* ---------- 직접 추가 ---------- */
function wgAddOpen(){
  wgEnsureDom();
  const now=new Date(Date.now()-30*60000), rec=wgRec();
  document.getElementById('wgAddD').value=d2s(now);
  document.getElementById('wgAddT').value=String(now.getHours()).padStart(2,'0')+':'+String(now.getMinutes()).padStart(2,'0');
  document.getElementById('wgAddM').value=rec? rec.per : 20;
  document.getElementById('wgAddK').value='';
  document.getElementById('wgAddH').textContent='';
  document.getElementById('wgAdd').classList.add('on');
}
function wgAddSave(){
  const d=document.getElementById('wgAddD').value, t=document.getElementById('wgAddT').value;
  const m=parseInt(document.getElementById('wgAddM').value, 10), kmv=document.getElementById('wgAddK').value, km=parseFloat(kmv);
  const hint=document.getElementById('wgAddH');
  if(!/^\d{4}-\d\d-\d\d$/.test(d) || !/^\d\d:\d\d$/.test(t)){ hint.textContent='날짜와 시작 시각을 입력해 주세요.'; return; }
  if(!(m>=1 && m<=300)){ hint.textContent='걸은 시간은 1~300분으로 입력해 주세요.'; return; }
  if(kmv!=='' && !(km>=0 && km<=50)){ hint.textContent='거리는 0~50km로 입력하거나 비워 두세요.'; return; }
  const o=new Date(d+'T'+t+':00').getTime(), i=o+m*60000;
  if(!isFinite(o)){ hint.textContent='날짜·시각을 확인해 주세요.'; return; }
  if(i>Date.now()){ hint.textContent='끝나는 시각이 지금보다 늦어요.'; return; }
  const key=d2s(new Date(i));
  const seg={o:o, i:i, man:1}; if(kmv!=='') seg.d=Math.round(km*1000);
  S.walkLog=S.walkLog||{};
  const dup=Object.keys(S.walkLog).some(function(k){ return (S.walkLog[k]||[]).some(function(x){ return x && x.o<i && x.i>o; }); });
  (S.walkLog[key]=S.walkLog[key]||[]).push(seg);
  S.walkLog[key].sort(function(a, b){ return a.o-b.o; });
  /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
  saveState(); try{ renderQlog(); }catch(e){} try{ renderCal(); }catch(e){}
  document.getElementById('wgAdd').classList.remove('on');
  const hub=document.getElementById('wgHub'); if(hub && hub.classList.contains('on')){ WG.hubTab='list'; wgHubPaint(); }
  uiToast(dup? '추가했어요 · 같은 시간대 산책 기록이 이미 있어요' : '산책 기록을 추가했어요');
}

/* ---------- 달력 ---------- */
function wgCalDot(ds){ const a=(S.walkLog||{})[ds]; return (Array.isArray(a) && a.some(function(s){ return s && +s.i>+s.o; }))? '<span class="dot wk"></span>' : ''; }
function wgCalSel(ds, box){
  if(!box) return;
  const a=((S.walkLog||{})[ds]||[]).filter(function(s){ return s && +s.i>+s.o; }); if(!a.length) return;
  let h='<div class="wg-cal">';
  a.forEach(function(s){
    h+='<div class="ev-row" role="button" tabindex="0" data-wgk="'+ds+'" data-wgo="'+s.o+'"><span><span class="ev-tag wk">산책</span> '+fmtHM(s.o)+'–'+fmtHM(s.i)+' · '+fmtDur(s.i-s.o)+(s.d!=null? ' · '+wgKm(s.d)+'km' : '')+'</span><svg class="ico chev"><use href="#i-chev"/></svg></div>';
  });
  box.insertAdjacentHTML('beforeend', h+'</div>');
  box.querySelectorAll('.wg-cal .ev-row').forEach(function(r){
    const go=function(){ wgDetOpen(r.dataset.wgk, +r.dataset.wgo, false); };
    r.addEventListener('click', go); r.addEventListener('keydown', function(e){ if(e.key==='Enter' || e.key===' '){ e.preventDefault(); go(); } });
  });
}

/* ---------- 새로고침·재시작 후 복구 ---------- */
function wgRecover(){
  let c=null; try{ c=JSON.parse(lsGet(WG_K.cur)||'null'); }catch(e){ c=null; }
  if(!c || !c.id || !Array.isArray(c.segs) || !c.st){ if(c) wgLsDel(WG_K.cur); return; }
  if(c.dev && c.dev!==DEV_ID){ wgLsDel(WG_K.cur); return; }
  WG.cur=c;
  if(c.ending){ c.ending=0; }
  wgTickOn(); wgHomePaint();
  const last=c.lastMove||c.startAt;
  uiSheetOpen({title:'진행 중이던 산책이 있어요', msg:fmtHM(c.o)+' 시작 · '+wgKm(wgDistLive())+'km\n마지막 움직임 '+fmtHM(last), list:true,
    actions:[{label:'이어서 기록'},{label:fmtHM(last)+'에 끝내고 저장'},{label:'지도 기록 버리기', destr:true}], cancel:'나중에'}).then(function(r){
    if(!r || !r.ok || !WG.cur) return;
    if(r.idx===0) wgOpenScr();
    else if(r.idx===1) wgEnd(last);
    else wgDiscardAsk();
  });
}

/* ---------- 시작 ---------- */
function walkInit(){
  wgEnsureDom();
  wgHomePaint();
  document.addEventListener('visibilitychange', function(){
    const c=WG.cur; if(!c) return;
    if(document.visibilityState==='hidden'){ WG.hiddenAt=Date.now(); wgPersist(true); return; }
    if(c.ending) return;
    if(WG.watchId!=null){
      if(Date.now()-(WG.hiddenAt||0)>10000) wgWatch();       /* 일부 폰은 돌아온 뒤 위치 알림이 멈춰 있어 다시 건다 */
      wgWakeOn(false);
    }
    wgPaintLive(); wgHomePaint();
  });
  window.addEventListener('pagehide', function(){ if(WG.cur) wgPersist(true); });
  window.addEventListener('online', function(){ wgQFlush(); });
  window.addEventListener('resize', function(){ if(WG.lm){ try{ WG.lm.map.invalidateSize(); }catch(e){} } });
  wgRecover();
  setTimeout(wgQFlush, 3000);
}


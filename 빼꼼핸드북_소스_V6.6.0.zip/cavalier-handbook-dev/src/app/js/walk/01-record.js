/* ---------- 기록 시작 ---------- */
async function wgStart(){
  if(WG.cur){ wgOpenScr(); return; }
  if(!navigator.geolocation){ uiAlert('이 화면에서는 위치를 쓸 수 없어요.\n아이폰은 사파리, 갤럭시는 크롬으로 핸드북을 열어 주세요.'); return; }
  const g=S.walkGps;
  if(g && g.d && g.d!==DEV_ID && S.walkCur && Date.now()-(+g.o||0)<4*3600000){
    const ok=await uiConfirm({title:'다른 폰에서 지도 기록 중', msg:(g.n? g.n+' 폰' : '다른 폰')+'에서 '+fmtHM(g.o)+'부터 기록하고 있어요.\n같이 산책 중이면 한 폰으로만 기록하세요.', ok:'이 폰에서도 기록'});
    if(!ok) return;
  }
  wgAudioPrime();
  const now=Date.now(), o=S.walkCur||now;
  WG.cur={v:1, id:'w'+now.toString(36)+Math.random().toString(36).slice(2,5), dev:DEV_ID, by:(myName()||''), startAt:now, o:o,
    segs:[[]], pauses:[], paused:0, gaps:[], anchor:null, out:0, rw:[], lastMove:now, lastFixAt:0, fixes:0, acc:null, pos:null, geoErr:0,
    st:{dist:0, mv:0, sn:0, gapD:0, gapS:0, run:0, runCur:0, runMax:0, maxV:0}, ele:{g:0, l:0, ref:null, n:0},
    w:null, wTry:0, photos:[], pins:[], al:{}, ending:0};
  if(!S.walkCur) S.walkCur=o;
  S.walkGps={d:DEV_ID, n:(myName()||''), o:o};
  saveState(); try{ renderQlog(); }catch(e){}
  WG.banner=null; WG.follow=true;
  wgPersist(true);
  wgWatch(); wgWakeOn(true); wgTickOn();
  wgOpenScr();
}
function wgWatch(){
  wgUnwatch();
  const c=WG.cur; if(!c) return;
  try{ WG.watchId=navigator.geolocation.watchPosition(wgOnFix, wgOnGeoErr, {enableHighAccuracy:true, maximumAge:0, timeout:27000}); }
  catch(e){ wgOnGeoErr({code:2}); }
}
function wgUnwatch(){ if(WG.watchId!=null){ try{ navigator.geolocation.clearWatch(WG.watchId); }catch(e){} WG.watchId=null; } }
function wgOnGeoErr(e){
  const c=WG.cur; if(!c) return;
  c.geoErr=(e && e.code)||2;
  if(c.geoErr===1){ wgUnwatch(); wgPermHelp(); }
  wgPaintLive();
}
function wgPermHelp(){
  const ios=/iPhone|iPad|iPod/.test(navigator.userAgent||'');
  const msg= ios
    ? '설정 > 개인정보 보호 및 보안 > 위치 서비스 > Safari 웹 사이트 → \'앱을 사용하는 동안\' 선택, \'정확한 위치\' 켜기.\n\n바꾼 뒤 핸드북으로 돌아와 \'다시 시도\'를 누르세요.'
    : '크롬 ⋮ > 설정 > 사이트 설정 > 위치 → 핸드북 허용.\n폰 위쪽 빠른 설정의 \'위치\'도 켜 주세요.\n\n바꾼 뒤 \'다시 시도\'를 누르세요.';
  uiSheetOpen({title:'위치 권한이 꺼져 있어요', msg:msg, actions:[{label:'다시 시도'}], cancel:'닫기'}).then(function(r){
    if(r && r.ok && WG.cur){ WG.cur.geoErr=0; wgWatch(); wgPaintLive(); }
  });
}

/* ---------- 위치 수신 → 거리·시간 계산 ----------
   점 p=[위도, 경도, 시각(ms), 오차(m), 고도(m|null)]
   · 오차 > 기준(35m) → 버림
   · 마지막 '유효 위치'(오차 기준 통과) 후 30초 넘게 아무것도 못 받았으면 → 기록 공백(직선거리 추정, 새 구간)
     ※ 제자리(킁킁)일 때도 위치는 계속 들어오므로 공백이 아님
   · 시속 25km 넘는 점프 → 튐(3번 연속이면 새 위치로 인정)   · 움직임 < max(3m, 오차/4) → 제자리(점 추가 안 함)
   · 시간 배분: 직전 점에서 마지막 제자리 위치까지 = 킁킁·쉼(10초 초과일 때), 그 뒤 = 이동 */
function wgOnFix(pos){
  const c=WG.cur; if(!c || c.ending || !pos || !pos.coords) return;
  const co=pos.coords, now=Date.now();
  if(!isFinite(co.latitude) || !isFinite(co.longitude)) return;
  let t=+pos.timestamp||now; if(Math.abs(t-now)>120000) t=now;
  const alt=(co.altitude!=null && isFinite(co.altitude) && (co.altitudeAccuracy==null || co.altitudeAccuracy<=30))? Math.round(co.altitude*10)/10 : null;
  const p=[Math.round(co.latitude*1e6)/1e6, Math.round(co.longitude*1e6)/1e6, t, Math.round(co.accuracy||0), alt];
  c.fixes++; c.lastFixAt=now; c.acc=p[3]; c.pos=p; c.geoErr=0;
  if(!c.w) wgWeatherFetch(p);
  if(c.paused){ wgLiveMe(p); wgPaintLive(); return; }
  const cfg=wgCfg();
  if(p[3]>cfg.acc){ wgLiveMe(p); wgPaintLive(); return; }
  let seg=c.segs[c.segs.length-1];
  const A=c.anchor;
  if(!A){
    if(seg.length){ seg=[]; c.segs.push(seg); }
    seg.push(p); c.anchor=p; c.goodT=t; c.lastMove=t; wgEleGps(p); wgAdded(p, true); return;
  }
  const gT=Math.max(+c.goodT||0, A[2]);
  if(t<=gT){ if(gT-t>60000){ c.anchor=null; c.goodT=0; } return; }   /* 폰 시계가 크게 뒤로 가면 새 구간으로 다시 시작 */
  const d=wgHav(A, p), dtG=(t-gT)/1000;
  if(dtG>WG_GAP){ wgGap(A, p, d, gT); return; }
  if(d/Math.max(dtG, 1)>WG_MAXV){ c.out=(c.out||0)+1; if(c.out<3){ wgPaintLive(); return; } wgGap(A, p, d, gT); return; }
  c.out=0;
  const thr=Math.max(3, (p[3]+A[3])/4);
  if(d<thr){ c.goodT=t; wgRun(t, t, 0, true); wgLiveMe(p); wgPaintLive(); return; }
  const stopS=(gT-A[2])/1000;
  if(stopS>10){ c.st.sn+=stopS; c.st.mv+=dtG; } else c.st.mv+=stopS+dtG;
  c.st.dist+=d; const v=d/Math.max(dtG, 1); if(v>c.st.maxV) c.st.maxV=v;
  seg.push(p); c.anchor=p; c.goodT=t; c.lastMove=t; c.al.still=0;
  wgEleGps(p); wgRun(gT, t, d, false);
  wgAdded(p, false);
}
function wgGap(A, p, d, gT){
  const c=WG.cur, stopS=Math.max(0, (gT-A[2])/1000);
  if(stopS>10) c.st.sn+=stopS; else c.st.mv+=stopS;
  c.gaps.push([gT, p[2], Math.round(d)]); c.st.gapD+=d; c.st.gapS+=Math.max(0, (p[2]-gT)/1000);
  c.segs.push([p]); c.anchor=p; c.goodT=p[2]; c.out=0; c.rw=[]; c.st.runCur=0; c.al.runNow=0; c.lastMove=p[2]; c.al.still=0;
  wgEleGps(p); wgAdded(p, true);
}
/* 마지막 점 이후 시간 정산 (멈춤·끝낼 때) — 제자리면 킁킁·쉼, 신호가 30초 넘게 없었으면 공백 */
function wgSettle(T){
  const c=WG.cur; if(!c || !c.anchor) return;
  const A=c.anchor, gT=Math.min(T, Math.max(+c.goodT||0, A[2]));
  const stopS=Math.max(0, (gT-A[2])/1000), after=Math.max(0, (T-gT)/1000);
  if(stopS>10) c.st.sn+=stopS; else c.st.mv+=stopS;
  if(after>WG_GAP) c.st.gapS+=after; else if(after>0){ if(stopS>10) c.st.sn+=after; else c.st.mv+=after; }
  c.anchor=null;
}
function wgAdded(p, newSeg){ wgPersist(false); try{ wgLiveAdd(p, newSeg); wgLiveMe(p); }catch(e){ console.warn('wg map', e); } wgPaintLive(); }   /* 지도 그리기 오류가 기록을 멈추지 않게 */
/* 뛰기 판정: 최근 30초 이동거리 ÷ 그 시간 ≥ 기준 속도 → 지속 시간 누적 */
function wgRun(t0, t1, d, still){
  const c=WG.cur, cfg=wgCfg();
  c.rw=(c.rw||[]).filter(function(x){ return t1-x[1]<=30000; });
  if(!still) c.rw.push([t0, t1, d]);
  if(still || !c.rw.length){ c.st.runCur=0; c.al.runNow=0; return; }
  let sd=0, a=Infinity; c.rw.forEach(function(x){ sd+=x[2]; if(x[0]<a) a=x[0]; });
  const span=Math.max(8, (t1-a)/1000), kmh=sd/span*3.6, dt=(t1-t0)/1000;
  if(kmh>=cfg.runKmh){
    c.st.runCur+=dt; c.st.run+=dt; if(c.st.runCur>c.st.runMax) c.st.runMax=c.st.runCur;
    if(c.st.runCur>=cfg.runSec && !c.al.runNow){ c.al.runNow=1; wgAlert('run'); }
  }else{ c.st.runCur=0; c.al.runNow=0; }
}
function wgEleGps(p){
  if(p[4]==null) return; const e=WG.cur.ele; e.n++;
  if(e.ref==null){ e.ref=p[4]; return; }
  const dz=p[4]-e.ref; if(Math.abs(dz)>=3){ if(dz>0) e.g+=dz; else e.l-=dz; e.ref=p[4]; }
}
function wgPause(){
  const c=WG.cur; if(!c || c.paused) return;
  const now=Date.now(); wgSettle(now);
  c.paused=now; c.st.runCur=0; c.al.runNow=0; c.rw=[];
  wgPersist(true); wgPaintLive();
  uiToast('위치 기록을 멈췄어요 · 산책 시간은 계속 셉니다');
}
function wgResume(){
  const c=WG.cur; if(!c || !c.paused) return;
  c.pauses.push([c.paused, Date.now()]); c.paused=0; c.anchor=null; c.segs.push([]); c.lastMove=Date.now();
  wgPersist(true); wgPaintLive();
}
function wgElapsed(now){ const c=WG.cur; return c? Math.max(0, ((now||Date.now())-c.o)/1000) : 0; }
function wgSniffLive(now){
  const c=WG.cur; if(!c) return 0;
  let s=c.st.sn;
  const n=now||Date.now();
  if(!c.paused && c.anchor && n-(+c.goodT||0)<=WG_GAP*1000){ const idle=(n-c.anchor[2])/1000; if(idle>10) s+=idle; }
  return s;
}
function wgDistLive(){ const c=WG.cur; return c? c.st.dist+c.st.gapD : 0; }

/* ---------- 화면 꺼짐 방지 · 소리 · 진동 ---------- */
async function wgWakeOn(){
  if(!WG.cur) return;
  if(!navigator.wakeLock || typeof navigator.wakeLock.request!=='function'){ WG.wakeNo=1; wgWakeTip(); wgPaintLive(); return; }
  if(WG.wake && !WG.wake.released) return;
  try{
    const w=await navigator.wakeLock.request('screen');
    WG.wake=w; WG.wakeFail=0;
    if(w && w.addEventListener) w.addEventListener('release', function(){ if(WG.wake===w) WG.wake=null; if(WG.cur && document.visibilityState==='visible') WG.wakeFail=1; wgPaintLive(); });
  }catch(e){ WG.wake=null; WG.wakeFail=1; }
  wgPaintLive();
}
function wgWakeOff(){ const w=WG.wake; WG.wake=null; WG.wakeFail=0; if(w){ try{ w.release(); }catch(e){} } }
function wgWakeTip(){
  if(lsGet(WG_K.tip)) return; lsSet(WG_K.tip, '1');
  uiAlert('이 폰은 화면 꺼짐 방지를 지원하지 않아요.\n산책 중에는 설정에서 자동 잠금을 \'안 함\'으로 바꿔 두면 기록이 끊기지 않아요.');
}
function wgAudioPrime(){
  try{ const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return; if(!WG.ac) WG.ac=new AC(); if(WG.ac.state==='suspended' && WG.ac.resume) WG.ac.resume(); }catch(e){}
}
function wgBeep(n){
  const ac=WG.ac; if(!ac || !ac.createOscillator) return;
  try{
    for(let i=0;i<(n||2);i++){
      const o=ac.createOscillator(), g=ac.createGain(), t=ac.currentTime+i*0.28;
      o.type='sine'; o.frequency.value=880; o.connect(g); g.connect(ac.destination);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t+0.02); g.gain.exponentialRampToValueAtTime(0.0001, t+0.2);
      o.start(t); o.stop(t+0.22);
    }
  }catch(e){}
}
function wgVibe(p){ try{ if(navigator.vibrate) navigator.vibrate(p||[180,90,180]); }catch(e){} }
function wgAlert(kind){
  const c=WG.cur; if(!c || c.ending) return;
  const rec=wgRec(), cfg=wgCfg();
  let msg='', cls='', act=null;
  if(kind==='rec'){ msg='권장 '+(rec? rec.per : '')+'분이 됐어요. 슬슬 집으로 가요.'; }
  else if(kind==='run'){ msg='뛰는 속도가 '+cfg.runSec+'초 넘게 이어졌어요. 성장기엔 천천히 걷는 게 좋아요.'; }
  else if(kind==='heat'){
    const v=wgHeat(c.w, cfg), f=c.w? wgT(c.w.f) : '';
    if(v==='danger'){ msg='체감 '+f+' · 더위 위험. 짧게 끝내고 그늘·물을 챙기세요.'; cls='bad'; }
    else if(v==='cold') msg='체감 '+f+' · 추워요. 짧게 걷고 몸을 떨면 귀가하세요.';
    else msg='체감 '+f+' · 더위 주의. 그늘로 걷고, 헐떡임이 심하면 쉬세요.';
  }
  else if(kind==='still'){
    const lm=c.lastMove;
    msg=Math.round((Date.now()-lm)/60000)+'분째 움직임이 없어요. 산책이 끝났나요?';
    act={label:fmtHM(lm)+'에 끝내기', fn:function(){ wgEnd(lm); }};
  }
  WG.banner={kind:kind, msg:msg, cls:cls, act:act, at:Date.now()};
  wgPaintBanner(); wgPaintLive();
  wgVibe(); wgBeep(kind==='rec'? 3 : 2);
}

/* ---------- 날씨 (Open-Meteo, 키 불필요) ---------- */
async function wgWeatherFetch(p){
  const c=WG.cur; if(!c || c.w || WG.wBusy) return;
  if(c.wTry && Date.now()-c.wTry<120000) return;
  WG.wBusy=true; c.wTry=Date.now();
  try{
    const j=await wgFetchJ('https://api.open-meteo.com/v1/forecast?latitude='+p[0].toFixed(3)+'&longitude='+p[1].toFixed(3)+'&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code&timezone=Asia%2FSeoul', 8000);
    const cu=j && j.current;
    if(cu && cu.apparent_temperature!=null && isFinite(cu.apparent_temperature) && WG.cur===c){
      c.w={t:+cu.temperature_2m, f:+cu.apparent_temperature, h:cu.relative_humidity_2m, c:cu.weather_code, at:Date.now()};
      wgPersist(true); wgPaintLive();
      const v=wgHeat(c.w, wgCfg()); if(v && v!=='ok' && !c.al.heat){ c.al.heat=1; wgAlert('heat'); }
    }
  }catch(e){}
  finally{ WG.wBusy=false; }
}

/* ---------- 1초 타이머 ---------- */
function wgTickOn(){ if(!WG.tick) WG.tick=setInterval(wgTickFn, 1000); }
function wgTickOff(){ clearInterval(WG.tick); WG.tick=null; }
function wgTickFn(){
  const c=WG.cur; if(!c){ wgTickOff(); return; }
  if(c.ending) return;
  const now=Date.now(), rec=wgRec();
  if(WG.watchId!=null){
    if(rec && !c.al.rec && wgElapsed(now)>=rec.per*60){ c.al.rec=1; wgAlert('rec'); wgPersist(true); }
    if(!c.paused && !c.al.still && c.anchor && (now-c.lastMove)/1000>=WG_STILL){ c.al.still=1; wgAlert('still'); }
  }
  if(WG.scrOpen || WG.pocket) wgPaintLive(); else wgHomePaintLive();
  if(now-WG.persistAt>15000) wgPersist(true);
}

/* ---------- 끝내기 ---------- */
async function wgEndAsk(){
  const c=WG.cur; if(!c || c.ending) return;
  const idle=(Date.now()-c.lastMove)/60000;
  if(c.fixes>0 && idle>=10){
    const lm=c.lastMove;
    const idx=await uiActions('마지막으로 움직인 시각은 '+fmtHM(lm)+'이에요', [{label:fmtHM(lm)+'에 끝내기'},{label:'지금 끝내기'}]);
    if(idx<0) return;
    wgEnd(idx===0? lm : Date.now()); return;
  }
  const ok=await uiConfirm({title:'산책을 끝낼까요?', msg:'오늘 산책 기록에 저장돼요.', ok:'끝내기'});
  if(ok) wgEnd();
}
function wgEnd(endAt){
  const c=WG.cur; if(!c || c.ending) return;
  const now=Date.now();
  if(c.paused){ c.pauses.push([c.paused, now]); c.paused=0; }
  c.endAt=Math.min(now, Math.max(c.o+1000, endAt||now));
  wgSettle(c.endAt);
  c.ending=1;
  wgUnwatch(); wgWakeOff(); wgPocketOff();
  WG.banner=null;
  wgPersist(true);
  if(!WG.scrOpen) wgOpenScr();
  wgChkOpen();
}
async function wgDiscardAsk(){
  if(!WG.cur) return;
  const ok=await uiConfirm({title:'지도 기록을 버릴까요?', msg:'경로·거리 기록이 지워져요.\n산책 시간 기록은 홈 \'지금\' 카드에서 끝내거나 취소할 수 있어요.', ok:'버리기', destr:true});
  if(!ok) return;
  wgUnwatch(); wgWakeOff(); wgPocketOff(); wgTickOff();
  WG.cur=null; WG.banner=null; wgLsDel(WG_K.cur);
  if(S.walkGps && S.walkGps.d===DEV_ID){ delete S.walkGps; saveState(); }
  wgLiveKill();
  wgCloseScr();
  try{ renderQlog(); }catch(e){}
  uiToast('지도 기록을 버렸어요');
}
/* 홈 산책 타일·'지금' 카드 종료 버튼 → 지도 기록 중이면 산책 화면에서 끝내기 */
function wgIntercept(){
  if(!WG.cur) return false;
  wgOpenScr();
  if(!WG.cur.ending) setTimeout(wgEndAsk, 80);
  return true;
}

/* ---------- 상태 체크 판정 ---------- */
const WG_CK=[
  {k:'m', nm:'컨디션',   ops:[['g','좋음'],['n','보통'],['t','처짐',1]]},
  {k:'b', nm:'호흡',     ops:[['n','정상'],['p','쉬어도 헐떡임',1]]},
  {k:'c', nm:'기침',     ops:[['n','없음'],['y','있음',1]]},
  {k:'a', nm:'걸음걸이', ops:[['n','정상'],['l','절뚝임',1]]},
  {k:'p', nm:'배변',     ops:[['n','정상'],['s','무름',1],['d','설사',1],['x','안 함']]}
];
function wgCkV(ck){
  if(!ck || typeof ck!=='object' || !Object.keys(ck).length) return null;
  const r=[]; let lv='ok';
  const vet=function(t){ r.push(t); lv='vet'; }, watch=function(t){ r.push(t); if(lv!=='vet') lv='watch'; };
  if(ck.c==='y') vet('기침 — 하루 넘게 이어지거나 숨이 가쁘면 병원 확인');
  if(ck.a==='l') vet('절뚝임 — 다음 산책은 쉬고, 하루 넘게 이어지면 병원 확인');
  if(ck.p==='d') vet('설사 — 반복되거나 피가 섞이거나 처지면 병원 확인');
  if(ck.b==='p' && ck.m==='t') vet('쉬어도 헐떡임 + 처짐 — 그늘에서 쉬게 하고 바로 병원 확인');
  else{
    if(ck.b==='p') watch('쉬어도 헐떡임 — 그늘·물로 쉬게 하고, 계속되면 병원 확인');
    if(ck.m==='t') watch('처짐 — 오늘 운동량을 줄이고 식욕·배변을 함께 보기');
  }
  if(ck.p==='s') watch('무른 변 — 다음 변 상태 지켜보기');
  return {lv:lv, r:r};
}
/* 산책 1건 판정 목록 — 저장된 값(seg) 기준. 권장 시간은 그 산책 때의 값(rp·rd)을 쓴다 */
function wgJudgeSeg(s, p){
  const cfg=Object.assign({}, wgCfg(), (p && p.cfg) || {});
  const out=[], min=(s.i-s.o)/60000;
  if(s.rp){
    out.push({lv: min>s.rp? 'warn':'ok', h:'시간', b:Math.round(min)+'분 · 1회 권장 '+s.rp+'분', s: min>s.rp? '긴 편 — 다음 산책을 짧게 하거나 쉬어 가세요' : '권장 범위'});
    const day=wgDayMin(s);
    out.push({lv: day>s.rd? 'warn':'ok', h:'그날 합계', b:Math.round(day)+'분 · 하루 권장 '+s.rd+'분', s: day>s.rd? '권장 초과 — 통계 화면과 같은 기준' : '권장 범위'});
  }else out.push({lv:'na', h:'시간', b:Math.round(min)+'분', s:'권장 시간 비교 정보가 없는 기록이에요'});
  if(s.tf!=null){
    const hv=wgHeat({f:s.tf}, cfg), w=p && p.w;
    out.push({lv: hv==='ok'? 'ok' : (hv==='danger'? 'bad' : 'warn'), h:'날씨', b:'체감 '+wgT(s.tf)+(w && w.c!=null && wgWx(w.c)? ' · '+wgWx(w.c) : ''),
      s:{ok:'적정', warn:'더위 주의 (체감 '+cfg.heatWarn+'℃ 이상)', danger:'더위 위험 (체감 '+cfg.heatDanger+'℃ 이상)', cold:'추위 주의 (체감 '+cfg.coldWarn+'℃ 이하)'}[hv]});
  }else if(s.g) out.push({lv:'na', h:'날씨', b:'정보 없음', s:'산책 시작 때 날씨를 받지 못했어요'});
  if(s.rm!=null){
    const bad=s.rm>=cfg.runSec;
    out.push({lv: bad? 'warn':'ok', h:'속도', b: bad? '뛰는 속도 '+wgMin(s.rm)+' 이어짐' : '뛰기 구간 없음', s:'시속 '+cfg.runKmh+'km 이상이 '+cfg.runSec+'초 넘게 이어지면 표시'+(bad? ' · 성장기 관절 부담' : '')});
  }
  const cv=wgCkV(s.ck);
  if(cv) out.push({lv: cv.lv==='vet'? 'bad' : (cv.lv==='watch'? 'warn' : 'ok'), h:'상태 체크', b: cv.lv==='ok'? '모두 괜찮음' : (cv.lv==='vet'? '병원 확인' : '지켜보기'), s: cv.r.join(' · ')||'이상 없음'});
  else if(s.g) out.push({lv:'na', h:'상태 체크', b:'건너뜀', s:''});
  return out;
}
function wgDayMin(s){
  let k=null; Object.keys(S.walkLog||{}).forEach(function(kk){ ((S.walkLog||{})[kk]||[]).forEach(function(x){ if(x===s) k=kk; }); });
  const arr=k? (S.walkLog[k]||[]) : [s];
  return sumSegs(arr.filter(function(x){ return x && +x.i>+x.o; }))/60000;
}
function wgSegLv(s){
  if(!s.g && !s.ck) return null;
  const cv=wgCkV(s.ck), cfg=wgCfg();
  if(cv && cv.lv==='vet') return ['bad','병원 확인'];
  if(s.vh==='danger') return ['bad','더위 위험'];
  const long=s.rp && (s.i-s.o)/60000>s.rp;
  if(long || s.vh==='warn' || s.vh==='cold' || (s.rm!=null && s.rm>=cfg.runSec) || (cv && cv.lv==='watch')) return ['warn','주의'];
  return ['ok','적정'];
}


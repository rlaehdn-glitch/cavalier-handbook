
/* =============== V6.3 (2026-10-23): 산책 지도 기록 (GPS) ===============
   핸드북 화면이 켜져 있는 동안 위치를 받아 경로·거리·속도·킁킁(정지) 시간·고도를 기록한다.
   ① 산책 구간은 기존 S.walkLog{날짜:[{o,i}]}에 그대로 넣는다(g·d·mv·sn 등 필드만 덧붙임)
      → 통계·오늘 리본·목록·달력·채팅 요약이 기존 계산 그대로 집계. 진행 중엔 S.walkCur(기존)도 함께 켠다.
   ② 좌표는 상태 문서와 분리 저장: /handbook/{가족코드}-walk/t/{id}.json (앨범과 같은 규칙 경로 → DB 규칙 변경 불필요).
   ③ 진행 중 기록은 이 폰 localStorage(_wg_cur)에 수시 저장 → 새로고침·앱 재시작 후 이어서/끝내기.
   ④ 권장 시간 = 통계와 같은 statBand('walk')(월령×5분·하루 2회). 날씨·속도 기준은 기본값(설정에서 변경).
   ⑤ 웹 제한: 화면이 꺼지거나 다른 앱이 앞에 오면 위치가 멈춤 → 30초 넘는 공백은 직선거리 추정·점선 표시.
   기존 저장 구조·동기화·병합 엔진 변경 없음(S.walkGps·S.walkCfg 키 추가만). */
const WG={cur:null, watchId:null, wake:null, wakeFail:0, wakeNo:0, tick:null, persistAt:0, lm:null, follow:true, leaflet:null, ac:null,
  hiddenAt:0, hist:[], scrollY:0, hubTab:'list', det:null, ck:{}, sumId:null, maps:{}, banner:null, qBusy:false, wBusy:false, built:false, svgFb:false};
const WG_K={cur:'_wg_cur', cache:'_wg_cache', q:'_wg_q', qdel:'_wg_qdel', tip:'_wg_tipwl'};
const WG_DEF={heatWarn:26, heatDanger:29, coldWarn:0, runKmh:7, runSec:60, acc:35, homeR:200, homeRset:0, hideHome:false, home:null};
const WG_STILL=15*60;   /* 15분 움직임 없음 → '끝났나요?' */
const WG_GAP=30;        /* 위치 간격 30초 초과 = 기록 공백 */
const WG_MAXV=7;        /* 초속 7m(시속 25km) 넘는 점프 = 튐 */
/* 지도: OpenStreetMap 기본 타일(키 불필요 · 저작자 표시 필수). CARTO 지도는 2026-09부터 API 키 필요 → 사용 안 함.
   다크 모드는 같은 타일에 색 반전 필터. Leaflet 1.9.4는 jsDelivr npm 원본 파일. */
const WG_TILE='https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const WG_ATTR='&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors';
const WG_LEAF='https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/';

/* ---------- 계산 도구 ---------- */
function wgHav(a,b){
  const R=6371008.8, r=Math.PI/180, dLa=(b[0]-a[0])*r, dLo=(b[1]-a[1])*r;
  const s=Math.sin(dLa/2)*Math.sin(dLa/2)+Math.cos(a[0]*r)*Math.cos(b[0]*r)*Math.sin(dLo/2)*Math.sin(dLo/2);
  return 2*R*Math.asin(Math.min(1, Math.sqrt(s)));
}
function wgEnc(pts){                         /* Google polyline (정밀도 1e-5 ≈ 1.1m) */
  let out='', pa=0, po=0;
  const e=function(v){ v=v<0? ~(v<<1) : (v<<1); let s=''; while(v>=0x20){ s+=String.fromCharCode((0x20|(v&0x1f))+63); v>>=5; } return s+String.fromCharCode(v+63); };
  for(let i=0;i<pts.length;i++){ const la=Math.round(pts[i][0]*1e5), lo=Math.round(pts[i][1]*1e5); out+=e(la-pa)+e(lo-po); pa=la; po=lo; }
  return out;
}
function wgDec(str){
  const pts=[]; let i=0, la=0, lo=0; str=String(str||'');
  while(i<str.length){
    let b, s=0, r=0;
    do{ b=str.charCodeAt(i++)-63; r|=(b&0x1f)<<s; s+=5; }while(b>=0x20 && i<str.length+1);
    la+=(r&1)? ~(r>>1) : (r>>1);
    s=0; r=0;
    do{ b=str.charCodeAt(i++)-63; r|=(b&0x1f)<<s; s+=5; }while(b>=0x20 && i<str.length+1);
    lo+=(r&1)? ~(r>>1) : (r>>1);
    pts.push([la/1e5, lo/1e5]);
  }
  return pts;
}
function wgClock(sec){ sec=Math.max(0, Math.floor(sec)); const h=Math.floor(sec/3600), m=Math.floor(sec%3600/60), s=sec%60; return h? h+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0') : m+':'+String(s).padStart(2,'0'); }
function wgKm(m){ return (Math.max(0, +m||0)/1000).toFixed(2); }
function wgKmh(m, s){ return (s>0 && m>0)? (m/s*3.6).toFixed(1) : '0.0'; }
function wgMin(sec){ return fmtDur(Math.max(0, sec)*1000); }
function wgT(v){ return Math.round(v)+'℃'; }
function wgDateLbl(ms){ const d=new Date(ms); return (d.getMonth()+1)+'월 '+d.getDate()+'일 ('+['일','월','화','수','목','금','토'][d.getDay()]+')'; }
function wgWx(c){
  if(c==null || !isFinite(c)) return ''; c=+c;
  if(c===0) return '맑음'; if(c<=2) return '구름 조금'; if(c===3) return '흐림'; if(c===45||c===48) return '안개';
  if(c>=51&&c<=57) return '이슬비'; if(c>=61&&c<=67) return '비'; if(c>=71&&c<=77) return '눈'; if(c>=80&&c<=82) return '소나기';
  if(c===85||c===86) return '눈 소나기'; if(c>=95) return '뇌우'; return '';
}
function wgLsDel(k){ try{ localStorage.removeItem(k); }catch(e){} }
function wgDark(){
  const t=document.documentElement.getAttribute('data-theme');
  if(t==='dark') return true; if(t==='light') return false;
  try{ return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); }catch(e){ return false; }
}
function wgCss(v, fb){ try{ const x=getComputedStyle(document.documentElement).getPropertyValue(v).trim(); return x||fb; }catch(e){ return fb; } }
async function wgFetchJ(url, ms, opt){
  const ctl=(typeof AbortController!=='undefined')? new AbortController() : null;
  const to=setTimeout(function(){ if(ctl) ctl.abort(); }, ms||8000);
  try{
    const o=Object.assign({}, opt||{}); if(ctl) o.signal=ctl.signal;
    const r=await fetch(url, o);
    if(!r.ok) throw new Error('HTTP '+r.status);
    return await r.json();
  }finally{ clearTimeout(to); }
}
function wgPath(p){ return SYNC.url.replace(/\/+$/,'')+'/handbook/'+SYNC.code+'-walk/'+p+'.json'; }

/* ---------- 기준 ---------- */
function wgCfg(){ return Object.assign({}, WG_DEF, (S.walkCfg && typeof S.walkCfg==='object')? S.walkCfg : {}); }
function wgCfgSet(p){ S.walkCfg=Object.assign({}, (S.walkCfg && typeof S.walkCfg==='object')? S.walkCfg : {}, p); saveState(); }
function wgHomeR(cfg){ return Math.max(+cfg.homeR||0, +cfg.homeRset||0, 50); }
/* 권장 시간 — 통계(statBand)와 같은 숫자. 퍼피: 1회=월령×5분(lo), 하루=2회(hi) */
function wgRec(){
  let b=null; try{ b=statBand('walk'); }catch(e){ b=null; }
  if(!b) return null;
  let mo=null; try{ mo=ageMo(); }catch(e){}
  let per=b.lo, stage=true; try{ stage=walkStage(); }catch(e){}
  if(mo!=null && mo>=12) per=Math.round(b.hi/2);       /* 성견: 하루 40~60분 → 1회 약 30분 */
  else if(!stage) per=15;                              /* 접종 완료 전: 안고 외출 10~15분 */
  return {per:per, day:b.hi, why:b.why};
}
function wgHeat(w, cfg){
  if(!w || w.f==null || !isFinite(w.f)) return null;
  if(w.f>=cfg.heatDanger) return 'danger'; if(w.f>=cfg.heatWarn) return 'warn'; if(w.f<=cfg.coldWarn) return 'cold';
  return 'ok';
}

/* ---------- 이 폰 임시 저장 · 경로 캐시 · 올리기 대기열 ---------- */
function wgPersist(force){
  const c=WG.cur; if(!c) return;
  const now=Date.now(); if(!force && now-WG.persistAt<4000) return;
  WG.persistAt=now; c.savedAt=now;
  const raw=JSON.stringify(c);
  if(!lsSet(WG_K.cur, raw)){ wgCacheSave(wgCacheAll(), 4); lsSet(WG_K.cur, raw); }
}
function wgCacheAll(){ try{ const o=JSON.parse(lsGet(WG_K.cache)||'{}'); return (o && typeof o==='object' && !Array.isArray(o))? o : {}; }catch(e){ return {}; } }
function wgCacheGet(id){ return id? (wgCacheAll()[id]||null) : null; }
function wgCachePut(id, p){ const a=wgCacheAll(); a[id]=p; wgCacheSave(a, 30); }
function wgCacheDel(id){ const a=wgCacheAll(); if(a[id]){ delete a[id]; wgCacheSave(a, 30); } }
function wgCacheSave(all, max){
  const keep=wgQ();
  let ids=Object.keys(all).sort(function(x,y){ return ((all[y]||{}).o||0)-((all[x]||{}).o||0); });
  for(let lim=max; lim>=2; lim=Math.floor(lim/2)){
    const out={}; let n=0;
    ids.forEach(function(id){ if(keep.indexOf(id)>-1 || n<lim){ out[id]=all[id]; if(keep.indexOf(id)<0) n++; } });
    if(lsSet(WG_K.cache, JSON.stringify(out))) return true;
  }
  return false;
}
function wgQ(){ try{ const a=JSON.parse(lsGet(WG_K.q)||'[]'); return Array.isArray(a)? a : []; }catch(e){ return []; } }
function wgQSet(a){ lsSet(WG_K.q, JSON.stringify(a)); }
function wgQAdd(id){ const q=wgQ(); if(q.indexOf(id)<0){ q.push(id); wgQSet(q); } }
function wgQDel(){ try{ const a=JSON.parse(lsGet(WG_K.qdel)||'[]'); return Array.isArray(a)? a : []; }catch(e){ return []; } }
async function wgQFlush(){
  if(!syncConfigured() || WG.qBusy) return;
  WG.qBusy=true;
  try{
    for(const id of wgQDel().slice()){
      try{ await wgFetchJ(wgPath('t/'+id), 12000, {method:'DELETE'}); lsSet(WG_K.qdel, JSON.stringify(wgQDel().filter(function(x){ return x!==id; }))); }
      catch(e){ logErr('산책 경로 지우기', e); break; }
    }
    for(const id of wgQ().slice()){
      const p=wgCacheGet(id);
      if(!p){ wgQSet(wgQ().filter(function(x){ return x!==id; })); continue; }
      try{ await wgFetchJ(wgPath('t/'+id), 15000, {method:'PUT', body:JSON.stringify(p)}); wgQSet(wgQ().filter(function(x){ return x!==id; })); }
      catch(e){ logErr('산책 경로 올리기', e); break; }
    }
  }finally{ WG.qBusy=false; }
}
async function wgFetchTrack(id){
  if(!id || !syncConfigured()) return null;
  try{ const p=await wgFetchJ(wgPath('t/'+id), 12000); if(p && typeof p==='object' && Array.isArray(p.segs)){ wgCachePut(id, p); return p; } }catch(e){}
  return null;
}


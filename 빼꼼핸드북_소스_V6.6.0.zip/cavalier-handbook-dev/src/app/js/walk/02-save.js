/* ---------- 저장 ---------- */
function wgPinAlive(pin){
  const tk=d2s(new Date(pin.at)); let q=null;
  try{ q=(((S.qlog||{})[tk])||{})[pin.k]; }catch(e){ q=null; }
  if(!Array.isArray(q)) return false;
  return q.some(function(x){ const hm=String(x).split('|')[0]; if(!/^\d\d:\d\d(:\d\d)?$/.test(hm)) return false; const t=new Date(tk+'T'+(hm.length===5? hm+':00' : hm)).getTime(); return Math.abs(t-pin.at)<=3000; });
}
function wgSave(ck){
  const c=WG.cur; if(!c) return;
  wgChkClose(true);
  const cfg=wgCfg(), rec=wgRec();
  const key=d2s(new Date(c.endAt));
  const seg={o:c.o, i:c.endAt, g:c.id, d:Math.round(c.st.dist+c.st.gapD)};
  if(c.st.gapD>=1) seg.dg=Math.round(c.st.gapD);
  if(c.st.gapS>=1) seg.gs=Math.round(c.st.gapS);
  seg.mv=Math.round(c.st.mv); seg.sn=Math.round(c.st.sn);
  if(c.w && isFinite(c.w.f)){ seg.tf=Math.round(c.w.f*10)/10; seg.vh=wgHeat(c.w, cfg); }
  if(c.ele.n>=10) seg.el=Math.round(c.ele.g);
  seg.rm=Math.round(c.st.runMax);
  if(rec){ seg.rp=rec.per; seg.rd=rec.day; }
  if(ck && Object.keys(ck).length) seg.ck=Object.assign({}, ck);
  if(c.photos.length) seg.ph=c.photos.length;
  const saved=wgCommit(seg, key, c);
  const pins=c.pins.filter(wgPinAlive);
  const payload=wgPayload(c, saved, pins, cfg);
  wgCachePut(c.id, payload);
  if(syncConfigured()) wgQAdd(c.id);
  const id=c.id;
  WG.cur=null; WG.banner=null; wgLsDel(WG_K.cur); wgTickOff(); wgLiveKill();
  saveState(); try{ renderQlog(); }catch(e){} try{ renderCal(); }catch(e){}
  wgShowSum(id, true);
  wgQFlush(); wgDem(id);
}
/* 기존 S.walkLog에 넣기 — 진행 중(S.walkCur)이던 같은 산책이면 그 시작 시각으로, 다른 폰에서 이미 끝냈으면 그 기록에 붙인다 */
function wgCommit(seg, key, c){
  S.walkLog=S.walkLog||{};
  const g=S.walkGps, mine=!!(g && g.d===DEV_ID);
  if(mine) delete S.walkGps;
  if(S.walkCur && (S.walkCur===c.o || mine)){ seg.o=Math.min(S.walkCur, seg.i-1000); S.walkCur=0; }
  else if(!S.walkCur){
    let found=null, fk=null;
    [key, d2s(new Date(c.o))].forEach(function(k){ ((S.walkLog||{})[k]||[]).forEach(function(s){ if(!found && s && s.o===c.o && !s.g){ found=s; fk=k; } }); });
    if(found){
      Object.assign(found, seg); found.o=c.o;
      if(fk!==key){ S.walkLog[fk]=S.walkLog[fk].filter(function(x){ return x!==found; }); if(!S.walkLog[fk].length) delete S.walkLog[fk]; (S.walkLog[key]=S.walkLog[key]||[]).push(found); }
      S.walkLog[key].sort(function(a,b){ return a.o-b.o; });
      return found;
    }
  }
  (S.walkLog[key]=S.walkLog[key]||[]).push(seg);
  S.walkLog[key].sort(function(a,b){ return a.o-b.o; });
  /* V6.6: 100일 지난 기록 자동 삭제 중지(기록 보존) */
  return seg;
}
function wgTrim(segs, home, R){
  const out=[], h=[home.lat, home.lng]; let n=0;
  segs.forEach(function(s){
    let cur=[];
    s.forEach(function(p){ if(wgHav(p, h)<R){ n++; if(cur.length){ out.push(cur); cur=[]; } } else cur.push(p); });
    if(cur.length) out.push(cur);
  });
  return {segs:out, n:n};
}
function wgPayload(c, seg, pins, cfg){
  let segs=c.segs.filter(function(s){ return s.length; }).map(function(s){ return s.map(function(p){ return [p[0], p[1]]; }); });
  let tr=0;
  const zone=!!(cfg.hideHome && cfg.home && isFinite(cfg.home.lat) && isFinite(cfg.home.lng)), R=wgHomeR(cfg);
  const near=function(la, lo){ return zone && la!=null && wgHav([la, lo], [cfg.home.lat, cfg.home.lng])<R; };
  if(zone){ const r=wgTrim(segs, cfg.home, R); segs=r.segs; tr=r.n; }
  return {
    v:1, id:c.id, o:seg.o, i:seg.i, dev:c.dev, by:c.by||'',
    segs:segs.map(wgEnc), tr:tr? 1 : 0,
    gaps:c.gaps.map(function(x){ return [x[0], x[1], x[2]]; }),
    st:{dist:Math.round(c.st.dist), gapD:Math.round(c.st.gapD), gapS:Math.round(c.st.gapS), mv:Math.round(c.st.mv), sn:Math.round(c.st.sn),
        run:Math.round(c.st.run), runMax:Math.round(c.st.runMax), maxKmh:Math.round(c.st.maxV*36)/10, pauses:c.pauses.length},
    ele: c.ele.n>=10? {src:'gps', g:Math.round(c.ele.g), l:Math.round(c.ele.l)} : null,
    w:c.w||null, ck:seg.ck||null, rec: seg.rp? {per:seg.rp, day:seg.rd} : null,
    photos:c.photos.map(function(x){ return near(x.lat, x.lng)? {id:x.id, at:x.at} : x; }),
    pins:pins.filter(function(x){ return x.lat!=null && !near(x.lat, x.lng); }),
    cfg:{runKmh:cfg.runKmh, runSec:cfg.runSec, heatWarn:cfg.heatWarn, heatDanger:cfg.heatDanger, coldWarn:cfg.coldWarn}
  };
}
function wgSegById(id){
  let f=null; Object.keys(S.walkLog||{}).forEach(function(k){ ((S.walkLog||{})[k]||[]).forEach(function(s){ if(s && s.g===id) f=s; }); });
  return f;
}
/* 고도: 저장된 경로를 15m 간격(최대 100점)으로 뽑아 지형 고도(Copernicus DEM 90m)를 받는다 */
async function wgDem(id){
  const p=wgCacheGet(id); if(!p || !Array.isArray(p.segs)) return;
  const pts=[]; p.segs.forEach(function(e){ wgDec(e).forEach(function(x){ pts.push(x); }); });
  if(pts.length<2) return;
  const cum=[0]; for(let i=1;i<pts.length;i++) cum.push(cum[i-1]+wgHav(pts[i-1], pts[i]));
  const tot=cum[cum.length-1]; if(tot<30) return;
  const n=Math.min(100, Math.max(2, Math.round(tot/15)+1)), samp=[]; let j=0;
  for(let k=0;k<n;k++){ const tg=tot*k/(n-1); while(j<cum.length-1 && cum[j+1]<=tg) j++; samp.push(pts[j]); }
  try{
    const r=await wgFetchJ('https://api.open-meteo.com/v1/elevation?latitude='+samp.map(function(x){ return x[0].toFixed(5); }).join(',')+'&longitude='+samp.map(function(x){ return x[1].toFixed(5); }).join(','), 10000);
    const el=((r && r.elevation)||[]).map(Number).filter(function(v){ return isFinite(v); });
    if(el.length<2) return;
    let g=0, l=0; for(let k=1;k<el.length;k++){ const dz=el[k]-el[k-1]; if(dz>0) g+=dz; else l-=dz; }
    const p2=wgCacheGet(id)||p;
    p2.ele={src:'dem', g:Math.round(g), l:Math.round(l), lo:Math.round(Math.min.apply(null, el)), hi:Math.round(Math.max.apply(null, el)), prof:el.map(function(v){ return Math.round(v*10)/10; })};
    wgCachePut(id, p2);
    const s=wgSegById(id); if(s){ s.el=Math.round(g); saveState(); }
    if(syncConfigured()){ wgQAdd(id); wgQFlush(); }
    if(WG.sumId===id) wgSumPaint(id);
  }catch(e){}
}


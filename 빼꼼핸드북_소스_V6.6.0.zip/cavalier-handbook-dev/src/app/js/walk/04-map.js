/* ---------- 지도 (Leaflet · OpenStreetMap 타일) ---------- */
function wgLeaflet(){
  if(window.L && window.L.map) return Promise.resolve(window.L);
  if(WG.leaflet) return WG.leaflet;
  WG.leaflet=new Promise(function(res, rej){
    if(!document.getElementById('wgLeafCss')){ const l=document.createElement('link'); l.id='wgLeafCss'; l.rel='stylesheet'; l.href=WG_LEAF+'leaflet.css'; document.head.appendChild(l); }
    const s=document.createElement('script'); s.src=WG_LEAF+'leaflet.js'; s.async=true;
    const to=setTimeout(function(){ WG.leaflet=null; rej(new Error('timeout')); }, 15000);
    s.onload=function(){ clearTimeout(to); if(window.L && window.L.map) res(window.L); else { WG.leaflet=null; rej(new Error('L')); } };
    s.onerror=function(){ clearTimeout(to); WG.leaflet=null; rej(new Error('load')); };
    document.head.appendChild(s);
  });
  return WG.leaflet;
}
function wgTiles(L, box){ if(box) box.classList.toggle('wg-dk', wgDark()); return L.tileLayer(WG_TILE, {maxZoom:19, attribution:WG_ATTR}); }
function wgWalkColor(){ return wgCss('--c-walk', '#FF9500'); }
async function wgLiveMapInit(){
  const box=document.getElementById('wgMap'); if(!box) return;
  if(WG.lm){ setTimeout(function(){ try{ WG.lm.map.invalidateSize(); }catch(e){} }, 80); wgLiveRedraw(); return; }
  try{
    const L=await wgLeaflet();
    if(!WG.scrOpen || WG.lm) return;
    const fb=box.querySelector('.wg-svgmap'); if(fb) fb.remove(); WG.svgFb=false;
    const c=WG.cur;
    const map=L.map(box, {zoomControl:false, attributionControl:true});
    wgTiles(L, box).addTo(map);
    if(c && c.pos) map.setView([c.pos[0], c.pos[1]], 17); else map.setView([36.4, 127.9], 7);
    WG.lm={L:L, map:map, lines:[], links:[], me:null, acc:null, pins:L.layerGroup().addTo(map), centered:!!(c && c.pos)};
    map.on('dragstart', function(){ WG.follow=false; const b=document.getElementById('wgCtr'); if(b) b.classList.add('on'); });
    wgLiveRedraw();
    setTimeout(function(){ try{ map.invalidateSize(); }catch(e){} }, 120);
    wgPaintLive();
  }catch(e){ WG.lm=null; WG.svgFb=true; wgSvgFallback(); }
}
function wgLiveKill(){ if(WG.lm){ try{ WG.lm.map.remove(); }catch(e){} WG.lm=null; } const box=document.getElementById('wgMap'); if(box) box.innerHTML='<div class="wg-mapmsg" id="wgMapMsg">위치를 찾는 중…</div>'; WG.svgFb=false; }
function wgLiveRedraw(){
  const lm=WG.lm, c=WG.cur; if(!lm || !c) return;
  try{
    const L=lm.L, col=wgWalkColor();
    lm.lines.concat(lm.links).forEach(function(l){ try{ lm.map.removeLayer(l); }catch(e){} });
    lm.lines=[]; lm.links=[];
    let prev=null;
    c.segs.forEach(function(s){
      if(!s.length) return;
      const ll=s.map(function(p){ return [p[0], p[1]]; });
      if(prev) lm.links.push(L.polyline([prev, ll[0]], {color:'#8E8E93', weight:3, opacity:.85, dashArray:'4 8', interactive:false}).addTo(lm.map));
      lm.lines.push(L.polyline(ll, {color:col, weight:5, opacity:.95, lineJoin:'round', lineCap:'round', interactive:false}).addTo(lm.map));
      prev=ll[ll.length-1];
    });
    wgLivePins();
    if(c.pos) wgLiveMe(c.pos);
  }catch(e){ console.warn('wg map redraw', e); }
}
function wgLiveAdd(p, newSeg){
  const lm=WG.lm;
  if(!lm){ if(WG.svgFb) wgSvgFallback(); return; }
  if(newSeg || !lm.lines.length){ wgLiveRedraw(); return; }
  try{ lm.lines[lm.lines.length-1].addLatLng([p[0], p[1]]); }catch(e){}
}
function wgLiveMe(p){
  const lm=WG.lm; if(!lm || !p) return;
  const L=lm.L, ll=[p[0], p[1]];
  try{
    if(!lm.me){
      lm.acc=L.circle(ll, {radius:Math.max(5, p[3]||10), color:wgCss('--wg-me', '#007AFF'), weight:1, opacity:.35, fillOpacity:.08, interactive:false}).addTo(lm.map);
      lm.me=L.marker(ll, {icon:L.divIcon({className:'', html:'<div class="wg-me"></div>', iconSize:[18,18], iconAnchor:[9,9]}), interactive:false, keyboard:false, zIndexOffset:1000}).addTo(lm.map);
    }else{ lm.me.setLatLng(ll); lm.acc.setLatLng(ll); lm.acc.setRadius(Math.max(5, p[3]||10)); }
    if(WG.follow){ if(!lm.centered){ lm.map.setView(ll, 17); lm.centered=true; } else lm.map.panTo(ll, {animate:true}); }
  }catch(e){}
}
function wgPinIcon(L, em){ return L.divIcon({className:'', html:'<div class="wg-pin">'+em+'</div>', iconSize:[26,26], iconAnchor:[13,13]}); }
function wgLivePins(){
  const lm=WG.lm, c=WG.cur; if(!lm || !c) return;
  try{ lm.pins.clearLayers(); }catch(e){}
  c.pins.concat(c.photos.map(function(x){ return {k:'ph', lat:x.lat, lng:x.lng}; })).forEach(function(x){
    if(x.lat==null) return;
    try{ lm.L.marker([x.lat, x.lng], {icon:wgPinIcon(lm.L, x.k==='poo'? '💩' : (x.k==='pee'? '💧' : '📷')), interactive:false, keyboard:false}).addTo(lm.pins); }catch(e){}
  });
}
function wgSvgFallback(){
  const box=document.getElementById('wgMap'), c=WG.cur; if(!box || !c) return;
  let fb=box.querySelector('.wg-svgmap');
  if(!fb){ fb=document.createElement('div'); fb.className='wg-svgmap'; box.appendChild(fb); }
  const segs=c.segs.filter(function(s){ return s.length; });
  fb.innerHTML=segs.length? wgRouteSvg(segs, 360, 300, {pad:28, sw:4, r:5}) : '';
  const msg=document.getElementById('wgMapMsg');
  if(msg){ msg.style.display=''; msg.textContent= segs.length? '' : '지도를 불러오지 못했어요 · 기록은 계속돼요'; if(segs.length) msg.style.display='none'; }
}
function wgRouteSvg(segs, W, H, o){
  o=o||{}; const pad=o.pad==null? 12 : o.pad;
  const all=[]; segs.forEach(function(s){ s.forEach(function(p){ all.push(p); }); });
  if(!all.length) return '<svg viewBox="0 0 '+W+' '+H+'" aria-hidden="true"></svg>';
  let a=90, b=-90, c=180, d=-180;
  all.forEach(function(p){ if(p[0]<a) a=p[0]; if(p[0]>b) b=p[0]; if(p[1]<c) c=p[1]; if(p[1]>d) d=p[1]; });
  const k=Math.cos((a+b)/2*Math.PI/180), w=Math.max((d-c)*k, 1e-5), h=Math.max(b-a, 1e-5);
  const sc=Math.min((W-2*pad)/w, (H-2*pad)/h), ox=(W-w*sc)/2, oy=(H-h*sc)/2;
  const X=function(p){ return (ox+(p[1]-c)*k*sc).toFixed(1); }, Y=function(p){ return (oy+(b-p[0])*sc).toFixed(1); };
  const sw=o.sw||3;
  let s='<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="xMidYMid meet" aria-hidden="true">', prev=null;
  segs.forEach(function(sg){
    if(!sg.length) return;
    if(prev) s+='<line x1="'+X(prev)+'" y1="'+Y(prev)+'" x2="'+X(sg[0])+'" y2="'+Y(sg[0])+'" stroke="var(--label3)" stroke-width="'+Math.max(1.5, sw*.6).toFixed(1)+'" stroke-dasharray="3 5" stroke-linecap="round"/>';
    if(sg.length>1) s+='<polyline fill="none" stroke="var(--c-walk)" stroke-width="'+sw+'" stroke-linecap="round" stroke-linejoin="round" points="'+sg.map(function(p){ return X(p)+','+Y(p); }).join(' ')+'"/>';
    prev=sg[sg.length-1];
  });
  if(!o.noDots){ const f=all[0], l=all[all.length-1], r=o.r||4.5; s+='<circle cx="'+X(f)+'" cy="'+Y(f)+'" r="'+r+'" fill="var(--wg-ok)" stroke="#fff" stroke-width="1.5"/><circle cx="'+X(l)+'" cy="'+Y(l)+'" r="'+r+'" fill="var(--wg-bad)" stroke="#fff" stroke-width="1.5"/>'; }
  return s+'</svg>';
}
function wgElevSvg(prof, W, H){
  if(!prof || prof.length<2) return '';
  const lo=Math.min.apply(null, prof), hi=Math.max.apply(null, prof), rg=Math.max(hi-lo, 5);
  const pts=prof.map(function(v, i){ return [i/(prof.length-1)*W, H-3-(v-lo)/rg*(H-10)]; });
  const path='M'+pts.map(function(p){ return p[0].toFixed(1)+' '+p[1].toFixed(1); }).join(' L');
  return '<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" aria-hidden="true"><path d="'+path+' L'+W+' '+H+' L0 '+H+' Z" fill="var(--c-walk)" opacity=".16"/><path d="'+path+'" fill="none" stroke="var(--c-walk)" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>';
}
/* 저장된 경로를 지도에 그리기 (상세·전체 지도 공용) */
async function wgDrawMap(boxId, tracks, opt){
  const box=document.getElementById(boxId); if(!box) return;
  opt=opt||{};
  const kill=function(){ if(WG.maps[boxId]){ try{ WG.maps[boxId].remove(); }catch(e){} delete WG.maps[boxId]; } };
  kill();
  const segsAll=tracks.map(function(p){ return (p.segs||[]).map(wgDec).filter(function(s){ return s.length; }); });
  try{
    const L=await wgLeaflet();
    if(!document.getElementById(boxId) || !box.isConnected) return;
    box.innerHTML='';
    const map=L.map(box, {zoomControl:false, attributionControl:true}); WG.maps[boxId]=map;
    wgTiles(L, box).addTo(map);
    const col=wgWalkColor(), bounds=[];
    segsAll.forEach(function(segs){
      let prev=null;
      segs.forEach(function(s){
        if(prev && !opt.heat) L.polyline([prev, s[0]], {color:'#8E8E93', weight:3, opacity:.85, dashArray:'4 8', interactive:false}).addTo(map);
        if(s.length>1) L.polyline(s, {color:col, weight:opt.heat? 4 : 5, opacity:opt.heat? .45 : .95, lineJoin:'round', lineCap:'round', interactive:false}).addTo(map);
        s.forEach(function(p){ bounds.push(p); }); prev=s[s.length-1];
      });
    });
    if(!opt.heat) tracks.forEach(function(p){
      (p.pins||[]).forEach(function(x){ if(x.lat!=null) L.marker([x.lat, x.lng], {icon:wgPinIcon(L, x.k==='poo'? '💩' : '💧'), interactive:false, keyboard:false}).addTo(map); });
      (p.photos||[]).forEach(function(x){ if(x.lat!=null) L.marker([x.lat, x.lng], {icon:wgPinIcon(L, '📷'), interactive:false, keyboard:false}).addTo(map); });
      const all=[]; (p.segs||[]).map(wgDec).forEach(function(s){ s.forEach(function(q){ all.push(q); }); });
      if(all.length){ L.circleMarker(all[0], {radius:6, color:'#fff', weight:2, fillColor:wgCss('--wg-ok','#34C759'), fillOpacity:1, interactive:false}).addTo(map); L.circleMarker(all[all.length-1], {radius:6, color:'#fff', weight:2, fillColor:wgCss('--wg-bad','#FF3B30'), fillOpacity:1, interactive:false}).addTo(map); }
    });
    if(bounds.length) map.fitBounds(bounds, {padding:[24,24], maxZoom:17}); else map.setView([36.4, 127.9], 7);
    setTimeout(function(){ try{ map.invalidateSize(); if(bounds.length) map.fitBounds(bounds, {padding:[24,24], maxZoom:17}); }catch(e){} }, 150);
  }catch(e){
    kill();
    const flat=[]; segsAll.forEach(function(s){ s.forEach(function(x){ flat.push(x); }); });
    box.innerHTML=flat.length? '<div class="wg-svgmap">'+wgRouteSvg(flat, 360, 260, {pad:20, sw:opt.heat? 2.5 : 4, noDots:!!opt.heat})+'</div><div class="wg-mapmsg" style="top:auto; bottom:10px; transform:translateX(-50%); font-size:12px;">지도 없이 경로만 표시</div>' : '<div class="wg-mapmsg">경로가 없어요</div>';
  }
}

/* ---------- 주머니 모드 ---------- */
function wgPocketOn(){
  if(!WG.cur) return;
  wgEnsureDom();
  const el=document.getElementById('wgPocket'); el.classList.add('on'); WG.pocket=true; wgBodyCls();
  if(!WG.wake && !WG.wakeNo) wgWakeOn(true);
  wgPaintLive();
}
function wgPocketOff(){ const el=document.getElementById('wgPocket'); if(el) el.classList.remove('on'); WG.pocket=false; wgBodyCls(); if(WG.scrOpen) wgPaintLive(); }
function wgSlideBind(){
  const knob=document.getElementById('wgKnob'), track=document.getElementById('wgSlide'), pk=document.getElementById('wgPocket');
  if(!knob || !track || !pk) return;
  let sx=0, x=0, drag=false, max=1;
  const px=function(e){ return (e.touches && e.touches.length)? e.touches[0].clientX : (e.changedTouches && e.changedTouches.length? e.changedTouches[0].clientX : e.clientX); };
  const down=function(e){ drag=true; sx=px(e); x=0; max=Math.max(1, track.clientWidth-knob.offsetWidth-8); knob.style.transition='none'; if(e.cancelable) e.preventDefault(); };
  const move=function(e){ if(!drag) return; x=Math.max(0, Math.min(max, px(e)-sx)); knob.style.transform='translateX('+x+'px)'; if(e.cancelable) e.preventDefault(); };
  const up=function(){ if(!drag) return; drag=false; knob.style.transition='transform .25s'; const done=x>=max*0.85; knob.style.transform='translateX(0)'; x=0; if(done) wgPocketOff(); };
  knob.addEventListener('touchstart', down, {passive:false}); knob.addEventListener('touchmove', move, {passive:false});
  knob.addEventListener('touchend', up); knob.addEventListener('touchcancel', up);
  knob.addEventListener('mousedown', down); window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
  ['click','dblclick','contextmenu'].forEach(function(t){ pk.addEventListener(t, function(e){ e.preventDefault(); e.stopPropagation(); }, true); });
  pk.addEventListener('touchmove', function(e){ if(e.cancelable) e.preventDefault(); }, {passive:false});
}


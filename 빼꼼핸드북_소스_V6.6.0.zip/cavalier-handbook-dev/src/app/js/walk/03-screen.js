/* ---------- 화면 조립 (한 번만) ---------- */
const WG_SVG={
  down:'<svg viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>',
  more:'<svg viewBox="0 0 24 24"><circle cx="6" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="18" cy="12" r="1.5" fill="currentColor" stroke="none"/></svg>',
  ctr:'<svg viewBox="0 0 24 24"><path d="M12 2.5v3.5M12 18v3.5M2.5 12H6M18 12h3.5"/><circle cx="12" cy="12" r="5"/></svg>',
  moon:'<svg viewBox="0 0 24 24"><path d="M19.5 14.5A7.5 7.5 0 0 1 9.5 4.5a7.5 7.5 0 1 0 10 10z"/></svg>',
  pause:'<svg viewBox="0 0 24 24"><path d="M9 6v12M15 6v12"/></svg>',
  play:'<svg viewBox="0 0 24 24"><path d="M8 5.5v13l10-6.5z"/></svg>',
  stop:'<svg viewBox="0 0 24 24"><rect x="6.5" y="6.5" width="11" height="11" rx="2"/></svg>',
  chev:'<svg viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>',
  back:'<svg class="ico"><use href="#i-back"/></svg>'
};
function wgEnsureDom(){
  if(WG.built) return; WG.built=true;
  const h=
  '<div id="wgScr" class="sheet-ovl" role="dialog" aria-modal="true" aria-label="산책 기록"><div class="wg-scr">'+
    '<div class="wg-map" id="wgMap"><div class="wg-mapmsg" id="wgMapMsg">위치를 찾는 중…</div></div>'+
    '<div class="wg-top"><button type="button" class="wg-ib wg-glass" id="wgMin" aria-label="화면 닫기 (기록은 계속)">'+WG_SVG.down+'</button>'+
      '<span class="wg-gps wg-glass" id="wgGps"><i></i><span id="wgGpsT">위치 찾는 중</span></span><span style="flex:1"></span>'+
      '<button type="button" class="wg-ib wg-glass" id="wgMore" aria-label="더보기">'+WG_SVG.more+'</button></div>'+
    '<button type="button" class="wg-ib wg-glass wg-recenter" id="wgCtr" aria-label="내 위치로">'+WG_SVG.ctr+'</button>'+
    '<div class="wg-btm">'+
      '<div class="wg-head"><span class="wg-ringbig" id="wgRing"></span><div><div class="wg-time" id="wgTime">0:00</div><div class="wg-sub" id="wgSub"></div></div></div>'+
      '<div class="wg-stats"><div class="wg-st"><b id="wgDist">0.00<small>km</small></b><span>거리</span></div>'+
        '<div class="wg-st"><b id="wgSpd">0.0<small>km/h</small></b><span>평균 속도</span></div>'+
        '<div class="wg-st"><b id="wgSnf">0:00</b><span>킁킁·쉼</span></div></div>'+
      '<div class="wg-chips" id="wgChips"></div>'+
      '<div class="wg-banner" id="wgBan" role="status" aria-live="polite"><p id="wgBanT"></p><button type="button" id="wgBanA"></button><button type="button" class="x" id="wgBanX" aria-label="알림 닫기">×</button></div>'+
      '<div class="wg-qa"><button type="button" id="wgPoo">💩 대변</button><button type="button" id="wgPee">💧 소변</button><button type="button" id="wgPh">📷 사진</button></div>'+
      '<div class="wg-ctrl"><button type="button" class="wg-cb" id="wgPk"><i>'+WG_SVG.moon+'</i>주머니</button>'+
        '<button type="button" class="wg-cb main" id="wgPause"><i id="wgPauseI">'+WG_SVG.pause+'</i><span id="wgPauseT">기록 멈춤</span></button>'+
        '<button type="button" class="wg-cb stop" id="wgStop"><i>'+WG_SVG.stop+'</i>끝내기</button></div>'+
    '</div>'+
    '<input type="file" id="wgCam" accept="image/*" capture="environment" style="display:none;">'+
  '</div></div>'+
  '<div id="wgPocket" role="dialog" aria-modal="true" aria-label="주머니 모드">'+
    '<p class="wg-pk-hint">주머니 모드 · 화면 터치가 막혀 있어요. 전화·카톡 알림은 그대로 받을 수 있어요.</p>'+
    '<div class="wg-pk-t">산책 기록 중</div><div class="wg-pk-big" id="wgPkTime">0:00</div><div class="wg-pk-s" id="wgPkSub">0.00km</div><div class="wg-pk-al" id="wgPkAl"></div>'+
    '<div class="wg-slide" id="wgSlide"><span>밀어서 해제</span><div class="wg-knob" id="wgKnob">'+WG_SVG.chev+'</div></div>'+
  '</div>'+
  '<div id="wgChk" class="sheet-ovl" role="dialog" aria-modal="true" aria-label="산책 후 상태 체크"><div class="sheet"><div class="grab"></div>'+
    '<div class="sh-t">산책 끝 · 상태 체크</div><div class="sh-sub" id="wgChkSub">이상한 점만 골라도 돼요</div>'+
    '<button type="button" class="wg-allok" id="wgAllOk">모두 괜찮아요</button><div class="wg-ckbox" id="wgCkBox"></div>'+
    '<button type="button" class="sh-b1" id="wgCkSave">저장</button><button type="button" class="sh-cancel" id="wgCkSkip">체크 없이 저장</button></div></div>'+
  '<div id="wgSum" class="sheet-ovl" role="dialog" aria-modal="true" aria-label="산책 요약"><div class="sheet"><div class="grab"></div><div id="wgSumBody"></div>'+
    '<button type="button" class="sh-b1" id="wgSumOk">완료</button><button type="button" class="sh-cancel" id="wgSumHub">산책 기록 보기</button></div></div>'+
  '<div id="wgHub" class="sheet-ovl" role="dialog" aria-modal="true" aria-label="산책 기록"><div class="wg-page" id="wgHubPage">'+
    '<div class="wg-bar"><span class="sp"><button type="button" class="lnk" id="wgHubX">닫기</button></span><span class="t">산책 기록</span><span class="sp"><button type="button" class="lnk" id="wgHubAdd">추가</button></span></div>'+
    '<div class="wg-in" id="wgHubIn"></div></div></div>'+
  '<div id="wgDet" class="sheet-ovl" role="dialog" aria-modal="true" aria-label="산책 상세"><div class="wg-page" id="wgDetPage">'+
    '<div class="wg-bar"><span class="sp"><button type="button" class="lnk" id="wgDetX">'+WG_SVG.back+'<span id="wgDetXT">닫기</span></button></span><span class="t" id="wgDetT"></span><span class="sp"></span></div>'+
    '<div class="wg-in" id="wgDetIn"></div></div></div>'+
  '<div id="wgAdd" class="sheet-ovl" role="dialog" aria-modal="true" aria-label="산책 직접 추가"><div class="sheet"><div class="grab"></div>'+
    '<div class="sh-t">산책 직접 추가</div><div class="sh-sub">지도 없이 시간만 기록해요</div>'+
    '<label class="wg-fl" for="wgAddD">날짜</label><input type="date" id="wgAddD">'+
    '<div class="wg-f2"><div><label class="wg-fl" for="wgAddT">시작</label><input type="time" id="wgAddT" step="60"></div><div><label class="wg-fl" for="wgAddM">걸은 시간(분)</label><input type="number" id="wgAddM" inputmode="numeric" min="1" max="300"></div></div>'+
    '<label class="wg-fl" for="wgAddK">거리 (km · 모르면 비워 두기)</label><input type="number" id="wgAddK" inputmode="decimal" step="0.01" min="0" max="50">'+
    '<p class="sh-hint" id="wgAddH"></p><button type="button" class="sh-b1" id="wgAddOk">추가</button><button type="button" class="sh-cancel" id="wgAddNo">취소</button></div></div>';
  document.body.insertAdjacentHTML('beforeend', h);
  const on=function(id, fn){ const el=document.getElementById(id); if(el) el.addEventListener('click', fn); };
  on('wgMin', function(){ wgCloseScr(); });
  on('wgMore', wgMore);
  on('wgCtr', function(){ WG.follow=true; const b=document.getElementById('wgCtr'); if(b) b.classList.remove('on'); const c=WG.cur; if(c && c.pos && WG.lm){ try{ WG.lm.map.setView([c.pos[0], c.pos[1]], Math.max(16, WG.lm.map.getZoom()||17)); }catch(e){} } });
  on('wgBanX', function(){ WG.banner=null; WG.wakeHide=1; wgPaintBanner(); });
  on('wgBanA', function(){ const b=WG.banner; if(b && b.act && b.act.fn){ WG.banner=null; wgPaintBanner(); b.act.fn(); } else if(WG.wakeFail){ wgWakeOn(true); } });
  on('wgPoo', function(){ wgMark('poo'); }); on('wgPee', function(){ wgMark('pee'); }); on('wgPh', wgPhoto);
  on('wgPk', wgPocketOn);
  on('wgPause', function(){ const c=WG.cur; if(!c) return; if(c.paused) wgResume(); else wgPause(); });
  on('wgStop', wgEndAsk);
  const cam=document.getElementById('wgCam'); if(cam) cam.addEventListener('change', function(){ const f=this.files && this.files[0]; this.value=''; if(f) wgPhotoUp(f); });
  on('wgAllOk', wgAllOk);
  on('wgCkSave', function(){ wgSave(WG.ck); });
  on('wgCkSkip', function(){ wgSave(null); });
  const ckb=document.getElementById('wgCkBox'); if(ckb) ckb.addEventListener('click', function(e){
    const b=e.target.closest('[data-ck]'); if(!b) return;
    const k=b.dataset.ck, v=b.dataset.v; if(WG.ck[k]===v) delete WG.ck[k]; else WG.ck[k]=v; wgChkPaint();
  });
  on('wgSumOk', function(){ wgSumClose(); });
  on('wgSumHub', function(){ wgSumClose(true); wgHubOpen('list', true); });
  on('wgHubX', function(){ wgHubClose(); });
  on('wgHubAdd', wgAddOpen);
  const hub=document.getElementById('wgHubIn'); if(hub) hub.addEventListener('click', wgHubTap);
  on('wgDetX', function(){ wgDetClose(); });
  on('wgAddOk', wgAddSave);
  on('wgAddNo', function(){ const el=document.getElementById('wgAdd'); if(el) el.classList.remove('on'); });
  ['wgChk','wgSum','wgAdd'].forEach(function(id){
    const el=document.getElementById(id); if(!el) return;
    el.addEventListener('click', function(e){ if(e.target!==el) return; if(id==='wgSum') wgSumClose(); else if(id==='wgAdd') el.classList.remove('on'); });
  });
  wgSlideBind();
}

/* ---------- 뒤로가기 (폰 뒤로 = 맨 위 산책 화면 닫기) ----------
   V6.6: 기록 칸 관리는 본체 화면 관리(NAV)에 맡긴다. WG.hist는 산책 화면 순서만 기억(층 id = 'wg:'+종류). */
function wgCloserFor(kind){
  return function(){
    const i=WG.hist.lastIndexOf(kind); if(i>-1) WG.hist.splice(i, 1);
    if(kind==='scr') wgCloseScr(true); else if(kind==='hub') wgHubClose(true); else if(kind==='det') wgDetClose(true); else if(kind==='sum') wgSumClose(false, true);
    wgRestoreScroll();
  };
}
function wgHistPush(kind){
  WG.hist.push(kind);
  navOpen('wg:'+kind, wgCloserFor(kind));
}
function wgHistBack(kind){
  const i=WG.hist.lastIndexOf(kind); if(i<0) return;
  WG.hist.splice(i, 1);
  navClosed('wg:'+kind, wgRestoreScroll);
}
function wgHistSwap(from, to){
  const i=WG.hist.lastIndexOf(from);
  if(i<0){ wgHistPush(to); return; }
  WG.hist[i]=to;
  navSwap('wg:'+from, 'wg:'+to, wgCloserFor(to));
}
function wgRestoreScroll(){ const y=WG.scrollY||0; try{ window.scrollTo(0, y); }catch(e){} setTimeout(function(){ try{ window.scrollTo(0, y); }catch(e){} }, 0); }

/* ---------- 산책 화면 ---------- */
function wgBodyCls(){ try{ document.body.classList.toggle('wg-scr-on', !!(WG.scrOpen || WG.pocket)); }catch(e){} }   /* 토스트를 화면 위쪽으로 (산책 버튼 가림 방지) */
function wgOpenScr(){
  wgEnsureDom();
  const el=document.getElementById('wgScr');
  const c=WG.cur;
  if(c && !c.ending && WG.watchId==null && c.geoErr!==1){ wgAudioPrime(); wgWatch(); wgWakeOn(true); wgTickOn(); }
  if(el.classList.contains('on')){ wgPaintLive(); return; }
  if(!WG.hist.length) WG.scrollY=window.scrollY||0;
  el.classList.add('on'); WG.scrOpen=true; wgBodyCls();
  wgHistPush('scr');
  wgPaintLive(); wgPaintBanner();
  wgLiveMapInit();
}
function wgCloseScr(fromPop){
  const el=document.getElementById('wgScr'); if(!el || !el.classList.contains('on')) return;
  el.classList.remove('on'); WG.scrOpen=false;
  wgPocketOff(); wgBodyCls();
  if(!fromPop) wgHistBack('scr');
  try{ wgHomePaint(); }catch(e){}
}
function wgMore(){
  if(!WG.cur) return;
  uiActions('산책 기록', [{label:'화면 꺼짐 방지 다시 켜기'},{label:'지도 기록 버리기', destr:true}]).then(function(i){
    if(i===0){ WG.wakeHide=0; wgWakeOn(true).then(function(){ uiToast(WG.wake? '화면 꺼짐 방지 켜짐' : '이 폰에서는 켤 수 없어요 — 자동 잠금을 \'안 함\'으로 바꿔 주세요'); }); }
    else if(i===1) wgDiscardAsk();
  });
}
function wgRingSvg(p, over, size, sw, inner){
  const r=(size-sw)/2, C=2*Math.PI*r, cx=size/2;
  let s='<svg viewBox="0 0 '+size+' '+size+'" aria-hidden="true"><circle class="tr" cx="'+cx+'" cy="'+cx+'" r="'+r+'"/>';
  if(p>0.002) s+='<circle class="pr" cx="'+cx+'" cy="'+cx+'" r="'+r+'" stroke-dasharray="'+C.toFixed(2)+'" stroke-dashoffset="'+(C*(1-Math.min(1,p))).toFixed(2)+'"/>';
  if(over>0.002) s+='<circle class="ov" cx="'+cx+'" cy="'+cx+'" r="'+r+'" stroke-dasharray="'+C.toFixed(2)+'" stroke-dashoffset="'+(C*(1-Math.min(1,over))).toFixed(2)+'"/>';
  return s+'</svg>'+(inner||'');
}
function wgGpsState(){
  const c=WG.cur, cfg=wgCfg(), now=Date.now();
  if(!c) return ['', ''];
  if(c.geoErr===1) return ['bad', '위치 권한 꺼짐'];
  if(c.paused) return ['', '위치 기록 멈춤'];
  if(!c.fixes) return ['', '위치 찾는 중'];
  if(now-c.lastFixAt>45000) return ['bad', '위치 신호 없음'];
  if(c.acc>cfg.acc) return ['weak', 'GPS 약함 ±'+c.acc+'m'];
  if(c.acc>20) return ['weak', 'GPS 보통 ±'+c.acc+'m'];
  return ['good', 'GPS 좋음 ±'+c.acc+'m'];
}
function wgPaintLive(){
  const c=WG.cur; if(!c) return;
  const now=c.ending? (c.endAt||Date.now()) : Date.now(), rec=wgRec(), el=wgElapsed(now);
  const set=function(id, v, html){ const e=document.getElementById(id); if(e){ if(html) e.innerHTML=v; else e.textContent=v; } };
  if(WG.pocket){
    set('wgPkTime', wgClock(el)); set('wgPkSub', wgKm(wgDistLive())+'km · '+(c.paused? '위치 기록 멈춤' : wgGpsState()[1]));
    set('wgPkAl', WG.banner? WG.banner.msg : '');
  }
  if(!WG.scrOpen) return;
  set('wgTime', wgClock(el));
  set('wgSub', fmtHM(c.o)+' 시작'+(rec? ' · 1회 권장 '+rec.per+'분' : ' · 생년월일을 넣으면 권장 시간이 보여요'));
  const per=rec? rec.per*60 : 0, p=per? el/per : 0;
  set('wgRing', wgRingSvg(p, per? (el-per)/per : 0, 76, 8, '<b>'+(rec? Math.floor(el/60)+'/'+rec.per+'분' : Math.floor(el/60)+'분')+'</b>'), true);
  set('wgDist', wgKm(wgDistLive())+'<small>km</small>', true);
  set('wgSpd', wgKmh(c.st.dist, c.st.mv)+'<small>km/h</small>', true);
  set('wgSnf', wgClock(wgSniffLive(now)));
  const g=wgGpsState(), gp=document.getElementById('wgGps');
  if(gp){ gp.className='wg-gps wg-glass '+g[0]; set('wgGpsT', g[1]); }
  const cfg=wgCfg(), ch=[];
  if(c.w){ const hv=wgHeat(c.w, cfg); ch.push('<span class="wg-chip-s '+(hv==='ok'? 'ok' : (hv==='danger'? 'bad' : 'warn'))+'">'+wgT(c.w.t)+' · 체감 '+wgT(c.w.f)+(wgWx(c.w.c)? ' · '+wgWx(c.w.c) : '')+'</span>'); }
  if(c.gaps.length) ch.push('<span class="wg-chip-s">기록 공백 '+c.gaps.length+'회 · '+wgMin(c.st.gapS)+'</span>');
  if(c.st.runMax>=cfg.runSec) ch.push('<span class="wg-chip-s warn">뛰기 '+wgMin(c.st.runMax)+'</span>');
  if(c.pins.length){ const np=c.pins.filter(function(x){ return x.k==='poo'; }).length, nq=c.pins.length-np; ch.push('<span class="wg-chip-s">'+(np? '💩 '+np : '')+(np&&nq? ' ' : '')+(nq? '💧 '+nq : '')+'</span>'); }
  if(c.photos.length) ch.push('<span class="wg-chip-s">📷 '+c.photos.length+'</span>');
  if(WG.wakeNo) ch.push('<span class="wg-chip-s warn">화면 꺼짐 방지 미지원</span>');
  set('wgChips', ch.join(''), true);
  const pb=document.getElementById('wgPause');
  if(pb){ pb.classList.toggle('paused', !!c.paused); set('wgPauseI', c.paused? WG_SVG.play : WG_SVG.pause, true); set('wgPauseT', c.paused? '다시 기록' : '기록 멈춤'); }
  const msg=document.getElementById('wgMapMsg');
  if(msg){ msg.style.display=(c.fixes && WG.lm)? 'none' : ''; if(!c.fixes) msg.textContent=c.geoErr===1? '위치 권한이 꺼져 있어요' : '위치를 찾는 중…'; }
  wgPaintBanner();
}
function wgPaintBanner(){
  const el=document.getElementById('wgBan'); if(!el) return;
  const b=WG.banner, t=document.getElementById('wgBanT'), a=document.getElementById('wgBanA');
  if(b){ el.className='wg-banner on '+(b.cls||''); t.textContent=b.msg; a.style.display=b.act? '' : 'none'; if(b.act) a.textContent=b.act.label; return; }
  if(WG.cur && !WG.cur.ending && WG.wakeFail && !WG.wakeHide && document.visibilityState!=='hidden'){
    el.className='wg-banner on info'; t.textContent='화면 꺼짐 방지가 꺼졌어요. 화면이 꺼지면 기록이 멈춰요.'; a.style.display=''; a.textContent='다시 켜기'; return;
  }
  el.className='wg-banner';
}


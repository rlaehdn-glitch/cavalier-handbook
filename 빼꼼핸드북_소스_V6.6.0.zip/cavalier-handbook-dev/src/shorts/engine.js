/* ================= 쇼츠 엔진 — 추천·구성·포맷·제목·중복 방지 (순수 함수) =================
   화면정의서 12장(처리 규칙)·13장(중복 방지)·14장(데이터 정의) 기준.
   입력: 앨범 메타(ALB.meta 형태), 쇼츠 설정(cfg), 레시피 목록, 오늘 날짜 → 출력: 추천 묶음·레시피 초안 */
const E = {};
E.SIT = ['놀이', '교감', '잠', '산책', '목욕', '식사', '유치원', '훈련', '사고'];
E.MOODS = ['포근', '신남', '졸림', '엉뚱', '의젓'];
E.FMTS = ['TRUST', 'ATTACK', 'SLEEP', 'GROWTH', 'FAIL', 'TRAIN', 'PHOTOS'];
E.SIT_FMT = { '놀이': 'ATTACK', '교감': 'TRUST', '잠': 'SLEEP', '사고': 'FAIL', '훈련': 'TRAIN' };
/* 메모 키워드 → 상황 (12-3: 메모에 '사고·말썽' → FAIL, '훈련' → TRAIN 등). '잠깐' 같은 오탐을 피하려고 '잠'은 단독·복합어만 */
E.MEMO_KW = [
  [/우다다|입질|놀이|장난감|터그|공놀이|뛰어|신나게/, '놀이'],
  [/교감|배\s?뒤집|배를\s?보|안기|안겨|품에|무릎|뽀뽀|애교|쓰다듬/, '교감'],
  [/낮잠|꿀잠|잠든|잠자|자는\s?중|자요|졸려|졸음|숙면|(^|[\s,.!])잠($|[\s,.!])/, '잠'],
  [/사고|말썽|저지레|물어뜯|엎질|난장/, '사고'],
  [/훈련|앉아|기다려|엎드려|하우스|하이파이브|교육/, '훈련'],
  [/산책/, '산책'],
  [/목욕|샤워/, '목욕'],
  [/유치원|도그스테이/, '유치원'],
  [/밥|식사|간식|사료|먹방|먹는/, '식사']
];
E.SIT_EN = { '놀이': 'playtime', '교감': 'cuddles', '잠': 'nap', '산책': 'walk', '목욕': 'bath', '식사': 'snack time', '유치원': 'puppy school', '훈련': 'training', '사고': 'mischief' };
E.SIT_TAG = { '놀이': '#puppyplay', '교감': '#puppylove', '잠': '#sleepypuppy', '산책': '#puppywalk', '목욕': '#puppybath', '식사': '#puppyfood', '유치원': '#doggydaycare', '훈련': '#puppytraining', '사고': '#puppyfail' };
E.SEASON = [['겨울', 'winter'], ['겨울', 'winter'], ['봄', 'spring'], ['봄', 'spring'], ['봄', 'spring'], ['여름', 'summer'], ['여름', 'summer'], ['여름', 'summer'], ['가을', 'autumn'], ['가을', 'autumn'], ['가을', 'autumn'], ['겨울', 'winter']];
E.DEF_CFG = { mode: 'A', recN: 3, cool: 30, maxUse: 3, ovl: 50, ch: '@DWKIM_CA', nsn: 0 };

/* ---------- 날짜 ---------- */
E.pad = function (n) { return String(n).padStart(2, '0'); };
E.dkey = function (dt) { return dt.getFullYear() + '-' + E.pad(dt.getMonth() + 1) + '-' + E.pad(dt.getDate()); };
E.dparse = function (s) { return new Date(String(s).slice(0, 10) + 'T00:00:00'); };
E.daysBetween = function (a, b) { return Math.round((E.dparse(b) - E.dparse(a)) / 86400000); };
E.isClip = function (m) { return !!m && m.t === 'r' && !!m.k; };
E.isPhoto = function (m) { return !!m && m.t !== 'v' && m.t !== 'r'; };
E.usable = function (m) { return E.isPhoto(m) || E.isClip(m); };
/* 촬영일(sd)이 있으면 촬영일, 없으면 올린 날(d) */
E.dOf = function (m) { const s = String((m && m.sd) || ''); return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : String((m && m.d) || ''); };
E.tOf = function (m) {
  const s = String((m && m.sd) || '');
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s)) { const t = new Date(s.slice(0, 19)).getTime(); if (isFinite(t)) return t; }
  if (m && m.at) return m.at;
  const d = E.dOf(m); return d ? new Date(d + 'T12:00:00').getTime() : 0;
};
E.season = function (dstr) { const mo = +String(dstr).slice(5, 7); return E.SEASON[(mo || 1) - 1]; };
E.seasonKey = function (dstr) {   /* 12·1·2월 겨울은 12월이 속한 해로 묶는다 */
  let y = +String(dstr).slice(0, 4), mo = +String(dstr).slice(5, 7);
  if (mo <= 2) y -= 1;
  return y + '-' + E.season(dstr)[1];
};
E.weekKey = function (dstr) { const d = E.dparse(dstr); const wd = (d.getDay() + 6) % 7; d.setDate(d.getDate() - wd); return E.dkey(d); };
/* day N — 입양일 = day 1 (카탈로그 규칙) */
E.dayN = function (dstr, home) { if (!home || !dstr) return 0; return E.daysBetween(home, dstr) + 1; };

/* ---------- 태그·점수 ---------- */
E.likeCount = function (m) { return (m && m.lk && typeof m.lk === 'object') ? Object.keys(m.lk).length : 0; };
E.sits = function (m) {
  const out = [];
  String((m && m.ts) || '').split(',').map(function (s) { return s.trim(); }).forEach(function (s) { if (s && E.SIT.indexOf(s) > -1 && out.indexOf(s) < 0) out.push(s); });
  const memo = String((m && m.m) || '');
  if (memo) E.MEMO_KW.forEach(function (kw) { if (kw[0].test(memo) && out.indexOf(kw[1]) < 0) out.push(kw[1]); });
  return out;
};
E.mood = function (m) { const v = String((m && m.tm) || ''); return E.MOODS.indexOf(v) > -1 ? v : ''; };
/* 12-1 점수: 좋아요 +3, 메모 있음 +2, 안 쓴 사진 +2, 눈맞춤 +2, 최근 14일 +1 (태그 없는 항목은 0점) */
E.score = function (m, today) {
  let s = 0;
  if (E.likeCount(m) > 0) s += 3;
  if (String(m.m || '').trim()) s += 2;
  if (!(m.su > 0)) s += 2;
  if (m.ec) s += 2;
  const d = E.dOf(m); if (d && E.daysBetween(d, today) <= 14) s += 1;
  return s;
};
E.inCool = function (m, cfg, today) { return !!(m && m.sl && E.daysBetween(m.sl, today) < cfg.cool); };
E.maxed = function (m, cfg) { return ((m && m.su) || 0) >= cfg.maxUse; };
E.isNew = function (m, today) { return !(m.su > 0) && E.daysBetween(E.dOf(m), today) <= 14; };

/* ---------- 연사(거의 같은 사진) — 이미지 지문(dHash 64비트, 16진수 16자) 해밍 거리 ≤ 6, 또는 촬영 시각 2초 이내 ---------- */
E.hamming = function (a, b) {
  if (!a || !b || a.length !== 16 || b.length !== 16) return 64;
  let d = 0;
  for (let i = 0; i < 16; i += 8) {
    let x = (parseInt(a.slice(i, i + 8), 16) ^ parseInt(b.slice(i, i + 8), 16)) >>> 0;
    while (x) { x &= x - 1; d++; }
  }
  return d;
};
E.sameBurst = function (a, b) {
  if (a.ih && b.ih && E.hamming(a.ih, b.ih) <= 6) return true;
  const sa = String(a.sd || ''), sb = String(b.sd || '');
  if (sa.length >= 19 && sb.length >= 19 && Math.abs(E.tOf(a) - E.tOf(b)) <= 2000) return true;
  return false;
};
/* 한 묶음 안에서 연사는 점수 높은 1장만 */
E.dedupeBursts = function (list) {   /* list: [{id, m, sc}] 점수 내림차순 */
  const kept = [];
  list.forEach(function (x) { if (!kept.some(function (k) { return E.sameBurst(k.m, x.m); })) kept.push(x); });
  return kept;
};

/* ---------- 지문 — 사진 조합(순서 무관) 해시 ---------- */
E.fnv = function (s, seed) { let h = seed >>> 0; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; };
E.fpOf = function (ids) { const s = ids.slice().sort().join(','); return 'f' + E.fnv(s, 2166136261).toString(36) + E.fnv(s, 3735928559).toString(36); };

/* ---------- 포맷 판정 (12-3) ---------- */
E.ACTIVE = ['놀이', '산책', '훈련', '사고', '목욕', '식사', '유치원', '교감'];
E.fmtOf = function (items) {   /* items: [{m}] */
  const cnt = {};
  let sleep = 0, active = 0;
  items.forEach(function (x) {
    const ss = E.sits(x.m);
    if (ss.indexOf('잠') > -1) sleep++;
    if (ss.some(function (s) { return s !== '잠'; }) || (E.isClip(x.m) && ss.indexOf('잠') < 0)) active++;
    ss.forEach(function (s) { const f = E.SIT_FMT[s]; if (f && f !== 'SLEEP') cnt[f] = (cnt[f] || 0) + 1; });
  });
  /* SLEEP: 활동 컷 2장 이상 섞은 반전 구성만 허용 (단독 금지) */
  if (sleep >= 1 && active >= 2 && sleep * 2 >= items.length * 0.5) return { fm: 'SLEEP', sleep: sleep, active: active };
  if (sleep === items.length) return { fm: '', sleep: sleep, active: active, bad: 'sleep-only' };
  let best = '', bn = 0;
  ['ATTACK', 'TRUST', 'FAIL', 'TRAIN'].forEach(function (f) { if ((cnt[f] || 0) > bn) { bn = cnt[f]; best = f; } });
  /* 한 포맷이 묶음의 40% 이상(최소 2장)일 때만 그 포맷, 아니면 PHOTOS(장별 캡션·통합 서사) */
  if (best && bn >= Math.max(2, Math.ceil(items.length * 0.4))) return { fm: best, sleep: sleep, active: active };
  return { fm: 'PHOTOS', sleep: sleep, active: active };
};

/* ---------- 겹침 — 올린 쇼츠와 겹치는 사진 비율 ---------- */
E.usedSets = function (recipes) {
  const out = [];
  Object.keys(recipes || {}).forEach(function (rid) {
    const r = recipes[rid]; if (!r || r.st !== 'up' || !Array.isArray(r.it)) return;
    out.push({ rid: rid, ids: r.it.map(function (x) { return x.id; }) });
  });
  return out;
};
E.overlap = function (ids, sets) {
  let best = { n: 0, frac: 0, rid: '', ids: [] };
  sets.forEach(function (s) {
    const hit = ids.filter(function (id) { return s.ids.indexOf(id) > -1; });
    const frac = ids.length ? hit.length / ids.length : 0;
    if (hit.length > best.n) best = { n: hit.length, frac: frac, rid: s.rid, ids: hit };
  });
  return best;
};
E.overlapIds = function (ids, sets) {
  const all = {};
  sets.forEach(function (s) { s.ids.forEach(function (id) { all[id] = 1; }); });
  return ids.filter(function (id) { return all[id]; });
};

/* ---------- 추천 생성 (12-1) ---------- */
E.candidates = function (meta, cfg, today, opt) {
  opt = opt || {};
  const out = [];
  Object.keys(meta || {}).forEach(function (id) {
    const m = meta[id];
    if (!E.usable(m) || E.maxed(m, cfg)) return;
    if (!opt.cool && E.inCool(m, cfg, today)) return;
    out.push({ id: id, m: m, sc: E.score(m, today) });
  });
  return out;
};
E.pickGroup = function (raw) {   /* 같은 묶음 후보 → 연사 정리 → 점수 상위 6~8장 */
  const sorted = raw.slice().sort(function (a, b) { return b.sc - a.sc || E.tOf(b.m) - E.tOf(a.m); });
  const ded = E.dedupeBursts(sorted);
  /* 영상은 한 편에 1개까지 (첫 2초용) */
  let clips = 0;
  const sel = [];
  ded.forEach(function (x) { if (sel.length >= 8) return; if (E.isClip(x.m)) { if (clips >= 1) return; clips++; } sel.push(x); });
  return sel.length >= 6 ? sel : null;
};
E.groups = function (cands, today) {
  const by = {};
  function add(k, x) { (by[k] = by[k] || []).push(x); }
  cands.forEach(function (x) {
    const d = E.dOf(x.m); if (!d) return;
    add('w:' + E.weekKey(d), x);
    add('s:' + E.seasonKey(d), x);
    E.sits(x.m).forEach(function (s) { add('t:' + s, x); });
  });
  const seen = {}, out = [];
  Object.keys(by).forEach(function (k) {
    const sel = E.pickGroup(by[k]); if (!sel) return;
    const ids = sel.map(function (x) { return x.id; });
    const sig = ids.slice().sort().join(',');
    if (seen[sig]) return; seen[sig] = 1;
    const f = E.fmtOf(sel); if (!f.fm) return;
    const top = sel.map(function (x) { return x.sc; }).sort(function (a, b) { return b - a; }).slice(0, 6);
    const score = top.reduce(function (a, b) { return a + b; }, 0) + (sel.some(function (x) { return E.isClip(x.m); }) ? 0.5 : 0) + (f.fm !== 'PHOTOS' ? 0.3 : 0);
    out.push({ key: k, sel: sel, ids: ids, sig: sig, fm: f.fm, score: score, nNew: sel.filter(function (x) { return E.isNew(x.m, today); }).length });
  });
  out.sort(function (a, b) { return b.score - a.score || (a.key < b.key ? 1 : -1); });
  return out;
};
/* 점수 높은 순으로 포맷이 서로 다른 n편 · n편끼리 사진 겹침 0.
   한 편을 고를 때마다 남은 사진으로 묶음을 다시 만든다(겹침 0을 지키면서 다음 편이 사라지지 않게).
   포맷이 모자라면 같은 포맷도 허용. opt.skip: 이미 보여 준 묶음(키·조합) — '다시 추천' */
E.recommend = function (meta, cfg, recipes, fps, today, opt) {
  opt = opt || {};
  cfg = Object.assign({}, E.DEF_CFG, cfg || {});
  const cands = E.candidates(meta, cfg, today, opt);
  const newCount = cands.filter(function (x) { return !(x.m.su > 0); }).length;
  const sets = E.usedSets(recipes);
  const skip = opt.skip || {};
  const n = cfg.recN || 3, picked = [], used = {}, fmts = {};
  let groupCount = 0;
  for (let round = 0; round < n; round++) {
    const rem = cands.filter(function (x) { return !used[x.id]; });
    const gs = E.groups(rem, today).filter(function (g) {
      if (skip[g.sig] || skip[g.key]) return false;
      if (picked.some(function (p) { return p.key === g.key; })) return false;
      if (fps && fps[E.fpOf(g.ids)]) return false;                                  /* 같은 사진 조합: 금지 */
      const o = E.overlap(g.ids, sets);
      return !(o.frac * 100 >= cfg.ovl);                                             /* 절반 이상 겹침: 추천에서 제외 */
    });
    if (round === 0) groupCount = gs.length;
    const g = gs.filter(function (x) { return !fmts[x.fm]; })[0] || gs[0];
    if (!g) break;
    picked.push(g); fmts[g.fm] = 1; g.ids.forEach(function (id) { used[id] = 1; });
  }
  return { recs: picked, newCount: newCount, candCount: cands.length, groupCount: groupCount };
};

/* ---------- 15~20초 구성 (12-2) ---------- */
E.XF = 0.35;   /* 크로스페이드(초) */
E.compose = function (sel, fm, today, opt) {   /* sel: [{id, m, sc}] → it[] */
  opt = opt || {};
  sel = sel.slice();
  const byScore = function (a, b) { return (b.m.ec ? 2 : 0) - (a.m.ec ? 2 : 0) || E.likeCount(b.m) - E.likeCount(a.m) || b.sc - a.sc; };
  const sleepOf = function (x) { return E.sits(x.m).indexOf('잠') > -1; };
  const clips = sel.filter(function (x) { return E.isClip(x.m); });
  let rest = sel.slice();
  let intro, outro;
  /* 0~2초: 지정한 첫 장 → 영상 클립 → 눈맞춤·좋아요 최다 사진(+빠른 줌인) */
  if (opt.firstId) intro = sel.filter(function (x) { return x.id === opt.firstId; })[0];
  if (!intro && clips.length) intro = clips.slice().sort(function (a, b) { return b.sc - a.sc; })[0];
  if (!intro) {
    const ph = sel.filter(function (x) { return !E.isClip(x.m); });
    intro = (fm === 'SLEEP' ? ph.filter(function (x) { return !sleepOf(x); }).sort(byScore)[0] : null) || ph.slice().sort(byScore)[0] || sel[0];
  }
  rest = rest.filter(function (x) { return x !== intro; });
  /* 16~20초: 첫 장과 다른 눈맞춤 사진 (SLEEP은 잠든 사진으로 끝내는 반전) */
  const photos = rest.filter(function (x) { return !E.isClip(x.m); });
  if (fm === 'SLEEP') outro = photos.filter(sleepOf).sort(byScore)[0] || photos.slice().sort(byScore)[0];
  else outro = photos.filter(function (x) { return x.m.ec; }).sort(byScore)[0] || photos.slice().sort(byScore)[0];
  rest = rest.filter(function (x) { return x !== outro; });
  if (!opt.keepAll) rest = rest.filter(function (x) { return !E.isClip(x.m); });   /* 자동 추천: 영상은 첫 2초에만 */
  /* 2~16초: 찍은 순서대로 5~6장 (직접 고른 경우는 모두 유지) */
  let mid = rest.slice().sort(function (a, b) { return E.tOf(a.m) - E.tOf(b.m); });
  if (fm === 'SLEEP') mid = mid.filter(function (x) { return !sleepOf(x); }).concat(mid.filter(sleepOf));
  if (!opt.keepAll && mid.length > 6) mid = mid.slice().sort(function (a, b) { return b.sc - a.sc; }).slice(0, 6).sort(function (a, b) { return E.tOf(a.m) - E.tOf(b.m); });
  const per = fm === 'TRUST' ? 2.5 : 2.2;
  const it = [];
  const zs = ['r', 'in', 'l', 'out'];
  if (intro) it.push(E.itemOf(intro, 2.0, 'in', { fast: !E.isClip(intro.m), slow: fm === 'ATTACK' && E.isClip(intro.m) }));
  mid.forEach(function (x, i) { it.push(E.itemOf(x, E.isClip(x.m) ? 2.5 : per, zs[i % zs.length])); });
  if (outro) it.push(E.itemOf(outro, 3.0, 'in'));
  E.fitLength(it);
  return it;
};
E.itemOf = function (x, du, z, o) {
  o = o || {};
  const it = { id: x.id, du: du, z: z, c: '' };
  if (E.isClip(x.m)) { it.v = 1; it.ss = 0; it.sp = o.slow ? 0.5 : 1; const d = +x.m.dur || 0; if (d > 6) it.ss = Math.max(0, Math.min(d - 3, d * 0.3)); }
  if (o.fast) it.zf = 1;
  if (typeof x.m.fx === 'number') it.fx = x.m.fx;
  if (typeof x.m.fy === 'number') it.fy = x.m.fy;
  return it;
};
E.total = function (it) { return Math.round(it.reduce(function (a, x) { return a + (+x.du || 0); }, 0) * 10) / 10; };
/* 길이를 15~20초 안으로 — 가운데 사진 길이만 1.5~3초 범위에서 조정 */
E.fitLength = function (it) {
  if (it.length < 3) return it;
  const mid = it.slice(1, -1).filter(function (x) { return !x.v; });
  let guard = 0;
  while (E.total(it) < 15 && guard++ < 60) { const c = mid.filter(function (x) { return x.du < 3; }); if (!c.length) break; c.forEach(function (x) { x.du = Math.min(3, Math.round((x.du + 0.1) * 10) / 10); }); }
  guard = 0;
  while (E.total(it) > 20 && guard++ < 60) { const c = mid.filter(function (x) { return x.du > 1.5; }); if (!c.length) break; c.forEach(function (x) { x.du = Math.max(1.5, Math.round((x.du - 0.1) * 10) / 10); }); }
  return it;
};

/* ---------- 제목·설명 틀 (12-4) — 영문, 감정·호기심형, 날짜형 금지. 포맷별 5개 ---------- */
E.TPL = {
  TRUST: [
    { t: 'She chose my lap on day {N}', h: 'She chose my lap', d: 'She found her spot.', k: '{N}일째, 내 무릎을 골랐어요', kh: '내 무릎을 골랐어요', kd: '자기 자리를 찾았어요.' },
    { t: '{N} days home and still a lap dog', h: 'Still a lap dog', d: 'Some things never change.', k: '집에 온 지 {N}일, 여전히 무릎 강아지', kh: '여전히 무릎 강아지', kd: '변하지 않는 것도 있죠.' },
    { t: 'Her favorite spot in the whole world', h: 'Her favorite spot', d: 'Guess where she wants to be.', k: '세상에서 제일 좋아하는 자리', kh: '제일 좋아하는 자리', kd: '어디에 있고 싶은지 맞혀 보세요.' },
    { t: 'This is how she says I love you', h: 'How she says I love you', d: 'No words needed.', k: '이게 사랑한다고 말하는 방법이에요', kh: '사랑한다고 말하는 방법', kd: '말이 필요 없어요.' },
    { t: 'She trusts me with her whole heart', h: 'Full trust unlocked', d: 'Belly up means total trust.', k: '온 마음으로 나를 믿어요', kh: '완전한 신뢰 달성', kd: '배를 보이는 건 완전히 믿는다는 뜻이에요.' }
  ],
  ATTACK: [
    { t: 'Tiny Cavalier in full attack mode', h: 'Full attack mode', d: 'Small but mighty.', k: '작은 카발리에, 전투 모드 돌입', kh: '전투 모드 돌입', kd: '작지만 강해요.' },
    { t: 'Who let the tiny shark out?', h: 'Tiny shark alert', d: 'Those puppy teeth though.', k: '누가 이 아기 상어를 풀어놨어?', kh: '아기 상어 경보', kd: '저 강아지 이빨 좀 봐요.' },
    { t: 'She thinks she is a lion', h: 'She thinks she is a lion', d: 'Fearless, as always.', k: '자기가 사자인 줄 알아요', kh: '자기가 사자인 줄 알아요', kd: '언제나처럼 겁이 없어요.' },
    { t: 'Zoomies level: maximum', h: 'Zoomies: MAX', d: 'Nobody can stop her now.', k: '우다다 레벨: 최대', kh: '우다다: 최대', kd: '이제 아무도 못 말려요.' },
    { t: 'The cutest little troublemaker', h: 'Little troublemaker', d: 'Chaos, but make it cute.', k: '세상에서 제일 귀여운 말썽꾸러기', kh: '작은 말썽꾸러기', kd: '난장판인데 귀여워요.' }
  ],
  SLEEP: [
    { t: 'Puppy battery: 0%', h: 'Puppy battery: 0%', d: 'From full power to nap mode.', k: '강아지 배터리: 0%', kh: '강아지 배터리: 0%', kd: '풀파워에서 낮잠 모드로.' },
    { t: 'From chaos to coma in seconds', h: 'Chaos to coma', d: 'She went all in, then crashed.', k: '몇 초 만에 난리에서 기절까지', kh: '난리 → 기절', kd: '온 힘을 다해 놀고 뻗었어요.' },
    { t: 'She fought sleep and lost', h: 'She fought sleep', d: 'Sleep always wins.', k: '잠이랑 싸우다 졌어요', kh: '잠이랑 싸우는 중', kd: '잠은 언제나 이겨요.' },
    { t: 'Energy saving mode: activated', h: 'Energy saving mode', d: 'Recharging for the next adventure.', k: '절전 모드: 켜짐', kh: '절전 모드', kd: '다음 모험을 위해 충전 중이에요.' },
    { t: 'Play hard, nap harder', h: 'Play hard, nap harder', d: 'A puppy’s perfect day.', k: '열심히 놀고, 더 열심히 자기', kh: '열심히 놀고, 더 열심히 자기', kd: '강아지의 완벽한 하루.' }
  ],
  GROWTH: [
    { t: 'Day 1 vs day {N}', h: 'Day 1 vs day {N}', d: 'Look how much she has grown.', k: '1일째 vs {N}일째', kh: '1일째 vs {N}일째', kd: '얼마나 컸는지 보세요.' },
    { t: 'She used to fit in one hand', h: 'She used to be this tiny', d: 'Time flies with a puppy.', k: '한 손에 쏙 들어오던 아이였는데', kh: '이만큼 작았었는데', kd: '강아지와 있으면 시간이 정말 빨라요.' },
    { t: 'Watch her grow up in seconds', h: 'Watch her grow', d: 'Growing up way too fast.', k: '몇 초 만에 크는 모습 보기', kh: '크는 모습 보기', kd: '너무 빨리 커요.' },
    { t: 'How it started vs how it’s going', h: 'How it started', d: 'Same puppy, new chapter.', k: '처음 모습 vs 지금 모습', kh: '처음엔 이랬어요', kd: '같은 강아지, 새로운 이야기.' },
    { t: '{N} days of growing up', h: '{N} days of growing up', d: 'Every day a little bigger.', k: '{N}일 동안 자란 기록', kh: '{N}일 동안 자란 기록', kd: '날마다 조금씩 커요.' }
  ],
  FAIL: [
    { t: 'She tried. She really tried.', h: 'She really tried', d: 'Points for effort.', k: '노력했어요. 정말 노력했어요.', kh: '정말 노력했어요', kd: '노력 점수는 만점.' },
    { t: 'Nobody tell her she missed', h: 'Nobody tell her', d: 'She thinks it went perfectly.', k: '빗나간 거 아무도 말해주지 마세요', kh: '아무도 말하지 마세요', kd: '본인은 완벽했다고 생각해요.' },
    { t: 'Expectation vs reality: puppy edition', h: 'Expectation vs reality', d: 'It did not go as planned.', k: '기대 vs 현실: 강아지 편', kh: '기대 vs 현실', kd: '계획대로 되지 않았어요.' },
    { t: 'Well… that didn’t go as planned', h: 'That didn’t go as planned', d: 'Oops.', k: '음… 계획대로 안 됐네요', kh: '계획대로 안 됐어요', kd: '앗.' },
    { t: 'She has zero regrets', h: 'Zero regrets', d: 'Would do it again.', k: '후회는 전혀 없대요', kh: '후회 없음', kd: '또 할 거래요.' }
  ],
  TRAIN: [
    { t: 'Training diary #{k}: she did it', h: 'Training diary #{k}', d: 'Little steps, big progress.', k: '훈련 일기 #{k}: 해냈어요', kh: '훈련 일기 #{k}', kd: '작은 걸음, 큰 발전.' },
    { t: 'Puppy school progress report', h: 'Progress report', d: 'Getting better every day.', k: '강아지 학교 성적표', kh: '성적표', kd: '날마다 나아지고 있어요.' },
    { t: 'Smarter than I thought', h: 'Smarter than I thought', d: 'She learns so fast.', k: '생각보다 똑똑해요', kh: '생각보다 똑똑해요', kd: '정말 빨리 배워요.' },
    { t: 'Day {N} of teaching a Cavalier', h: 'Teaching a Cavalier', d: 'Patience pays off.', k: '카발리에 가르치기 {N}일째', kh: '카발리에 가르치기', kd: '인내는 보답받아요.' },
    { t: 'She actually listened this time', h: 'She actually listened', d: 'A proud puppy parent moment.', k: '이번엔 진짜 말을 들었어요', kh: '진짜 말을 들었어요', kd: '견주로서 뿌듯한 순간.' }
  ],
  PHOTOS: [
    { t: 'Her first {season} {act}', h: 'Her first {season} {act}', d: 'Small moments, big love.', t0: 'Her first {season} with us', h0: 'Her first {season} with us',
      k: '처음 맞는 {seasonKo} {actKo}', kh: '처음 맞는 {seasonKo} {actKo}', k0: '우리와 함께하는 첫 {seasonKo}', kh0: '우리와 함께하는 첫 {seasonKo}', kd: '작은 순간, 큰 사랑.' },
    { t: 'A little {act} with my Cavalier', h: 'A little {act}', d: 'Just another happy day.', t0: 'A little moment with my Cavalier', h0: 'A little moment',
      k: '우리 카발리에와 함께한 {actKo}', kh: '소소한 {actKo}', k0: '우리 카발리에와의 작은 순간', kh0: '작은 순간', kd: '또 하나의 행복한 하루.' },
    { t: 'Every day with her is the best day', h: 'Every day is the best day', d: 'Life is better with her.', k: '함께하는 모든 날이 최고의 날', kh: '모든 날이 최고의 날', kd: '함께라서 더 좋은 하루하루.' },
    { t: 'Small moments, big love', h: 'Small moments, big love', d: 'These are the days.', k: '작은 순간, 큰 사랑', kh: '작은 순간, 큰 사랑', kd: '바로 이런 날들.' },
    { t: 'Just a puppy living her best life', h: 'Living her best life', d: 'Nothing but good vibes.', k: '최고의 삶을 사는 강아지', kh: '최고의 삶을 사는 중', kd: '좋은 기운만 가득.' }
  ]
};
E.SEASON_KO = { winter: '겨울', spring: '봄', summer: '여름', autumn: '가을' };
E.ACT_KO = { '놀이': '놀이 시간', '교감': '포옹', '잠': '낮잠', '산책': '산책', '목욕': '목욕', '식사': '간식 시간', '유치원': '유치원', '훈련': '훈련', '사고': '말썽' };
E.koFill = function (s, ctx) {
  return String(s || '').replace(/\{N\}/g, ctx.N || '').replace(/\{k\}/g, ctx.k || 1)
    .replace(/\{seasonKo\}/g, E.SEASON_KO[ctx.season] || '').replace(/\{actKo\}/g, E.ACT_KO[ctx.sit] || '하루').replace(/\s{2,}/g, ' ').trim();
};
E.fill = function (s, ctx) {
  return String(s || '').replace(/\{N\}/g, ctx.N || '').replace(/\{act\}/g, ctx.act || 'day').replace(/\{season\}/g, ctx.season || '').replace(/\{k\}/g, ctx.k || 1).replace(/\s{2,}/g, ' ').trim();
};
/* 묶음의 대표 상황 — 2장 이상에 붙은 상황만, 동점이면 상황 목록 순서 (어디서 계산해도 같은 결과) */
E.mainSit = function (sel) {
  const cnt = {};
  sel.forEach(function (x) { E.sits(x.m).forEach(function (s) { cnt[s] = (cnt[s] || 0) + 1; }); });
  let best = '', bn = 1;
  E.SIT.forEach(function (s) { if ((cnt[s] || 0) > bn) { bn = cnt[s]; best = s; } });
  return best;
};
E.mainMood = function (sel) {
  const cnt = {};
  sel.forEach(function (x) { const md = E.mood(x.m); if (md) cnt[md] = (cnt[md] || 0) + 1; });
  let best = '', bn = 0;
  E.MOODS.forEach(function (s) { if ((cnt[s] || 0) > bn) { bn = cnt[s]; best = s; } });
  return best;
};
E.ctxOf = function (sel, fm, home, recipes) {
  const dates = sel.map(function (x) { return E.dOf(x.m); }).filter(Boolean).sort();
  const last = dates[dates.length - 1] || '';
  const sit = E.mainSit(sel);
  let k = 1;
  if (fm === 'TRAIN') Object.keys(recipes || {}).forEach(function (rid) { const r = recipes[rid]; if (r && r.st === 'up' && r.fm === 'TRAIN') k++; });
  return { N: E.dayN(last, home) || '', act: E.SIT_EN[sit] || '', season: last ? E.season(last)[1] : '', k: k, sit: sit, last: last, mood: E.mainMood(sel) };
};
/* 포맷별 틀 5개 중 최근 10편에 안 쓴 틀로 3안 */
E.titles = function (fm, ctx, recipes) {
  const tpl = E.TPL[fm] || E.TPL.PHOTOS;
  const ups = Object.keys(recipes || {}).map(function (rid) { return recipes[rid]; })
    .filter(function (r) { return r && r.st === 'up'; })
    .sort(function (a, b) { return (b.up || 0) - (a.up || 0); }).slice(0, 10);
  const usedT = {}; ups.forEach(function (r, i) { if (r.tt && usedT[r.tt] === undefined) usedT[r.tt] = i; });
  const order = tpl.map(function (t, i) { return { i: i, key: fm + '.' + i, used: usedT[fm + '.' + i] }; });
  const fresh = order.filter(function (o) { return o.used === undefined; });
  const old = order.filter(function (o) { return o.used !== undefined; }).sort(function (a, b) { return b.used - a.used; });   /* 오래전에 쓴 것부터 */
  return fresh.concat(old).slice(0, 3).map(function (o) {
    const t = tpl[o.i];
    const noAct = !ctx.act && /\{act\}/.test(t.t);
    let ti = E.fill(noAct ? (t.t0 || t.t) : t.t, ctx), hk = E.fill(noAct ? (t.h0 || t.h) : t.h, ctx);
    let kt = E.koFill(noAct ? (t.k0 || t.k) : t.k, ctx), kh = E.koFill(noAct ? (t.kh0 || t.kh) : t.kh, ctx);
    if (!ctx.N) { ti = ti.replace(/\s*on day\s*$/i, '').replace(/^\s*days? home and/i, 'Home and'); hk = hk.replace(/day\s*$/i, '').trim(); kt = kt.replace(/^일째, /, '').replace(/^집에 온 지 일, /, ''); }
    return { key: o.key, t: ti, h: hk, d: E.fill(t.d, ctx), kt: kt, kh: kh, kd: t.kd || '' };
  });
};
/* 설명의 한글 한 줄 — 기본값은 상황·계절로 만든 짧은 문구(메모를 그대로 넣지 않음). 후보는 E.koLines */
E.koLine = function (sel, ctx) { return E.koLines(sel, ctx).p[0] || '빼꼼이의 하루'; };
E.koLines = function (sel, ctx) {
  const ss = ctx.last ? E.season(ctx.last)[0] : '';
  const sit = ctx.sit, act = E.ACT_KO[sit] || '';
  const p = [], st = [];
  if (sit) { p.push('빼꼼이의 ' + (ss ? ss + ' ' : '') + act); p.push((ss ? ss + ' ' : '') + act + ' 기록'); }
  else { p.push('빼꼼이의 ' + (ss ? ss + ' ' : '') + '하루'); }
  if (ctx.N) p.push('빼꼼이와 함께한 ' + ctx.N + '일째');
  const bank = E.KO_SUG[sit] || E.KO_SUG._;
  bank.s.forEach(function (x) { st.push(x); });
  E.KO_SUG._.s.forEach(function (x) { if (st.indexOf(x) < 0) st.push(x); });
  const memos = [];
  sel.slice().sort(function (a, b) { return E.likeCount(b.m) - E.likeCount(a.m); }).forEach(function (x) { const mm = String(x.m.m || '').trim(); if (mm && memos.indexOf(mm) < 0) memos.push(mm); });
  return { p: p.slice(0, 3), s: st.slice(0, 3), memo: memos.slice(0, 2) };
};
/* 설명: 카탈로그 고정 템플릿(화면정의서 12-4 코드 블록 그대로)
   Day N with our Cavalier King Charles Spaniel puppy 🐾 / [영문 훅 한 줄] / (빈 줄) / [한글 한 줄] / (빈 줄) / 해시태그 8개 + 상황 태그 1~2개 / 빼꼼 #N */
E.DESC_TAGS = '#cavalierkingcharlesspaniel #cavalier #puppy #cutepuppy #dogsofyoutube #puppylove #blenheim #shorts';
E.desc = function (title, sel, ctx, sn, ko) {
  const l1 = (ctx.N ? 'Day ' + ctx.N + ' with our Cavalier King Charles Spaniel puppy' : 'Life with our Cavalier King Charles Spaniel puppy') + ' 🐾';
  const l2 = title.d || title.t || '';
  const sitCnt = {}, extra = [];
  sel.forEach(function (x) { E.sits(x.m).forEach(function (s) { sitCnt[s] = (sitCnt[s] || 0) + 1; }); });
  Object.keys(sitCnt).sort(function (a, b) { return sitCnt[b] - sitCnt[a]; }).slice(0, 2).forEach(function (s) { if (E.SIT_TAG[s]) extra.push(E.SIT_TAG[s]); });
  const k = (ko === undefined || ko === null) ? E.koLine(sel, ctx) : ko;
  const out = [l1, l2, ''];
  if (k) out.push(k, '');
  out.push(E.DESC_TAGS + (extra.length ? ' ' + extra.join(' ') : ''), '빼꼼 #' + (sn || '?'));
  return out.join('\n');
};
E.descSn = function (de, sn) {   /* 끝줄 시리즈 번호 갱신 */
  const lines = String(de || '').split('\n');
  if (/^빼꼼 #/.test(lines[lines.length - 1] || '')) lines[lines.length - 1] = '빼꼼 #' + sn; else lines.push('빼꼼 #' + sn);
  return lines.join('\n');
};

/* ---------- 시리즈 번호 (빼꼼 #N) — 예약·회수 (V6.5.2) ----------
   nsn: 다음 번호 · fsn: 지운 초안이 놓고 간 빈 번호
   · '영상 만들기' 때 예약: 빈 번호가 있으면 가장 작은 것부터, 없으면 nsn
   · 초안을 지우면 그 번호를 빈 번호로 돌려놓고, 맨 끝 번호가 비면 nsn을 그만큼 되돌린다
   · 이미 올린 번호보다 작은 빈 번호는 버린다(올린 순서가 뒤집히지 않게) */
E.snList = function (v) {
  const a = Array.isArray(v) ? v : (v && typeof v === 'object' ? Object.keys(v).map(function (k) { return v[k]; }) : []);
  const seen = {}, out = [];
  a.forEach(function (x) { x = +x; if (x > 0 && Math.floor(x) === x && !seen[x]) { seen[x] = 1; out.push(x); } });
  return out.sort(function (p, q) { return p - q; });
};
E.snState = function (nsn, recipes, fsn) {
  const taken = {}; let max = 0, upMax = 0;
  Object.keys(recipes || {}).forEach(function (rid) {
    const r = recipes[rid]; if (!r || !(r.sn > 0)) return;
    taken[r.sn] = 1; if (r.sn > max) max = r.sn; if (r.st === 'up' && r.sn > upMax) upMax = r.sn;
  });
  let top = Math.max(+nsn || 1, max + 1);
  const free = E.snList(fsn).filter(function (n) { return n > upMax && n < top && !taken[n]; });
  while (free.length && free[free.length - 1] === top - 1) { top--; free.pop(); }
  return { nsn: top, fsn: free };
};
E.snPick = function (nsn, recipes, fsn) {
  const st = E.snState(nsn, recipes, fsn);
  if (st.fsn.length) return { sn: st.fsn[0], nsn: st.nsn, fsn: st.fsn.slice(1) };
  return { sn: st.nsn, nsn: st.nsn + 1, fsn: [] };
};
E.snFree = function (nsn, recipes, fsn, sn) {   /* recipes: 초안을 뺀 뒤 */
  return E.snState(nsn, recipes, E.snList(fsn).concat(sn > 0 ? [sn] : []));
};

/* ---------- 음악 (12-5) — A: 유튜브 앱 '사운드' 검색어 2~3개 ---------- */
E.MQ_FMT = {
  TRUST: ['cute piano', 'heartwarming'],
  ATTACK: ['Monkeys Spinning Monkeys', 'Sneaky Snitch'],
  SLEEP: ['lullaby', 'sleepy piano'],
  GROWTH: ['emotional piano', 'growing up'],
  FAIL: ['funny fail', 'Sneaky Snitch'],
  TRAIN: ['upbeat ukulele', 'proud moment'],
  PHOTOS: ['happy acoustic', 'cute puppy']
};
E.MQ_MOOD = { '포근': 'cozy piano', '신남': 'upbeat funny', '졸림': 'calm lullaby', '엉뚱': 'quirky funny', '의젓': 'cinematic inspiring' };
E.music = function (fm, mood) {
  const out = (E.MQ_FMT[fm] || E.MQ_FMT.PHOTOS).slice();
  const mq = E.MQ_MOOD[mood];
  if (mq && out.indexOf(mq) < 0) out.push(mq);
  return out.slice(0, 3);
};

/* ---------- 장면 자막 — 자동으로 넣지 않는다 (V6.5.1). 영상에는 위쪽 영문 2줄(훅 · day N)만.
   한글은 장면마다 추천 문구·문장을 보여 주고 사람이 고른 것만 붙인다. ---------- */
E.captions = function (it) { it.forEach(function (x) { x.c = ''; }); return it; };
E.KO_SUG = {
  '산책': { p: ['산책 가자!', '킁킁 탐색 중', '낙엽 밟기'], s: ['오늘도 신나게 산책했어요', '밖에 나오면 세상이 다 신기해요'] },
  '놀이': { p: ['우다다 타임', '장난감은 내 거야', '놀아 주세요!'], s: ['한 번 시작하면 멈출 수 없어요', '에너지 충전 완료, 이제 놀 시간!'] },
  '교감': { p: ['품이 제일 좋아', '꼭 안아 줘', '눈 맞춤 중'], s: ['여기가 제일 편해요', '오늘도 사랑받는 중이에요'] },
  '잠': { p: ['꿀잠 중', '배터리 0%', '쿨쿨'], s: ['놀다 지쳐서 잠들었어요', '깨우지 마세요, 꿈꾸는 중이에요'] },
  '목욕': { p: ['목욕 싫어요', '뽀송뽀송', '젖은 빼꼼이'], s: ['목욕은 싫지만 끝나면 개운해요', '말리는 시간이 제일 길어요'] },
  '식사': { p: ['냠냠', '간식 주세요', '밥 먹는 중'], s: ['밥그릇 앞에서는 진지해요', '간식 소리만 들어도 달려와요'] },
  '유치원': { p: ['유치원 가는 날', '친구들 만나러', '하원했어요'], s: ['오늘도 유치원에서 신나게 놀았어요', '친구들이랑 노는 게 제일 좋아요'] },
  '훈련': { p: ['앉아 성공!', '기다려…', '칭찬받는 중'], s: ['오늘은 앉아를 해냈어요', '간식 앞에서 꾹 참는 중이에요'] },
  '사고': { p: ['제가 안 그랬어요', '범인은 나', '앗, 들켰다'], s: ['잠깐 혼자 뒀더니 이렇게 됐어요', '반성은 하는데 후회는 없어요'] },
  _: { p: ['귀여움 주의', '빼꼼이 등장', '오늘의 빼꼼'], s: ['오늘도 귀여움 한도 초과', '빼꼼이의 하루를 소개합니다'] }
};
E.KO_MOOD = { '포근': '포근포근', '신남': '신난다!', '졸림': '졸려요…', '엉뚱': '이게 뭐지?', '의젓': '의젓한 빼꼼이' };
/* 영어 장면 자막 후보 — 뜻과 함께 (FAIL 1인칭 문장, GROWTH 날짜 표시) */
E.FAIL_LINES = [['Me: totally under control', '나: 완벽하게 통제 중'], ['The plan:', '계획:'], ['What actually happened:', '실제로 일어난 일:'], ['No regrets.', '후회 없음.']];
E.sceneSug = function (m, i, fm, home) {   /* → {p:[], s:[], en:[[영문, 뜻]], memo:''} */
  const ss = E.sits(m || {});
  const p = [], st = [], en = [];
  ss.forEach(function (sit) { const b = E.KO_SUG[sit]; if (!b) return; b.p.forEach(function (x) { if (p.indexOf(x) < 0) p.push(x); }); b.s.forEach(function (x) { if (st.indexOf(x) < 0) st.push(x); }); });
  const md = E.mood(m || {}); if (md && E.KO_MOOD[md] && p.indexOf(E.KO_MOOD[md]) < 0) p.push(E.KO_MOOD[md]);
  E.KO_SUG._.p.forEach(function (x) { if (p.length < 5 && p.indexOf(x) < 0) p.push(x); });
  E.KO_SUG._.s.forEach(function (x) { if (st.length < 3 && st.indexOf(x) < 0) st.push(x); });
  if (fm === 'FAIL') E.FAIL_LINES.forEach(function (x) { en.push(x); });
  const n = E.dayN(E.dOf(m || {}), home);
  if (n) en.push(['day ' + n, n + '일째']);
  return { p: p.slice(0, 5), s: st.slice(0, 3), en: en, memo: String((m && m.m) || '').trim() };
};

/* ---------- 영어 문구 → 한글 뜻 (내장 문구만. 직접 쓴 문장은 파파고 링크) ---------- */
E.DL_KO = function (N) { return N ? '우리 카발리에와 함께한 ' + N + '일째' : '우리 카발리에와 함께'; };
E.MQ_KO = { 'cute piano': '귀여운 피아노', 'heartwarming': '마음이 따뜻해지는', 'Monkeys Spinning Monkeys': '곡명 — 경쾌하고 장난스러운 곡', 'Sneaky Snitch': '곡명 — 살금살금 장난스러운 곡',
  'lullaby': '자장가', 'sleepy piano': '잔잔한 피아노', 'emotional piano': '감성 피아노', 'growing up': '성장', 'funny fail': '웃긴 실수', 'upbeat ukulele': '경쾌한 우쿨렐레',
  'proud moment': '뿌듯한 순간', 'happy acoustic': '밝은 어쿠스틱', 'cute puppy': '귀여운 강아지', 'cozy piano': '포근한 피아노', 'upbeat funny': '신나고 웃긴',
  'calm lullaby': '잔잔한 자장가', 'quirky funny': '엉뚱하고 웃긴', 'cinematic inspiring': '웅장하고 감동적인' };
E.gloss = function (ctx) {
  const g = {};
  Object.keys(E.TPL).forEach(function (fm) {
    E.TPL[fm].forEach(function (t) {
      [[t.t, t.k], [t.h, t.kh], [t.t0, t.k0], [t.h0, t.kh0], [t.d, t.kd]].forEach(function (pr) {
        if (!pr[0] || !pr[1]) return;
        g[E.fill(pr[0], ctx)] = E.koFill(pr[1], ctx);
      });
    });
  });
  g['day ' + (ctx.N || '') + ' with my Cavalier'] = E.DL_KO(ctx.N);
  g['with my Cavalier'] = E.DL_KO(0);
  E.FAIL_LINES.forEach(function (x) { g[x[0]] = x[1]; });
  Object.keys(E.MQ_KO).forEach(function (k) { g[k] = E.MQ_KO[k]; });
  return g;
};
E.meaning = function (text, ctx) {
  const t = String(text || '').trim(); if (!t) return '';
  const g = E.gloss(ctx || {});
  if (g[t]) return g[t];
  const m = /^day (\d+)$/i.exec(t); if (m) return m[1] + '일째';
  const m2 = /^day (\d+) with my Cavalier$/i.exec(t); if (m2) return E.DL_KO(m2[1]);
  /* 설명 첫 줄: 'Day N with our Cavalier King Charles Spaniel puppy 🐾' (예전 형식 '— 문장'도 읽음) */
  const m3 = /^(Day (\d+) with our|Life with our) Cavalier King Charles Spaniel puppy(?: 🐾)?(?: — (.+))?$/.exec(t);
  if (m3) { const tail = m3[3] ? (g[m3[3].trim()] || '') : ''; return (m3[2] ? '카발리에 킹 찰스 스패니얼 강아지와 함께한 ' + m3[2] + '일째' : '카발리에 킹 찰스 스패니얼 강아지와 함께하는 삶') + (tail ? ' — ' + tail : ''); }
  return '';
};
E.papago = function (text) { return 'https://papago.naver.com/?sk=en&tk=ko&st=' + encodeURIComponent(String(text || '')); };

/* ---------- 레시피 초안 ---------- */
E.draft = function (sel, fm, opt) {
  opt = opt || {};
  const home = opt.home || '', recipes = opt.recipes || {}, today = opt.today;
  const ctx = E.ctxOf(sel, fm, home, recipes);
  const it = E.captions(E.compose(sel, fm, today, { firstId: opt.firstId, keepAll: opt.keepAll }), sel, fm, ctx, home);
  const ts = E.titles(fm, ctx, recipes);
  const t0 = ts[0] || { key: '', t: '', h: '', d: '' };
  return {
    st: 'draft', mo: 'A', fm: fm, it: it, ti: t0.t, tt: t0.key, hk: t0.h,
    dl: ctx.N ? 'day ' + ctx.N + ' with my Cavalier' : 'with my Cavalier',
    ko: E.koLine(sel, ctx), de: E.desc(t0, sel, ctx, opt.sn || 0), mq: E.music(fm, ctx.mood), dn: ctx.N || 0,
    ln: E.total(it), src: opt.src || 'rec'
  };
};
/* 사진 한 장에서 시작 — 같은 시기·분위기 사진 6~8장을 자동으로 묶음 (SH-00-2) */
E.bundleFrom = function (id, meta, cfg, today) {
  cfg = Object.assign({}, E.DEF_CFG, cfg || {});
  const m0 = meta[id]; if (!m0) return [];
  const d0 = E.dOf(m0), md0 = E.mood(m0), s0 = E.sits(m0);
  const cands = E.candidates(meta, cfg, today, {}).filter(function (x) { return x.id !== id; });
  cands.forEach(function (x) {
    const dd = Math.abs(E.daysBetween(d0, E.dOf(x.m)));
    let r = x.sc;
    if (dd <= 3) r += 4; else if (dd <= 10) r += 2; else if (dd > 45) r -= 3;
    if (md0 && E.mood(x.m) === md0) r += 2;
    if (s0.length && E.sits(x.m).some(function (s) { return s0.indexOf(s) > -1; })) r += 2;
    x.rel = r;
  });
  cands.sort(function (a, b) { return b.rel - a.rel; });
  const first = { id: id, m: m0, sc: E.score(m0, today) + 10 };
  const sel = E.dedupeBursts([first].concat(cands));
  let clips = E.isClip(m0) ? 1 : 0;
  const out = [];
  sel.forEach(function (x) { if (out.length >= 8) return; if (E.isClip(x.m)) { if (clips >= 1 && x.id !== id) return; if (x.id !== id) clips++; } out.push(x); });
  return out.slice(0, 8);
};

if (typeof module === 'object' && module.exports) module.exports = E;

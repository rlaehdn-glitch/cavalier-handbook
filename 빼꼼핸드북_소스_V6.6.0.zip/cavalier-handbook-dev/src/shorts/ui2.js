/* ================= SH-01 쇼츠 홈(추천) · SH-07 기록 · SH-08 설정 · 장면 태그 시트 ================= */
const RC = { recs: null, skip: {}, at: 0, metaN: 0, cool: false, info: null };
function metaCount() { return Object.keys(ALB.meta || {}).filter(function (id) { return E.usable(ALB.meta[id]); }).length; }
function needRefresh() {
  if (!RC.recs) return true;
  const n = metaCount();
  return Math.abs(n - RC.metaN) >= 5;   /* 새 사진이 5장 이상 쌓였을 때 */
}
function computeRecs(force) {
  if (!force && !needRefresh()) return RC.recs;
  const r = E.recommend(ALB.meta || {}, C(), D.rec, D.fp, today(), { skip: RC.skip, cool: RC.cool });
  RC.recs = r.recs; RC.info = r; RC.at = Date.now(); RC.metaN = metaCount();
  return RC.recs;
}
function recDraft(g) {
  const fm = g.fm;
  const r = E.draft(g.sel, fm, { home: (S.profile || {}).home, today: today(), recipes: D.rec, src: 'rec' });
  return r;
}
function coverId(g) { return g.ids[0]; }
function fmtTags(g) {
  const ctx = E.ctxOf(g.sel, g.fm, (S.profile || {}).home, D.rec);
  const out = [];
  if (ctx.last) out.push(E.season(ctx.last)[0]);
  if (ctx.sit) out.push(ctx.sit);
  if (g.fm === 'SLEEP') out.push('반전'); else if (ctx.mood) out.push(ctx.mood);
  return out.join(' · ');
}

/* ---------- SH-01 / SH-07 ---------- */
function openHome(tab) {
  const el = scrEl('sx-home');
  el.innerHTML = navBar({ back: '앨범', right: '<button type="button" class="sx-nbtn" data-act="set" aria-label="쇼츠 설정">' + ICO.gear + '</button>' }) +
    '<div class="sx-body"><div class="sx-big">쇼츠</div>' +
    '<div class="sx-seg" role="tablist"><button type="button" data-tab="rec">추천</button><button type="button" data-tab="log">기록</button></div>' +
    '<div class="sx-pane"></div></div>';
  const scr = { el: el, tab: tab || 'rec' };
  function paint() {
    $$(el, '.sx-seg button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === scr.tab); b.setAttribute('aria-selected', b.dataset.tab === scr.tab); });
    const pane = $(el, '.sx-pane');
    if (scr.tab === 'rec') paintRecs(pane, scr); else paintLog(pane, scr);
  }
  scr.paint = paint;
  scr.resume = function () { paint(); };
  el.addEventListener('click', function (e) {
    const t = e.target.closest('.sx-seg [data-tab]'); if (t && el.contains(t)) { scr.tab = t.dataset.tab; paint(); return; }
    if (e.target.closest('[data-act="set"]')) { openSettings(); return; }
  });
  push(scr);
  paint();
  dLoad().then(function () { paint(); idxHashes(); }).catch(function (e) { $(el, '.sx-pane').innerHTML = '<div class="sx-empty">쇼츠 기록을 불러오지 못했어요.<br>인터넷을 확인해 주세요.<br><small>' + esc(String(e && e.message || e)) + '</small></div>'; });
  return scr;
}
/* 'A · B · C' — 줄이 넘치면 항목 단위로 넘김(글자가 홀로 떨어지지 않게) */
function segs(a) { return a.map(function (x, i) { return '<span class="nw">' + x + (i < a.length - 1 ? ' ·' : '') + '</span>'; }).join(' '); }
function paintRecs(pane, scr) {
  if (!D.ok) { pane.innerHTML = '<div class="sx-empty">불러오는 중…</div>'; return; }
  const recs = computeRecs(false) || [];
  const info = RC.info || { newCount: 0 };
  let html = '';
  const dr = drafts();
  if (!dr.length) scr.dEdit = false;
  if (dr.length) {
    const me = myName() || '', ed = !!scr.dEdit;
    html += '<div class="sx-row"><span class="sx-h">만들다 만 쇼츠 ' + dr.length + '편</span><span class="sx-acts">' +
      (ed ? (dr.length > 1 ? '<button type="button" class="sx-lnk red" data-act="delall">모두 삭제</button>' : '') + '<button type="button" class="sx-lnk b" data-act="dedit">완료</button>'
        : '<button type="button" class="sx-lnk" data-act="dedit">편집</button>') +
      '</span></div><div class="sx-card' + (ed ? ' sx-dedit' : '') + '" style="padding:4px 12px;">' +
      dr.map(function (r) {
        const left = Math.max(0, 14 - Math.floor((Date.now() - (r.ut || r.at || Date.now())) / 86400000));
        const l1 = [esc(r.fm), fmtSec(E.total(r.it || []))];
        if (r.sn) l1.push('빼꼼 #' + esc(r.sn));
        const l2 = [];
        if (r.mk) l2.push('<span class="mk">영상까지 만듦</span>');
        if (r.by && me && r.by !== me) l2.push(esc(r.by) + ' 폰');
        l2.push(left + '일 남음');
        return '<div class="sx-draft" data-draft="' + esc(r.rid) + '"><div class="th"><img class="sx-ph" data-th="' + esc(((r.it || [])[0] || {}).id || '') + '" alt=""></div><div class="tx"><div class="t1">' + esc(r.ti || '제목 없음') + '</div><div class="sx-sub">' + segs(l1) + '</div><div class="sx-sub">' + segs(l2) + '</div></div>' +
          (ed ? '<button type="button" class="sx-badge del" data-ddel="' + esc(r.rid) + '" aria-label="이 초안 삭제">삭제</button>' : '<span class="sx-badge">이어서</span>') + '</div>';
      }).join('') + '</div><p class="sx-sub sx-dnote">14일 동안 안 열면 자동으로 지워져요.</p>';
  }
  const showRecs = RC.cool || info.newCount >= 5;
  if (!showRecs) {
    const need = Math.max(1, 5 - info.newCount);
    html += '<div class="sx-card"><div class="sx-empty" style="padding:18px 8px;">추천할 새 사진이 부족해요.<br>사진을 ' + need + '장 더 올리면 새 추천이 생겨요.</div>' +
      '<button type="button" class="sx-btn soft" data-act="cool">쉬는 중인 사진도 넣어서 추천</button></div>';
  } else if (!recs.length) {
    html += '<div class="sx-card"><div class="sx-empty" style="padding:18px 8px;">지금 사진으로는 만들 수 있는 묶음이 없어요.<br>한 편에 사진 6장 이상이 필요해요.</div></div>';
  } else {
    html += '<div class="sx-row"><span class="sx-h">이번 주 후보 ' + recs.length + '편</span><button type="button" class="sx-lnk" data-act="again">다시 추천</button></div>';
    html += recs.map(function (g, i) {
      const d = recDraft(g);
      const nV = g.sel.filter(function (x) { return E.isClip(x.m); }).length, nP = g.sel.length - nV;
      const nNew = g.sel.filter(function (x) { return E.isNew(x.m, today()); }).length;
      return '<div class="sx-rec" data-rec="' + i + '"><div class="cv"><img class="sx-ph" data-th="' + esc(d.it[0].id) + '" alt=""><span class="len">' + Math.round(E.total(d.it)) + '초</span></div>' +
        '<div class="bd"><div class="tg"><span class="sx-badge">' + g.fm + '</span><span>' + esc(fmtTags(g)) + '</span></div>' +
        '<div class="tt">' + esc(d.ti) + '</div>' + meanHTML(d.ti, E.ctxOf(g.sel, g.fm, (S.profile || {}).home, D.rec)) + '<div class="in">' + (nV ? '영상 ' + nV + ' · ' : '') + '사진 ' + nP + '장 · ' + Math.round(E.total(d.it)) + '초</div>' +
        (nNew ? '<div class="sx-new">새 사진 ' + nNew + '장 포함</div>' : '') +
        '<button type="button" class="sx-btn sm soft go" data-rec="' + i + '">만들기</button></div></div>';
    }).join('');
  }
  html += '<button type="button" class="sx-btn gray" data-act="pick" style="margin-top:6px; background:var(--card); color:var(--tint);">사진 직접 골라 만들기</button>';
  pane.innerHTML = html;
  thumbsIn(pane);
  pane.onclick = async function (e) {
    if (e.target.closest('[data-act="dedit"]')) { scr.dEdit = !scr.dEdit; paintRecs(pane, scr); return; }
    const dl = e.target.closest('[data-ddel]'); if (dl) { if (await runDelDraft(dl.dataset.ddel)) paintRecs(pane, scr); return; }
    if (e.target.closest('[data-act="delall"]')) { if (await runDelAll()) paintRecs(pane, scr); return; }
    if (scr.dEdit && e.target.closest('[data-draft]')) return;   /* 편집 중에는 행을 눌러도 열지 않음 */
    const dr2 = e.target.closest('[data-draft]'); if (dr2) { const r = D.rec[dr2.dataset.draft]; if (r) openEdit(Object.assign({}, JSON.parse(JSON.stringify(r)), { rid: dr2.dataset.draft })); return; }
    const rc = e.target.closest('[data-rec]'); if (rc) { const g = (RC.recs || [])[+rc.dataset.rec]; if (g) { const d = recDraft(g); d.key = g.key; openEdit(d); } return; }
    if (e.target.closest('[data-act="again"]')) { (RC.recs || []).forEach(function (g) { RC.skip[g.sig] = 1; RC.skip[g.key] = 1; }); const r = computeRecs(true); if (!r.length) { RC.skip = {}; computeRecs(true); toast('추천을 처음부터 다시 보여 드려요'); } paintRecs(pane, scr); return; }
    if (e.target.closest('[data-act="cool"]')) { RC.cool = true; RC.skip = {}; computeRecs(true); paintRecs(pane, scr); if (!(RC.recs || []).length) toast('쉬는 사진을 넣어도 만들 수 있는 묶음이 없어요'); return; }
    if (e.target.closest('[data-act="pick"]')) { closeAll(); setTimeout(function () { try { albSelStart(); } catch (er) { } }, 420); return; }
  };
}
/* ---------- 초안 삭제 (V6.5.2) ----------
   영상까지 만든 초안은 유튜브에 이미 올렸을 수 있으니 '기록으로 옮기기'도 고르게 한다(번호 중복 방지) */
async function askDelDraft(rid) {
  const r = D.rec[rid]; if (!r || r.st === 'up') return null;
  const me = myName() || '';
  const lines = [];
  if (r.by && me && r.by !== me) lines.push(r.by + ' 폰에서 만든 초안이에요.');
  let snLine = '';
  if (r.sn) {
    const rest = Object.assign({}, D.rec); delete rest[rid];
    const st = E.snFree(C().nsn, rest, C().fsn, r.sn);
    snLine = st.nsn <= r.sn || st.fsn.indexOf(r.sn) > -1 ? '사진은 앨범에 그대로 남고, 번호(빼꼼 #' + r.sn + ')는 다음 영상이 이어받아요.' : '사진은 앨범에 그대로 남아요. 번호(빼꼼 #' + r.sn + ')는 비게 돼요 — 뒤 번호가 이미 올라가 있어요.';
  }
  const after = snLine || '사진은 앨범에 그대로 남아요.';
  if (r.mk) {
    lines.push('영상까지 만든 초안이에요. 유튜브에 이미 올렸다면 \'기록으로 옮기기\'를 눌러 주세요.');
    lines.push('삭제하면 ' + after);
  } else lines.push(after);
  if (r.mk) {
    const res = await uiSheetOpen({ title: '이 초안을 삭제할까요?', msg: lines.join('\n'), actions: [{ label: '유튜브에 올렸어요 · 기록으로 옮기기' }, { label: '삭제', destr: true }], cancel: '취소' });
    if (!res || !res.ok) return null;
    return res.idx === 0 ? 'up' : 'del';
  }
  return (await uiConfirm({ title: '이 초안을 삭제할까요?', msg: lines.join('\n'), ok: '삭제', destr: true })) ? 'del' : null;
}
async function runDelDraft(rid) {
  const act = await askDelDraft(rid);
  if (!act) return null;
  try {
    if (act === 'up') {
      const r = Object.assign(JSON.parse(JSON.stringify(D.rec[rid])), { rid: rid });
      if (!r.sn) await reserveSn(r);
      await markUp(r);
      toast('기록으로 옮겼어요 — 빼꼼 #' + r.sn);
    } else {
      await delDraft(rid);
      toast('초안을 삭제했어요');
    }
    return act;
  } catch (e) { uiAlert('처리하지 못했어요 — 인터넷 확인 후 다시 시도해 주세요.'); return null; }
}
async function runDelAll() {
  const list = drafts(); if (!list.length) return false;
  const me = myName() || '';
  const nMk = list.filter(function (r) { return r.mk; }).length;
  const nOther = list.filter(function (r) { return r.by && me && r.by !== me; }).length;
  const msg = ['사진은 앨범에 그대로 남아요.'];
  if (nMk) msg.push('영상까지 만든 초안이 ' + nMk + '편 있어요. 유튜브에 올린 게 있다면 먼저 하나씩 \'기록으로 옮기기\' 해 주세요.');
  if (nOther) msg.push('다른 폰에서 만든 초안 ' + nOther + '편도 함께 지워져요.');
  const ok = await uiConfirm({ title: '만들다 만 쇼츠 ' + list.length + '편을 모두 삭제할까요?', msg: msg.join('\n'), ok: '모두 삭제', destr: true });
  if (!ok) return false;
  let fail = 0;
  for (let i = 0; i < list.length; i++) { try { await delDraft(list[i].rid); } catch (e) { fail++; } }
  toast(fail ? (list.length - fail) + '편 삭제 · ' + fail + '편 실패 — 인터넷 확인' : '초안 ' + list.length + '편을 삭제했어요');
  return true;
}
function paintLog(pane) {
  if (!D.ok) { pane.innerHTML = '<div class="sx-empty">불러오는 중…</div>'; return; }
  const list = ups();
  const nRec = Object.keys(D.rec).length, nFp = Object.keys(D.fp).length;
  let html = '<div class="sx-card" style="padding:16px 18px;"><div style="font-size:20px;font-weight:800;">올린 쇼츠 ' + list.length + '편</div><div class="sx-sub" style="margin-top:3px;">레시피 ' + nRec + '건 · 지문 ' + nFp + '건 보관 중</div></div>';
  if (list.length) {
    html += '<div class="sx-list">' + list.map(function (r) {
      const link = r.yu ? '' : '<div class="t3">유튜브 링크 붙여넣기</div>';
      return '<div class="sx-li" data-log="' + esc(r.rid) + '"><div class="th"><img class="sx-ph" data-th="' + esc((r.it[0] || {}).id || '') + '" alt=""></div><div class="tx"><div class="t1">' + esc(r.ti || '') + '</div><div class="t2">' + mdK(E.dkey(new Date(r.up || r.at || Date.now()))) + ' · 빼꼼 #' + esc(r.sn || '?') + '</div>' + link + '</div><span class="bg sx-badge ' + (r.mo === 'B' ? '' : 'gray') + '">' + (r.mo === 'B' ? '자동' : '직접') + '</span></div>';
    }).join('') + '</div>';
  } else html += '<div class="sx-empty">아직 올린 쇼츠가 없어요.<br>추천 탭에서 첫 편을 만들어 보세요.</div>';
  html += '<p class="sx-sub" style="margin:6px 6px 0;">오래된 기록은 설정에서 정리해요. 지문은 남아요.</p>';
  pane.innerHTML = html;
  thumbsIn(pane);
  pane.onclick = function (e) { const li = e.target.closest('[data-log]'); if (li) logSheet(li.dataset.log, function () { paintLog(pane); }); };
}
/* 기록 상세 시트 */
function logSheet(rid, after) {
  const r = D.rec[rid]; if (!r) return;
  const ids = (r.it || []).map(function (x) { return x.id; });
  const lctx = E.ctxOf(selOf(ids), r.fm, (S.profile || {}).home, D.rec);
  const sh = sheet('<h3>' + esc(r.ti || '') + '</h3>' + meanHTML(r.ti, lctx) + '<div class="sx-sub">' + mdK(E.dkey(new Date(r.up || r.at || Date.now()))) + ' · 빼꼼 #' + esc(r.sn || '?') + ' · ' + esc(r.fm) + ' · ' + fmtSec(E.total(r.it || [])) + '</div>' +
    '<div class="lbl">사용한 사진 ' + ids.length + '장</div><div class="sx-hs">' + ids.map(function (id) { return '<div style="flex:0 0 54px;height:76px;border-radius:9px;overflow:hidden;background:var(--fill2);"><img class="sx-ph" data-th="' + esc(id) + '" alt=""></div>'; }).join('') + '</div>' +
    '<div class="lbl">음악 검색어</div><div class="sx-chips">' + mqChips(r.mq, lctx) + '</div>' +
    '<div class="lbl">설명</div><div class="sx-card" style="background:var(--card);"><div class="sx-desc">' + esc(r.de || '') + '</div></div>' +
    '<div class="sx-btns"><button type="button" class="sx-btn gray" data-act="cpt">제목 복사</button><button type="button" class="sx-btn gray" data-act="cpd">설명 복사</button></div>' +
    (r.yu ? '<button type="button" class="sx-btn" style="margin-top:10px;" data-act="open">유튜브에서 열기</button>' : '<button type="button" class="sx-btn" style="margin-top:10px;" data-act="link">유튜브 링크 붙여넣기</button>') +
    '<button type="button" class="sx-btn gray" style="margin-top:10px;" data-act="x">닫기</button>');
  thumbsIn(sh.el);
  sh.el.addEventListener('click', async function (e) {
    if (e.target.closest('.sx-pap')) return;
    const cp = e.target.closest('[data-copy]'); if (cp) { copyText(cp.dataset.copy); toast('복사했어요: ' + cp.dataset.copy); return; }
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'x') sh.close();
    else if (a.dataset.act === 'cpt') { copyText(r.ti); toast('제목을 복사했어요'); }
    else if (a.dataset.act === 'cpd') { copyText(r.de); toast('설명을 복사했어요'); }
    else if (a.dataset.act === 'open') { try { window.open(r.yu, '_blank', 'noopener'); } catch (er) { } }
    else if (a.dataset.act === 'link') { sh.close(); await pasteLink(rid); if (after) after(); }
  });
}
/* 유튜브 링크 붙여넣기 → 레시피에 저장 + 앨범 유튜브 카드로 자동 등록 */
async function pasteLink(rid) {
  const r = D.rec[rid]; if (!r) return false;
  const v = await uiPrompt('유튜브 링크 붙여넣기', '');
  if (v === null) return false;
  const u = String(v).trim(); const yid = ytId(u);
  if (!yid) { uiAlert('유튜브 링크가 아니에요. 유튜브 앱에서 공유 → 링크 복사 후 붙여넣어 주세요.'); return false; }
  r.yu = 'https://youtube.com/shorts/' + yid; r.yi = yid;
  try {
    await recPut(rid, r);
    const aid = 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const meta = { t: 'v', d: E.dkey(new Date(r.up || Date.now())), m: r.ti || '', u: r.yu, at: Date.now(), s: 0, sh: rid };
    await albFetch('meta/' + aid, 'PUT', JSON.stringify(meta));
    await albBumpIdx();
    ALB.meta = ALB.meta || {}; ALB.meta[aid] = meta;
    try { renderAlbum(); } catch (e) { }
    toast('링크를 연결하고 앨범에도 넣었어요');
    return true;
  } catch (e) { uiAlert('저장하지 못했어요 — 인터넷 확인 후 다시 시도해 주세요.'); return false; }
}

/* ---------- SH-08 쇼츠 설정 ---------- */
function openSettings() {
  const el = scrEl();
  const scr = { el: el };
  function row(label, val, attr, cls) { return '<div class="sx-set' + (attr ? ' tap' : '') + '"' + (attr || '') + '><span>' + label + '</span><span class="v ' + (cls || '') + '">' + val + (attr ? ICO.chev : '') + '</span></div>'; }
  function paint() {
    const c = C();
    el.innerHTML = navBar({ back: '쇼츠', title: '쇼츠 설정' }) + '<div class="sx-body">' +
      '<div class="sx-sec">기본</div><div class="sx-grp">' +
      '<div class="sx-set"><span>기본 올리기 방식</span><div class="sx-mini"><button type="button" class="on">직접</button><button type="button" data-act="auto">자동</button></div></div>' +
      '<div class="sx-set"><span>주간 추천 편수</span><div class="sx-step"><button type="button" data-st="recN" data-d="-1" aria-label="줄이기">−</button><b>' + c.recN + '편</b><button type="button" data-st="recN" data-d="1" aria-label="늘리기">+</button></div></div>' +
      '</div>' +
      '<div class="sx-sec">채널</div><div class="sx-grp">' +
      row('내 채널', esc(c.ch || '설정 안 됨'), ' data-act="ch"') +
      row('다음 시리즈 번호', '빼꼼 #' + esc(c.nsn || 1), ' data-act="sn"') +
      '</div>' + (c.nsnGuess ? '<p class="sx-sub" style="margin:7px 8px 0;">처음 값은 앨범의 유튜브 링크 수로 추정했어요. 채널에 올린 쇼츠 편수 + 1이 맞는지 확인해 주세요.</p>' : '') +
      '<div class="sx-sec">자동 올리기</div><div class="sx-grp">' + row('자동 올리기', '다음 업데이트(V6.6)', '', 'dis') + '</div>' +
      '<div class="sx-sec">중복 방지</div><div class="sx-grp">' +
      '<div class="sx-set"><span>같은 사진 쉬는 기간</span><div class="sx-step"><button type="button" data-st="cool" data-d="-5">−</button><b>' + c.cool + '일</b><button type="button" data-st="cool" data-d="5">+</button></div></div>' +
      '<div class="sx-set"><span>최대 사용</span><div class="sx-step"><button type="button" data-st="maxUse" data-d="-1">−</button><b>' + c.maxUse + '회</b><button type="button" data-st="maxUse" data-d="1">+</button></div></div>' +
      '<div class="sx-set"><span>겹침 허용</span><div class="sx-step"><button type="button" data-st="ovl" data-d="-10">−</button><b>' + c.ovl + '%</b><button type="button" data-st="ovl" data-d="10">+</button></div></div>' +
      '</div>' +
      '<div class="sx-sec">저장공간</div><div class="sx-grp">' +
      row('보관 중', '레시피 ' + Object.keys(D.rec).length + '건 · 지문 ' + Object.keys(D.fp).length + '건', '') +
      '<div class="sx-set tap" data-act="clean"><span>오래된 기록 정리</span><span class="v act">지문은 남아요</span></div>' +
      '</div>' +
      '<div class="sx-sec">이 폰</div><div class="sx-grp">' + row('영상 만들기', '<span id="sxCapV">확인 중…</span>', '') + row('원본 소리 넣기', '<span id="sxCapA">확인 중…</span>', '') + '</div>' +
      '<p class="sx-sub" style="margin:10px 8px 0;">쇼츠 V' + SXV + ' · 설정은 두 폰이 함께 씁니다.</p></div>';
    R.caps().then(function (cp) {
      const v = document.getElementById('sxCapV'), a = document.getElementById('sxCapA');
      if (v) v.textContent = cp.video ? '가능 (' + cp.fps + 'fps' + (cp.rot ? ' · 눕혀 저장' : '') + ')' : '안 됨 — iOS 26 이상 또는 안드로이드 크롬';
      if (a) a.textContent = cp.audio ? '가능 (AAC)' : '안 됨 — 소리 없이 만들어요';
    });
  }
  el.addEventListener('click', async function (e) {
    const st = e.target.closest('[data-st]');
    if (st) {
      const k = st.dataset.st, d = +st.dataset.d, c = C();
      const lim = { recN: [1, 5], cool: [0, 120], maxUse: [1, 10], ovl: [0, 100] }[k];
      const v = Math.max(lim[0], Math.min(lim[1], (+c[k] || 0) + d));
      try { await cfgSet(k, v); RC.recs = null; } catch (er) { toast('저장 실패 — 인터넷 확인'); }
      paint(); return;
    }
    const a = e.target.closest('[data-act]'); if (!a) return;
    const act = a.dataset.act;
    if (act === 'auto') { uiAlert('자동 올리기는 첫 설정이 필요해요.\n다음 업데이트(V6.6)에서 Zapier 연결과 함께 열려요.'); return; }
    if (act === 'ch') { const v = await uiPrompt('내 채널 (예: @DWKIM_CA)', C().ch || ''); if (v !== null) { try { await cfgSet('ch', v.trim()); } catch (er) { } paint(); } return; }
    if (act === 'sn') {
      const v = await uiPrompt('다음 시리즈 번호 (채널에 올린 쇼츠 편수 + 1)', String(C().nsn || 1));
      if (v === null) return;
      const n = parseInt(v, 10); if (!(n > 0)) { uiAlert('숫자를 입력해 주세요.'); return; }
      try { await cfgSet('nsn', n); await cfgSet('nsnGuess', null); await cfgSet('fsn', null); } catch (er) { }   /* 직접 정한 번호가 기준 — 빈 번호 목록은 비움 */
      paint(); return;
    }
    if (act === 'clean') {
      const lim = Date.now() - 90 * 86400000;
      const old = ups().filter(function (r) { return (r.up || 0) < lim; });
      if (!old.length) { uiAlert('정리할 기록이 없어요.\n올린 지 90일 지난 레시피만 지웁니다.'); return; }
      const ok = await uiConfirm({ title: '오래된 기록 정리', msg: '올린 지 90일 지난 레시피 ' + old.length + '건을 지웁니다.\n지문은 남아서 같은 사진 조합은 다시 만들어지지 않아요.', ok: '정리', destr: true });
      if (!ok) return;
      for (let i = 0; i < old.length; i++) { try { await recDel(old[i].rid); } catch (er) { } }
      toast('레시피 ' + old.length + '건을 정리했어요'); paint();
    }
  });
  push(scr); paint();
}

/* ---------- SH-00-3 장면 태그 시트 (사진 올린 뒤 · 태그 수정) ---------- */
function shotMs(m) { const s = String((m && m.sd) || ''); return /T\d{2}:\d{2}/.test(s) ? E.tOf(m) : 0; }
function within(segs, t, pad) { return (segs || []).some(function (x) { return x && x.o && t >= x.o - pad && t <= (x.i || Date.now()) + pad; }); }
function logSegs(log, t) {
  const k = E.dkey(new Date(t)), prev = E.dkey(new Date(t - 86400000));
  return [].concat((log || {})[k] || [], (log || {})[prev] || []);
}
/* 찍은 시각이 산책·목욕·유치원·수면 기록과 겹치면 미리 선택 */
function suggest(ids) {
  const out = {}; const why = [];
  ids.forEach(function (id) {
    const m = (ALB.meta || {})[id]; let t = shotMs(m);
    if (!t && m && m.at && Date.now() - m.at < 10 * 60000) t = m.at;   /* 촬영 정보가 없고 방금 올렸으면 지금 시각 */
    if (!t) return;
    const PAD = 10 * 60000;
    if (within(logSegs(S.walkLog, t), t, PAD) || (S.walkCur && t >= S.walkCur - PAD)) { out['산책'] = 1; }
    if (within(logSegs(S.kgLog, t), t, 0)) out['유치원'] = 1;
    if (within(logSegs(S.sleepLog, t), t, 0) || (S.sleepCur && t >= S.sleepCur)) out['잠'] = 1;
    const bl = S.bathLog || {}; const bk = E.dkey(new Date(t));
    if (bl[bk] && bl[bk].t && Math.abs(bl[bk].t - t) < 3 * 3600000) out['목욕'] = 1;
  });
  Object.keys(out).forEach(function (s) { why.push(s); });
  return { pick: out, why: why };
}
function tagSheet(ids, o) {
  o = o || {};
  ids = (ids || []).filter(function (id) { return (ALB.meta || {})[id]; });
  if (!ids.length) return Promise.resolve(false);
  const one = ids.length === 1 ? ALB.meta[ids[0]] : null;
  const pick = {}; let mood = '';
  if (one) { E.sits({ ts: one.ts }).forEach(function (s) { pick[s] = 1; }); mood = E.mood(one); }
  let sg = { pick: {}, why: [] };
  if (o.auto) { sg = suggest(ids); Object.keys(sg.pick).forEach(function (s) { pick[s] = 1; }); }
  return new Promise(function (resolve) {
    const head = o.auto ? '어떤 장면인가요?' : '장면 태그';
    const sub = o.auto ? '고르면 쇼츠 추천이 정확해져요. 건너뛰어도 돼요.' : '쇼츠 추천과 포맷 정하기에 쓰여요.';
    const sh = sheet('<h3>' + head + '</h3><div class="sx-sub">' + sub + '</div>' +
      '<div class="sx-thr">' + ids.slice(0, 4).map(function (id) { return '<div class="t"><img class="sx-ph" data-th="' + esc(id) + '" alt=""></div>'; }).join('') + '<span class="sx-sub" style="margin-left:6px;">' + (o.auto ? '방금 올린 ' : '') + ids.length + '장</span></div>' +
      '<div class="lbl">상황</div><div class="sx-chips" data-g="sit">' + E.SIT.map(function (s) { return '<button type="button" class="sx-chip' + (pick[s] ? ' on' : '') + '" data-v="' + s + '">' + s + '</button>'; }).join('') + '</div>' +
      (sg.why.length ? '<div class="sx-note">' + sg.why.map(function (s) { return s + ' 기록'; }).join('·') + '과 시간이 겹쳐 ' + sg.why.map(function (s) { return '‘' + s + '’'; }).join('·') + '을 미리 골랐어요</div>' : '') +
      '<div class="lbl">분위기</div><div class="sx-chips" data-g="mood">' + E.MOODS.map(function (s) { return '<button type="button" class="sx-chip' + (mood === s ? ' on' : '') + '" data-v="' + s + '">' + s + '</button>'; }).join('') + '</div>' +
      '<div class="sx-btns"><button type="button" class="sx-btn gray" data-act="skip">' + (o.auto ? '건너뛰기' : '취소') + '</button><button type="button" class="sx-btn" data-act="save">저장</button></div>',
      { onClose: function () { resolve(false); }, noHist: !!o.auto && !(navigator.userActivation && navigator.userActivation.isActive) });
    thumbsIn(sh.el);
    sh.el.addEventListener('click', async function (e) {
      const c = e.target.closest('.sx-chip');
      if (c) {
        const g = c.parentNode.dataset.g, v = c.dataset.v;
        if (g === 'sit') { if (pick[v]) delete pick[v]; else pick[v] = 1; c.classList.toggle('on', !!pick[v]); }
        else { mood = mood === v ? '' : v; $$(c.parentNode, '.sx-chip').forEach(function (b) { b.classList.toggle('on', b.dataset.v === mood); }); }
        return;
      }
      const a = e.target.closest('[data-act]'); if (!a) return;
      if (a.dataset.act === 'skip') { sh.close(); return; }
      const ts = E.SIT.filter(function (s) { return pick[s]; }).join(',');
      const up = {};
      ids.forEach(function (id) { up[id + '/ts'] = ts || null; up[id + '/tm'] = mood || null; });
      a.disabled = true;
      try {
        await albFetch('meta', 'PATCH', JSON.stringify(up));
        await albBumpIdx();
        ids.forEach(function (id) { const m = ALB.meta[id]; if (!m) return; if (ts) m.ts = ts; else delete m.ts; if (mood) m.tm = mood; else delete m.tm; });
        RC.recs = null;
        sh.close(); resolve(true);
        if (o.after) o.after();
      } catch (er) { a.disabled = false; toast('저장 실패 — 인터넷 확인 후 다시 시도'); }
    });
  });
}
/* 사진마다 이미지 지문(ih) — 연사 묶기용. 한 번에 3장씩, 없는 것만 */
let IDX_RUN = false;
async function idxHashes(ids) {
  if (IDX_RUN || !syncConfigured()) return;
  IDX_RUN = true;
  try {
    const meta = ALB.meta || {};
    const todo = (ids || Object.keys(meta)).filter(function (id) { const m = meta[id]; return m && E.isPhoto(m) && !m.ih; }).slice(0, 60);
    const up = {};
    for (let i = 0; i < todo.length; i += 3) {
      await Promise.all(todo.slice(i, i + 3).map(async function (id) {
        try { const u = await thumbSrc(id); if (!u) return; const hx = await R.dhash(u); if (hx && hx.length === 16) { up[id + '/ih'] = hx; meta[id].ih = hx; } } catch (e) { }
      }));
    }
    if (Object.keys(up).length) { await albFetch('meta', 'PATCH', JSON.stringify(up)); }
  } catch (e) { } finally { IDX_RUN = false; }
}

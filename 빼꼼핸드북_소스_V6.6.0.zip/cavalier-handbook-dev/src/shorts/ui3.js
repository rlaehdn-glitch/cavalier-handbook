/* ================= SH-02 구성 편집 · SH-03 마무리 · SH-04 만드는 중 · SH-05A 직접 올리기 ================= */
const FMT_KO = { TRUST: '교감', ATTACK: '놀이·우다다', SLEEP: '잠 반전', GROWTH: '성장', FAIL: '말썽', TRAIN: '훈련', PHOTOS: '사진 모음' };
function ctxFor(rcp) { return E.ctxOf(selOf(rcp.it.map(function (x) { return x.id; })), rcp.fm, (S.profile || {}).home, D.rec); }
function idsOf(rcp) { return rcp.it.map(function (x) { return x.id; }); }

/* 포맷 바꾸기 — 자막 문체·장당 시간·음악 분위기가 함께 바뀜 (사람이 고친 값은 유지) */
function applyFormat(rcp, fm) {
  rcp.fm = fm;
  const sel = selOf(idsOf(rcp)), home = (S.profile || {}).home;
  const ctx = E.ctxOf(sel, fm, home, D.rec);
  const per = fm === 'TRUST' ? 2.5 : 2.2;
  rcp.it.forEach(function (x, i) {
    if (i > 0 && i < rcp.it.length - 1 && !x.v && !x.dm) x.du = per;
    if (x.v && !x.spm) x.sp = (fm === 'ATTACK' && i === 0) ? 0.5 : 1;
  });
  E.fitLength(rcp.it);
  rcp.it.forEach(function (x) { if (!x.ce) x.c = ''; });   /* 장면 자막은 사람이 고른 것만 */
  if (!rcp.koe) rcp.ko = E.koLine(sel, ctx);
  if (!rcp.tc) {
    const ts = E.titles(fm, ctx, D.rec); const t0 = ts[0];
    if (t0) { rcp.ti = t0.t; rcp.tt = t0.key; if (!rcp.hke) rcp.hk = t0.h; if (!rcp.dee) rcp.de = E.desc(t0, sel, ctx, rcp.sn || nextSn(), rcp.ko); }
  }
  rcp.mq = E.music(fm, ctx.mood);
  rcp.dn = ctx.N || 0;
  if (!rcp.dle) rcp.dl = ctx.N ? 'day ' + ctx.N + ' with my Cavalier' : 'with my Cavalier';
}

/* ---------- SH-02 구성 편집 ---------- */
function openEdit(rcp, o) {
  o = o || {};
  rcp = JSON.parse(JSON.stringify(rcp));
  const el = scrEl('sx-edit');
  const backLbl = U.stack.length ? '쇼츠' : '앨범';
  el.innerHTML = navBar({ back: backLbl, title: '구성 편집', right: '<button type="button" class="sx-nbtn red" data-act="del" style="visibility:hidden;">삭제</button>' }) +
    '<div class="sx-body">' +
    '<div class="sx-pv"><canvas></canvas><div class="pl">' + ICO.play + '</div><div class="ld">불러오는 중…</div><div class="tm">0:00 / 0:00</div><div class="pb"><i></i></div></div>' +
    '<div class="sx-capc" data-act="cap"><div class="hd"><span>영상 자막</span><span class="ed">수정</span></div><div class="cc"></div></div>' +
    '<div class="sx-len"><div class="hd"><b class="lt"></b><span>권장 15~20초</span></div><div class="bar"><div class="ok"></div><div class="kn"></div></div><div class="msg"></div></div>' +
    '<div class="sx-hs sx-fmts">' + E.FMTS.map(function (f) { return '<button type="button" class="sx-chip" data-fm="' + f + '">' + f + '</button>'; }).join('') + '</div>' +
    '<div class="sx-row" style="margin-top:14px;"><span class="sx-h cnt"></span><span class="sx-sub">눌러서 장면 자막·길이</span></div>' +
    '<div class="sx-strip"></div>' +
    '<button type="button" class="sx-add" data-act="add">+ 사진 추가</button>' +
    '<div class="ovw"></div>' +
    '</div><div class="sx-foot"><button type="button" class="sx-btn" data-act="next">다음</button></div>';
  const scr = { el: el, rcp: rcp, player: null };
  const cv = $(el, '.sx-pv canvas');
  function sizeCanvas() {
    const w = Math.max(160, Math.round(($(el, '.sx-pv').getBoundingClientRect().width || 240)));
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.min(540, Math.round(w * dpr)); cv.height = Math.round(cv.width * 16 / 9);
  }
  function onTick(t, total) {
    $(el, '.sx-pv .tm').textContent = mmss(t) + ' / ' + mmss(total);
    $(el, '.sx-pv .pb i').style.width = (total ? Math.min(100, t / total * 100) : 0) + '%';
    $(el, '.sx-pv').classList.toggle('playing', !!(scr.player && scr.player.playing));
  }
  function paintLen() {
    const tot = E.total(rcp.it); rcp.ln = tot;
    $(el, '.sx-len .lt').textContent = '길이 ' + tot.toFixed(1) + '초';
    const MIN = 8, MAX = 26, pos = function (v) { return (Math.max(MIN, Math.min(MAX, v)) - MIN) / (MAX - MIN) * 100; };
    const ok = $(el, '.sx-len .ok'); ok.style.left = pos(15) + '%'; ok.style.width = (pos(20) - pos(15)) + '%';
    const kn = $(el, '.sx-len .kn'); kn.style.left = pos(tot) + '%';
    const out = tot < 15 || tot > 20; kn.classList.toggle('out', out);
    $(el, '.sx-len .msg').textContent = out ? '추천 길이는 15~20초예요. 이대로도 만들 수 있어요.' : '';
  }
  function paintCap() {
    const ctx = ctxFor(rcp);
    $(el, '.sx-capc .cc').innerHTML =
      '<div class="en">' + esc(rcp.hk || '') + '</div>' + meanHTML(rcp.hk, ctx) +
      '<div class="en en2">' + esc(rcp.dl || '') + '</div>' + meanHTML(rcp.dl, ctx) +
      (rcp.it.some(function (x) { return x.c; }) ? '<div class="sx-sub" style="margin-top:6px;">장면 자막 ' + rcp.it.filter(function (x) { return x.c; }).length + '개</div>' : '');
  }
  function paintFmts() {
    $$(el, '[data-fm]').forEach(function (b) { b.classList.toggle('on', b.dataset.fm === rcp.fm); });
    const on = $(el, '[data-fm].on'), row = $(el, '.sx-fmts');
    if (on && row) { const l = on.offsetLeft - 16; if (l < row.scrollLeft || l + on.offsetWidth > row.scrollLeft + row.clientWidth) row.scrollLeft = Math.max(0, l - 8); }
  }
  /* 저장된 초안일 때만 '삭제' (새로 만드는 중이면 뒤로가기로 충분) */
  function paintDel() {
    const r = rcp.rid && D.rec[rcp.rid];
    $(el, '[data-act="del"]').style.visibility = r && r.st !== 'up' ? 'visible' : 'hidden';
  }
  async function delThis() {
    if (scr.player) scr.player.pause();
    const res = await runDelDraft(rcp.rid);
    if (!res) return;
    if (U.stack.some(function (s) { return s.el.classList.contains('sx-home'); })) goHome(res === 'up' ? 'log' : 'rec');
    else back();
  }
  function ovlInfo() {
    const ids = idsOf(rcp), sets = E.usedSets(D.rec);
    const hit = E.overlapIds(ids, sets);
    const o2 = E.overlap(ids, sets);
    const same = !!D.fp[E.fpOf(ids)];
    return { hit: hit, frac: o2.frac, same: same };
  }
  function paintStrip() {
    const ov = ovlInfo();
    $(el, '.cnt').textContent = '구성 ' + rcp.it.length + '개';
    $(el, '.sx-strip').innerHTML = rcp.it.map(function (x, i) {
      return '<div class="sx-it' + (ov.hit.indexOf(x.id) > -1 && scr.showOvl ? ' ovl' : '') + '" data-i="' + i + '"><div class="im"><img class="sx-ph" draggable="false" data-th="' + esc(x.id) + '" alt=""><span class="no">' + (i + 1) + '</span>' +
        (x.c ? '<span class="cp" title="자막">T</span>' : '') + (x.v ? '<span class="vb">▶ 영상' + ((+x.sp || 1) < 1 ? ' ½' : '') + '</span>' : '') + '</div><div class="du">' + fmtSec(x.du) + '</div></div>';
    }).join('');
    thumbsIn($(el, '.sx-strip'));
    const w = $(el, '.ovw');
    if (ov.same) w.innerHTML = '<div class="sx-warn">이 사진 조합은 이미 올렸어요. 사진을 바꾸거나 빼 주세요.</div>';
    else if (ov.hit.length) w.innerHTML = '<div class="sx-warn" data-act="ovl" style="cursor:pointer;">사진 ' + ov.hit.length + '장이 올린 쇼츠와 겹쳐요 · ' + (scr.showOvl ? '표시 끄기' : '보기') + '</div>';
    else w.innerHTML = '';
    $(el, '[data-act="next"]').disabled = ov.same || rcp.it.length < 2;
  }
  function refresh(noPlayer) {
    /* 빠른 줌인은 첫 장(사진)에만 — 순서를 바꿔도 첫 장이 이어받는다(직접 고른 확대 방향은 유지) */
    rcp.it.forEach(function (x, i) { if (i === 0 && !x.v && !x.zm) x.zf = 1; else if (!(i === 0 && x.zf && !x.zm)) delete x.zf; });
    paintCap(); paintLen(); paintFmts(); paintStrip(); paintDel();
    if (!noPlayer && scr.player) { scr.player.set(rcp).then(function () { const ld = $(el, '.sx-pv .ld'); if (ld) ld.style.display = 'none'; }); }
  }
  scr.refresh = refresh;
  scr.destroy = function () { if (scr.player) scr.player.destroy(); };
  scr.resume = function () { refresh(true); };
  el.addEventListener('click', function (e) {
    if (scr.suppress) { scr.suppress = false; return; }
    if (e.target.closest('.sx-pap')) return;
    if (e.target.closest('.sx-pv')) { if (scr.player) scr.player.toggle(); onTick(scr.player ? scr.player.t : 0, scr.player ? scr.player.total() : 0); return; }
    const f = e.target.closest('[data-fm]'); if (f) { if (f.dataset.fm !== rcp.fm) { applyFormat(rcp, f.dataset.fm); refresh(); } return; }
    const it = e.target.closest('.sx-it'); if (it) { itemSheet(scr, +it.dataset.i); return; }
    const a = e.target.closest('[data-act]'); if (!a) return;
    const act = a.dataset.act;
    if (act === 'cap') capSheet(scr);
    else if (act === 'add') openPick(scr);
    else if (act === 'ovl') { scr.showOvl = !scr.showOvl; paintStrip(); }
    else if (act === 'next') goNext();
    else if (act === 'del') delThis();
  });
  async function goNext() {
    if (scr.player) scr.player.pause();
    const ov = ovlInfo();
    if (ov.same) return;
    if (ov.frac * 100 >= C().ovl) {
      const r = await uiSheetOpen({ title: '올린 쇼츠와 사진이 ' + Math.round(ov.frac * 100) + '% 겹쳐요', msg: '같은 사진이 너무 많이 들어가면 비슷한 영상이 돼요.', actions: [{ label: '그래도 만들기' }, { label: '다른 후보 보기' }], cancel: '계속 편집' });
      if (!r || !r.ok) return;
      if (r.idx === 1) { back(); return; }
    }
    if (!rcp.rid) rcp.rid = newRid();
    rcp.st = rcp.st === 'up' ? 'up' : 'draft'; rcp.at = rcp.at || Date.now(); rcp.by = myName() || '';
    rcp.ln = E.total(rcp.it);
    try { await recPut(rcp.rid, stripLocal(rcp)); } catch (er) { toast('초안 저장 실패 — 인터넷 확인'); }
    openFin(scr);
  }
  bindDrag(scr);
  push(scr);
  requestAnimationFrame(function () {
    sizeCanvas();
    scr.player = new R.Player(cv, onTick);
    refresh();
  });
  return scr;
}
function stripLocal(r) { const c = JSON.parse(JSON.stringify(r)); delete c.rid; delete c.key; return c; }

/* 구성 줄 — 꾹 눌러 끌어서 순서 바꾸기 (터치·마우스) */
function bindDrag(scr) {
  const el = scr.el;
  let dg = null;
  function strip() { return $(el, '.sx-strip'); }
  function start(itEl, x, y) {
    const r = itEl.getBoundingClientRect();
    const g = h('<div class="sx-ghost"></div>');
    const im = $(itEl, 'img'); if (im && im.src) g.innerHTML = '<img src="' + im.src + '" style="width:100%;height:100%;object-fit:cover;">';
    document.body.appendChild(g);
    dg.on = true; dg.g = g; dg.dx = x - r.left; dg.dy = y - r.top; dg.from = +itEl.dataset.i; dg.to = dg.from; itEl.classList.add('drag');
    move(x, y);
    try { if (navigator.vibrate) navigator.vibrate(12); } catch (e) { }
  }
  function move(x, y) {
    if (!dg || !dg.on) return;
    dg.g.style.left = (x - dg.dx) + 'px'; dg.g.style.top = (y - dg.dy) + 'px';
    const items = $$(strip(), '.sx-it');
    let to = items.length - 1;
    for (let i = 0; i < items.length; i++) { const r = items[i].getBoundingClientRect(); if (x < r.left + r.width / 2) { to = i; break; } }
    dg.to = to;
    const sr = strip().getBoundingClientRect();
    if (x > sr.right - 30) strip().scrollLeft += 8; else if (x < sr.left + 30) strip().scrollLeft -= 8;
  }
  function end() {
    if (!dg) return;
    const was = dg; dg = null;
    clearTimeout(was.t);
    if (!was.on) return;
    was.g.remove();
    scr.suppress = true; setTimeout(function () { scr.suppress = false; }, 60);
    let to = was.to; if (to > was.from) to--;
    if (to !== was.from && to >= 0) { const a = scr.rcp.it.splice(was.from, 1)[0]; scr.rcp.it.splice(to, 0, a); }
    scr.refresh();
  }
  el.addEventListener('touchstart', function (e) {
    const it = e.target.closest('.sx-it'); if (!it || e.touches.length !== 1) return;
    const t = e.touches[0];
    dg = { x: t.clientX, y: t.clientY, on: false, it: it };
    dg.t = setTimeout(function () { if (dg && !dg.on) start(it, dg.x, dg.y); }, 320);
  }, { passive: true });
  el.addEventListener('touchmove', function (e) {
    if (!dg) return;
    const t = e.touches[0];
    if (!dg.on) { if (Math.abs(t.clientX - dg.x) > 9 || Math.abs(t.clientY - dg.y) > 9) { clearTimeout(dg.t); dg = null; } return; }
    e.preventDefault(); move(t.clientX, t.clientY);
  }, { passive: false });
  el.addEventListener('touchend', function (e) { if (dg && dg.on) e.preventDefault(); end(); });
  el.addEventListener('touchcancel', end);
  el.addEventListener('contextmenu', function (e) { if (e.target.closest('.sx-it')) e.preventDefault(); });
  el.addEventListener('mousedown', function (e) {
    const it = e.target.closest('.sx-it'); if (!it || e.button !== 0) return;
    dg = { x: e.clientX, y: e.clientY, on: false, it: it, mouse: true };
  });
  window.addEventListener('mousemove', function (e) {
    if (!dg || !dg.mouse) return;
    if (!dg.on) { if (Math.abs(e.clientX - dg.x) > 6) start(dg.it, e.clientX, e.clientY); return; }
    move(e.clientX, e.clientY);
  });
  window.addEventListener('mouseup', function () { if (dg && dg.mouse) end(); });
}

/* 항목 시트 — 자막·길이(1.5~3초)·확대 방향·초점·빼기 / 영상은 쓸 구간 */
function itemSheet(scr, i) {
  const rcp = scr.rcp, x = rcp.it[i]; if (!x) return;
  const m = (ALB.meta || {})[x.id] || {};
  const vdur = Math.max(1, +m.dur || 8);
  const ZS = [['in', '확대'], ['out', '축소'], ['l', '왼쪽'], ['r', '오른쪽']];
  const sh = sheet('<h3>' + (i + 1) + '번째 · ' + (x.v ? '영상' : '사진') + '</h3><div class="sx-sub">' + esc(m.d || '') + (m.m ? ' · ' + esc(m.m) : '') + '</div>' +
    '<div class="lbl">장면 자막 — 비워 두면 위쪽 영문 2줄만 나와요</div><input type="text" class="sx-in" data-k="c" maxlength="40" placeholder="없음" value="' + esc(x.c || '') + '"><div class="cm"></div>' +
    sugHTML(E.sceneSug(m, i, rcp.fm, (S.profile || {}).home)) +
    (x.v ?
      '<div class="lbl">쓸 구간 · <b class="vs"></b></div><div class="sx-vstrip"><div class="sg"></div></div>' +
      '<input type="range" class="sx-slider" data-k="ss" min="0" max="' + Math.max(0, vdur - 1).toFixed(1) + '" step="0.1" value="' + (+x.ss || 0) + '">' +
      '<div class="sx-kv"><span>길이</span><b class="dv"></b></div><input type="range" class="sx-slider" data-k="du" min="2" max="5" step="0.1" value="' + x.du + '">' +
      '<label class="sx-set" style="padding:12px 2px;"><span>0.5배속 (슬로모션)</span><input type="checkbox" class="sw" data-k="sp"' + ((+x.sp || 1) < 1 ? ' checked' : '') + '></label>'
      :
      '<div class="sx-kv" style="margin-top:14px;"><span>길이</span><b class="dv"></b></div><input type="range" class="sx-slider" data-k="du" min="1.5" max="3" step="0.1" value="' + x.du + '">') +
    '<div class="lbl">확대 방향</div><div class="sx-mini" data-k="z" style="display:flex;">' + ZS.map(function (z) { return '<button type="button" style="flex:1;" data-z="' + z[0] + '" class="' + (x.z === z[0] ? 'on' : '') + '">' + z[1] + '</button>'; }).join('') + '</div>' +
    (!x.v ? '<div class="lbl">초점 — 세로로 자를 때 가운데 (좌우로 밀기)</div><div class="sx-focus"><img alt=""><div class="fr"></div></div>' : '') +
    '<div class="sx-btns"><button type="button" class="sx-btn gray" data-act="l"' + (i === 0 ? ' disabled' : '') + '>◀ 앞으로</button><button type="button" class="sx-btn gray" data-act="r"' + (i === rcp.it.length - 1 ? ' disabled' : '') + '>뒤로 ▶</button></div>' +
    '<div class="sx-btns" style="margin-top:10px;"><button type="button" class="sx-btn gray" style="color:var(--red-sys);" data-act="del">빼기</button><button type="button" class="sx-btn" data-act="ok">완료</button></div>',
    { onClose: function () { scr.refresh(); } });
  function paintV() {
    const dv = $(sh.el, '.dv'); if (dv) dv.textContent = fmtSec(x.du);
    if (x.v) {
      const used = x.du * (+x.sp || 1);
      if (x.ss + used > vdur) x.ss = Math.max(0, vdur - used);
      const sg = $(sh.el, '.sg'); sg.style.left = (x.ss / vdur * 100) + '%'; sg.style.width = Math.min(100, used / vdur * 100) + '%';
      $(sh.el, '.vs').textContent = x.ss.toFixed(1) + '초 ~ ' + (x.ss + used).toFixed(1) + '초 (원본 ' + mmss(vdur) + ')';
      $(sh.el, '[data-k="ss"]').value = x.ss;
    }
  }
  paintV();
  /* 초점 */
  const fc = $(sh.el, '.sx-focus');
  if (fc) {
    const img = $(fc, 'img'), fr = $(fc, '.fr');
    albImgSrc('full', x.id).then(function (u) { img.src = u; }).catch(function () { fillThumb(img, x.id); });
    function paintF() {
      const W = img.naturalWidth || 3, H = img.naturalHeight || 4;
      const box = fc.getBoundingClientRect(); const bw = box.width || 150, bh = box.height || 200;
      const sc = Math.min(bw / W, bh / H), iw = W * sc, ih = H * sc, ox = (bw - iw) / 2;
      if (W / H >= 0.9) { fr.style.display = 'none'; return; }
      const cw = Math.min(iw, ih * 9 / 16);
      const fx = typeof x.fx === 'number' ? x.fx : 0.5;
      const left = Math.max(0, Math.min(iw - cw, fx * iw - cw / 2));
      fr.style.display = ''; fr.style.left = (ox + left) + 'px'; fr.style.width = cw + 'px'; fr.style.top = ((bh - ih) / 2) + 'px'; fr.style.bottom = ((bh - ih) / 2) + 'px';
    }
    img.onload = paintF; setTimeout(paintF, 60);
    let fd = false;
    function setF(cx) { const r = img.getBoundingClientRect(); const W = img.naturalWidth || 3, H = img.naturalHeight || 4; const sc = Math.min(r.width / W, r.height / H), iw = W * sc, ox = (r.width - iw) / 2; x.fx = Math.max(0, Math.min(1, (cx - r.left - ox) / iw)); paintF(); }
    fc.addEventListener('pointerdown', function (e) { fd = true; setF(e.clientX); try { fc.setPointerCapture(e.pointerId); } catch (er) { } });
    fc.addEventListener('pointermove', function (e) { if (fd) setF(e.clientX); });
    fc.addEventListener('pointerup', function () { fd = false; });
  }
  const ctx0 = ctxFor(rcp);
  function paintCm() { const cm = $(sh.el, '.cm'); if (cm) cm.innerHTML = meanHTML(x.c, ctx0); }
  paintCm();
  sh.el.addEventListener('click', function (e) {
    const sg = e.target.closest('[data-sug]'); if (!sg) return;
    x.c = sg.getAttribute('data-sug'); x.ce = 1;
    const inp = $(sh.el, '[data-k="c"]'); if (inp) inp.value = x.c;
    paintCm();
  });
  sh.el.addEventListener('input', function (e) {
    const k = e.target.dataset.k;
    if (k === 'c') { x.c = e.target.value; x.ce = 1; paintCm(); }
    else if (k === 'du') { x.du = Math.round(+e.target.value * 10) / 10; x.dm = 1; paintV(); }
    else if (k === 'ss') { x.ss = Math.round(+e.target.value * 10) / 10; paintV(); }
  });
  sh.el.addEventListener('change', function (e) { if (e.target.dataset.k === 'sp') { x.sp = e.target.checked ? 0.5 : 1; x.spm = 1; paintV(); } });
  sh.el.addEventListener('click', function (e) {
    const z = e.target.closest('[data-z]'); if (z) { x.z = z.dataset.z; delete x.zf; x.zm = 1; $$(sh.el, '[data-z]').forEach(function (b) { b.classList.toggle('on', b === z); }); return; }
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'ok') sh.close();
    else if (a.dataset.act === 'l' && i > 0) { rcp.it.splice(i - 1, 0, rcp.it.splice(i, 1)[0]); sh.close(); }
    else if (a.dataset.act === 'r' && i < rcp.it.length - 1) { rcp.it.splice(i + 1, 0, rcp.it.splice(i, 1)[0]); sh.close(); }
    else if (a.dataset.act === 'del') { if (rcp.it.length <= 2) { toast('최소 2장은 있어야 해요'); return; } rcp.it.splice(i, 1); sh.close(); }
  });
}

/* 자막 전체 수정 — 위쪽 영문 2줄(뜻 표시) + 장면별 자막(추천 문구·문장에서 고르기) */
function capSheet(scr) {
  const rcp = scr.rcp, ctx = ctxFor(rcp), home = (S.profile || {}).home;
  const sh = sheet('<h3>영상 자막</h3><div class="sx-sub">위쪽 영문 2줄은 모든 장면에 나와요. 장면 자막은 고른 장면에만 들어가요(영문 Poppins · 한글 Jua).</div>' +
    '<div class="lbl">맨 위 큰 자막</div><input type="text" class="sx-in" data-k="hk" maxlength="60" value="' + esc(rcp.hk || '') + '"><div class="m-hk"></div>' +
    '<div class="lbl">둘째 줄</div><input type="text" class="sx-in" data-k="dl" maxlength="60" value="' + esc(rcp.dl || '') + '"><div class="m-dl"></div>' +
    '<div class="lbl">장면 자막 — 비워 두면 없음</div>' + rcp.it.map(function (x, i) {
      return '<div class="sx-scap" data-row="' + i + '"><div class="r1"><div class="th"><img class="sx-ph" data-th="' + esc(x.id) + '" alt=""></div>' +
        '<div class="in"><input type="text" class="sx-in" data-i="' + i + '" maxlength="40" placeholder="' + (i + 1) + '번째 — 없음" value="' + esc(x.c || '') + '"><div class="m-c"></div></div>' +
        '<button type="button" class="sx-lnk" data-tg="' + i + '">추천</button></div><div class="sg"></div></div>';
    }).join('') +
    '<div class="sx-btns"><button type="button" class="sx-btn" data-act="ok">완료</button></div>', { onClose: function () { scr.refresh(); } });
  thumbsIn(sh.el);
  function paintM() {
    $(sh.el, '.m-hk').innerHTML = meanHTML(rcp.hk, ctx);
    $(sh.el, '.m-dl').innerHTML = meanHTML(rcp.dl, ctx);
    $$(sh.el, '.sx-scap').forEach(function (row) { const i = +row.dataset.row; $(row, '.m-c').innerHTML = meanHTML(rcp.it[i].c, ctx); });
  }
  paintM();
  sh.el.addEventListener('input', function (e) {
    const t = e.target;
    if (t.dataset.k === 'hk') { rcp.hk = t.value; rcp.hke = 1; }
    else if (t.dataset.k === 'dl') { rcp.dl = t.value; rcp.dle = 1; }
    else if (t.dataset.i !== undefined) { const x = rcp.it[+t.dataset.i]; x.c = t.value; x.ce = 1; }
    paintM();
  });
  sh.el.addEventListener('click', function (e) {
    const tg = e.target.closest('[data-tg]');
    if (tg) {
      const i = +tg.dataset.tg, box = $(sh.el, '.sx-scap[data-row="' + i + '"] .sg');
      if (box.innerHTML) { box.innerHTML = ''; tg.textContent = '추천'; return; }
      box.innerHTML = sugHTML(E.sceneSug((ALB.meta || {})[rcp.it[i].id] || {}, i, rcp.fm, home)); tg.textContent = '닫기'; return;
    }
    const sg = e.target.closest('[data-sug]');
    if (sg) {
      const row = sg.closest('.sx-scap'); if (!row) return;
      const i = +row.dataset.row, x = rcp.it[i];
      x.c = sg.getAttribute('data-sug'); x.ce = 1;
      $(row, '[data-i]').value = x.c; paintM(); return;
    }
    if (e.target.closest('[data-act="ok"]')) sh.close();
  });
}

/* 사진 추가 — 앨범에서 고르기 (쿨다운 사진은 회색) */
function openPick(edit) {
  const rcp = edit.rcp, have = {}; idsOf(rcp).forEach(function (id) { have[id] = 1; });
  const c = C(), td = today();
  const ids = Object.keys(ALB.meta || {}).filter(function (id) { return E.usable(ALB.meta[id]); }).sort(function (a, b) { return (ALB.meta[b].at || 0) - (ALB.meta[a].at || 0); });
  const el = scrEl();
  const pick = {};
  el.innerHTML = navBar({ back: '편집', title: '사진 추가', right: '<button type="button" class="sx-nbtn" data-act="done" style="font-weight:600;">추가</button>' }) +
    '<div class="sx-body"><p class="sx-sub" style="margin:4px 2px 12px;">회색은 쉬는 중(최근 ' + c.cool + '일 안에 쓴 사진)이에요. 골라도 되지만 겹침 경고가 떠요.</p><div class="sx-grid">' +
    ids.map(function (id) {
      const m = ALB.meta[id]; const cool = E.inCool(m, c, td) || E.maxed(m, c);
      return '<div class="sx-gc' + (have[id] ? ' on' : '') + (cool ? ' cool' : '') + '" data-id="' + esc(id) + '"' + (have[id] ? ' data-have="1"' : '') + '><img class="sx-ph" data-th="' + esc(id) + '" loading="lazy" alt=""><span class="ck"></span>' + (E.isClip(m) ? '<span class="vd">▶ ' + (m.dur ? mediaDur(m.dur) : '영상') + '</span>' : '') + (m.su ? '<span class="u">' + m.su + '회</span>' : '') + '</div>';
    }).join('') + '</div></div>';
  const scr = { el: el };
  el.addEventListener('click', function (e) {
    const gc = e.target.closest('.sx-gc');
    if (gc) { if (gc.dataset.have) { toast('이미 들어간 사진이에요'); return; } const id = gc.dataset.id; if (pick[id]) delete pick[id]; else pick[id] = 1; gc.classList.toggle('on', !!pick[id]); const n = Object.keys(pick).length; $(el, '[data-act="done"]').textContent = n ? '추가 (' + n + ')' : '추가'; return; }
    if (e.target.closest('[data-act="done"]')) {
      const add = ids.filter(function (id) { return pick[id]; });
      if (add.length) {
        const per = rcp.fm === 'TRUST' ? 2.5 : 2.2;
        const items = selOf(add).map(function (x) { return E.itemOf(x, E.isClip(x.m) ? 2.5 : per, 'in'); });
        const at = Math.max(1, rcp.it.length - 1);
        Array.prototype.splice.apply(rcp.it, [at, 0].concat(items));
      }
      back();
    }
  });
  push(scr);
  /* 화면에 보이는 칸만 썸네일 */
  const io = ('IntersectionObserver' in window) ? new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) { io.unobserve(en.target); fillThumb(en.target, en.target.getAttribute('data-th')); } }); }, { root: el, rootMargin: '300px' }) : null;
  $$(el, 'img[data-th]').forEach(function (im) { if (io) io.observe(im); else fillThumb(im, im.getAttribute('data-th')); });
}

/* ---------- SH-03 마무리 (A) ---------- */
function setKo(rcp, v) {
  const old = rcp.ko || '';
  rcp.ko = v; rcp.koe = 1;
  if (!rcp.dee) { const ctx = ctxFor(rcp); const t = E.titles(rcp.fm, ctx, D.rec).filter(function (x) { return x.t === rcp.ti; })[0] || { t: rcp.ti, d: '' }; rcp.de = E.desc(t, selOf(idsOf(rcp)), ctx, rcp.sn || nextSn(), v); return; }
  const lines = String(rcp.de || '').split('\n');
  const i = old ? lines.indexOf(old) : -1;
  if (i > -1) { if (v) lines[i] = v; else { lines.splice(i, 1); if (lines[i] === '' && lines[i - 1] === '') lines.splice(i, 1); } }
  else if (v) lines.splice(Math.min(3, lines.length), 0, v, '');   /* 템플릿 자리: 영문 두 줄 + 빈 줄 다음 */
  rcp.de = lines.join('\n');
}
/* 설명의 영문 두 줄(첫 줄 · 영문 훅) 뜻 */
function descMean(de, ctx) {
  const ls = String(de || '').split('\n').slice(0, 2).map(function (x) { return x.trim(); }).filter(function (x) { return x && !R.HANGUL.test(x); });
  if (!ls.length) return '';
  return '<div class="sx-mean">영문 줄 뜻 · ' + ls.map(function (x) { const m = E.meaning(x, ctx); return m ? esc(m) : '<a class="sx-pap" href="' + esc(E.papago(x)) + '" target="_blank" rel="noopener">파파고</a>'; }).join(' / ') + '</div>';
}
function mqChips(list, ctx) {
  return (list || []).map(function (q) { const k = E.meaning(q, ctx); return '<button type="button" class="sx-chip soft" data-copy="' + esc(q) + '">' + esc(q) + (k ? '<span class="k">' + esc(k) + '</span>' : '') + '</button>'; }).join('');
}
function nextSn() { return E.snPick(C().nsn, D.rec, C().fsn).sn; }   /* '영상 만들기' 때 받을 번호(미리 보기) */
function openFin(edit) {
  const rcp = edit.rcp;
  if (!rcp.sn) rcp.de = E.descSn(rcp.de, nextSn());   /* 끝줄 번호는 미리 보여 주고, 확정은 '영상 만들기' 때 */
  const el = scrEl('sx-fin');
  const scr = { el: el, open: false, koOpen: false };
  function paint() {
    const ctx = ctxFor(rcp);
    const ts = E.titles(rcp.fm, ctx, D.rec);
    const custom = !ts.some(function (t) { return t.t === rcp.ti; });
    const kl = E.koLines(selOf(idsOf(rcp)), ctx);
    el.innerHTML = navBar({ back: '편집', title: '마무리' }) + '<div class="sx-body">' +
      '<div class="sx-seg"><button type="button" class="on">직접 올리기</button><button type="button" data-act="auto">자동 올리기</button></div>' +
      '<div class="sx-row" style="margin-bottom:6px;"><span class="sx-sub" style="font-size:14px;">제목</span><button type="button" class="sx-lnk" data-act="own">직접 쓰기</button></div>' +
      '<div class="sx-card" style="padding:0;">' + ts.map(function (t, i) { return '<div class="sx-opt' + (rcp.ti === t.t ? ' on' : '') + '" data-t="' + i + '"><span class="sx-rad"></span><span class="tx">' + esc(t.t) + '<span class="sx-mean">뜻 · ' + esc(t.kt) + '</span></span></div>'; }).join('') +
      (custom ? '<div class="sx-opt on"><span class="sx-rad"></span><span class="tx">' + esc(rcp.ti) + meanHTML(rcp.ti, ctx) + '</span></div>' : '') + '</div>' +
      '<div class="sx-card" style="padding:12px 14px;"><div class="sx-sub" style="font-size:13px;">영상 맨 위 자막</div><div style="font-weight:700;margin-top:2px;">' + esc(rcp.hk || '') + '</div>' + meanHTML(rcp.hk, ctx) +
      '<div style="font-weight:600;margin-top:6px;font-size:14.5px;">' + esc(rcp.dl || '') + '</div>' + meanHTML(rcp.dl, ctx) + '</div>' +
      '<div class="sx-row" style="margin-bottom:6px;"><span class="sx-sub" style="font-size:14px;">설명의 한글 한 줄</span><button type="button" class="sx-lnk" data-act="kotg">' + (scr.koOpen ? '닫기' : '바꾸기') + '</button></div>' +
      '<div class="sx-card" style="padding:12px 14px;"><div style="font-size:15.5px;">' + (rcp.ko ? esc(rcp.ko) : '<span class="sx-sub">없음</span>') + '</div>' +
      (scr.koOpen ? '<div class="sx-sg"><span class="t">추천 문구</span><div class="sx-chips">' + kl.p.map(function (x) { return '<button type="button" class="sx-chip sm" data-ko="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div></div>' +
        '<div class="sx-sg"><span class="t">추천 문장</span><div class="sx-chips">' + kl.s.map(function (x) { return '<button type="button" class="sx-chip sm" data-ko="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div></div>' +
        (kl.memo.length ? '<div class="sx-sg"><span class="t">사진 메모</span><div class="sx-chips">' + kl.memo.map(function (x) { return '<button type="button" class="sx-chip sm" data-ko="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div></div>' : '') +
        '<div class="sx-sg"><div class="sx-chips"><button type="button" class="sx-chip sm" data-act="kown">직접 쓰기</button><button type="button" class="sx-chip sm" data-ko="">없음</button></div></div>' : '') + '</div>' +
      '<div class="sx-row" style="margin-bottom:6px;"><span class="sx-sub" style="font-size:14px;">설명</span></div>' +
      '<div class="sx-card">' + (scr.open ? '<textarea class="sx-ta" rows="7" data-k="de">' + esc(rcp.de || '') + '</textarea>' : '<div class="sx-desc fold">' + esc(rcp.de || '') + '</div>') +
      descMean(rcp.de, ctx) +
      '<div style="text-align:right;"><button type="button" class="sx-lnk" data-act="fold">' + (scr.open ? '접기' : '펼치기') + '</button></div></div>' +
      '<div class="sx-row" style="margin-bottom:6px;"><span class="sx-sub" style="font-size:14px;">음악</span></div>' +
      '<div class="sx-card" style="padding:14px 16px;"><div style="font-size:17px;font-weight:700;">유튜브 앱에서 고를 곡</div><div class="sx-sub" style="margin:2px 0 10px;">누르면 검색어가 복사돼요</div><div class="sx-chips">' + mqChips(rcp.mq, ctx) + '</div></div>' +
      '<p class="sx-sub" style="margin:4px 6px 0;">음악은 유튜브 앱의 사운드에서 넣어요. 인기곡도 쓸 수 있어요.</p>' +
      '</div><div class="sx-foot"><button type="button" class="sx-btn" data-act="make">영상 만들기</button></div>';
  }
  el.addEventListener('input', function (e) { if (e.target.dataset.k === 'de') { rcp.de = e.target.value; rcp.dee = 1; } });
  el.addEventListener('click', async function (e) {
    if (e.target.closest('.sx-pap')) return;
    const cp = e.target.closest('[data-copy]'); if (cp) { copyText(cp.dataset.copy); toast('복사했어요: ' + cp.dataset.copy); return; }
    const ko = e.target.closest('[data-ko]'); if (ko) { setKo(rcp, ko.getAttribute('data-ko')); paint(); return; }
    const o = e.target.closest('[data-t]');
    if (o) {
      const ctx = ctxFor(rcp); const t = E.titles(rcp.fm, ctx, D.rec)[+o.dataset.t];
      if (t) { rcp.ti = t.t; rcp.tt = t.key; rcp.tc = 0; if (!rcp.hke) rcp.hk = t.h; if (!rcp.dee) rcp.de = E.desc(t, selOf(idsOf(rcp)), ctx, rcp.sn || nextSn(), rcp.ko); }
      paint(); return;
    }
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'auto') { uiAlert('자동 올리기는 첫 설정이 필요해요.\n다음 업데이트(V6.6)에서 열려요. 지금은 직접 올리기로 만들어요.'); return; }
    if (a.dataset.act === 'kotg') { scr.koOpen = !scr.koOpen; paint(); return; }
    if (a.dataset.act === 'kown') { const v = await uiPrompt('설명의 한글 한 줄', rcp.ko || ''); if (v !== null) { setKo(rcp, v.trim()); paint(); } return; }
    if (a.dataset.act === 'own') {
      const v = await uiPrompt('제목 (영문 권장)', rcp.ti || '');
      if (v === null || !v.trim()) return;
      rcp.ti = v.trim(); rcp.tt = ''; rcp.tc = 1;
      if (!rcp.hke) rcp.hk = rcp.ti.length <= 40 ? rcp.ti : rcp.ti.slice(0, 38) + '…';
      paint(); return;
    }
    if (a.dataset.act === 'fold') { scr.open = !scr.open; paint(); return; }
    if (a.dataset.act === 'make') {
      a.disabled = true;
      try { await reserveSn(rcp); await recPut(rcp.rid, stripLocal(rcp)); }
      catch (er) { a.disabled = false; uiAlert('저장하지 못했어요 — 인터넷 확인 후 다시 시도해 주세요.'); return; }
      openMake(rcp, edit);
      setTimeout(function () { a.disabled = false; }, 600);
    }
  });
  scr.resume = paint;
  push(scr); paint();
}

/* ---------- SH-04 만드는 중 ---------- */
function openMake(rcp, edit) {
  const el = scrEl();
  const nV = rcp.it.filter(function (x) { return x.v; }).length, nP = rcp.it.length - nV;
  el.innerHTML = '<div class="sx-mk"><div class="sx-ring"><svg viewBox="0 0 200 200"><circle class="bgc" cx="100" cy="100" r="86"/><circle class="fgc" cx="100" cy="100" r="86" stroke-dasharray="540.4" stroke-dashoffset="540.4"/></svg><b>0%</b></div>' +
    '<h2>영상 만드는 중</h2><div class="sx-sub" style="font-size:15px;">' + (nV ? '영상 ' + nV + ' · ' : '') + '사진 ' + nP + '장 · ' + Math.round(E.total(rcp.it)) + '초 · 1080×1920</div>' +
    '<div class="sx-steps"><div class="s0 now"><i></i>사진 준비<span>0%</span></div><div class="s1"><i></i>영상 만들기<span></span></div><div class="s2 off"><i></i>저장소로 보내기<span>자동 올리기만</span></div></div>' +
    '<div class="warn">화면을 끄거나 닫지 마세요</div><div class="err"></div><div style="flex:1;"></div>' +
    '<button type="button" class="sx-lnk" data-act="cancel" style="font-size:17px;font-weight:600;">취소</button></div>';
  const ctl = new AbortController();
  const scr = { el: el, ctl: ctl, busy: true };
  let wl = null;
  function setP(p) { const v = Math.round(p * 100); $(el, '.sx-ring b').textContent = v + '%'; $(el, '.fgc').setAttribute('stroke-dashoffset', String(540.4 * (1 - p))); }
  function onProg(o) {
    if (o.step === 0) { $(el, '.s0 span').textContent = Math.round(o.p * 100) + '%'; setP(o.p * 0.15); }
    else { const s0 = $(el, '.s0'); s0.className = 's0 done'; $(el, '.s0 span').textContent = '완료'; const s1 = $(el, '.s1'); s1.className = 's1 now'; $(el, '.s1 span').textContent = Math.round(o.p * 100) + '%'; setP(0.15 + o.p * 0.85); }
  }
  function onVis() { if (document.visibilityState === 'hidden' && scr.busy) { scr.hidden = true; ctl.abort(); } }
  document.addEventListener('visibilitychange', onVis);
  scr.destroy = function () { scr.busy = false; try { ctl.abort(); } catch (e) { } document.removeEventListener('visibilitychange', onVis); try { if (wl) wl.release(); } catch (e) { } };
  scr.onBack = function () {
    if (!scr.busy) return true;
    uiConfirm({ title: '만들기를 멈출까요?', msg: '지금까지 만든 부분은 남지 않아요.', ok: '멈추기', destr: true }).then(function (ok) { if (ok) { try { ctl.abort(); } catch (e) { } scr.busy = false; back(); } });
    return false;
  };
  el.addEventListener('click', function (e) {
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'cancel') { scr.busy = false; try { ctl.abort(); } catch (er) { } back(); }
    else if (a.dataset.act === 'retry') { back(); setTimeout(function () { openMake(rcp, edit); }, 420); }
  });
  push(scr);
  (async function () {
    try { if (navigator.wakeLock) wl = await navigator.wakeLock.request('screen'); } catch (e) { }
    try {
      const out = await R.make(rcp, { onProg: onProg, signal: ctl.signal });
      if (!scr.busy) return;
      scr.busy = false;
      rcp.st = 'draft'; rcp.mk = Date.now();
      try { await recPut(rcp.rid, stripLocal(rcp)); } catch (e) { }
      replaceTop(upScreen(rcp, out));
    } catch (e) {
      scr.busy = false;
      if (e && e.name === 'AbortError') {
        if (scr.hidden) { $(el, '.warn').textContent = '화면이 꺼져서 만들기가 멈췄어요.'; $(el, '.err').innerHTML = '<p class="sx-sub" style="margin:8px 0 14px;text-align:center;">처음부터 다시 만들어요.</p><button type="button" class="sx-btn" data-act="retry">다시 만들기</button>'; }
        return;
      }
      $(el, '.warn').textContent = e && e.code === 'nosupport' ? e.message : '만들지 못했어요';
      $(el, '.err').innerHTML = (e && e.code === 'nosupport' ? '' : '<p class="sx-sub" style="margin:8px 0 14px;text-align:center;">' + esc(String(e && e.message || e)) + '</p><button type="button" class="sx-btn" data-act="retry">다시 시도</button>');
    } finally { try { if (wl) wl.release(); } catch (e) { } wl = null; }
  })();
}
function replaceTop(scr) {
  const old = U.stack.pop();
  if (old) { try { if (old.destroy) old.destroy(); } catch (e) { } old.el.remove(); }
  scr.h = old ? old.h : false;
  U.stack.push(scr);
  root().appendChild(scr.el);
  scr.el.classList.add('noanim', 'on');
  bindBack(scr);
  setTimeout(function () { scr.el.classList.remove('noanim'); }, 50);
}

/* ---------- SH-05A 직접 올리기 안내 ---------- */
function upScreen(rcp, out) {
  const el = scrEl();
  const file = new File([out.blob], 'bbaekkom_' + (rcp.sn || 'shorts') + '.mp4', { type: 'video/mp4' });
  const url = URL.createObjectURL(out.blob);
  el.innerHTML = navBar({ title: '직접 올리기', right: '<button type="button" class="sx-nbtn mute" data-act="later">나중에</button>' }) +
    '<div class="sx-body"><div class="sx-done"><div class="th"><video src="' + url + '" muted playsinline loop autoplay></video></div><div><div style="font-size:21px;font-weight:800;">영상이 준비됐어요</div>' +
    '<div class="sx-sub" style="font-size:15px;margin-top:3px;">' + esc(rcp.ti) + '</div>' + meanHTML(rcp.ti, ctxFor(rcp)) + '<div class="sx-sub" style="margin-top:3px;">' + Math.round(out.dur) + '초 · ' + (out.hasAudio ? '영상 원본 소리 포함 · 음악은 유튜브 앱에서' : '음악 없음 (유튜브 앱에서 추가)') + ' · ' + (out.blob.size / 1048576).toFixed(1) + 'MB' + (out.fps && out.fps !== 60 ? ' · ' + out.fps + 'fps(이 폰 한계)' : '') + '</div></div></div>' +
    '<div class="sx-card" style="padding:4px 16px;">' +
    '<div class="sx-st"><span class="n">1</span><div class="b"><div class="h">유튜브로 보내기</div><div class="sx-sub">누르면 제목이 자동으로 복사돼요</div><button type="button" class="sx-btn" style="margin-top:10px;" data-act="share">유튜브로 보내기</button></div></div>' +
    '<div class="sx-st"><span class="n">2</span><div class="b"><div class="h">유튜브에서 ‘사운드’를 눌러 검색</div><div class="sx-chips" style="margin-top:9px;">' + mqChips(rcp.mq, ctxFor(rcp)) + '</div><div class="sx-sub" style="margin-top:7px;">누르면 검색어가 복사돼요</div></div></div>' +
    '<div class="sx-st"><span class="n">3</span><div class="b"><div class="h">‘다음’ → 제목 붙여넣기 → 업로드</div><div class="sx-chips" style="margin-top:9px;"><button type="button" class="sx-chip soft" data-act="cpt">제목 다시 복사</button><button type="button" class="sx-chip soft" data-act="cpd">설명 복사</button></div></div></div>' +
    '</div><div style="text-align:center;"><button type="button" class="sx-lnk" data-act="save">유튜브가 안 보이면 사진에 저장</button></div></div>' +
    '<div class="sx-foot"><button type="button" class="sx-btn soft" data-act="done">올렸어요</button></div>';
  const scr = { el: el };
  scr.destroy = function () { try { URL.revokeObjectURL(url); } catch (e) { } };
  function saveFile() {
    const ios = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    if (ios && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file] }).catch(function () { }); return; }
    const a = document.createElement('a'); a.href = url; a.download = file.name; document.body.appendChild(a); a.click(); a.remove();
    toast('사진 앱(다운로드)에 저장했어요. 유튜브 앱에서 이 영상을 골라 주세요.');
  }
  el.addEventListener('click', async function (e) {
    if (e.target.closest('.sx-pap')) return;
    const cp = e.target.closest('[data-copy]'); if (cp) { copyText(cp.dataset.copy); toast('복사했어요: ' + cp.dataset.copy); return; }
    const a = e.target.closest('[data-act]'); if (!a) return;
    const act = a.dataset.act;
    if (act === 'share') {
      copyText(rcp.ti);
      if (navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: rcp.ti }).catch(function () { }); toast('제목을 복사했어요. 공유 메뉴에서 유튜브를 고르세요.'); }
      else { saveFile(); }
      return;
    }
    if (act === 'cpt') { copyText(rcp.ti); toast('제목을 복사했어요'); return; }
    if (act === 'cpd') { copyText(rcp.de); toast('설명을 복사했어요'); return; }
    if (act === 'save') { saveFile(); return; }
    if (act === 'later') { rcp.st = 'draft'; try { await recPut(rcp.rid, stripLocal(rcp)); } catch (er) { } toast('초안으로 보관했어요 (14일)'); goHome('rec'); return; }
    if (act === 'done') {
      a.disabled = true;
      try { await markUp(rcp); toast('기록했어요 — 빼꼼 #' + rcp.sn); goHome('log'); }
      catch (er) { a.disabled = false; uiAlert('기록하지 못했어요 — 인터넷 확인 후 다시 눌러 주세요.'); }
    }
  });
  return scr;
}
/* 쇼츠 홈으로 — 아래에 홈이 있으면 거기까지 닫고, 없으면 새로 연다 */
function goHome(tab) {
  const i = U.stack.findIndex(function (s) { return s.el.classList.contains('sx-home'); });
  if (i > -1) { const home = U.stack[i]; home.tab = tab; popTo(i + 1); setTimeout(function () { try { home.paint(); } catch (e) { } }, 30); }
  else { popTo(0); setTimeout(function () { openHome(tab); }, 420); }
}
/* 올렸어요 — 지문 저장 · 사진 사용 횟수 · 시리즈 번호 확정 */
async function markUp(rcp) {
  const rid = rcp.rid;
  const r = stripLocal(rcp);
  r.st = 'up'; r.up = Date.now(); r.mo = 'A'; r.by = myName() || '';
  r.fp = E.fpOf(idsOf(rcp));
  await recPut(rid, r);
  await shFetch('fp/' + r.fp, 'PUT', r.sn || 0); D.fp[r.fp] = r.sn || 0;
  const up = {}, td = today();
  rcp.it.forEach(function (x) { const m = (ALB.meta || {})[x.id]; if (!m || up[x.id + '/su']) return; const su = (m.su || 0) + 1; up[x.id + '/su'] = su; up[x.id + '/sl'] = td; m.su = su; m.sl = td; });
  if (Object.keys(up).length) { await albFetch('meta', 'PATCH', JSON.stringify(up)); await albBumpIdx(); }
  if ((+C().nsn || 1) <= (r.sn || 0)) await cfgSet('nsn', r.sn + 1);
  RC.recs = null;
  try { renderAlbum(); } catch (e) { }
}

/* ---------- 바깥에서 여는 길 ---------- */
async function ensure() {
  if (!syncConfigured()) { uiAlert('설정에서 동기화를 먼저 켜주세요.'); return false; }
  try { await dLoad(); return true; }
  catch (e) { uiAlert('쇼츠 기록을 불러오지 못했어요. 인터넷 확인 후 다시 시도해 주세요.'); return false; }
}
async function fromIds(ids) {
  if (!(await ensure())) return;
  const sel = selOf(ids);
  if (sel.length < 2) { toast('2장 이상 골라 주세요'); return; }
  const f = E.fmtOf(sel).fm || 'PHOTOS';
  const r = E.draft(sel, f, { home: (S.profile || {}).home, today: today(), recipes: D.rec, keepAll: true, src: 'pick' });
  openEdit(r);
}
async function fromPhoto(id) {
  if (!(await ensure())) return;
  const b = E.bundleFrom(id, ALB.meta || {}, C(), today());
  if (b.length < 2) { toast('같이 묶을 사진이 부족해요'); return; }
  const f = E.fmtOf(b).fm || 'PHOTOS';
  const r = E.draft(b, f, { home: (S.profile || {}).home, today: today(), recipes: D.rec, firstId: id, src: 'photo' });
  openEdit(r);
}
async function badge() {
  if (!syncConfigured()) return 0;
  try { await dLoad(); } catch (e) { return 0; }
  const r = computeRecs(false) || [];
  return (RC.info && RC.info.newCount >= 5) ? r.length : 0;
}
window.SHORTS = {
  v: SXV,
  open: async function (tab) { if (await ensure()) openHome(tab); },
  fromIds: fromIds,
  fromPhoto: fromPhoto,
  tagSheet: function (ids, o) { const p = tagSheet(ids, o); setTimeout(function () { idxHashes(ids); }, 1500); return p; },
  badge: badge,
  onPop: onPop,
  isOpen: function () { return U.stack.length > 0; },
  caps: function () { return R.caps(); },
  _E: E, _R: R, _D: D, _RC: RC, _markUp: markUp, _recPut: recPut, _newRid: newRid
};

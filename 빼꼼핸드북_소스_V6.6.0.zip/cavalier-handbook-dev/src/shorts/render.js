/* ================= 영상 합성·인코딩 (12-2·12-6) =================
   1080×1920 · 60fps · H.264(+AAC: 영상 클립 원본 소리, 기기가 AAC 인코딩을 지원할 때만).
   사진: 세로는 화면 꽉 채움(초점 fx·fy), 가로는 흐린 배경 위 가운데. 켄번즈 + 크로스페이드 0.35초.
   자막: 영문 Poppins ExtraBold · 한글 Jua, 흰색 + 검은 테두리, 상단. 폰 브라우저에서 직접 만든다. */
const R = { W: 1080, H: 1920, FPS: 60, BR: 8000000, XF: 0.35, TOPY: 250 };
R.HANGUL = /[ㄱ-ㆎ가-힣]/;
R.easeOut = function (p) { return 1 - Math.pow(1 - p, 3); };
R.clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

/* ---------- 서체 ---------- */
R.fontP = null;
R.loadFonts = function () {
  if (R.fontP) return R.fontP;
  R.fontP = new Promise(function (res) {
    let done = false; const fin = function () { if (!done) { done = true; res(true); } };
    try {
      let l = document.getElementById('sxFontCss');
      const go = function () {
        if (!document.fonts || !document.fonts.load) return fin();
        Promise.all([document.fonts.load('800 80px Poppins', 'Aa'), document.fonts.load('80px Jua', '가나')]).then(fin, fin);
      };
      if (!l) {
        l = document.createElement('link'); l.id = 'sxFontCss'; l.rel = 'stylesheet';
        l.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@800&family=Jua&display=swap';
        l.onload = go; l.onerror = fin; document.head.appendChild(l);
      } else go();
    } catch (e) { fin(); }
    setTimeout(fin, 7000);
  });
  return R.fontP;
};
/* 구글 폰트는 한글을 글자 묶음(조각)별로 나눠 받는다 → 실제로 쓸 글자를 미리 받아 둔다 */
R.ensureGlyphs = function (texts) {
  if (!document.fonts || !document.fonts.load) return Promise.resolve();
  const jobs = [];
  (texts || []).forEach(function (t) { t = String(t || '').trim(); if (!t) return; jobs.push(document.fonts.load(R.fontOf(t, 60), t).catch(function () { })); });
  return Promise.race([Promise.all(jobs), new Promise(function (r) { setTimeout(r, 5000); })]);
};
R.textsOf = function (rcp) { return [rcp.hk, rcp.dl].concat((rcp.it || []).map(function (x) { return x.c; })); };
R.fontsOK = function () { try { return document.fonts.check('800 40px Poppins') && document.fonts.check('40px Jua', '가') ? 1 : 0; } catch (e) { return 0; } };
R.fontOf = function (txt, px) {
  return R.HANGUL.test(txt) ? (px + 'px Jua, "Apple SD Gothic Neo", "Noto Sans KR", sans-serif') : ('800 ' + px + 'px Poppins, "Helvetica Neue", Arial, sans-serif');
};
/* 줄바꿈 — 영문은 단어, 한글은 어절 단위(넘치면 글자 단위) */
R.wrap = function (g, txt, maxW, maxLines) {
  const words = String(txt || '').split(/\s+/).filter(Boolean), lines = [];
  let cur = '';
  words.forEach(function (w) {
    const t = cur ? cur + ' ' + w : w;
    if (g.measureText(t).width <= maxW || !cur) {
      if (!cur && g.measureText(w).width > maxW) {   /* 한 단어가 너무 길면 글자 단위 */
        let part = '';
        Array.from(w).forEach(function (ch) { if (g.measureText(part + ch).width > maxW && part) { lines.push(part); part = ch; } else part += ch; });
        cur = part;
      } else cur = t;
    } else { lines.push(cur); cur = w; }
  });
  if (cur) lines.push(cur);
  if (lines.length > maxLines) { const keep = lines.slice(0, maxLines); keep[maxLines - 1] = keep[maxLines - 1].replace(/.{0,2}$/, '…'); return keep; }
  /* 두 줄이면 줄 길이를 고르게 (한 단어만 아래로 떨어지지 않게) */
  if (lines.length === 2 && words.length >= 3) {
    let best = null;
    for (let k = 1; k < words.length; k++) {
      const a = words.slice(0, k).join(' '), b = words.slice(k).join(' ');
      const wa = g.measureText(a).width, wb = g.measureText(b).width;
      if (wa > maxW || wb > maxW) continue;
      const m = Math.max(wa, wb);
      if (!best || m < best.m) best = { m: m, l: [a, b] };
    }
    if (best) return best.l;
  }
  return lines;
};
/* 흰 글씨 + 검은 테두리 텍스트를 미리 그려 둔 레이어(캔버스) */
R.TL = new Map();
R.textLayer = function (blocks) {   /* 같은 글자·크기는 다시 그리지 않음 (최근 40개) */
  let ok = 1; try { blocks.forEach(function (b) { if (b.t && !document.fonts.check(R.fontOf(b.t, b.px), b.t)) ok = 0; }); } catch (e) { ok = 0; }
  const key = JSON.stringify(blocks) + '|' + ok;   /* 글자가 늦게 도착하면 다시 그림 */
  if (R.TL.has(key)) { const v = R.TL.get(key); R.TL.delete(key); R.TL.set(key, v); return v; }
  const v = R.textLayer0(blocks);
  R.TL.set(key, v);
  if (R.TL.size > 40) { const k0 = R.TL.keys().next().value; const o = R.TL.get(k0); R.TL.delete(k0); if (o && o.c) { o.c.width = 0; o.c.height = 0; } }
  return v;
};
R.textLayer0 = function (blocks) {   /* blocks: [{t, px, gap}] → {c, h} */
  const W = R.W, padX = 80, maxW = W - padX * 2;
  const tmp = document.createElement('canvas').getContext('2d');
  const rows = []; let h = 0;
  blocks.forEach(function (b) {
    if (!b.t || !String(b.t).trim()) return;
    tmp.font = R.fontOf(b.t, b.px);
    const ls = R.wrap(tmp, b.t, maxW, b.max || 2);
    ls.forEach(function (ln, i) { rows.push({ t: ln, px: b.px, y: h + b.px * 1.08 * i + b.px }); });
    h += b.px * 1.08 * ls.length + (b.gap || 10);
  });
  if (!rows.length) return null;
  const c = document.createElement('canvas'); c.width = W; c.height = Math.ceil(h + 30);
  const g = c.getContext('2d');
  g.textAlign = 'center'; g.textBaseline = 'alphabetic'; g.lineJoin = 'round'; g.miterLimit = 2;
  rows.forEach(function (r) {
    g.font = R.fontOf(r.t, r.px);
    g.lineWidth = R.HANGUL.test(r.t) ? Math.max(5, r.px * 0.12) : Math.max(6, r.px * 0.17); g.strokeStyle = '#000';
    g.shadowColor = 'rgba(0,0,0,.35)'; g.shadowBlur = r.px * 0.12; g.shadowOffsetY = r.px * 0.04;
    g.strokeText(r.t, W / 2, r.y + 6);
    g.shadowColor = 'transparent'; g.fillStyle = '#fff';
    g.fillText(r.t, W / 2, r.y + 6);
  });
  return { c: c, h: c.height };
};
R.layers = function (rcp) {
  const top = R.textLayer([{ t: rcp.hk, px: 82, max: 2, gap: 14 }, { t: rcp.dl, px: 46, max: 1, gap: 0 }]);
  const caps = rcp.it.map(function (x) { return x.c ? R.textLayer([{ t: x.c, px: 60, max: 3 }]) : null; });
  return { top: top, caps: caps };
};

/* ---------- 원본 준비 ---------- */
/* 흐린 배경 — 90×160으로 줄여 상자 흐림 3번(가우스 근사) → 270×480. 그릴 때 4배 확대 (canvas filter 없는 사파리도 같은 결과) */
R.blurBg = function (src, w, h) {
  const SW = 90, SH = 160;
  const a = document.createElement('canvas'); a.width = SW; a.height = SH;
  const ga = a.getContext('2d'); ga.imageSmoothingEnabled = true; ga.imageSmoothingQuality = 'high';
  R.cover(ga, src, w, h, SW, SH, 0.5, 0.5, 1);
  try {
    const id = ga.getImageData(0, 0, SW, SH);
    for (let i = 0; i < 3; i++) R.blur2(id.data, SW, SH, 5);
    ga.putImageData(id, 0, 0);
  } catch (e) { }
  const b = document.createElement('canvas'); b.width = 270; b.height = 480;
  const g = b.getContext('2d'); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
  g.drawImage(a, 0, 0, 270, 480);
  g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(0, 0, 270, 480);
  a.width = a.height = 0;
  return b;
};
/* 가로·세로 상자 흐림 1회 */
R.blur2 = function (d, W, H, r) {
  const t = new Float32Array(W * H * 4), win = r * 2 + 1;
  for (let y = 0; y < H; y++) {
    for (let c = 0; c < 4; c++) {
      let acc = 0;
      for (let k = -r; k <= r; k++) acc += d[(y * W + Math.min(W - 1, Math.max(0, k))) * 4 + c];
      for (let x = 0; x < W; x++) {
        t[(y * W + x) * 4 + c] = acc / win;
        acc += d[(y * W + Math.min(W - 1, x + r + 1)) * 4 + c] - d[(y * W + Math.max(0, x - r)) * 4 + c];
      }
    }
  }
  for (let x = 0; x < W; x++) {
    for (let c = 0; c < 4; c++) {
      let acc = 0;
      for (let k = -r; k <= r; k++) acc += t[(Math.min(H - 1, Math.max(0, k)) * W + x) * 4 + c];
      for (let y = 0; y < H; y++) {
        d[(y * W + x) * 4 + c] = acc / win;
        acc += t[(Math.min(H - 1, y + r + 1) * W + x) * 4 + c] - t[(Math.max(0, y - r) * W + x) * 4 + c];
      }
    }
  }
};
R.cover = function (g, src, w, h, W, H, fx, fy, k) {
  const base = Math.max(W / w, H / h) * (k || 1);
  const dw = w * base, dh = h * base;
  const x = R.clamp(W / 2 - fx * dw, W - dw, 0), y = R.clamp(H / 2 - fy * dh, H - dh, 0);
  g.drawImage(src, x, y, dw, dh);
};
R.loadPhoto = async function (id) {
  const url = await albImgSrc('full', id);
  const r = await fetch(url); if (!r.ok) throw new Error('사진 HTTP ' + r.status);
  const bl = await r.blob();
  const bmp = await createImageBitmap(bl);
  return { kind: 'img', src: bmp, w: bmp.width, h: bmp.height, bg: (bmp.width / bmp.height >= 0.9) ? R.blurBg(bmp, bmp.width, bmp.height) : null };
};
R.hiddenBox = function () {
  let b = document.getElementById('sxVidBox');
  if (!b) { b = document.createElement('div'); b.id = 'sxVidBox'; b.setAttribute('aria-hidden', 'true'); b.style.cssText = 'position:fixed;left:0;top:0;width:2px;height:2px;overflow:hidden;opacity:0.01;pointer-events:none;z-index:-1;'; document.body.appendChild(b); }
  return b;
};
R.makeVideo = function (src) {
  const v = document.createElement('video');
  v.muted = true; v.defaultMuted = true; v.playsInline = true; v.setAttribute('playsinline', ''); v.setAttribute('muted', '');
  v.preload = 'auto'; v.crossOrigin = 'anonymous'; v.width = 2; v.height = 2;
  v.src = src; R.hiddenBox().appendChild(v);
  return v;
};
R.waitMeta = function (v, ms) {
  return new Promise(function (res, rej) {
    if (v.readyState >= 1 && v.videoWidth) return res();
    const to = setTimeout(function () { cl(); rej(new Error('영상 정보를 읽지 못했어요')); }, ms || 20000);
    const ok = function () { if (v.videoWidth) { cl(); res(); } };
    const bad = function () { cl(); rej(new Error('이 영상은 이 폰에서 열 수 없어요')); };
    function cl() { clearTimeout(to); v.removeEventListener('loadedmetadata', ok); v.removeEventListener('loadeddata', ok); v.removeEventListener('error', bad); }
    v.addEventListener('loadedmetadata', ok); v.addEventListener('loadeddata', ok); v.addEventListener('error', bad);
    try { const p = v.play(); if (p && p.then) p.then(function () { v.pause(); }, function () { }); } catch (e) { }   /* 아이폰: 재생을 한 번 걸어야 불러온다 */
  });
};
R.seekTo = function (v, t) {
  return new Promise(function (res) {
    if (Math.abs(v.currentTime - t) < 0.002 && v.readyState >= 2) return res();
    let done = false, seeked = false, framed = !('requestVideoFrameCallback' in v);
    const fin = function () { if (done) return; done = true; v.removeEventListener('seeked', onS); clearTimeout(to); res(); };
    const onS = function () { seeked = true; if (framed) fin(); else setTimeout(fin, 120); };
    if (!framed) { try { v.requestVideoFrameCallback(function () { framed = true; if (seeked) fin(); }); } catch (e) { framed = true; } }
    v.addEventListener('seeked', onS);
    const to = setTimeout(fin, 3000);
    try { v.currentTime = t; } catch (e) { fin(); }
  });
};
/* 영상 원본 받기 — 소리를 쓰거나 빠른 탐색을 위해. 150MB 넘으면 받지 않고 스트리밍 */
R.MAXDL = 150 * 1048576;
R.loadClip = async function (id, m, o) {
  o = o || {};
  const url = mediaApi('/file/' + m.k);
  let src = url, buf = null, blobUrl = '';
  if (o.download && (!m.vs || m.vs <= R.MAXDL)) {
    try {
      const r = await fetch(url, { signal: o.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const total = +r.headers.get('content-length') || m.vs || 0;
      let got = 0; const parts = [];
      if (r.body && r.body.getReader) {
        const rd = r.body.getReader();
        for (; ;) { const x = await rd.read(); if (x.done) break; parts.push(x.value); got += x.value.length; if (o.onProg && total) o.onProg(got / total); }
      } else { parts.push(new Uint8Array(await r.arrayBuffer())); }
      const bl = new Blob(parts, { type: m.ct || 'video/mp4' });
      blobUrl = URL.createObjectURL(bl); src = blobUrl;
      if (o.audio) { try { buf = await bl.arrayBuffer(); } catch (e) { buf = null; } }
    } catch (e) { if (e && e.name === 'AbortError') throw e; src = url; }
  }
  const v = R.makeVideo(src);
  await R.waitMeta(v, 25000);
  const s = { kind: 'vid', src: v, w: v.videoWidth, h: v.videoHeight, dur: isFinite(v.duration) ? v.duration : (+m.dur || 0), blobUrl: blobUrl, ab: buf, bg: null };
  if (s.w / s.h >= 0.9) {
    try { await R.seekTo(v, Math.min(0.5, (s.dur || 1) / 2)); s.bg = R.blurBg(v, s.w, s.h); } catch (e) { s.bg = null; }
  }
  return s;
};
R.release = function (srcs) {
  (srcs || []).forEach(function (s) {
    if (!s) return;
    try { if (s.kind === 'img' && s.src && s.src.close) s.src.close(); } catch (e) { }
    try { if (s.bg) { s.bg.width = 0; s.bg.height = 0; s.bg = null; } } catch (e) { }
    if (s.kind === 'vid') { try { s.src.pause(); s.src.removeAttribute('src'); s.src.load(); s.src.remove(); } catch (e) { } if (s.blobUrl) { try { URL.revokeObjectURL(s.blobUrl); } catch (e) { } } }
  });
};

/* ---------- 한 장면 그리기 ---------- */
R.drawItem = function (g, s, it, p, alpha) {
  if (!s || alpha <= 0) return;
  const W = R.W, H = R.H;
  p = R.clamp(p, 0, 1);
  let k = 1;
  if (it.zf) k = 1 + 0.18 * R.easeOut(p);
  else if (it.z === 'out') k = 1.09 - 0.08 * p;
  else if (it.z === 'in') k = 1.01 + 0.08 * p;
  else k = 1.07;
  let dx = 0;
  if (it.z === 'l') dx = (0.5 - p) * 0.05 * W; else if (it.z === 'r') dx = (p - 0.5) * 0.05 * W;
  g.globalAlpha = alpha;
  const w = s.w, h = s.h;
  if (!w || !h) { g.globalAlpha = 1; return; }
  if (w / h >= 0.9) {
    /* 가로·정사각: 흐린 배경 + 원본 가운데(가로 꽉) */
    if (s.bg) g.drawImage(s.bg, 0, 0, W, H); else { g.fillStyle = '#111'; g.fillRect(0, 0, W, H); }
    const k2 = 1 + (k - 1) * 0.5;
    const dw = W * k2, dh = dw * h / w;
    g.drawImage(s.src, (W - dw) / 2 + dx * 0.3, (H - dh) / 2, dw, dh);
  } else {
    const fx = typeof it.fx === 'number' ? it.fx : 0.5, fy = typeof it.fy === 'number' ? it.fy : 0.45;
    const base = Math.max(W / w, H / h) * k;
    const dw = w * base, dh = h * base;
    const x = R.clamp(W / 2 - fx * dw + dx, W - dw, 0), y = R.clamp(H / 2 - fy * dh, H - dh, 0);
    g.drawImage(s.src, x, y, dw, dh);
  }
  g.globalAlpha = 1;
};
/* 시간표: 각 항목의 시작·끝 */
R.timeline = function (it) {
  let t = 0;
  return it.map(function (x) { const s = t; t += +x.du || 0; return { s: s, e: t }; });
};
R.at = function (tl, t) { for (let i = 0; i < tl.length; i++) { if (t < tl[i].e) return i; } return tl.length - 1; };
/* 프레임 t초 — 지금 장면 + (끝나기 0.35초 전부터) 다음 장면 크로스페이드 + 자막 */
R.drawFrame = function (g, rcp, srcs, lay, tl, t) {
  const W = R.W, H = R.H, it = rcp.it;
  g.globalAlpha = 1; g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const i = R.at(tl, t);
  const cur = tl[i];
  R.drawItem(g, srcs[i], it[i], (t - cur.s) / Math.max(0.01, cur.e - cur.s), 1);
  let a = 0;
  if (i + 1 < it.length && t > cur.e - R.XF) {
    a = R.clamp((t - (cur.e - R.XF)) / R.XF, 0, 1);
    const nx = tl[i + 1];
    R.drawItem(g, srcs[i + 1], it[i + 1], (t - nx.s) / Math.max(0.01, nx.e - nx.s), a);
  }
  if (lay) {
    const total = tl.length ? tl[tl.length - 1].e : 0;
    const ta = R.clamp(t / 0.3, 0, 1) * R.clamp((total - t) / 0.25 + 0.2, 0, 1);
    let y = R.TOPY;
    if (lay.top) { g.globalAlpha = ta; g.drawImage(lay.top.c, 0, y); y += lay.top.h + 10; }
    const c1 = lay.caps[i], c2 = lay.caps[i + 1];
    if (c1) { g.globalAlpha = (1 - a) * R.clamp((t - cur.s) / 0.25, 0, 1); g.drawImage(c1.c, 0, y); }
    if (c2 && a > 0) { g.globalAlpha = a; g.drawImage(c2.c, 0, y); }
    g.globalAlpha = 1;
  }
};
/* 프레임 t초에 보여야 하는 영상 장면의 원본 시각 */
R.vidTime = function (x, seg, t, s) {
  const sp = +x.sp || 1;
  let vt = (+x.ss || 0) + Math.max(0, t - seg.s) * sp;
  const dur = (s && s.dur) || 0;
  if (dur) vt = Math.min(vt, Math.max(0, dur - 0.05));
  return vt;
};

/* ---------- 기기 지원 확인 ---------- */
R.CODECS = ['avc1.64002A', 'avc1.640033', 'avc1.4D002A', 'avc1.4D0033', 'avc1.42002A', 'avc1.420033'];
/* 1080×1920 60fps가 기본. 기기 인코더가 세로 크기를 못 받으면 가로(1920×1080)로 눕혀 만들고 회전 정보(90°)를 붙인다 — 재생·유튜브에서는 세로로 보임.
   60fps가 안 되는 기기만 30fps. */
R.ATTEMPTS = [{ w: 1080, h: 1920, fps: 60, rot: 0 }, { w: 1920, h: 1080, fps: 60, rot: 90 }, { w: 1080, h: 1920, fps: 30, rot: 0 }, { w: 1920, h: 1080, fps: 30, rot: 90 }];
R.FORCE = null;   /* 테스트용: {rot:90} 등 */
R.pickCodec = async function () {
  if (typeof VideoEncoder === 'undefined' || typeof VideoFrame === 'undefined') return null;
  const hws = ['prefer-hardware', 'no-preference'];
  for (let a = 0; a < R.ATTEMPTS.length; a++) {
    const at = R.ATTEMPTS[a];
    if (R.FORCE && Object.keys(R.FORCE).some(function (k) { return R.FORCE[k] !== at[k]; })) continue;
    for (let h = 0; h < hws.length; h++) {
      for (let i = 0; i < R.CODECS.length; i++) {
        const cfg = { codec: R.CODECS[i], width: at.w, height: at.h, framerate: at.fps, bitrate: R.BR, hardwareAcceleration: hws[h], avc: { format: 'avc' } };
        try { const s = await VideoEncoder.isConfigSupported(cfg); if (s && s.supported) return { cfg: cfg, fps: at.fps, rot: at.rot }; } catch (e) { }
      }
    }
  }
  return null;
};
R.AC = { enc: 'mp4a.40.2', mux: 'aac' };   /* AAC (유튜브 권장) */
R.audioOk = async function () {
  if (typeof AudioEncoder === 'undefined' || typeof AudioData === 'undefined' || typeof OfflineAudioContext === 'undefined') return false;
  try { const s = await AudioEncoder.isConfigSupported({ codec: R.AC.enc, sampleRate: 48000, numberOfChannels: 2, bitrate: 128000 }); return !!(s && s.supported); } catch (e) { return false; }
};
R.caps = async function () { const c = await R.pickCodec(); return { video: !!c, codec: c && c.cfg.codec, fps: c && c.fps, rot: c && c.rot, audio: c ? await R.audioOk() : false }; };

/* ---------- 원본 소리 섞기 (영상 클립, 1배속 구간만) ---------- */
R.mixAudio = async function (rcp, srcs, tl) {
  const SR = 48000, total = tl[tl.length - 1].e;
  const len = Math.ceil(total * SR);
  const dec = new OfflineAudioContext(2, SR, SR);
  const ctx = new OfflineAudioContext(2, len, SR);
  let any = false;
  for (let i = 0; i < rcp.it.length; i++) {
    const x = rcp.it[i], s = srcs[i];
    if (!x.v || !s || !s.ab || (+x.sp || 1) !== 1) continue;
    let ab = null;
    try { ab = await dec.decodeAudioData(s.ab.slice(0)); } catch (e) { ab = null; }
    s.ab = null;
    if (!ab) continue;
    const st = tl[i].s, du = tl[i].e - tl[i].s, off = +x.ss || 0;
    if (off >= ab.duration) continue;
    const src = ctx.createBufferSource(); src.buffer = ab;
    const gn = ctx.createGain();
    gn.gain.setValueAtTime(0, st); gn.gain.linearRampToValueAtTime(1, st + 0.08);
    gn.gain.setValueAtTime(1, Math.max(st + 0.08, st + du - 0.12)); gn.gain.linearRampToValueAtTime(0, st + du);
    src.connect(gn); gn.connect(ctx.destination);
    src.start(st, off, Math.min(du, ab.duration - off));
    any = true;
  }
  if (!any) return null;
  return await ctx.startRendering();
};
R.encodeAudio = async function (buf) {   /* → [[chunk, meta], …] (실패하면 throw) */
  const SR = 48000, len = buf.length, CH = 2, out = [];
  let err = null;
  const enc = new AudioEncoder({ output: function (c, m) { out.push([c, m]); }, error: function (e) { err = e; } });
  enc.configure({ codec: R.AC.enc, sampleRate: SR, numberOfChannels: CH, bitrate: 128000 });
  const L = buf.getChannelData(0), Rr = buf.numberOfChannels > 1 ? buf.getChannelData(1) : L;
  const STEP = 4096;
  for (let off = 0; off < len; off += STEP) {
    const n = Math.min(STEP, len - off);
    const data = new Float32Array(n * CH);
    data.set(L.subarray(off, off + n), 0); data.set(Rr.subarray(off, off + n), n);
    const ad = new AudioData({ format: 'f32-planar', sampleRate: SR, numberOfFrames: n, numberOfChannels: CH, timestamp: Math.round(off / SR * 1e6), data: data });
    enc.encode(ad); ad.close();
    if (err) throw err;
    while (enc.encodeQueueSize > 16) await new Promise(function (r) { setTimeout(r, 0); });
  }
  await enc.flush(); enc.close();
  if (err) throw err;
  if (!out.length) throw new Error('no audio');
  return out;
};

/* ---------- 영상 만들기 ---------- */
R.make = async function (rcp, o) {
  o = o || {};
  const prog = o.onProg || function () { };
  const sig = o.signal || { aborted: false };
  const chk = function () { if (sig.aborted) { const e = new Error('취소'); e.name = 'AbortError'; throw e; } };
  const pk = await R.pickCodec();
  if (!pk) { const e = new Error('이 폰에서는 영상을 만들 수 없어요. iOS를 업데이트하거나 다른 기기에서 열어 주세요.'); e.code = 'nosupport'; throw e; }
  const cfg = pk.cfg, FPS = pk.fps;
  const wantAudio = rcp.it.some(function (x) { return x.v && (+x.sp || 1) === 1; }) && await R.audioOk();
  await R.loadFonts();
  await R.ensureGlyphs(R.textsOf(rcp));
  const tl = R.timeline(rcp.it), total = tl.length ? tl[tl.length - 1].e : 0;
  const srcs = [];
  let encV = null;
  try {
    /* 1) 사진 준비 */
    prog({ step: 0, p: 0 });
    const n = rcp.it.length;
    for (let i = 0; i < n; i++) {
      chk();
      const x = rcp.it[i], m = (ALB.meta || {})[x.id];
      if (!m) throw new Error('앨범에서 사라진 사진이 있어요 (' + (i + 1) + '번째)');
      if (x.v) srcs.push(await R.loadClip(x.id, m, { download: true, audio: wantAudio, signal: o.signal, onProg: function (p) { prog({ step: 0, p: (i + p) / n }); } }));
      else srcs.push(await R.loadPhoto(x.id));
      prog({ step: 0, p: (i + 1) / n });
    }
    const lay = R.layers(rcp);
    chk();
    /* 2) 소리 */
    let audioBuf = null;
    if (wantAudio) { try { audioBuf = await R.mixAudio(rcp, srcs, tl); } catch (e) { audioBuf = null; } }
    let achunks = null;
    if (audioBuf) { try { achunks = await R.encodeAudio(audioBuf); } catch (e) { achunks = null; } }
    const target = new Mp4Muxer.ArrayBufferTarget();
    const mux = new Mp4Muxer.Muxer({
      target: target,
      video: { codec: 'avc', width: cfg.width, height: cfg.height, frameRate: FPS, rotation: pk.rot || 0 },
      audio: achunks ? { codec: R.AC.mux, sampleRate: 48000, numberOfChannels: 2 } : undefined,
      fastStart: 'in-memory', firstTimestampBehavior: 'offset'
    });
    const hasAudio = !!achunks;
    if (achunks) achunks.forEach(function (a) { mux.addAudioChunk(a[0], a[1]); });
    /* 3) 영상 만들기 */
    const cv = document.createElement('canvas'); cv.width = R.W; cv.height = R.H;
    const g = cv.getContext('2d', { alpha: false });
    g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
    let cv2 = null, g2 = null;
    if (pk.rot === 90) {   /* 세로 화면을 왼쪽으로 눕혀 담기 — 재생 때 시계 방향 90° 회전 */
      cv2 = document.createElement('canvas'); cv2.width = cfg.width; cv2.height = cfg.height;
      g2 = cv2.getContext('2d', { alpha: false }); g2.setTransform(0, -1, 1, 0, 0, R.W);
    }
    let verr = null;
    encV = new VideoEncoder({ output: function (c, m) { mux.addVideoChunk(c, m); }, error: function (e) { verr = e; } });
    encV.configure(cfg);
    const N = Math.round(total * FPS), dt = 1e6 / FPS;
    const lastQ = {};
    for (let f = 0; f < N; f++) {
      chk(); if (verr) throw verr;
      const t = f / FPS;
      const i = R.at(tl, t);
      const vis = [i]; if (i + 1 < n && t > tl[i].e - R.XF) vis.push(i + 1);
      for (let k = 0; k < vis.length; k++) {
        const j = vis[k], x = rcp.it[j], s = srcs[j];
        if (!x.v || !s) continue;
        const step = (+x.sp || 1) < 1 ? 60 : 30;
        const q = Math.round(R.vidTime(x, tl[j], t, s) * step) / step;
        if (lastQ[j] !== q) { await R.seekTo(s.src, q); lastQ[j] = q; }
      }
      R.drawFrame(g, rcp, srcs, lay, tl, t);
      if (g2) g2.drawImage(cv, 0, 0);
      const fr = new VideoFrame(g2 ? cv2 : cv, { timestamp: Math.round(f * dt), duration: Math.round(dt) });
      encV.encode(fr, { keyFrame: f % (FPS * 2) === 0 }); fr.close();
      while (encV.encodeQueueSize > 6) { await new Promise(function (r) { setTimeout(r, 0); }); if (verr) throw verr; }
      if (f % 6 === 0) prog({ step: 1, p: f / N });
    }
    await encV.flush(); encV.close(); encV = null;
    if (verr) throw verr;
    mux.finalize();
    cv.width = 0; cv.height = 0; if (cv2) { cv2.width = 0; cv2.height = 0; }
    prog({ step: 1, p: 1 });
    const blob = new Blob([target.buffer], { type: 'video/mp4' });
    return { blob: blob, hasAudio: hasAudio, dur: total, codec: cfg.codec, frames: N, fps: FPS, rot: pk.rot || 0 };
  } finally {
    try { if (encV && encV.state !== 'closed') encV.close(); } catch (e) { }
    R.release(srcs);
  }
};

/* ---------- 미리보기 (저해상도, 실시간) ---------- */
R.Player = function (canvas, onTick) {
  this.cv = canvas; this.g = canvas.getContext('2d'); this.onTick = onTick || function () { };
  this.rcp = null; this.srcs = []; this.lay = null; this.tl = []; this.t = 0; this.playing = false; this.raf = 0; this.t0 = 0; this.gen = 0; this.cache = {};
};
R.Player.prototype.set = async function (rcp) {
  const gen = ++this.gen;
  this.rcp = JSON.parse(JSON.stringify(rcp));
  this.tl = R.timeline(this.rcp.it);
  this.t = Math.min(this.t, this.total());
  await R.loadFonts();
  await R.ensureGlyphs(R.textsOf(this.rcp));
  if (gen !== this.gen) return;
  this.lay = R.layers(this.rcp);
  const self = this, need = {};
  this.srcs = this.rcp.it.map(function (x) { need[x.id] = 1; return self.cache[x.id] || null; });
  this.draw();
  for (let i = 0; i < this.rcp.it.length; i++) {
    const x = this.rcp.it[i];
    if (this.cache[x.id]) continue;
    try {
      const m = (ALB.meta || {})[x.id]; if (!m) continue;
      const s = x.v ? await R.loadClip(x.id, m, { download: false }) : await R.loadPhoto(x.id);
      this.cache[x.id] = s;
    } catch (e) { this.cache[x.id] = null; }
    if (gen !== this.gen) return;
    this.srcs = this.rcp.it.map(function (y) { return self.cache[y.id] || null; });
    if (!this.playing) this.draw();
  }
  Object.keys(this.cache).forEach(function (id) { if (!need[id]) { R.release([self.cache[id]]); delete self.cache[id]; } });
};
R.Player.prototype.total = function () { return this.tl.length ? this.tl[this.tl.length - 1].e : 0; };
R.Player.prototype.draw = function () {
  const g = this.g, sc = this.cv.width / R.W;
  g.setTransform(sc, 0, 0, sc, 0, 0);
  if (!this.rcp || !this.tl.length) { g.fillStyle = '#222'; g.fillRect(0, 0, R.W, R.H); return; }
  const srcs = this.srcs.map(function (s) { return s; });
  R.drawFrame(g, this.rcp, srcs.map(function (s) { return s || null; }), this.lay, this.tl, Math.min(this.t, this.total() - 0.001));
  this.onTick(this.t, this.total());
};
R.Player.prototype.syncVideos = function () {
  const t = this.t, i = R.at(this.tl, t), self = this;
  this.rcp.it.forEach(function (x, j) {
    const s = self.srcs[j]; if (!x.v || !s) return;
    const v = s.src;
    const active = self.playing && (j === i || (j === i + 1 && t > self.tl[i].e - R.XF));
    if (active) {
      const want = R.vidTime(x, self.tl[j], t, s);
      if (Math.abs(v.currentTime - want) > 0.25) { try { v.currentTime = want; } catch (e) { } }
      v.playbackRate = +x.sp || 1;
      if (v.paused) { const p = v.play(); if (p && p.catch) p.catch(function () { }); }
    } else {
      if (!v.paused) v.pause();
      if (!self.playing) { const want = R.vidTime(x, self.tl[j], Math.max(t, self.tl[j].s), s); if (Math.abs(v.currentTime - want) > 0.05) { try { v.currentTime = want; } catch (e) { } } }
    }
  });
};
R.Player.prototype.play = function () {
  if (this.playing || !this.rcp) return;
  if (this.t >= this.total() - 0.05) this.t = 0;
  this.playing = true; this.t0 = performance.now() - this.t * 1000;
  const self = this;
  const loop = function (now) {
    if (!self.playing) return;
    self.t = (now - self.t0) / 1000;
    if (self.t >= self.total()) { self.t = self.total(); self.pause(); self.draw(); return; }
    self.syncVideos(); self.draw();
    self.raf = requestAnimationFrame(loop);
  };
  this.raf = requestAnimationFrame(loop);
};
R.Player.prototype.pause = function () { this.playing = false; cancelAnimationFrame(this.raf); this.syncVideos(); };
R.Player.prototype.toggle = function () { if (this.playing) this.pause(); else this.play(); };
R.Player.prototype.seek = function (t) { this.t = R.clamp(t, 0, this.total()); if (this.playing) this.t0 = performance.now() - this.t * 1000; this.syncVideos(); this.draw(); };
R.Player.prototype.destroy = function () { this.pause(); this.gen++; const c = this.cache; R.release(Object.keys(c).map(function (k) { return c[k]; })); this.cache = {}; this.srcs = []; };

/* ---------- 이미지 지문(dHash) — 연사 묶기용 ---------- */
R.dhash = async function (url) {
  const r = await fetch(url); const bl = await r.blob(); const bmp = await createImageBitmap(bl);
  const c = document.createElement('canvas'); c.width = 9; c.height = 8;
  const g = c.getContext('2d'); g.drawImage(bmp, 0, 0, 9, 8); try { bmp.close(); } catch (e) { }
  const d = g.getImageData(0, 0, 9, 8).data;
  let hex = '', nib = 0, nb = 0;
  for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
    const a = (y * 9 + x) * 4, b = (y * 9 + x + 1) * 4;
    const la = d[a] * 0.299 + d[a + 1] * 0.587 + d[a + 2] * 0.114, lb = d[b] * 0.299 + d[b + 1] * 0.587 + d[b + 2] * 0.114;
    nib = (nib << 1) | (la > lb ? 1 : 0); nb++;
    if (nb === 4) { hex += nib.toString(16); nib = 0; nb = 0; }
  }
  return hex;
};

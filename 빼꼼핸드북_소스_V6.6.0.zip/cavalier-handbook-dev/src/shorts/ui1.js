/* ================= 쇼츠 화면 — 공통(스타일·데이터·화면 쌓기) ================= */
const CSS = `
#sxRoot{position:fixed; inset:0; z-index:95; pointer-events:none;}
body.sx-open{overflow:hidden;}
.sx-scr{position:absolute; inset:0; background:var(--bg); color:var(--label); overflow-y:auto; -webkit-overflow-scrolling:touch; overscroll-behavior:contain; pointer-events:auto;
  transform:translateX(104%); transition:transform .34s cubic-bezier(.2,.9,.3,1); box-shadow:-8px 0 24px rgba(0,0,0,.08); padding-bottom:calc(28px + env(safe-area-inset-bottom));}
.sx-scr.on{transform:none;}
.sx-scr.under{transform:translateX(-22%); transition:transform .34s cubic-bezier(.2,.9,.3,1);}
.sx-scr.noanim{transition:none;}
@media (prefers-reduced-motion: reduce){ .sx-scr, .sx-scr.under{transition:none;} }
.sx-nav{position:sticky; top:0; z-index:5; display:flex; align-items:center; justify-content:space-between; gap:8px;
  min-height:calc(48px + env(safe-area-inset-top)); padding:calc(4px + env(safe-area-inset-top)) 10px 4px;
  background:var(--glass-bar); -webkit-backdrop-filter:saturate(180%) blur(20px); backdrop-filter:saturate(180%) blur(20px);}
.sx-nav.line{border-bottom:.5px solid var(--sep);}
.sx-back, .sx-nbtn{display:flex; align-items:center; gap:1px; background:none; border:none; color:var(--tint); font-family:inherit; font-size:17px; padding:8px 6px; cursor:pointer; min-height:40px;}
.sx-back svg{width:22px; height:22px; fill:none; stroke:currentColor; stroke-width:2.4; stroke-linecap:round; stroke-linejoin:round; margin-left:-4px;}
.sx-nbtn svg{width:25px; height:25px; fill:none; stroke:currentColor; stroke-width:1.8; stroke-linecap:round; stroke-linejoin:round;}
.sx-nbtn.mute{color:var(--label2);}
.sx-ttl{position:absolute; left:50%; transform:translateX(-50%); font-size:17px; font-weight:600; white-space:nowrap; pointer-events:none; bottom:12px;}
.sx-big{font-size:34px; font-weight:800; letter-spacing:-.03em; line-height:1.15; margin:2px 0 14px;}
.sx-body{padding:4px 16px 0; max-width:640px; margin:0 auto;}
.sx-seg{display:flex; background:var(--fill2); border-radius:11px; padding:2px; margin:0 0 16px; position:relative;}
.sx-seg button{flex:1; border:none; background:none; font-family:inherit; font-size:14.5px; font-weight:600; padding:8px 0; border-radius:9px; color:var(--label); cursor:pointer; position:relative; z-index:1;}
.sx-seg button.on{background:var(--card); box-shadow:0 2px 8px rgba(0,0,0,.12);}
.sx-seg button:disabled{color:var(--label3);}
.sx-row{display:flex; align-items:center; justify-content:space-between; gap:10px; margin:4px 2px 10px;}
.sx-h{font-size:17px; font-weight:700; letter-spacing:-.01em;}
.sx-lnk{background:none; border:none; color:var(--tint); font-family:inherit; font-size:15px; font-weight:500; cursor:pointer; padding:6px 2px;}
.sx-lnk:disabled{color:var(--label3);}
.sx-card{background:var(--card); border-radius:20px; padding:12px; margin-bottom:12px;}
.sx-sub{font-size:13px; color:var(--label2); line-height:1.45;}
.sx-sec{font-size:13px; color:var(--label2); margin:18px 6px 7px; letter-spacing:.01em;}
.sx-btn{display:block; width:100%; border:none; border-radius:15px; padding:15px; font-family:inherit; font-size:17px; font-weight:600; background:var(--tint-btn,var(--tint)); color:#fff; cursor:pointer;}
.sx-btn:disabled{background:var(--fill2); color:var(--label3); cursor:default;}
.sx-btn.soft{background:var(--tint-fill); color:var(--tint-ink);}
.sx-btn.gray{background:var(--fill2); color:var(--label);}
.sx-btn.sm{display:inline-block; width:auto; padding:9px 18px; font-size:15px; border-radius:999px;}
.sx-edit .sx-foot, .sx-fin .sx-foot{position:static; background:none;}
.sx-foot{position:sticky; bottom:0; padding:12px 16px calc(12px + env(safe-area-inset-bottom)); background:linear-gradient(transparent, var(--bg) 30%); max-width:640px; margin:0 auto; z-index:4;}
.sx-chip{display:inline-flex; align-items:center; gap:4px; border:1px solid var(--sep); background:var(--card); color:var(--label); border-radius:999px; padding:7px 14px; font-family:inherit; font-size:15px; cursor:pointer; white-space:nowrap;}
.sx-chip.on{background:var(--tint-btn,var(--tint)); border-color:transparent; color:#fff;}
.sx-chip.soft{background:var(--tint-fill); border-color:transparent; color:var(--tint-ink);}
.sx-chips{display:flex; flex-wrap:wrap; gap:8px;}
.sx-hs{display:flex; gap:8px; overflow-x:auto; -webkit-overflow-scrolling:touch; scrollbar-width:none; padding:2px 16px 4px; margin:0 -16px;}
.sx-hs::-webkit-scrollbar{display:none;}
.sx-badge{display:inline-block; font-size:12px; font-weight:700; letter-spacing:.02em; padding:3px 9px; border-radius:999px; background:var(--tint-fill); color:var(--tint-ink);}
.sx-badge.gray{background:var(--fill2); color:var(--label2);}
.sx-new{color:var(--green); font-size:14px; font-weight:500;}
.sx-warn{background:var(--amber-bg); color:var(--warn-ink); border-radius:14px; padding:11px 13px; font-size:14px; line-height:1.45; margin:10px 0;}
.sx-note{background:var(--tint-fill); color:var(--tint-ink); border-radius:14px; padding:11px 13px; font-size:14px; line-height:1.45; margin:10px 0;}
.sx-empty{text-align:center; color:var(--label2); font-size:15px; line-height:1.55; padding:26px 12px;}
.sx-ph{background:var(--fill2); display:block; width:100%; height:100%; object-fit:cover; opacity:0; transition:opacity .25s;}
.sx-ph.ld{opacity:1;}
/* 추천 카드 */
.sx-rec{display:flex; gap:14px; background:var(--card); border-radius:22px; padding:12px; margin-bottom:12px; cursor:pointer;}
.sx-rec .cv{position:relative; flex:0 0 112px; height:200px; border-radius:14px; overflow:hidden; background:var(--fill2);}
.sx-rec .cv .len{position:absolute; right:7px; bottom:7px; background:rgba(0,0,0,.55); color:#fff; font-size:12.5px; font-weight:600; border-radius:8px; padding:2px 7px;}
.sx-rec .bd{flex:1; min-width:0; display:flex; flex-direction:column; gap:6px; padding:2px 0;}
.sx-rec .tg{display:flex; align-items:center; gap:7px; flex-wrap:wrap; font-size:13px; color:var(--label2);}
.sx-rec .tt{font-size:19px; font-weight:700; line-height:1.25; letter-spacing:-.01em; word-break:break-word;}
.sx-rec .in{font-size:14px; color:var(--label2);}
.sx-rec .go{margin-top:auto; align-self:flex-start;}
.sx-draft{display:flex; align-items:center; gap:12px; padding:10px 4px; border-bottom:.5px solid var(--sep); cursor:pointer;}
.sx-draft:last-child{border-bottom:none;}
.sx-draft .th{flex:0 0 44px; height:62px; border-radius:9px; overflow:hidden; background:var(--fill2);}
.sx-draft .tx{flex:1; min-width:0;}
.sx-draft .t1{font-size:15.5px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
/* 기록 */
.sx-list{background:var(--card); border-radius:20px; overflow:hidden; margin-bottom:12px;}
.sx-li{display:flex; align-items:center; gap:13px; padding:12px 14px; cursor:pointer; position:relative;}
.sx-li + .sx-li::before{content:""; position:absolute; top:0; left:86px; right:0; border-top:.5px solid var(--sep);}
.sx-li .th{flex:0 0 58px; height:82px; border-radius:10px; overflow:hidden; background:var(--fill2);}
.sx-li .tx{flex:1; min-width:0;}
.sx-li .t1{font-size:16.5px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
.sx-li .t2{font-size:14px; color:var(--label2); margin-top:3px;}
.sx-li .t3{font-size:14px; margin-top:3px; color:var(--warn-ink);}
.sx-li .t3.ok{color:var(--green);}
.sx-li .bg{flex:0 0 auto; align-self:flex-start; margin-top:4px;}
/* 설정 */
.sx-grp{background:var(--card); border-radius:16px; overflow:hidden;}
.sx-set{display:flex; align-items:center; justify-content:space-between; gap:12px; padding:13px 16px; min-height:50px; font-size:16.5px; position:relative; cursor:default;}
.sx-set + .sx-set::before{content:""; position:absolute; top:0; left:16px; right:0; border-top:.5px solid var(--sep);}
.sx-set .v{color:var(--label2); display:flex; align-items:center; gap:4px; text-align:right;}
.sx-set.tap{cursor:pointer;}
.sx-set .v svg{width:15px; height:15px; fill:none; stroke:var(--label3); stroke-width:2.4; stroke-linecap:round; stroke-linejoin:round;}
.sx-set .act{color:var(--tint);}
.sx-set .dis{color:var(--label3);}
.sx-mini{display:flex; background:var(--fill2); border-radius:9px; padding:2px;}
.sx-mini button{border:none; background:none; font-family:inherit; font-size:14px; font-weight:600; padding:6px 16px; border-radius:7px; color:var(--label); cursor:pointer;}
.sx-mini button.on{background:var(--card); box-shadow:0 1px 5px rgba(0,0,0,.14);}
.sx-mini button:disabled{color:var(--label3);}
.sx-step{display:flex; align-items:center; gap:2px;}
.sx-step button{width:34px; height:30px; border:none; background:var(--fill2); color:var(--label); font-size:18px; border-radius:8px; cursor:pointer; font-family:inherit;}
.sx-step b{min-width:52px; text-align:center; font-weight:600; font-size:15.5px;}
/* 편집 */
.sx-pv{position:relative; width:min(46vw, 212px); aspect-ratio:9/16; margin:4px auto 0; border-radius:22px; overflow:hidden; background:#111; cursor:pointer; box-shadow:0 8px 28px rgba(0,0,0,.18);}
.sx-pv canvas{width:100%; height:100%; display:block;}
.sx-pv .pl{position:absolute; left:50%; top:50%; width:64px; height:64px; margin:-32px 0 0 -32px; border-radius:50%; background:rgba(255,255,255,.88); display:flex; align-items:center; justify-content:center; transition:opacity .2s; pointer-events:none;}
.sx-pv .pl svg{width:26px; height:26px; fill:#111; margin-left:4px;}
.sx-pv.playing .pl{opacity:0;}
.sx-pv .tm{position:absolute; right:12px; bottom:20px; color:#fff; font-size:13px; font-weight:600; text-shadow:0 1px 3px rgba(0,0,0,.6); font-variant-numeric:tabular-nums;}
.sx-pv .pb{position:absolute; left:14px; right:14px; bottom:10px; height:4px; border-radius:2px; background:rgba(255,255,255,.35); overflow:hidden;}
.sx-pv .pb i{display:block; height:100%; width:0; background:#fff;}
.sx-pv .ld{position:absolute; left:0; right:0; top:45%; text-align:center; color:rgba(255,255,255,.75); font-size:13px;}
.sx-len{margin:18px 2px 6px;}
.sx-len .hd{display:flex; justify-content:space-between; align-items:baseline;}
.sx-len .hd b{font-size:17px; font-weight:700;}
.sx-len .hd span{font-size:13.5px; color:var(--label2);}
.sx-len .bar{position:relative; height:8px; border-radius:4px; background:var(--fill2); margin-top:10px;}
.sx-len .ok{position:absolute; top:0; bottom:0; border-radius:4px; background:rgba(52,199,89,.45);}
.sx-len .kn{position:absolute; top:50%; width:20px; height:20px; margin:-10px 0 0 -10px; border-radius:50%; background:var(--card); border:3px solid var(--green); box-shadow:0 1px 4px rgba(0,0,0,.2);}
.sx-len .kn.out{border-color:var(--warn-ink);}
.sx-len .msg{font-size:13.5px; color:var(--warn-ink); margin-top:7px; min-height:1px;}
.sx-fmts{margin:12px -16px 4px; padding:2px 16px 6px;}
.sx-fmts .sx-chip{font-weight:600; letter-spacing:.02em;}
.sx-strip{display:flex; gap:9px; overflow-x:auto; -webkit-overflow-scrolling:touch; padding:4px 16px 8px; margin:0 -16px; scrollbar-width:none;}
.sx-strip::-webkit-scrollbar{display:none;}
.sx-it{flex:0 0 74px; text-align:center; touch-action:pan-x; user-select:none; -webkit-user-select:none; -webkit-touch-callout:none;}
.sx-it .im{position:relative; width:74px; height:104px; border-radius:12px; overflow:hidden; background:var(--fill2); cursor:pointer;}
.sx-it .no{position:absolute; left:5px; top:5px; width:21px; height:21px; border-radius:50%; background:rgba(0,0,0,.55); color:#fff; font-size:12px; font-weight:700; display:flex; align-items:center; justify-content:center;}
.sx-it .vb{position:absolute; left:5px; bottom:5px; right:5px; background:rgba(0,0,0,.55); color:#fff; font-size:11px; font-weight:600; border-radius:7px; padding:1px 4px;}
.sx-it .cp{position:absolute; right:5px; top:5px; width:19px; height:19px; border-radius:50%; background:rgba(255,255,255,.9); color:#111; font-size:11px; font-weight:800; display:flex; align-items:center; justify-content:center;}
.sx-it .du{font-size:13px; color:var(--label2); margin-top:5px; font-variant-numeric:tabular-nums;}
.sx-it.ovl .im{box-shadow:0 0 0 3px var(--warn-ink) inset;}
.sx-it.drag{opacity:.35;}
.sx-ghost{position:fixed; z-index:200; width:74px; height:104px; border-radius:12px; overflow:hidden; pointer-events:none; box-shadow:0 12px 30px rgba(0,0,0,.35); transform:scale(1.08);}
.sx-add{background:none; border:none; color:var(--tint); font-family:inherit; font-size:16px; font-weight:500; padding:8px 2px; cursor:pointer;}
/* 마무리 */
.sx-opt{display:flex; align-items:center; gap:13px; padding:14px 14px; cursor:pointer; position:relative; font-size:16.5px; line-height:1.35;}
.sx-opt + .sx-opt::before{content:""; position:absolute; top:0; left:50px; right:0; border-top:.5px solid var(--sep);}
.sx-rad{flex:0 0 22px; height:22px; border-radius:50%; border:2px solid var(--label3); position:relative;}
.sx-opt.on .sx-rad{border-color:var(--tint);}
.sx-opt.on .sx-rad::after{content:""; position:absolute; inset:3px; border-radius:50%; background:var(--tint);}
.sx-desc{font-size:15px; line-height:1.55; white-space:pre-wrap; word-break:break-word; color:var(--label);}
.sx-desc.fold{max-height:4.65em; overflow:hidden; -webkit-mask-image:linear-gradient(#000 60%, transparent);}
.sx-ta{width:100%; border:none; background:var(--fill3); border-radius:12px; padding:10px 12px; font-family:inherit; font-size:15px; line-height:1.5; color:var(--label); resize:vertical;}
.sx-in{width:100%; border:none; background:var(--fill3); border-radius:12px; padding:11px 12px; font-family:inherit; font-size:16px; color:var(--label);}
/* 만드는 중 */
.sx-mk{min-height:100%; display:flex; flex-direction:column; align-items:center; padding:calc(70px + env(safe-area-inset-top)) 18px calc(24px + env(safe-area-inset-bottom));}
.sx-ring{position:relative; width:190px; height:190px; margin-top:6vh;}
.sx-ring svg{width:100%; height:100%; transform:rotate(-90deg);}
.sx-ring circle{fill:none; stroke-width:16;}
.sx-ring .bgc{stroke:var(--fill2); stroke-dasharray:none !important;} .sx-ring .fgc{stroke:var(--tint); stroke-linecap:round; transition:stroke-dashoffset .2s linear;}
.sx-ring b{position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-size:44px; font-weight:800; letter-spacing:-.02em; font-variant-numeric:tabular-nums;}
.sx-mk h2{font-size:24px; font-weight:800; margin:26px 0 4px;}
.sx-steps{width:100%; max-width:420px; background:var(--card); border-radius:18px; margin-top:22px; overflow:hidden;}
.sx-steps div{display:flex; align-items:center; gap:12px; padding:14px 15px; font-size:16.5px; position:relative;}
.sx-steps div + div::before{content:""; position:absolute; top:0; left:52px; right:0; border-top:.5px solid var(--sep);}
.sx-steps i{flex:0 0 24px; height:24px; border-radius:50%; border:2px solid var(--label3); position:relative;}
.sx-steps .now i{border-color:var(--tint);}
.sx-steps .now i::after{content:""; position:absolute; inset:4px; border-radius:50%; background:var(--tint);}
.sx-steps .done i{border:none; background:var(--green);}
.sx-steps .done i::after{content:""; position:absolute; left:8px; top:4px; width:6px; height:11px; border:solid #fff; border-width:0 2.5px 2.5px 0; transform:rotate(45deg);}
.sx-steps .off{color:var(--label3);}
.sx-steps span{margin-left:auto; color:var(--label2); font-size:14.5px;}
.sx-mk .warn{color:var(--warn-ink); font-size:15px; font-weight:500; margin-top:18px;}
/* 직접 올리기 */
.sx-done{display:flex; gap:14px; align-items:center; margin:4px 0 16px;}
.sx-done .th{flex:0 0 74px; height:120px; border-radius:12px; overflow:hidden; background:var(--fill2);}
.sx-done video{width:100%; height:100%; object-fit:cover; display:block;}
.sx-st{display:flex; gap:12px; padding:14px 2px; position:relative;}
.sx-st + .sx-st{border-top:.5px solid var(--sep);}
.sx-st .n{flex:0 0 28px; height:28px; border-radius:50%; background:var(--tint-fill); color:var(--tint-ink); font-weight:700; display:flex; align-items:center; justify-content:center; font-size:15px;}
.sx-st .b{flex:1; min-width:0;}
.sx-st .h{font-size:16.5px; font-weight:700;}
/* 고르기 */
.sx-grid{display:grid; grid-template-columns:repeat(4,1fr); gap:3px; margin:0 -14px;}
.sx-gc{position:relative; aspect-ratio:1; background:var(--fill2); overflow:hidden; cursor:pointer;}
.sx-gc .ck{position:absolute; right:5px; top:5px; width:22px; height:22px; border-radius:50%; border:2px solid #fff; background:rgba(0,0,0,.18);}
.sx-gc.on .ck{background:var(--tint); border-color:#fff;}
.sx-gc.on .ck::after{content:""; position:absolute; left:6px; top:2px; width:5px; height:10px; border:solid #fff; border-width:0 2px 2px 0; transform:rotate(45deg);}
.sx-gc.cool img{filter:grayscale(.9) opacity(.55);}
.sx-gc .u{position:absolute; left:4px; bottom:4px; font-size:10.5px; color:#fff; background:rgba(0,0,0,.55); border-radius:6px; padding:1px 5px;}
.sx-gc .vd{position:absolute; left:4px; top:4px; font-size:10.5px; color:#fff; background:rgba(0,0,0,.55); border-radius:6px; padding:1px 5px;}
/* 시트 */
.sx-ovl{position:fixed; inset:0; z-index:120; background:rgba(0,0,0,.35); display:flex; align-items:flex-end; justify-content:center; opacity:0; transition:opacity .2s;}
.sx-ovl.on{opacity:1;}
.sx-sheet{width:100%; max-width:540px; max-height:90vh; overflow-y:auto; background:var(--sheet); color:var(--label); border-radius:28px 28px 0 0; padding:8px 18px calc(18px + env(safe-area-inset-bottom)); transform:translateY(100%); transition:transform .3s cubic-bezier(.2,.9,.3,1);}
.sx-ovl.on .sx-sheet{transform:none;}
.sx-sheet .grab{width:36px; height:5px; border-radius:3px; background:var(--label3); margin:4px auto 12px;}
.sx-sheet h3{font-size:22px; font-weight:800; margin:6px 0 4px; letter-spacing:-.02em;}
.sx-sheet .lbl{font-size:13.5px; color:var(--label2); margin:16px 2px 8px;}
.sx-btns{display:flex; gap:10px; margin-top:18px;}
.sx-btns .sx-btn{flex:1;}
.sx-thr{display:flex; align-items:center; gap:8px; margin:12px 0 2px;}
.sx-thr .t{width:58px; height:58px; border-radius:12px; overflow:hidden; background:var(--fill2);}
.sx-slider{width:100%; accent-color:var(--tint);}
.sx-focus{position:relative; width:150px; aspect-ratio:3/4; margin:4px auto; border-radius:12px; overflow:hidden; background:var(--fill2); touch-action:none;}
.sx-focus img{width:100%; height:100%; object-fit:contain;}
.sx-focus .fr{position:absolute; top:0; bottom:0; border:2px solid #fff; box-shadow:0 0 0 999px rgba(0,0,0,.45); border-radius:6px;}
.sx-vstrip{position:relative; height:46px; border-radius:10px; background:var(--fill2); margin:8px 0 2px; overflow:hidden;}
.sx-vstrip .sg{position:absolute; top:0; bottom:0; background:var(--tint-fill); border:2px solid var(--tint); border-radius:8px;}
.sx-kv{display:flex; justify-content:space-between; font-size:14px; color:var(--label2); margin:4px 2px;}
/* V6.5.1 — 뜻 · 추천 칩 · 영상 자막 카드 */
.sx-mean{font-size:13.5px; color:var(--label2); margin-top:3px; line-height:1.4; font-weight:400;}
.sx-pap{color:var(--tint); text-decoration:none;}
.sx-opt .tx{display:flex; flex-direction:column; min-width:0;}
.sx-sugs{margin-top:4px;}
.sx-sg{margin-top:10px;}
.sx-sg .t{display:block; font-size:12.5px; color:var(--label2); margin:0 2px 6px;}
.sx-chip.sm{font-size:14px; padding:6px 12px;}
.sx-chip .k{color:var(--label2); font-size:12px; margin-left:6px; font-weight:400;}
.sx-chip.soft .k{color:var(--tint-ink); opacity:.7;}
.sx-capc{background:var(--card); border-radius:16px; padding:11px 14px 12px; margin:12px 0 0; cursor:pointer;}
.sx-capc .hd{display:flex; justify-content:space-between; font-size:12.5px; color:var(--label2); margin-bottom:3px;}
.sx-capc .ed{color:var(--tint); font-size:14px;}
.sx-capc .en{font-weight:700; font-size:15.5px; line-height:1.3;}
.sx-capc .en2{font-weight:600; font-size:14px; margin-top:5px;}
.sx-scap{padding:6px 0; border-bottom:.5px solid var(--sep);}
.sx-scap:last-of-type{border-bottom:none;}
.sx-scap .r1{display:flex; gap:10px; align-items:flex-start;}
.sx-scap .th{flex:0 0 40px; height:56px; border-radius:8px; overflow:hidden; background:var(--fill2);}
.sx-scap .in{flex:1; min-width:0;}
.sx-scap .sg{padding-left:50px;}
/* V6.5.2 초안 삭제 — 목록 [편집] → 행마다 [삭제] */
.sx-row .sx-acts{display:flex; align-items:center; gap:16px;}
.sx-lnk.b{font-weight:700;}
.sx-lnk.red, .sx-nbtn.red{color:var(--red-sys);}
.sx-badge.del{border:none; font-family:inherit; font-size:13px; padding:6px 13px; background:var(--red-bg); color:var(--red-sys); cursor:pointer;}
.sx-badge.del:active{opacity:.5;}
.sx-dedit .sx-draft{cursor:default;}
.sx-draft .sx-sub{line-height:1.35;}
.sx-draft .sx-sub .nw{white-space:nowrap;}
.sx-draft .sx-sub .mk{color:var(--tint-ink); font-weight:600;}
.sx-dnote{margin:-4px 8px 16px;}
`;

/* ---------- 데이터: /handbook/{가족코드}-shorts/ (cfg · r · fp) ---------- */
const D = { cfg: null, rec: {}, fp: {}, ok: false, p: null, at: 0 };
function shPath(p) { return SYNC.url.replace(/\/+$/, '') + '/handbook/' + SYNC.code + '-shorts/' + p + '.json'; }
async function shFetch(p, method, body) {
  const ctl = new AbortController(); const to = setTimeout(function () { ctl.abort(); }, 20000);
  try {
    const r = await fetch(shPath(p), { method: method || 'GET', body: body === undefined ? undefined : JSON.stringify(body), signal: ctl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(to); }
}
function C() { return Object.assign({}, E.DEF_CFG, D.cfg || {}); }
function today() { return todayKey(); }
async function dLoad(force) {
  if (!syncConfigured()) throw new Error('동기화가 꺼져 있어요');
  if (D.ok && !force && Date.now() - D.at < 20000) return;
  if (D.p) return D.p;
  D.p = (async function () {
    try {
      const all = await Promise.all([shFetch('cfg'), shFetch('r'), shFetch('fp')]);
      D.cfg = all[0] || {}; D.rec = all[1] || {}; D.fp = all[2] || {};
      D.ok = true; D.at = Date.now();
      await migrate();
      await cleanDrafts();
    } finally { D.p = null; }
  })();
  return D.p;
}
async function cfgSet(k, v) { D.cfg = D.cfg || {}; D.cfg[k] = v; await shFetch('cfg/' + k, 'PUT', v); }
async function recPut(rid, r) { r.ut = Date.now(); D.rec[rid] = r; await shFetch('r/' + rid, 'PUT', r); }
async function recDel(rid) { delete D.rec[rid]; await shFetch('r/' + rid, 'DELETE'); }
function newRid() { return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
/* 첫 실행: 기존에 손으로 만든 쇼츠의 원본 영상(앨범 영상)을 한 번 '사용됨'으로 표시. 시리즈 번호 시작값 = 앨범 유튜브 링크 수 + 1(추정) */
async function migrate() {
  const c = D.cfg || {};
  if (c.mig1) return;
  const meta = ALB.meta || {};
  const up = {};
  Object.keys(meta).forEach(function (id) {
    const m = meta[id];
    if (E.isClip(m) && !(m.su > 0)) { up[id + '/su'] = 1; up[id + '/sl'] = E.dOf(m) || today(); m.su = 1; m.sl = E.dOf(m) || today(); }
  });
  try {
    if (Object.keys(up).length) { await albFetch('meta', 'PATCH', JSON.stringify(up)); await albBumpIdx(); }
    if (!c.nsn) { const yt = Object.keys(meta).filter(function (id) { return meta[id] && meta[id].t === 'v'; }).length; await cfgSet('nsn', yt + 1); await cfgSet('nsnGuess', 1); }
    await cfgSet('mig1', Date.now());
  } catch (e) { }
}
/* 작성 중 초안: 14일 안 열면 자동 삭제 */
async function cleanDrafts() {
  const lim = Date.now() - 14 * 86400000;
  const ids = Object.keys(D.rec).filter(function (rid) { const r = D.rec[rid]; return r && r.st !== 'up' && (r.ut || r.at || 0) < lim; });
  for (let i = 0; i < ids.length; i++) { try { const r = D.rec[ids[i]]; await recDel(ids[i]); await freeSn(r); } catch (e) { } }
}
/* 초안 삭제 (V6.5.2) — 서버에서 먼저 지우고(실패하면 그대로 둠), 잡고 있던 시리즈 번호는 회수. 사진·앨범은 건드리지 않음 */
async function delDraft(rid) {
  const r = D.rec[rid]; if (!r || r.st === 'up') return false;
  await shFetch('r/' + rid, 'DELETE');
  delete D.rec[rid];
  await freeSn(r);
  return true;
}
/* 시리즈 번호 — 예약 직전·회수 직전에 두 폰 공용 값(nsn·fsn)을 새로 읽는다 */
async function snSync() {
  try { const v = await Promise.all([shFetch('cfg/nsn'), shFetch('cfg/fsn')]); D.cfg = D.cfg || {}; if (v[0]) D.cfg.nsn = v[0]; D.cfg.fsn = v[1] || null; } catch (e) { }
}
async function snSave(st) {
  const c = C();
  if ((+c.nsn || 0) !== st.nsn) await cfgSet('nsn', st.nsn);
  if (E.snList(c.fsn).join(',') !== st.fsn.join(',')) await cfgSet('fsn', st.fsn.length ? st.fsn : null);
}
async function freeSn(r) {   /* r: D.rec에서 이미 뺀 초안 */
  if (!r || !r.sn || r.st === 'up') return;
  await snSync();
  try { await snSave(E.snFree(C().nsn, D.rec, C().fsn, r.sn)); } catch (e) { }
}
async function reserveSn(r) {
  if (r.sn) return r.sn;
  await snSync();
  const p = E.snPick(C().nsn, D.rec, C().fsn);
  r.sn = p.sn;
  await snSave(p);
  r.de = E.descSn(r.de, p.sn);
  return p.sn;
}
function ups() { return Object.keys(D.rec).map(function (k) { return Object.assign({ rid: k }, D.rec[k]); }).filter(function (r) { return r.st === 'up'; }).sort(function (a, b) { return (b.up || 0) - (a.up || 0); }); }
function drafts() { return Object.keys(D.rec).map(function (k) { return Object.assign({ rid: k }, D.rec[k]); }).filter(function (r) { return r.st !== 'up'; }).sort(function (a, b) { return (b.ut || 0) - (a.ut || 0); }); }

/* ---------- 작은 도구 ---------- */
const ICO = {
  back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
  gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  chev: '<svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12.5-7.5z"/></svg>'
};
function h(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; }
function $(root, sel) { return root.querySelector(sel); }
function $$(root, sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }
function fmtSec(s) { return (Math.round(s * 10) / 10).toFixed(1) + '초'; }
function mmss(s) { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function mdK(d) { d = String(d || ''); return d ? (+d.slice(5, 7)) + '월 ' + (+d.slice(8, 10)) + '일' : ''; }
function thumbSrc(id) {
  if (ALB.thumbs && ALB.thumbs.has(id)) return Promise.resolve(ALB.thumbs.get(id));
  return albImgSrc('th', id).then(function (v) { if (v && ALB.thumbs) ALB.thumbs.set(id, v); return v; });
}
function fillThumb(img, id) {
  if (!img || !id) return;
  thumbSrc(id).then(function (v) { if (v) { img.src = v; img.classList.add('ld'); } }).catch(function () { });
}
function thumbsIn(root) { $$(root, 'img[data-th]').forEach(function (im) { fillThumb(im, im.getAttribute('data-th')); }); }
function copyText(t) {
  t = String(t || '');
  try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).catch(function () { copyFallback(t); }); return true; } } catch (e) { }
  return copyFallback(t);
}
function copyFallback(t) {
  try { const ta = document.createElement('textarea'); ta.value = t; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:-100px;opacity:0;'; document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; } catch (e) { return false; }
}
function toast(m) { try { uiToast(m); } catch (e) { } }
/* 영어 문구의 한글 뜻 — 내장 문구는 뜻, 직접 쓴 문장은 파파고 링크. 한글 문구는 표시 안 함 */
function meanHTML(text, ctx) {
  const t = String(text || '').trim(); if (!t || R.HANGUL.test(t)) return '';
  const m = E.meaning(t, ctx || {});
  if (m) return '<div class="sx-mean">뜻 · ' + esc(m) + '</div>';
  return '<div class="sx-mean"><a class="sx-pap" href="' + esc(E.papago(t)) + '" target="_blank" rel="noopener">파파고에서 뜻 보기</a></div>';
}
/* 장면 자막 추천 — 추천 문구 · 추천 문장 · 사진 메모 · 영문(뜻) · 자막 없음 */
function sugHTML(sg) {
  function chips(list, en) { return list.map(function (x) { const t = en ? x[0] : x, k = en ? x[1] : ''; return '<button type="button" class="sx-chip sm" data-sug="' + esc(t) + '">' + esc(t) + (k ? '<span class="k">' + esc(k) + '</span>' : '') + '</button>'; }).join(''); }
  return '<div class="sx-sugs">' +
    (sg.p.length ? '<div class="sx-sg"><span class="t">추천 문구</span><div class="sx-chips">' + chips(sg.p) + '</div></div>' : '') +
    (sg.s.length ? '<div class="sx-sg"><span class="t">추천 문장</span><div class="sx-chips">' + chips(sg.s) + '</div></div>' : '') +
    (sg.memo ? '<div class="sx-sg"><span class="t">사진 메모</span><div class="sx-chips">' + chips([sg.memo]) + '</div></div>' : '') +
    (sg.en.length ? '<div class="sx-sg"><span class="t">영문</span><div class="sx-chips">' + chips(sg.en, true) + '</div></div>' : '') +
    '<div class="sx-sg"><div class="sx-chips"><button type="button" class="sx-chip sm" data-sug="">자막 없음</button></div></div></div>';
}
function selOf(ids) { return ids.map(function (id) { return { id: id, m: (ALB.meta || {})[id], sc: E.score((ALB.meta || {})[id] || {}, today()) }; }).filter(function (x) { return x.m; }); }

/* ---------- 화면 쌓기 + 뒤로가기 (V6.5.1) ----------
   기록(history) 한 칸 = 화면 한 장 또는 시트 한 장. 각 칸에 깊이(sx: 화면 수, sh: 시트 수)를 적어 두고,
   폰 뒤로가기가 오면 그 깊이에 맞춰 '시트 → 화면' 순서로 닫는다 — 브라우저가 칸을 건너뛰어도 화면이 어긋나지 않게.
   앱 안 버튼(뒤로·닫기)은 화면을 먼저 닫고 기록을 한 칸 되돌린다(그때 오는 popstate는 무시). */
const U = { stack: [], sheets: [], closing: 0 };
function hstate() { return { tab: 'album', sx: U.stack.length, sh: U.sheets.length, d: ((history.state && history.state.d) || 0) + 1 }; }
/* V6.6: 기록 칸 넣기·되돌리기는 앱의 문지기(navHistPush / navHistBack)를 쓴다 — 되돌리기 도중 넣은 칸을 브라우저가 잃지 않게.
   alive: 칸을 실제로 넣는 순간 그 화면이 아직 열려 있는지(닫혔으면 넣지 않음) */
function hpush(alive) {
  const s = hstate();
  if (typeof navHistPush === 'function') { navHistPush(function () { return (!alive || alive()) ? s : null; }, location.hash || '#album'); return true; }
  try { history.pushState(s, '', location.hash || '#album'); return true; } catch (e) { return false; }
}
function hback(n) {
  if (typeof navHistBack === 'function') { navHistBack(n || 1, true); return; }
  U.closing++; try { if ((n || 1) === 1) history.back(); else history.go(-n); } catch (e) { U.closing--; }
}
function root() {
  let r = document.getElementById('sxRoot');
  if (!r) {
    if (!document.getElementById('sxCss')) { const st = document.createElement('style'); st.id = 'sxCss'; st.textContent = CSS; document.head.appendChild(st); }
    r = document.createElement('div'); r.id = 'sxRoot'; document.body.appendChild(r);
  }
  return r;
}
function navBar(o) {
  return '<div class="sx-nav' + (o.line ? ' line' : '') + '">' +
    (o.back ? '<button type="button" class="sx-back" data-act="back">' + ICO.back + '<span>' + esc(o.back) + '</span></button>' : '<span></span>') +
    (o.title ? '<div class="sx-ttl">' + esc(o.title) + '</div>' : '') +
    (o.right || '<span></span>') + '</div>';
}
function bindBack(scr) { scr.el.addEventListener('click', function (e) { const b = e.target.closest('[data-act="back"]'); if (b && scr.el.contains(b)) { e.preventDefault(); back(); } }); }
function push(scr) {
  const r = root();
  const prev = U.stack[U.stack.length - 1];
  U.stack.push(scr);
  r.appendChild(scr.el);
  document.body.classList.add('sx-open');
  bindBack(scr);
  requestAnimationFrame(function () { requestAnimationFrame(function () { scr.el.classList.add('on'); if (prev) prev.el.classList.add('under'); }); });
  scr.h = hpush(function () { return U.stack.indexOf(scr) > -1; });
  return scr;
}
function dropTop(anim) {
  const s = U.stack.pop(); if (!s) return;
  try { if (s.destroy) s.destroy(); } catch (e) { }
  const prev = U.stack[U.stack.length - 1];
  if (prev) { prev.el.classList.remove('under'); try { if (prev.resume) prev.resume(); } catch (e) { } }
  if (anim === false) s.el.remove();
  else { s.el.classList.remove('on'); setTimeout(function () { s.el.remove(); }, 380); }
  if (!U.stack.length) document.body.classList.remove('sx-open');
}
/* 앱 안 '뒤로' 버튼 */
function back() {
  if (U.sheets.length) { U.sheets[U.sheets.length - 1].close(); return; }
  if (!U.stack.length) return;
  const top = U.stack[U.stack.length - 1];
  if (top.onBack && top.onBack() === false) return;
  const st = history.state || {};
  const mine = top.h && st.sx === U.stack.length && !(st.sh > 0);
  dropTop();
  if (mine) hback(1);
}
/* 화면 여러 장을 한 번에 닫기(예: 올렸어요 → 쇼츠 홈) */
function popTo(n) {
  let hk = 0;
  U.sheets.slice().reverse().forEach(function (sh) { if (sh.h) hk++; sh.close(true); });
  const k = U.stack.length - n;
  for (let i = 0; i < k; i++) { const s = U.stack[U.stack.length - 1]; if (s.h) hk++; dropTop(i === k - 1); }
  if (hk) hback(hk);
}
function restoreEntry() { hpush(); }
/* 폰 뒤로가기 (index.html의 popstate가 먼저 여기로 보낸다) */
function onPop(e) {
  if (U.closing > 0) { U.closing--; return true; }
  if (!U.stack.length && !U.sheets.length) return false;
  const st = (e && e.state) || {};
  const tS = typeof st.sh === 'number' ? st.sh : 0;
  const tD = typeof st.sx === 'number' ? st.sx : 0;
  /* 앱 확인창(시트)이 쇼츠 위에 떠 있으면 그것만 닫는다 */
  const us = document.getElementById('uiSheet');
  if (us && us.classList.contains('on')) { try { uiSheetClose({ ok: false }); } catch (er) { } restoreEntry(); return true; }
  let did = false;
  if (U.sheets.length > tS) {
    const noHist = U.sheets.length && !U.sheets[U.sheets.length - 1].h;
    while (U.sheets.length > tS) U.sheets[U.sheets.length - 1].close(true);
    did = true;
    if (noHist && tD >= U.stack.length) { restoreEntry(); return true; }   /* 기록 없이 뜬 시트: 닫기만 하고 칸 되살림 */
  }
  if (U.stack.length > tD) {
    const top = U.stack[U.stack.length - 1];
    if (top.onBack && top.onBack() === false) { restoreEntry(); return true; }   /* 만드는 중: 확인 먼저 */
    while (U.stack.length > tD) dropTop(U.stack.length - 1 === tD);
    did = true;
  }
  return did || true;
}
function closeAll() { popTo(0); }
function scrEl(cls) { return h('<div class="sx-scr ' + (cls || '') + '" role="dialog" aria-modal="true"></div>'); }

/* ---------- 시트 — 열 때 기록 한 칸(폰 뒤로가기 = 시트 닫기) ---------- */
function sheet(inner, o) {
  o = o || {};
  const ov = h('<div class="sx-ovl" role="dialog" aria-modal="true"><div class="sx-sheet"><div class="grab"></div></div></div>');
  const sh = $(ov, '.sx-sheet');
  sh.insertAdjacentHTML('beforeend', inner);
  document.body.appendChild(ov);
  requestAnimationFrame(function () { requestAnimationFrame(function () { ov.classList.add('on'); }); });
  const api = {
    el: sh, ov: ov, closed: false, h: false,
    close: function (fromPop) {
      if (api.closed) return; api.closed = true;
      const i = U.sheets.indexOf(api);
      if (i > -1) U.sheets.splice(i, 1);
      ov.classList.remove('on'); setTimeout(function () { ov.remove(); }, 320);
      if (fromPop !== true && api.h && history.state && history.state.sh === i + 1) hback(1);
      if (o.onClose) o.onClose();
    }
  };
  U.sheets.push(api);
  if (!o.noHist) api.h = hpush(function () { return !api.closed; });
  ov.addEventListener('click', function (e) { if (e.target === ov && !o.modal) api.close(); });
  return api;
}

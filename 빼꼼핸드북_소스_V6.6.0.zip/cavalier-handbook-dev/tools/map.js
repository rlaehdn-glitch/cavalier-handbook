// 본체 index.html 구조 지도: 스크립트별 최상위 선언, 중복, 미사용, 이벤트/타이머/네트워크/저장소 사용처
const fs = require('fs');
const acorn = require('acorn');
const walk = require('acorn-walk');
const src = fs.readFileSync(process.argv[2], 'utf8');
const lineOf = (pos) => src.slice(0, pos).split('\n').length;
const scripts = [];
const re = /<script([^>]*)>([\s\S]*?)<\/script>/g; let m;
while ((m = re.exec(src))) { if (/\bsrc=/.test(m[1])) continue; const off = m.index + m[0].indexOf('>') + 1; scripts.push({ attrs: m[1].trim(), code: m[2], off, line: lineOf(off) }); }
const html = src.replace(re, '');
const decl = {}; const all = [];
const out = { scripts: [], dupFuncs: [], dupVars: [], unused: [], listeners: [], intervals: [], fetches: [], storage: {}, popstate: [], timeouts: 0, nativeDialogs: [] };
scripts.forEach((s, si) => {
  let ast;
  try { ast = acorn.parse(s.code, { ecmaVersion: 2022, sourceType: 'script', locations: true, allowHashBang: true }); }
  catch (e) { out.scripts.push({ si, attrs: s.attrs, line: s.line, parseError: e.message }); return; }
  const tl = { funcs: 0, vars: 0 };
  ast.body.forEach(n => {
    if (n.type === 'FunctionDeclaration') { tl.funcs++; const nm = n.id.name; const L = s.line + n.loc.start.line - 1; const len = n.loc.end.line - n.loc.start.line + 1; (decl[nm] = decl[nm] || []).push({ kind: 'function', si, L, len }); all.push({ nm, L, len, si }); }
    if (n.type === 'VariableDeclaration') n.declarations.forEach(d => { if (d.id.type === 'Identifier') { tl.vars++; const nm = d.id.name; (decl[nm] = decl[nm] || []).push({ kind: n.kind, si, L: s.line + n.loc.start.line - 1 }); } });
    if (n.type === 'ClassDeclaration') { const nm = n.id.name; (decl[nm] = decl[nm] || []).push({ kind: 'class', si, L: s.line + n.loc.start.line - 1 }); }
  });
  walk.full(ast, (node) => {
    const L = () => s.line + node.loc.start.line - 1;
    if (node.type === 'CallExpression') {
      const c = node.callee; const name = c.type === 'Identifier' ? c.name : (c.type === 'MemberExpression' && !c.computed ? c.property.name : '');
      const obj = c.type === 'MemberExpression' && c.object.type === 'Identifier' ? c.object.name : (c.type === 'MemberExpression' && c.object.type === 'MemberExpression' && !c.object.computed ? c.object.property.name : '');
      if (name === 'addEventListener') { const ev = node.arguments[0] && node.arguments[0].type === 'Literal' ? node.arguments[0].value : '?'; out.listeners.push({ L: L(), ev, on: obj }); if (ev === 'popstate') out.popstate.push(L()); }
      if (name === 'setInterval') out.intervals.push(L());
      if (name === 'setTimeout') out.timeouts++;
      if (name === 'fetch') out.fetches.push(L());
      if (['alert', 'confirm', 'prompt'].includes(name) && (c.type === 'Identifier' || obj === 'window')) out.nativeDialogs.push({ L: L(), name });
      if (['getItem', 'setItem', 'removeItem'].includes(name) && /localStorage|sessionStorage/.test(obj) || ['lsGet', 'lsSet', 'lsDel'].includes(name)) {
        const a = node.arguments[0]; const k = a && a.type === 'Literal' ? a.value : (a && a.type === 'TemplateLiteral' ? '`' + a.quasis.map(q => q.value.raw).join('${}') + '`' : '?expr');
        (out.storage[k] = out.storage[k] || []).push(L());
      }
    }
  });
  out.scripts.push({ si, attrs: s.attrs, line: s.line, lines: s.code.split('\n').length, bytes: Buffer.byteLength(s.code), topFuncs: tl.funcs, topVars: tl.vars });
});
Object.keys(decl).forEach(nm => { const d = decl[nm]; if (d.length > 1) { if (d.every(x => x.kind === 'function')) out.dupFuncs.push({ nm, at: d.map(x => 'L' + x.L + '(' + x.len + '줄)') }); else out.dupVars.push({ nm, at: d.map(x => x.kind + '@L' + x.L) }); } });
// 미사용 최상위 함수: 이름이 선언 외에 한 번도 안 나옴(문자열·HTML 속성 포함 전체 텍스트 기준)
all.forEach(f => { const re2 = new RegExp('\\b' + f.nm.replace(/\$/g, '\\$') + '\\b', 'g'); const n = (src.match(re2) || []).length; if (n <= 1) out.unused.push({ nm: f.nm, L: f.L, len: f.len }); });
out.funcCount = all.length; out.bigFuncs = all.filter(f => f.len >= 120).sort((a, b) => b.len - a.len).map(f => f.nm + '@L' + f.L + '(' + f.len + ')');
fs.writeFileSync(process.argv[3], JSON.stringify(out, null, 1));
console.log('scripts', JSON.stringify(out.scripts));
console.log('top-level functions', all.length, '| dupFuncs', out.dupFuncs.length, '| dupVars', out.dupVars.length, '| unused', out.unused.length);
console.log('listeners', out.listeners.length, '| popstate', out.popstate, '| intervals', out.intervals, '| timeouts', out.timeouts, '| fetch', out.fetches.length, '| native dialogs', out.nativeDialogs.length);
console.log('storage keys', Object.keys(out.storage).length, JSON.stringify(Object.fromEntries(Object.entries(out.storage).map(([k, v]) => [k, v.length]))));
console.log('dupFuncs', JSON.stringify(out.dupFuncs));
console.log('dupVars', JSON.stringify(out.dupVars));
console.log('bigFuncs', out.bigFuncs.join(', '));

// 이벤트 리스너가 '여러 번 불리는 함수' 안에서 붙는지(중복 누적 위험) 찾기
const fs = require('fs');
const acorn = require('acorn');
const walk = require('acorn-walk');
const src = fs.readFileSync(process.argv[2], 'utf8');
const lineOf = (pos) => src.slice(0, pos).split('\n').length;
const re = /<script([^>]*)>([\s\S]*?)<\/script>/g; let m; const funcs = {}; const calls = {};
while ((m = re.exec(src))) {
  if (/\bsrc=/.test(m[1])) continue;
  const base = lineOf(m.index + m[0].indexOf('>') + 1) - 1;
  let ast; try { ast = acorn.parse(m[2], { ecmaVersion: 2022, locations: true }); } catch (e) { continue; }
  ast.body.forEach(n => {
    let fn = null, name = null;
    if (n.type === 'FunctionDeclaration') { fn = n; name = n.id.name; }
    if (!fn) return;
    const info = { L: base + fn.loc.start.line, listeners: [], guarded: false, callees: new Set() };
    const code = m[2].slice(fn.start, fn.end);
    info.guarded = /dataset\.(bound|b|on|wired|bd)\b|\._bound|\.bound\s*=|onclick\s*=|\.on[a-z]+\s*=/.test(code);
    walk.full(fn.body, (node) => {
      if (node.type === 'CallExpression') {
        const c = node.callee;
        if (c.type === 'MemberExpression' && !c.computed && c.property.name === 'addEventListener') info.listeners.push(base + node.loc.start.line);
        if (c.type === 'Identifier') info.callees.add(c.name);
      }
    });
    funcs[name] = info;
  });
}
Object.keys(funcs).forEach(n => funcs[n].callees.forEach(c => { (calls[c] = calls[c] || new Set()).add(n); }));
// 반복 호출되는 함수 = render*/paint*/update*/refresh* 이름이거나 그런 함수에서 불림
const rep = n => /^(render|paint|refresh|update|redraw|draw|show)/i.test(n);
const out = [];
Object.keys(funcs).forEach(n => {
  const f = funcs[n]; if (!f.listeners.length) return;
  const callers = Array.from(calls[n] || []);
  const risky = rep(n) || callers.some(rep);
  out.push({ n, L: f.L, k: f.listeners.length, callers: callers.slice(0, 6), risky, guarded: f.guarded });
});
out.sort((a, b) => (b.risky - a.risky) || (b.k - a.k));
out.forEach(o => console.log((o.risky ? 'RISK ' : '     ') + (o.guarded ? 'g ' : '  ') + o.n + '@L' + o.L + ' listeners=' + o.k + ' callers=' + o.callers.join(',')));

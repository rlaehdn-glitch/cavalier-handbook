#!/usr/bin/env python3
"""1회용: V6.5.2 index.html(한 파일)을 기능별 소스 파일 + manifest.json으로 나눈다.
나눈 뒤 build.py로 다시 합치면 원본과 바이트 단위로 같아야 한다(검증 포함)."""
import re, os, json, sys
SRC = sys.argv[1]; OUT = sys.argv[2]
s = open(SRC, encoding='utf-8').read()
line_off = [0] + [m.end() for m in re.finditer('\n', s)]          # line N(1-base) 시작 오프셋 = line_off[N-1]
def L(n): return line_off[n - 1]
def lineno(off): import bisect; return bisect.bisect_right(line_off, off)
CSS_NAMES = ['01-base', '02-pager', '03-mobile', '04-album', '05-v2-appbar', '06-v21-typo', '07-v3-theme', '08-v31-stamps', '09-v32-log-table', '10-v33-away',
             '11-v4-quicklog', '12-v41-stamp-delete', '13-v42-quicklog-4col', '14-v43-stat-btn', '15-v5', '16-v6-chat', '17-anchor-offset', '18-v6-design-layer',
             '19-v61-stats', '20-v62-feed', '21-v63-walk', '22-v64-bath', '23-v65-shorts']
MAIN = [(None, '00-changelog'), (4348, '01-state'), (4394, '02-sync'), (4605, '03-notice'), (4726, '04-basics'), (4851, '05-health-money'), (4952, '06-calendar'),
        (5147, '07-page-helpers'), (5209, '08-album'), (5509, '09-album-r2'), (5744, '10-album-backup'), (5912, '11-media'), (6106, '12-homecam'),
        (6173, '13-album-likes-viewer'), (6281, '14-album-shorts'), (6412, '15-nav'), (6503, '16-sos-dashboard'), (6635, '17-strip-chart-library'),
        (6790, '18-quicklog-away'), (6895, '19-toggles-quickedit'), (7035, '20-chat'), (7282, '21-feed'), (7673, '22-weight-backup-midnight'), (7737, '23-stats'),
        (8784, '24-ui-common'), (8866, '25-kindergarten-away'), (9052, '26-home'), (9333, '27-bind-theme-hero'), (9559, '28-init')]
WALK = [(None, '00-base-storage'), (9743, '01-record'), (10079, '02-save'), (10188, '03-screen'), (10392, '04-map'), (10568, '05-ui')]
TABS = ['home', 'cal', 'notice', 'prep', 'health', 'money', 'food', 'walk', 'work', 'neuter', 'record', 'settings', 'shop', 'place', 'emerg', 'behav', 'life', 'index', 'album', 'stats', 'lib']
first_style = s.find('<style')
blocks = []
for m in re.finditer(r'<(style|script)([^>]*)>', s):
    if m.start() < first_style: continue
    tag, attrs = m.group(1), m.group(2)
    if tag == 'script' and 'src=' in attrs: continue
    close = s.find('</' + tag + '>', m.end())
    blocks.append(dict(tag=tag, open=m.group(0), start=m.start(), inner_s=m.end(), inner_e=close, end=close + len('</' + tag + '>'), attrs=attrs))
items = []; files = {}
def put(path, text): files[path] = text; return path
def raw(a, b, name):
    if a >= b: return
    t = s[a:b]
    if t.strip() == '': items.append({'text': t}); return
    items.append({'file': put(name, t)})
# head
items.append({'file': put('html/00-head.html', s[:first_style])})
pos = first_style; ci = 0; sc = 0
for bi, b in enumerate(blocks):
    if b['start'] > pos:
        seg = s[pos:b['start']]
        if b['tag'] == 'script' and sc == 0:          # 마지막 style 뒤 ~ 첫 inline script 앞 = 본문
            # 본문을 탭 단위로 나눈다
            cuts = []
            for t in TABS:
                ln = lineno(s.find('id="tab-' + t + '"'))
                if s[L(ln - 1):L(ln)].lstrip().startswith('<!--'): ln -= 1
                cuts.append((L(ln), 'html/20-tab-%02d-%s.html' % (TABS.index(t), t)))
            main_end = s.find('</main>'); sdk = s.find('<script src="https://www.gstatic.com')
            pts = [(pos, 'html/10-body-top.html')] + cuts + [(L(lineno(main_end)), 'html/80-body-bottom.html'), (L(lineno(sdk)), 'html/90-firebase-sdk.html')]
            for i, (a, nm) in enumerate(pts):
                e = pts[i + 1][0] if i + 1 < len(pts) else b['start']
                raw(a, e, nm)
        else:
            raw(pos, b['start'], 'html/01-head-meta.html')
    if b['tag'] == 'style':
        nm = 'css/' + CSS_NAMES[ci] + '.css'; ci += 1
        items.append({'open': b['open'], 'files': [put(nm, s[b['inner_s']:b['inner_e']])], 'close': '</style>'})
    else:
        sid = re.search(r'id="([^"]+)"', b['attrs']); sid = sid.group(1) if sid else ''
        inner_s, inner_e = b['inner_s'], b['inner_e']
        if sid == 'videoRtc': parts = [put('js/vendor/video-rtc.js', s[inner_s:inner_e])]
        elif sid == 'bathV64': parts = [put('js/bath.js', s[inner_s:inner_e])]
        else:
            spec, base = (WALK, 'js/walk/') if sid == 'walkGps' else (MAIN, 'js/main/')
            offs = [inner_s if ln is None else L(ln) for ln, _ in spec]
            parts = []
            for i, (ln, nm) in enumerate(spec):
                a = offs[i]; e = offs[i + 1] if i + 1 < len(spec) else inner_e
                assert inner_s <= a < e <= inner_e, (nm, a, e)
                parts.append(put(base + nm + '.js', s[a:e]))
        sc += 1
        items.append({'open': b['open'], 'files': parts, 'close': '</script>'})
    pos = b['end']
raw(pos, len(s), 'html/99-foot.html')
for p, t in files.items():
    fp = os.path.join(OUT, p); os.makedirs(os.path.dirname(fp), exist_ok=True)
    open(fp, 'w', encoding='utf-8', newline='').write(t)
json.dump({'out': 'index.html', 'items': items}, open(os.path.join(OUT, 'manifest.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('files', len(files), 'items', len(items))

# 빼꼼 핸드북 — 개발 기준서 (V6.6.0 · 2026-10-28)

기능을 고치거나 더할 때 이 문서 순서대로 합니다. 목적은 두 가지입니다.

- 새 기능을 붙여도 기존 기능이 몰래 깨지지 않게 한다(자동 테스트 + 구조 검사).
- 누가 고쳐도 같은 자리, 같은 방식으로 고치게 한다(규칙 10개).

---

## 1. 한눈에

| 항목 | 내용 |
|---|---|
| 올리는 파일 | `dist/index.html`, `dist/shorts.js` 두 개만 GitHub(rlaehdn-glitch/cavalier-handbook)에 올린다 |
| 고치는 곳 | `src/` (dist는 빌드 결과물이라 직접 고치지 않는다) |
| 만들기 | `python3 build.py` |
| 시험 | `node tests/run.js` (빌드 후 자동 시험, 약 3분) |
| 버전 | `VERSION` 한 곳만 바꾼다 |

---

## 2. 폴더 구성

| 경로 | 내용 |
|---|---|
| `VERSION` | 1줄째 버전(6.6.0), 2줄째 날짜(2026-10-28). 빌드 때 `__APP_VER__`·`__APP_DATE__`·`__APP_BUILD__`(660) 자리를 채운다 |
| `build.py` | `src/` → `dist/index.html`·`dist/shorts.js`. `--check DIR`은 DIR의 두 파일과 바이트 단위로 같은지 확인 |
| `src/app/manifest.json` | index.html 조립 순서(머리 → CSS 24개 → 본문 HTML → 스크립트 4개) |
| `src/app/html/` | `00-head` · `10-body-top` · `20-tab-NN-이름`(탭 21개) · `80-body-bottom`(시트·확인창) · `90-firebase-sdk` · `99-foot` |
| `src/app/css/` | `NN-vXX-기능.css` — 버전별로 더해진 스타일. 뒤 파일이 앞 파일을 덮는다 |
| `src/app/js/main/` | 본체 스크립트 30개(한 `<script>`). `00-changelog` → `01-state` → … → `28-diag` → `30-init` |
| `src/app/js/walk/` | 산책 지도 기록(GPS) 6개(`<script id="walkGps">`) |
| `src/app/js/bath.js` | 목욕(`<script id="bathV64">`) |
| `src/app/js/vendor/` | 홈캠 재생기(외부 코드, 고치지 않음) |
| `src/shorts/` | shorts.js 조각: `engine` → `render` → `ui1`·`ui2`·`ui3`, `vendor/mp4-muxer`(MIT) |
| `tests/` | 자동 테스트. `run.js`가 묶어서 돌린다. 결과는 `tests/out/summary.txt` |
| `tests/visual-base/` | 화면 모양 비교 기준 사진 24장 |
| `tests/debug/` | 수동 점검용 도구(묶음에 안 들어감) |
| `tools/map.js` | 구조 지도(함수·중복·안 쓰는 함수·뒤로가기·저장 키 목록). `structure.test.js`가 사용 |
| `tools/split_app.py` | V6.6에서 한 번 쓴 분리 도구(기록용, 다시 쓰지 않음) |

자바스크립트 공간: 모든 `<script>`는 **같은 전역 공간**을 씁니다. 같은 이름의 함수가 두 군데 있으면 뒤엣것이 앞엣것을 몰래 덮어씁니다(V6.6 정리 중 실제로 1건 발견: `fmtBytes`). 그래서 이름 중복은 구조 검사가 0개로 지킵니다.

---

## 3. 데이터 지도

### 3-1. 기록 문서 `S` (폰 `ckcs-data` + 서버 `handbook/{가족코드}`)

최상위 칸은 대부분 `01-state.js`의 `DEFAULT_S`에 적혀 있습니다(예외: 목욕 `bathLog`처럼 첫 기록 때 생기는 칸 — 규칙 5).

| 칸 | 내용 |
|---|---|
| `qlog` | 날짜별 빠른 기록. `{ '2026-10-28': { poo:['08:10:00\|m'], pee:[...], meal:[...] } }` |
| `walkLog` · `sleepLog` · `awayLog` · `kgLog` | 날짜별 산책·수면·외출·유치원 기록 |
| `weight` · `visits` · `expenses` · `events` | 체중·병원·지출·일정 목록 |
| `daily` · `checks` · `vax` · `marks` | 오늘 루틴·체크리스트·접종·달력 표시 |
| `profile` · `vet` · `feed` · `kgCfg` · `media` | 설정값 |
| `ntc` · `notice` · `rep` | 공지·대표 사진 |
| `bathLog` · `walkGps` · `walkCfg` | 목욕 기록 · 산책 지도 진행 중 표시 · 산책 지도 설정(첫 사용 때 생김, `DEFAULT_S` 밖) |
| `_seed` · `_mk` · `ntcMig` | 한 번만 하는 초기 작업 완료 표시 |
| `_at` · `_dev` · `_seen` | 동기화 관리용(직접 쓰지 않음) |

### 3-2. 이 폰 저장공간(localStorage)

| 키 | 내용 |
|---|---|
| `ckcs-data` | 기록 문서 S |
| `_sync_base` | 마지막으로 서버와 맞춘 기록(합치기 기준) |
| `_sync_seq` · `_sync_par` | V6.6 동시 저장 판별용(내 업로드 번호 · 올리기 직전 서버본) |
| `_sync_url` · `_sync_code` · `_sync_on` | 동기화 설정 |
| `_dev` | 이 폰 기기 번호 |
| `_ntc_by` | 이 폰 사용자 이름 |
| `_ntc_seen` · `_chat_read` | 공지 읽음 · 채팅 읽음 위치 |
| `_errlog` | 오류 기록함(최근 50건) |
| `_hero_v1` · `_theme` · `_wg_*` | 대표 사진 캐시 · 화면 테마 · 산책 지도 캐시 |

브라우저 한도는 약 5MB입니다. 설정 > 진단에서 사용량을 봅니다. 가득 차면 캐시(`_wg_*`·`_hero_v1`·`_sync_par`)부터 비우고 다시 저장합니다(`persistLocal`).

### 3-3. 서버

| 위치 | 내용 | 읽는 방식 |
|---|---|---|
| Firebase `handbook/{코드}` | 기록 문서 S | 20초마다 + 화면 다시 켤 때. 3방향 합치기 |
| Firebase `handbook/{코드}-album` | 사진 목록·좋아요·메모·태그·기기 버전(`ver/`) | 앨범 열 때 |
| Firebase `handbook/{코드}-shorts` | 쇼츠 기록·초안·시리즈 번호 | 쇼츠 열 때 |
| Firebase `handbook/{코드}-walk` | 산책 경로 | 산책 기록 볼 때 |
| Firebase `chat/{코드}` | 채팅(실시간) | 계속 연결 |
| Cloudflare Worker + R2 | 사진·영상 원본 | 필요할 때 |

### 3-4. 두 폰 합치기 규칙(`02-sync.js` `merge3`)

- 목록·날짜별 기록: 양쪽에서 더한 것은 모두 남고, 한쪽에서 지운 것은 지워집니다(기준본과 비교).
- 같은 칸 하나(예: 프로필 이름)를 두 폰이 동시에 다르게 고치면 **나중에 저장한 것**이 남습니다.
- V6.6: 업로드마다 기기별 번호(`_seen`)를 남깁니다. 서버에 내 마지막 업로드가 없으면(다른 폰이 그 사이 덮어씀) 올리기 직전 서버본(`_sync_par`)을 기준으로 합쳐서 내 기록이 사라지지 않게 합니다.

---

## 4. 기능 추가 규칙 10개

| # | 규칙 | 지키는 장치 |
|---|---|---|
| 1 | **겹쳐 뜨는 화면은 NAV에 등록**(`15-nav.js`). `.sheet-ovl` 시트와 `NAV_SHEETS` 목록 id는 자동 등록. 그 밖의 전체 화면은 열 때 `navOpen(id, 닫는함수)`, 앱 안에서 닫을 때 `navClosed(id)`, 바꿔 끼울 때 `navSwap`. `popstate` 리스너를 새로 만들지 않고, `history.pushState`·`back`·`go`를 직접 부르지 않는다 — 기록 칸은 문지기 `navHistPush(state, url)` / `navHistBack(n, silent)`로만 넣고 뺀다(되돌리기 도중 넣은 칸을 브라우저가 잃는 문제를 막음. 쇼츠도 같은 함수 사용) | 구조 검사(뒤로가기 처리 1곳, history 직접 호출 문지기 1곳), `e2e_nav`·`e2e_v66` |
| 2 | **확인·알림·입력은 앱 시트로**: `await askConfirm(문구)` · `uiAlert` · `await uiPrompt(제목, 값)` · `uiActions` · `uiToast(문구, 되돌리기함수)`. 기본 `confirm()`·`prompt()` 금지(`alert()`는 `uiAlert`로 연결되어 있음) | 구조 검사(기본 confirm·prompt 0개) |
| 3 | **오류는 기록함에**: `catch`에서 조용히 넘기지 말고 `logErr('구역: 동작', e)`. 시작 단계는 `30-init.js`의 `BINDS`, 화면 그리기는 `RENDERS`에 `[이름, 함수]`로 넣는다(한 칸이 실패해도 나머지는 계속) | `e2e_v66`(그리기 보호), 설정 > 진단 |
| 4 | **저장은 `saveState()`**. localStorage는 `lsGet`/`lsSet`만. 사진·영상 같은 큰 데이터는 S에 넣지 않는다(Cloudflare R2에 저장) | `e2e_storage` |
| 5 | **S에 새 칸**: 기본값이 숫자·글자면 `DEFAULT_S`에 넣는다. 기본값이 빈 `{}`·`[]`이면 `DEFAULT_S`에 넣지 않고 첫 기록 때 만들고, 마지막 기록을 지우면 칸째 지운다(Firebase가 빈 칸을 저장하지 않아 매번 '바뀜'으로 잡히는 문제 — V6.4 목욕 기록 방식). 날짜별 기록은 `{날짜:{종류:[시각…]}}` 모양을 따르면 두 폰 합치기가 그대로 된다 | `e2e_sync` |
| 6 | **날짜는 한 번만 읽기**: 시트를 열 때 날짜를 정해 두고 저장·삭제 때 그 날짜를 쓴다(자정 넘김 사고 방지, V6.6 D5) | `e2e_midnight` |
| 7 | **이름은 기능 앞글자로**(`alb*` 앨범, `wg*` 산책, `ntc*` 공지, `qe*` 빠른 수정, `diag*` 진단 …). 새 이름은 `grep`으로 먼저 확인 | 구조 검사(이름 중복 0) |
| 8 | **기록 자동 삭제 금지**. V6.6부터 기록을 보존한다(유치원 400일·오늘 루틴 90일 정리만 유지) | `e2e_retention` |
| 9 | **스타일은 새 파일로**: 새 버전 화면 스타일은 `css/NN-vXX-기능.css`로 만들고 `manifest.json`에 등록 | 화면 비교(`e2e_visual`) |
| 10 | **버전은 `VERSION` 한 곳**. 둘째·셋째 자리는 0~9(6.6.9 다음은 6.7.0). `00-changelog.js` 맨 앞에 바뀐 점을 적는다. shorts.js 버전이 다르면 앱이 안내한다 | 구조 검사(버전 일치), `build.py` 검사 |

---

## 5. 고치는 순서(한 번 고칠 때마다)

1. `VERSION` 올리기 + `00-changelog.js` 맨 앞에 항목 추가
2. `src/`에서 고치기
3. 새 기능이면 시험 추가: `tests/e2e_이름.js` 만들고 `tests/run.js`의 `QUICK` 목록과 이 문서 7번 표에 넣기
4. `node tests/run.js` → `전체 통과` 확인(빌드도 자동)
   - 쇼츠 영상 만들기를 건드렸으면 `node tests/run.js --full`(약 10분)
   - 화면 모양이 바뀌는 수정이면 `VISUAL_EXPECT=settings node tests/e2e_visual.js`처럼 바뀔 화면 이름을 적어 돌리고, `tests/out/visual-now/` 사진을 눈으로 확인한 뒤 의도한 변화면 `node tests/e2e_visual.js base`로 기준 사진을 새로 저장
5. `dist/index.html`·`dist/shorts.js`를 올리고 아래 6번 점검표대로 확인. 소스를 바꿨으면 소스 묶음(zip, `tests/out`·`node_modules` 제외)도 같이 올려 보관

처음 한 번 준비: `npm install`(acorn·playwright), 파이썬 `Pillow`(화면 비교용).

---

## 6. 배포 점검표

| 순서 | 할 일 | 확인 |
|---|---|---|
| 1 | 올리기 전 한 폰에서 설정 > 백업 > **전체 기록 파일로 저장** | 파일이 내려받아짐 |
| 2 | 지금 쓰는 index.html·shorts.js를 따로 보관(되돌리기용) | 보관 폴더에 두 파일 |
| 3 | GitHub 저장소 → Add file → Upload files → 두 파일(+소스 묶음 zip) 끌어 놓기 → Commit changes | 목록에 파일 시간이 방금으로 바뀜 |
| 4 | 1~2분 뒤 두 폰 모두 앱을 완전히 닫았다 다시 열기 | — |
| 5 | 설정 > 진단 | 앱 V(새 버전) · 쇼츠 파일 “같음” |
| 6 | 한 폰에서 대변 1번 → 다른 폰에서 20초 안에 보임 → 빠른 수정으로 지우기 | 양쪽 0 |
| 7 | 문제가 있으면 2번에 보관한 두 파일을 3번 방법으로 다시 올리기 | 진단에 옛 버전 표시 |

---

## 7. 테스트 목록

| 파일 | 확인하는 것 |
|---|---|
| `structure.test.js` | 이름 중복 0, 뒤로가기 처리 1곳, history 직접 호출은 문지기 안에서만, 기본 confirm·prompt 0, 안 쓰는 함수 0, 버전 자리표시 남김 0, 두 파일 버전 일치 |
| `unit/engine.test.js` | 쇼츠 추천·구성·제목·중복 방지·시리즈 번호 계산 |
| `e2e_core` | 홈 기록·수정·삭제 → 새로고침 후 유지 → 서버 반영(급여 경고·수면·외출·유치원·목욕·체중·병원·지출·공지 포함) |
| `e2e_sync` | 두 폰 추가·삭제 공유, 끊김 후 재연결, 거의 동시 저장(D1) |
| `e2e_backup` | 텍스트·파일 백업, 파일 형식 붙여넣기(D2), 옛 백업 합치기 |
| `e2e_nav` | 탭·서재·사진 확대·시트·확인창 뒤로가기(D4) |
| `e2e_midnight` | 자정 넘긴 뒤 빠른 수정 삭제(D5) |
| `e2e_storage` | 폰 저장공간 가득 참 경고(R1) |
| `e2e_retention` | 100일 지난 기록 보존(R7) |
| `e2e_walk` | 산책 지도 기록 시작~저장~뒤로가기 |
| `e2e_v66` | 겹친 시트 뒤로가기, 사진 삭제 뒤 뒤로가기, 진단·복사, 그리기 보호, 파일 가져오기·되돌리기, 이름 묻기 시트, 버전 불일치 안내, 쇼츠 시트를 닫자마자 입력창 열기 |
| `e2e_visual` | 탭 21개 + 다크 3개 화면 모양(기준 사진과 0.5% 넘게 다르면 실패) |
| `e2e_album` · `e2e_regress` | 앨범 선택·확대·좋아요·메모·삭제·영상 업로드 |
| `e2e_look` · `e2e_look2` · `e2e_recs` · `e2e_edit` · `e2e_back` · `e2e_v651` · `e2e_two` · `e2e_del` · `e2e_del_look` | 쇼츠 화면·추천·편집·뒤로가기·두 폰·초안 삭제 |
| `e2e_make` · `e2e_clip` · `e2e_kocap` · `e2e_flow2` (`--full`) | 실제 MP4 만들기·영상 클립·한글 자막·초안→기록 흐름 |

시험 환경: 헤드리스 Chromium + 가짜 Firebase·가짜 Worker. 실제 서버 규칙·실제 폰(iOS Safari 등) 차이는 배포 후 6번 점검표로 확인합니다.

---

## 8. 알려진 한계

- 같은 칸을 두 폰에서 같은 때 다르게 고치면 나중 것이 남습니다(목록·날짜별 기록은 합쳐짐).
- 폰 저장공간은 브라우저 한도(약 5MB) 안에서만 씁니다. 설정 > 진단에서 사용량 확인.
- 테스트는 가짜 서버 기준입니다. Firebase 규칙(`handbook`·`chat` 경로 허용)은 콘솔에서 직접 확인합니다.

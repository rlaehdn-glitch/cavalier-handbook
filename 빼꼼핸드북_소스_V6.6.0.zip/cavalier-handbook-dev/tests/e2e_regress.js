/* 시나리오 13(일부): 기존 기능 회귀 — 탭 전환, 확대 화면 좋아요·메모·삭제, 영상 업로드, 보기 필터 */
const H = require('./harness');
const A = H.ASSETS;
(async () => {
  const dir = process.argv[2] || H.DIST;
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 20 });
  const { page } = await H.newPhone(b, { env, dir });
  page.on('dialog', d => d.accept());
  const res = { dir };
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  for (const t of ['cal', 'record', 'album', 'lib', 'stats', 'notice', 'settings', 'home', 'album']) {
    await page.evaluate(t => goTab(t), t); await page.waitForTimeout(700);
  }
  res.tabErrors = page.errors.slice();
  res.version = await page.evaluate(() => (document.body.innerText.match(/빼꼼 핸드북 V[\d.]+ · [\d-]+/) || [''])[0]);
  // 보기 필터
  for (const f of ['p', 'v', 'l', 'all']) { await page.click('.alb-chip[data-f="' + f + '"]'); await page.waitForTimeout(200); }
  res.cellsAll = await page.$$eval('#albGrid .alb-cell', e => e.length);
  // 확대 화면 · 좋아요
  const cells = await page.$$('#albGrid [data-open]');
  await cells[0].click(); await page.waitForTimeout(1000);
  const id = await page.evaluate(() => ALB.cur);
  await page.click('#albLbLike'); await page.waitForTimeout(800);
  res.liked = !!(env.db.get('/handbook/testfam01-album/meta/' + id + '/lk') || {})[await page.evaluate(() => DEV_ID)];
  // 메모 수정 (⋯ → 메모 수정 → 입력 → 저장)
  await page.click('#albLbMore'); await page.waitForTimeout(400);
  await page.click('#uiActs .sh-b1:nth-child(2)'); await page.waitForTimeout(400);
  await page.fill('#uiIn', '테스트 메모'); await page.click('#uiActs .sh-b1'); await page.waitForTimeout(900);
  res.memo = (env.db.get('/handbook/testfam01-album/meta/' + id) || {}).m;
  res.lbCap = await page.textContent('#albLbCap');
  await page.screenshot({ path: H.OUT + '40_lb_after.png' });
  // 다음 사진으로 넘기기
  await page.click('#albLbNext'); await page.waitForTimeout(800);
  res.navMoved = (await page.evaluate(() => ALB.cur)) !== id;
  // 삭제 (⋯ → 삭제 → 확인)
  const delId = await page.evaluate(() => ALB.cur);
  await page.click('#albLbMore'); await page.waitForTimeout(400);
  await page.click('#uiActs .sh-b1:nth-child(3)'); await page.waitForTimeout(700);
  await page.click('#uiSheet.on #uiActs .sh-b1'); await page.waitForTimeout(1500);   /* 앱 안 확인 시트의 '삭제' */
  res.deleted = !env.db.get('/handbook/testfam01-album/meta/' + delId);
  res.lbClosedAfterDel = await page.evaluate(() => !document.getElementById('albLb').classList.contains('on'));
  // 영상 업로드
  await page.evaluate(() => { const f = document.getElementById('mediaCfg'); if (f) f.open = false; });
  const vf = await page.$('#albVidFile');
  await vf.setInputFiles(A + 'clip_land.mp4');
  await page.waitForTimeout(6000);
  const meta = env.db.get('/handbook/testfam01-album/meta');
  const vids = Object.keys(meta).filter(k => meta[k].t === 'r' && meta[k].vs === require('fs').statSync(A + 'clip_land.mp4').size);
  res.videoUploaded = vids.length; res.videoMeta = vids.length ? meta[vids[0]] : null;
  res.errors = page.errors; res.logs = page.logs.filter(l => !/ERR_FAILED|404/.test(l));
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_regress');
  rep.eq('탭 오류 없음', res.tabErrors, []);
  rep.eq('앨범 칸 24개', res.cellsAll, 24);
  rep.eq('좋아요·메모', [res.liked, res.memo], [true, '테스트 메모']);
  rep.ok('확대 화면 메모 표시', String(res.lbCap).includes('테스트 메모'));
  rep.eq('넘기기·삭제', [res.navMoved, res.deleted, res.lbClosedAfterDel], [true, true, true]);
  rep.eq('영상 올리기', res.videoUploaded, 1);
  rep.eq('화면 오류 없음', [res.errors, res.logs], [[], []]);
  rep.end();
  await b.close();
})();

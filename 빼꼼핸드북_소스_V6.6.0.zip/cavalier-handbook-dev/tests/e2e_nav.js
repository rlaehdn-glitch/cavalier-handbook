/* 안전망 ④ 화면 이동·뒤로가기 — 탭 기록, 서재 장, 사진 확대, [D4] 시트·확인창 열린 채 뒤로가기 */
const H = require('./harness');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_nav');
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 8, videos: false, yt: 0 });
  const { page } = await H.newPhone(b, { env });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(3000);
  const st = () => page.evaluate(() => ({ tab: document.body.getAttribute('data-tab'), sheets: Array.from(document.querySelectorAll('.sheet-ovl.on, #qeOvl.on, #wtOvl.on, #sosOvl.on, #ntcOvl.on')).map((e) => e.id), lb: document.getElementById('albLb').classList.contains('on') }));
  const nav = async (t) => { await page.click('.bn-btn[data-tab="' + t + '"]'); await page.waitForTimeout(350); };
  const back = async () => { await page.goBack(); await page.waitForTimeout(600); };

  // 1) 탭 기록
  await nav('cal'); await nav('record');
  await back(); rep.eq('기록 → 뒤로 → 달력', (await st()).tab, 'cal');
  await back(); rep.eq('달력 → 뒤로 → 홈', (await st()).tab, 'home');
  // 2) 서재 → 01장 → 뒤로 → 서재
  await nav('lib'); await page.click('.lib-row[data-go="prep"]'); await page.waitForTimeout(400);
  rep.eq('서재 → 01장', (await st()).tab, 'prep');
  await back(); rep.eq('01장 → 뒤로 → 서재', (await st()).tab, 'lib');
  // 3) 앨범 사진 확대 → 뒤로 = 닫기
  await nav('album'); await page.waitForTimeout(1500);
  await page.click('#albGrid .alb-cell'); await page.waitForTimeout(800);
  rep.ok('사진 확대 열림', (await st()).lb);
  await back(); rep.eq('뒤로 → 확대만 닫힘(앨범 그대로)', await st(), { tab: 'album', sheets: [], lb: false });
  // 4) [D4] 목욕 시트 → 뒤로 = 시트 닫기
  await nav('cal'); await nav('home');
  await page.evaluate(() => bathOpen()); await page.waitForTimeout(300);
  await back(); rep.eq('[D4] 목욕 시트 → 뒤로 → 시트만 닫힘', await st(), { tab: 'home', sheets: [], lb: false }, 'defect');
  await page.evaluate(() => document.querySelectorAll('.sheet-ovl.on, #qeOvl.on, #wtOvl.on, #sosOvl.on, #ntcOvl.on').forEach((e) => e.classList.remove('on')));
  // 5) [D4] 확인창 → 뒤로 = 확인창 닫기
  await nav('record');
  await page.evaluate(() => { uiConfirm({ msg: '시험 확인창' }); }); await page.waitForTimeout(300);
  await back(); rep.eq('[D4] 확인창 → 뒤로 → 확인창만 닫힘', await st(), { tab: 'record', sheets: [], lb: false }, 'defect');
  await page.evaluate(() => { try { uiSheetClose({ ok: false }); } catch (e) { } document.querySelectorAll('.sheet-ovl.on, #qeOvl.on, #wtOvl.on, #sosOvl.on, #ntcOvl.on').forEach((e) => e.classList.remove('on')); });
  // 6) [D4] 빠른 수정 시트 → 뒤로 = 닫기
  await nav('home'); await page.click('#qlPoo span'); await page.waitForTimeout(300);
  await page.evaluate(() => qeOpen('count', 'poo', 0)); await page.waitForTimeout(300);
  await back(); rep.eq('[D4] 빠른 수정 → 뒤로 → 시트만 닫힘', await st(), { tab: 'home', sheets: [], lb: false }, 'defect');
  await page.evaluate(() => document.querySelectorAll('.sheet-ovl.on, #qeOvl.on, #wtOvl.on, #sosOvl.on, #ntcOvl.on').forEach((e) => e.classList.remove('on')));
  // 7) 시트를 닫기 버튼으로 닫은 뒤 뒤로 → 바로 이전 탭(남는 기록 칸 없음)
  await nav('cal'); await nav('home');
  await page.evaluate(() => bathOpen()); await page.waitForTimeout(300);
  await page.click('#bathClose'); await page.waitForTimeout(400);
  await back(); rep.eq('닫기 버튼으로 닫은 뒤 뒤로 → 이전 탭(달력)', (await st()).tab, 'cal');

  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

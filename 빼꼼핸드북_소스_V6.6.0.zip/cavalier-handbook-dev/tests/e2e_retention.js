/* 안전망 ⑦ [R7] 기록 보존 — 기록 있는 날이 100일을 넘어도 오래된 날이 지워지면 안 됨 */
const H = require('./harness');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_retention');
  const b = await H.launch();
  const env = H.newEnv();
  const { page } = await H.newPhone(b, { env });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  const first = await page.evaluate(() => {
    const d = new Date(); d.setDate(d.getDate() - 130);
    const keys = [];
    for (let i = 0; i < 120; i++) { const x = new Date(d.getTime() + i * 86400000); keys.push(x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0')); }
    S.qlog = {}; S.sleepLog = {}; S.walkLog = {}; S.awayLog = {};
    keys.forEach((k) => { S.qlog[k] = { poo: ['09:00:00|m'] }; S.sleepLog[k] = [{ o: Date.parse(k + 'T13:00:00'), i: Date.parse(k + 'T14:00:00') }]; S.walkLog[k] = [{ o: Date.parse(k + 'T08:00:00'), i: Date.parse(k + 'T08:30:00') }]; S.awayLog[k] = [{ o: Date.parse(k + 'T10:00:00'), i: Date.parse(k + 'T11:00:00') }]; });
    saveState(); renderAll(); return keys[0];
  });
  await page.click('#qlPoo span'); await page.waitForTimeout(300);
  await page.click('#qlSleep span'); await page.waitForTimeout(300); await page.click('#qlSleep span'); await page.waitForTimeout(500);
  const left = await page.evaluate((k) => ({ q: Object.keys(S.qlog).length, s: Object.keys(S.sleepLog).length, firstQ: !!S.qlog[k], firstS: !!S.sleepLog[k] }), first);
  rep.ok('[R7] 빠른 기록 120일 + 오늘 모두 남음 (' + left.q + '일)', left.q >= 121 && left.firstQ, 'defect');
  rep.ok('[R7] 수면 기록 120일 + 오늘 모두 남음 (' + left.s + '일)', left.s >= 121 && left.firstS, 'defect');
  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

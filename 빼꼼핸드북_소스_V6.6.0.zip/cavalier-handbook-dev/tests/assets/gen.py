from PIL import Image, ImageDraw, ImageFont
import random, json, os, base64, io, datetime
random.seed(7)
font = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc', 90)
small = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc', 40)
pal = [(214,160,120),(190,120,90),(232,200,170),(160,110,80),(240,220,200),(120,90,70),(200,170,140),(180,140,110)]
def make(i, w, h):
    bg = pal[i % len(pal)]
    im = Image.new('RGB', (w, h), bg)
    d = ImageDraw.Draw(im)
    # gradient stripes
    for y in range(0, h, 8):
        c = tuple(max(0, min(255, v + int(30 * (y / h) - 15))) for v in bg)
        d.rectangle([0, y, w, y + 8], fill=c)
    # "dog": head + ears + eyes
    cx, cy = w // 2 + random.randint(-w//8, w//8), h // 2 + random.randint(-h//10, h//10)
    r = min(w, h) // 4
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(250, 240, 228))
    d.ellipse([cx - r - r//2, cy - r//3, cx - r + r//3, cy + r], fill=(150, 80, 40))
    d.ellipse([cx + r - r//3, cy - r//3, cx + r + r//2, cy + r], fill=(150, 80, 40))
    d.ellipse([cx - r//2 - 18, cy - 20, cx - r//2 + 18, cy + 16], fill=(30, 20, 15))
    d.ellipse([cx + r//2 - 18, cy - 20, cx + r//2 + 18, cy + 16], fill=(30, 20, 15))
    d.ellipse([cx - 22, cy + r//3, cx + 22, cy + r//3 + 34], fill=(40, 25, 20))
    d.text((40, 40), 'P%02d' % i, fill=(255, 255, 255), font=font, stroke_width=4, stroke_fill=(0,0,0))
    d.text((40, h - 90), '%dx%d' % (w, h), fill=(255, 255, 255), font=small)
    return im
os.makedirs('photos', exist_ok=True)
items = []
for i in range(1, 37):
    portrait = (i % 3 != 0)
    w, h = (960, 1280) if portrait else (1280, 960)
    im = make(i, w, h)
    p = 'photos/p%02d.jpg' % i
    im.save(p, 'JPEG', quality=80)
    th = im.copy(); th.thumbnail((360, 360)); th.save('photos/p%02d_th.jpg' % i, 'JPEG', quality=70)
    items.append({'i': i, 'w': w, 'h': h})
json.dump(items, open('photos/index.json', 'w'))
# upload test photos with EXIF DateTimeOriginal
from PIL import Image as I2
for j, dt in enumerate(['2026:10:27 08:15:30', '2026:10:27 08:20:00', '2026:10:26 14:05:12']):
    im = make(50 + j, 3024 // 3, 4032 // 3)
    exif = im.getexif()
    exif[0x0132] = dt  # DateTime
    ifd = exif.get_ifd(0x8769)
    ifd[0x9003] = dt  # DateTimeOriginal
    exif[0x8769] = ifd
    im.save('photos/up%d.jpg' % (j + 1), 'JPEG', quality=85, exif=exif)
print('ok', len(items))

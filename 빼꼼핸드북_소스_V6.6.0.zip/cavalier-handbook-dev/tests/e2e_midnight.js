/* 안전망 ⑤ [D5] 자정 경계 — 빠른 수정 시트를 자정 전에 열고 자정 뒤 삭제하면 '연 날짜'의 기록이 지워져야 함 */
const H = require('./harness');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_midnight');
  const b = await H.launch();
  const env = H.newEnv();
  const { page } = await H.newPhone(b, { env });
  await page.clock.install({ time: new Date('2026-10-28T23:58:30+09:00') });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  const pee = (k) => page.evaluate((k) => (((S.qlog || {})[k] || {}).pee || []).length, k);
  await page.click('#qlPee span'); await page.waitForTimeout(300); await page.click('#qlPee span'); await page.waitForTimeout(300);
  rep.eq('10/28 소변 2건', await pee('2026-10-28'), 2);
  await page.evaluate(() => qeOpen('count', 'pee', 1)); await page.waitForTimeout(300);   // 10/28 두 번째 기록 수정 시트
  await page.clock.fastForward('02:00');                                                // → 10/29 00:00:30
  rep.eq('자정 지남', await page.evaluate(() => todayKey()), '2026-10-29');
  await page.evaluate(() => qlBump('pee', 1)); await page.waitForTimeout(300);            // 10/29 새 기록 1건
  await page.click('#qeDel'); await page.waitForTimeout(300);
  await page.click('#uiActs .sh-b1'); await page.waitForTimeout(600);
  rep.eq('[D5] 10/28 기록이 지워짐(2 → 1)', await pee('2026-10-28'), 1, 'defect');
  rep.eq('[D5] 10/29 기록은 그대로(1)', await pee('2026-10-29'), 1, 'defect');
  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

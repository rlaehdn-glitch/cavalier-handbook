/* 안전망 ② 두 폰 동기화 — 추가·삭제가 서로 보임, 끊겼다 이어지면 올라감, [D1] 거의 동시 저장 */
const H = require('./harness');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_sync');
  const b = await H.launch();
  const env = H.newEnv();
  const A = await H.newPhone(b, { env, name: '도우' });
  const B = await H.newPhone(b, { env, name: '가족' });
  await A.page.goto(H.BASE + '#home'); await B.page.goto(H.BASE + '#home');
  await A.page.waitForTimeout(2500); await B.page.waitForTimeout(500);
  const today = await A.page.evaluate(() => todayKey());
  const cnt = (p) => p.evaluate(() => { const d = (S.qlog || {})[todayKey()] || {}; const n = (k) => (Array.isArray(d[k]) ? d[k].length : 0); return { poo: n('poo'), pee: n('pee'), meal: n('meal') }; });
  const srv = () => { const s = env.db.get('/handbook/' + H.FAM) || {}; const d = ((s.qlog || {})[today]) || {}; const n = (k) => (Array.isArray(d[k]) ? d[k].length : 0); return { poo: n('poo'), pee: n('pee'), meal: n('meal') }; };
  const pull = async (p) => { await p.evaluate(() => syncPull()); await p.waitForTimeout(1500); };

  // 1) A 기록 → B에 보임
  await A.page.click('#qlPoo span'); await A.page.waitForTimeout(2500); await pull(B.page);
  rep.eq('A 대변 1 → B에 보임', (await cnt(B.page)).poo, 1);
  // 2) B 기록 → A에 보임
  await B.page.click('#qlPee span'); await B.page.waitForTimeout(2500); await pull(A.page);
  rep.eq('B 소변 1 → A에 보임', await cnt(A.page), { poo: 1, pee: 1, meal: 0 });
  // 3) B가 대변 삭제 → A에서도 삭제
  await B.page.evaluate(() => qeOpen('count', 'poo', 0)); await B.page.waitForTimeout(300);
  await B.page.click('#qeDel'); await B.page.waitForTimeout(300); await B.page.click('#uiActs .sh-b1'); await B.page.waitForTimeout(2500);
  await pull(A.page);
  rep.eq('B 삭제 → A에서도 삭제', (await cnt(A.page)).poo, 0);
  // 4) A 인터넷 끊김 → 식사 기록 → 다시 연결되면 올라감
  const PATH = '**/handbook/' + H.FAM + '.json';
  await A.page.route(PATH, (r) => r.abort());
  await A.page.click('#qlMeal span'); await A.page.waitForTimeout(3500);
  rep.eq('끊긴 동안 서버에 없음', srv().meal, 0);
  rep.ok('끊김 경고 표시', await A.page.evaluate(() => { const w = document.getElementById('syncWarn'); return !!w && w.style.display === 'block'; }));
  await A.page.unroute(PATH);
  await A.page.evaluate(() => window.dispatchEvent(new Event('online'))); await A.page.waitForTimeout(3500);
  rep.eq('다시 연결 → 서버에 올라감', srv().meal, 1);
  await pull(B.page);
  rep.eq('→ B에도 보임', (await cnt(B.page)).meal, 1);

  // 5) [D1] 거의 동시 저장: B 업로드가 1.5초 늦게 도착하는 사이 A가 올림 → 둘 다 남아야 함
  const before = await cnt(A.page);
  await B.page.route(PATH, async (route) => { if (route.request().method() === 'PUT') await new Promise((r) => setTimeout(r, 1500)); return route.fallback(); });
  await B.page.click('#qlPee span'); await B.page.waitForTimeout(800);
  await A.page.click('#qlPoo span'); await A.page.waitForTimeout(3500);
  await B.page.unroute(PATH);
  for (let i = 0; i < 3; i++) { await pull(A.page); await pull(B.page); }
  await A.page.waitForTimeout(2500); await pull(A.page); await pull(B.page);
  const want = { poo: before.poo + 1, pee: before.pee + 1, meal: before.meal };
  rep.eq('[D1] 동시 저장 → A 화면에 둘 다', await cnt(A.page), want, 'defect');
  rep.eq('[D1] 동시 저장 → B 화면에 둘 다', await cnt(B.page), want, 'defect');
  rep.eq('[D1] 동시 저장 → 서버에 둘 다', srv(), want, 'defect');

  rep.eq('화면 오류 없음', A.page.errors.concat(B.page.errors), []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

/* V6.5.1: 한글 자동 자막 없음 · 뜻 표시 · 추천 칩 · 폰 뒤로가기(시트 → 화면) */
const H = require('./harness');
const OUT = H.OUT;
async function stack(page) { return page.evaluate(() => ({ scr: Array.from(document.querySelectorAll('#sxRoot .sx-scr.on')).map(s => (s.querySelector('.sx-ttl') || s.querySelector('.sx-big') || {}).textContent), sheets: document.querySelectorAll('.sx-ovl.on').length, ui: document.getElementById('uiSheet').classList.contains('on') })); }
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 30 });
  // 메모 '내로가'가 붙은 사진을 일부 → 자동 자막으로 들어가면 안 됨
  const meta = env.db.get('/handbook/testfam01-album/meta'); Object.keys(meta).slice(0, 30).forEach((k, i) => { if (meta[k].t === 'p' && i % 3 === 0) { meta[k].m = '내로가'; meta[k].ts = '산책'; } });
  env.db.set('/handbook/testfam01-album/meta', meta);
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  const res = {};
  await page.click('#albSxBtn'); await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '80_home.png' });
  res.cardMean = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-rec .sx-mean')).map(e => e.textContent));
  await page.click('.sx-rec .go'); await page.waitForTimeout(2500);
  res.capsAuto = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-scr.on:last-child .sx-it .cp')).length);
  res.capCard = await page.textContent('.sx-scr.on:last-child .sx-capc');
  await page.screenshot({ path: OUT + '81_edit.png' });
  // 항목 시트 → 폰 뒤로가기 = 시트만 닫힘
  await page.click('.sx-scr.on:last-child .sx-it[data-i="2"] .im'); await page.waitForTimeout(700);
  await page.screenshot({ path: OUT + '82_item.png' });
  res.itemSugs = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-ovl.on .sx-sg .t')).map(e => e.textContent));
  await page.click('.sx-ovl.on [data-sug="산책 가자!"]').catch(() => {});
  await page.waitForTimeout(200);
  res.itemPicked = await page.inputValue('.sx-ovl.on [data-k="c"]');
  res.beforeBack1 = await stack(page);
  await page.goBack(); await page.waitForTimeout(700);
  res.afterBack1 = await stack(page);
  // 자막 시트 → 뜻 표시 · 추천 펼치기
  await page.click('.sx-scr.on:last-child .sx-capc'); await page.waitForTimeout(700);
  await page.click('.sx-ovl.on [data-tg="1"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '83_capsheet.png' });
  res.capMeans = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-ovl.on .sx-mean')).map(e => e.textContent).slice(0, 3));
  await page.click('.sx-ovl.on [data-act="ok"]'); await page.waitForTimeout(700);
  res.afterCapOk = await stack(page);
  // 다음 → 마무리 → 뒤로(폰) → 편집
  await page.click('.sx-scr.on:last-child [data-act="next"]'); await page.waitForTimeout(1500);
  await page.click('.sx-scr.on:last-child [data-act="kotg"]'); await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '84_fin.png', fullPage: false });
  await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); s[s.length - 1].scrollTo(0, 700); });
  await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '85_fin2.png' });
  res.finMeans = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-scr.on:last-child .sx-mean')).map(e => e.textContent));
  await page.click('.sx-scr.on:last-child [data-ko="오늘도 신나게 산책했어요"]').catch(() => {});
  await page.waitForTimeout(300);
  const rcpDe = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return s[s.length - 1].querySelector('.sx-desc') && s[s.length - 1].querySelector('.sx-desc').textContent; });
  res.descAfterKo = rcpDe;
  res.beforeBack2 = await stack(page);
  await page.goBack(); await page.waitForTimeout(800);
  res.afterBack2 = await stack(page);
  // 앱 안 확인창(uiPrompt) 열린 채 폰 뒤로가기 → 확인창만 닫힘
  await page.click('.sx-scr.on:last-child [data-act="next"]'); await page.waitForTimeout(1500);
  await page.click('.sx-scr.on:last-child [data-act="own"]'); await page.waitForTimeout(500);
  res.beforeBack3 = await stack(page);
  await page.goBack(); await page.waitForTimeout(700);
  res.afterBack3 = await stack(page);
  // 앱 안 뒤로 버튼 2번 → 홈
  await page.click('.sx-scr.on:last-child [data-act="back"]'); await page.waitForTimeout(700);
  await page.click('.sx-scr.on:last-child [data-act="back"]'); await page.waitForTimeout(700);
  res.afterInAppBack = await stack(page);
  res.histState = await page.evaluate(() => JSON.stringify(history.state));
  await page.goBack(); await page.waitForTimeout(800);
  res.afterBackHome = await stack(page);
  res.tab = await page.evaluate(() => document.body.getAttribute('data-tab'));
  res.errors = page.errors; res.logs = page.logs.filter(l => !/ERR_FAILED|404/.test(l));
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_v651');
  rep.eq('자동 한글 자막 없음', res.capsAuto, 0);
  rep.eq('장면 추천 칩 4종', res.itemSugs, ['추천 문구', '추천 문장', '사진 메모', '영문']);
  rep.eq('추천 칩 고르기', res.itemPicked, '산책 가자!');
  rep.eq('시트 → 폰 뒤로 → 시트만', [res.beforeBack1.sheets, res.afterBack1.sheets, res.afterBack1.scr], [1, 0, ['쇼츠', '구성 편집']]);
  rep.eq('마무리 → 폰 뒤로 → 편집', [res.beforeBack2.scr.length, res.afterBack2.scr], [3, ['쇼츠', '구성 편집']]);
  rep.eq('확인창 → 폰 뒤로 → 확인창만', [res.beforeBack3.ui, res.afterBack3.ui, res.afterBack3.scr.length], [true, false, 3]);
  rep.eq('앱 안 뒤로 2번 → 쇼츠 홈', res.afterInAppBack.scr, ['쇼츠']);
  rep.eq('폰 뒤로 → 앨범', [res.afterBackHome.scr, res.tab], [[], 'album']);
  rep.eq('화면 오류 없음', [res.errors, res.logs], [[], []]);
  rep.end();
  await b.close();
})();

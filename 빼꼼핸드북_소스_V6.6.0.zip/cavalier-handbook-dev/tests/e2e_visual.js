/* 안전망 ⑨ 화면 모양 비교 — 탭 21개(+다크 3개)를 같은 날짜·같은 데이터로 찍어 기준 사진과 비교
   node tests/e2e_visual.js base   → tests/visual-base/ 에 기준 사진 저장
   node tests/e2e_visual.js        → 기준과 비교(픽셀 차이 %) — 0.5% 넘으면 표시, 차이 사진은 tests/out/visual-diff/ */
const H = require('./harness');
const R = require('./lib/report');
const fs = require('fs'); const path = require('path'); const cp = require('child_process');
const TABS = ['home', 'cal', 'notice', 'prep', 'health', 'money', 'food', 'walk', 'work', 'neuter', 'record', 'settings', 'shop', 'place', 'emerg', 'behav', 'life', 'index', 'album', 'stats', 'lib'];
const DARK = ['home', 'record', 'settings'];
const BASE_DIR = path.join(__dirname, 'visual-base'), NOW_DIR = path.join(H.OUT, 'visual-now'), DIFF_DIR = path.join(H.OUT, 'visual-diff');
(async () => {
  const mode = process.argv[2] === 'base' ? 'base' : 'check';
  const rep = R.start('e2e_visual');
  const dir = mode === 'base' ? BASE_DIR : NOW_DIR; fs.mkdirSync(dir, { recursive: true }); fs.mkdirSync(DIFF_DIR, { recursive: true });
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 8, videos: false, yt: 0 });
  const st = { profile: { name: '빼꼼이', birth: '2026-05-20', home: '2026-07-25', reg: '' }, media: { url: H.MEDIA }, weight: [{ d: '2026-10-01', kg: '3.9' }, { d: '2026-10-15', kg: '4.4' }, { d: '2026-10-27', kg: '4.8' }],
    qlog: { '2026-10-28': { poo: ['08:10:00|m', '13:20:00|s'], pee: ['07:30:00', '11:00:00', '15:40:00'], meal: ['07:40:00', '12:30:00'] } } };
  const { page } = await H.newPhone(b, { env, state: st });
  await page.clock.setFixedTime(new Date('2026-10-28T16:00:00+09:00'));
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(3500);
  await page.addStyleTag({ content: '*{transition:none !important; animation:none !important; caret-color:transparent !important;}' });
  const shots = [];
  for (const t of TABS) { await page.evaluate((t) => { goTab(t, true); window.scrollTo(0, 0); }, t); await page.waitForTimeout(450); const f = 'light-' + t + '.png'; await page.screenshot({ path: path.join(dir, f) }); shots.push(f); }
  await page.emulateMedia({ colorScheme: 'dark' });
  for (const t of DARK) { await page.evaluate((t) => { goTab(t, true); window.scrollTo(0, 0); }, t); await page.waitForTimeout(450); const f = 'dark-' + t + '.png'; await page.screenshot({ path: path.join(dir, f) }); shots.push(f); }
  await b.close();
  if (mode === 'base') { rep.ok('기준 사진 ' + shots.length + '장 저장', true); rep.end(); return; }
  const py = "import sys\nfrom PIL import Image, ImageChops\na=Image.open(sys.argv[1]).convert('RGB'); b=Image.open(sys.argv[2]).convert('RGB')\nif a.size!=b.size: print('SIZE'); sys.exit()\nd=ImageChops.difference(a,b).convert('L').point(lambda v: 255 if v>16 else 0)\nn=d.histogram()[255]; print('%.3f'%(100.0*n/(a.size[0]*a.size[1])))\nif n: d.save(sys.argv[3])";
  for (const f of shots) {
    const bf = path.join(BASE_DIR, f); if (!fs.existsSync(bf)) { rep.ok(f + ' 기준 없음', false); continue; }
    const out = cp.execFileSync('python3', ['-c', py, bf, path.join(dir, f), path.join(DIFF_DIR, f)]).toString().trim();
    const pct = out === 'SIZE' ? 100 : parseFloat(out);
    const expected = (process.env.VISUAL_EXPECT || '').split(',').includes(f.replace(/^(light|dark)-|\.png$/g, ''));
    rep.ok(f + ' 차이 ' + out + '%' + (expected ? ' (바뀔 것으로 예상된 화면)' : ''), expected || pct <= 0.5);
  }
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

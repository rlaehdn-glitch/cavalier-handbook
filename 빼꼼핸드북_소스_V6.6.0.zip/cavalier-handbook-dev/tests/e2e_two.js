/* 시나리오 11: 두 폰이 같은 기록을 씀 — 두 번째 폰(B)에서 추천 시 첫 번째 폰(A)에서 올린 조합·사진 제외 */
const H = require('./harness');
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 36, videos: false, yt: 0 });
  const A = await H.newPhone(b, { env, dir: H.DIST, name: '도우', dev: 'dDOWOO01' });
  const B = await H.newPhone(b, { env, dir: H.DIST, name: '가족', dev: 'dFAM0002' });
  const res = {};
  await A.page.goto(H.BASE + '#album'); await A.page.waitForTimeout(3000);
  // A: 추천 첫 편을 '올렸어요'까지 (영상 만들기는 다른 테스트에서 확인 — 여기서는 기록 단계만)
  const up = await A.page.evaluate(async () => {
    const sx = await shLoad(); await sx.open('rec');
    await new Promise(r => setTimeout(r, 800));
    const RC = sx._RC, E = sx._E, D = sx._D;
    const g = RC.recs[0];
    const r = E.draft(g.sel, g.fm, { home: S.profile.home, today: todayKey(), recipes: D.rec });
    r.rid = sx._newRid(); r.sn = 7; r.de = E.descSn(r.de, 7);
    await sx._recPut(r.rid, JSON.parse(JSON.stringify(r)));
    await sx._markUp(r);
    return { ids: g.ids, fp: E.fpOf(g.ids), recs: RC.recs ? RC.recs.length : 0 };
  });
  res.A_uploaded = up.ids.length;
  // B: 새로 열기 → 추천 계산
  await B.page.goto(H.BASE + '#album'); await B.page.waitForTimeout(3500);
  const bInfo = await B.page.evaluate(async (up) => {
    const sx = await shLoad(); await sx.open('rec');
    await new Promise(r => setTimeout(r, 900));
    const recs = sx._RC.recs || [];
    const all = recs.flatMap(g => g.ids);
    const overlap = all.filter(id => up.ids.includes(id));
    const fps = recs.map(g => sx._E.fpOf(g.ids));
    const usedMeta = up.ids.map(id => ALB.meta[id] && (ALB.meta[id].su + '@' + ALB.meta[id].sl));
    // 기록 탭
    document.querySelector('.sx-scr.on .sx-seg [data-tab="log"]').click();
    await new Promise(r => setTimeout(r, 300));
    const logTxt = document.querySelector('.sx-scr.on .sx-pane').textContent;
    return { nRecs: recs.length, overlap: overlap.length, sameFp: fps.includes(up.fp), usedMeta, logTxt: logTxt.slice(0, 120), fpCount: Object.keys(sx._D.fp).length };
  }, up);
  Object.assign(res, bInfo);
  // B: 같은 조합을 직접 골라도 막힘 (다음 버튼 비활성 + 경고)
  const blocked = await B.page.evaluate(async (up) => {
    const sx = await shLoad();
    history.back(); await new Promise(r => setTimeout(r, 600));
    await sx.fromIds(up.ids); await new Promise(r => setTimeout(r, 1500));
    const scr = document.querySelectorAll('.sx-scr.on'); const top = scr[scr.length - 1];
    return { nextDisabled: top.querySelector('[data-act="next"]').disabled, warn: (top.querySelector('.ovw') || {}).textContent };
  }, up);
  Object.assign(res, blocked);
  res.errorsA = A.page.errors; res.errorsB = B.page.errors;
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_two');
  rep.eq('A 올림 → 사진 8장 사용 표시', [res.A_uploaded, res.usedMeta.length], [8, 8]);
  rep.eq('B 추천 2편 · A와 겹침 0', [res.nRecs, res.overlap, res.sameFp], [2, 0, false]);
  rep.eq('지문 1건', res.fpCount, 1);
  rep.eq('같은 조합 다시 만들기 막힘', [res.nextDisabled, res.warn], [true, '이 사진 조합은 이미 올렸어요. 사진을 바꾸거나 빼 주세요.']);
  rep.eq('화면 오류 없음', [res.errorsA, res.errorsB], [[], []]);
  rep.end();
  await b.close();
})();

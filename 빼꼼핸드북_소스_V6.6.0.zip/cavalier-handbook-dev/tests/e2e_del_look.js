/* V6.5.2 초안 목록 — 좁은 폰(360px)에서 줄바꿈·배치 확인 */
const H = require('./harness');
const E = require('../src/shorts/engine.js');
const OUT = H.OUT;
const FAM = H.FAM, TD = '2026-10-28', SP = '/handbook/' + FAM + '-shorts/';
(async () => {
  const rep = require('./lib/report').start('e2e_del_look');
  const b = await H.launch();
  const env = H.newEnv();
  const ids = H.seedAlbum(env, { n: 30 });
  const meta = env.db.get('/handbook/' + FAM + '-album/meta');
  const photos = ids.filter(id => meta[id].t === 'p');
  const sel = a => a.map(id => ({ id, m: meta[id], sc: E.score(meta[id], TD) }));
  function mk(i0, o) {
    const d = E.draft(sel(photos.slice(i0, i0 + 6)), o.fm || 'PHOTOS', { home: '2026-07-25', today: TD, recipes: {}, keepAll: true, src: 'pick' });
    const t = Date.now() - o.age * 86400000;
    return Object.assign(d, { st: 'draft', at: t, ut: t, by: o.by || '도우' }, o.x || {});
  }
  env.db.set(SP + 'cfg', { mig1: 1, nsn: 14 });
  env.db.set(SP + 'r', {
    rA: mk(0, { age: 1 }),
    rB: mk(6, { age: 2, by: '가족', x: { sn: 12, mk: Date.now() } }),
    rC: mk(12, { age: 9, fm: 'TRUST', x: { sn: 13 } })
  });
  for (const w of [360, 412]) {
    const { page, ctx } = await H.newPhone(b, { env, dir: H.DIST, viewport: { width: w, height: 800 } });
    await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
    await page.click('#albSxBtn'); await page.waitForTimeout(1500);
    await page.screenshot({ path: OUT + '96_list_' + w + '.png' });
    await page.click('[data-act="dedit"]'); await page.waitForTimeout(300);
    await page.screenshot({ path: OUT + '97_edit_' + w + '.png' });
    const ov = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-draft')).map(r => ({ w: r.scrollWidth, cw: r.clientWidth, h: Math.round(r.getBoundingClientRect().height) })));
    console.log(w, JSON.stringify(ov), 'errors', page.errors.length);
    rep.ok(w + 'px 목록 가로 넘침 없음', ov.length === 3 && ov.every(o => o.w <= o.cw));
    rep.eq(w + 'px 화면 오류 없음', page.errors, []);
    await ctx.close();
  }
  await b.close();
  rep.end();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

/* 나중에 → 초안 → 이어서 만들기 → 올렸어요 → 기록 → 링크 붙여넣기(앨범 유튜브 카드) + 눕혀 저장(회전) 경로 + 설정 */
const H = require('./harness');
const fs = require('fs');
const OUT = H.OUT;
async function grab(page, path) {
  const b64 = await page.evaluate(async () => {
    const v = document.querySelector('.sx-done video'); const r = await fetch(v.src); const u8 = new Uint8Array(await r.arrayBuffer());
    let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s);
  });
  fs.writeFileSync(path, Buffer.from(b64, 'base64'));
}
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 12, videos: false, yt: 0 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  const res = {};
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  const two = await page.evaluate(() => Object.keys(ALB.meta).filter(k => ALB.meta[k].t === 'p').slice(0, 2));
  await page.evaluate((two) => shLoad().then(sx => { sx._R.FORCE = { rot: 90 }; return sx.fromIds(two); }), two);
  await page.waitForTimeout(2500);
  await page.click('.sx-scr.on [data-act="next"]'); await page.waitForTimeout(1200);
  let t0 = Date.now();
  await page.click('[data-act="make"]');
  await page.waitForSelector('.sx-done video', { timeout: 200000 });
  res.renderRot = (Date.now() - t0) / 1000;
  await grab(page, H.OUT + 'out_rot.mp4');
  res.upInfo = await page.textContent('.sx-done');
  await page.click('[data-act="later"]'); await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '60_drafts.png' });
  res.draftCard = await page.evaluate(() => { const d = document.querySelector('.sx-scr.on [data-draft]'); return d && d.textContent; });
  const draftRec = env.db.get('/handbook/testfam01-shorts/r'); res.draftSt = Object.values(draftRec || {}).map(r => r.st + ':' + r.sn);
  // 이어서 만들기
  await page.click('.sx-scr.on [data-draft]'); await page.waitForTimeout(2500);
  res.resumedItems = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return s[s.length - 1].querySelectorAll('.sx-it').length; });
  await page.evaluate(() => { SHORTS._R.FORCE = null; });
  await page.click('.sx-scr.on:last-of-type [data-act="next"]'); await page.waitForTimeout(1200);
  t0 = Date.now();
  await page.click('[data-act="make"]');
  await page.waitForSelector('.sx-done video', { timeout: 200000 });
  res.render2 = (Date.now() - t0) / 1000;
  await page.click('[data-act="done"]'); await page.waitForTimeout(1500);
  const recs = env.db.get('/handbook/testfam01-shorts/r');
  res.afterUp = Object.values(recs).map(r => r.st + ':' + r.sn);
  res.oneRecipe = Object.keys(recs).length === 1;
  // 기록 → 링크 붙여넣기
  await page.click('.sx-scr.on [data-log]'); await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '61_log_sheet.png' });
  await page.click('.sx-ovl.on [data-act="link"]'); await page.waitForTimeout(600);
  await page.fill('#uiIn', 'https://youtube.com/shorts/AbCdEfGhIjK?si=xyz'); await page.click('#uiActs .sh-b1'); await page.waitForTimeout(1500);
  const meta = env.db.get('/handbook/testfam01-album/meta');
  res.ytCard = Object.values(meta).filter(m => m.t === 'v').map(m => m.u + ' | ' + m.m);
  res.recLink = Object.values(env.db.get('/handbook/testfam01-shorts/r')).map(r => r.yu);
  await page.screenshot({ path: OUT + '62_log_linked.png' });
  // 설정
  await page.click('.sx-scr.on [data-act="set"]'); await page.waitForTimeout(1800);
  await page.screenshot({ path: OUT + '63_settings.png', fullPage: false });
  res.settingsOpen = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return s[s.length - 1].textContent.includes('쇼츠 설정'); });
  res.errors = page.errors; res.logs = page.logs.filter(l => !/ERR_FAILED|404/.test(l));
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_flow2');
  rep.eq('초안 저장', res.draftSt, ['draft:1']);
  rep.eq('초안 이어서 열기', res.resumedItems, 2);
  rep.eq('올렸어요 → 기록', [res.afterUp, res.oneRecipe], [['up:1'], true]);
  rep.eq('링크 붙여넣기 → 앨범 카드', [res.ytCard.length, res.recLink.length], [1, 1]);
  rep.ok('설정 열림', res.settingsOpen);
  rep.eq('화면 오류 없음', [res.errors, res.logs], [[], []]);
  rep.end();
  await b.close();
})();

/* 안전망 ① 본체 기록 기능 — 한 폰에서 기록·수정·삭제 → 새로고침 후 유지 → 서버에도 올라감
   (V6.5.2 동작을 기준으로 고정. [결함] 표시는 V6.6에서 고친 뒤 통과해야 하는 항목) */
const H = require('./harness');
const assert = require('assert');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_core');
  const b = await H.launch();
  const env = H.newEnv();
  const { page } = await H.newPhone(b, { env });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  const q = () => page.evaluate(() => { const d = (S.qlog || {})[todayKey()] || {}; const n = (k) => (Array.isArray(d[k]) ? d[k].length : 0); return { poo: n('poo'), pee: n('pee'), meal: n('meal'), diar: n('diar') }; });
  const sheet = () => page.evaluate(() => ({ on: document.getElementById('uiSheet').classList.contains('on'), m: document.getElementById('uiM').textContent }));

  // 1) 빠른 기록 — 글자 부분을 탭
  await page.click('#qlPoo span'); await page.click('#qlPee span'); await page.click('#qlPee span'); await page.click('#qlDiar span');
  await page.click('#qlMeal span'); await page.waitForTimeout(400);
  rep.eq('빠른 기록 4종', await q(), { poo: 1, pee: 2, meal: 1, diar: 1 });
  rep.eq('홈 숫자 표시', await page.evaluate(() => ['qlPooN', 'qlPeeN', 'qlMealN', 'qlDiarN'].map(i => document.getElementById(i).textContent)), ['1', '2', '1', '1']);

  // 2) 식사 2시간 안 중복 경고 — 글자 탭 → 계속
  await page.click('#qlMeal span'); await page.waitForTimeout(300);
  rep.ok('중복 급여 경고 시트', (await sheet()).m.includes('중복 급여'));
  await page.click('#uiActs .sh-b1'); await page.waitForTimeout(500);
  rep.eq('경고 후 계속 → 식사 2', (await q()).meal, 2);

  // 3) [결함 D3] 같은 경고를 아이콘으로 시작 → 계속 → 기록돼야 함
  const ib = await page.locator('#qlMeal svg').boundingBox();
  await page.mouse.click(ib.x + ib.width / 2, ib.y + ib.height / 2); await page.waitForTimeout(400);
  await page.click('#uiActs .sh-b1'); await page.waitForTimeout(600);
  rep.eq('[D3] 아이콘 탭 → 계속 → 식사 3', (await q()).meal, 3, 'defect');

  // 4) 수면 시작·끝
  await page.click('#qlSleep span'); await page.waitForTimeout(300);
  rep.ok('수면 시작', await page.evaluate(() => S.sleepCur > 0));
  await page.click('#qlSleep span'); await page.waitForTimeout(500);
  if ((await sheet()).on) { await page.click('#uiActs .sh-b1'); await page.waitForTimeout(400); }
  rep.eq('수면 끝 → 기록 1건', await page.evaluate(() => ({ cur: S.sleepCur, n: (((S.sleepLog || {})[todayKey()]) || []).length })), { cur: 0, n: 1 });

  // 5) 외출(혼자) 시작·귀가
  await page.click('#qlAway span'); await page.waitForTimeout(400);
  if ((await sheet()).on) { await page.click('#uiActs .sh-b1'); await page.waitForTimeout(300); }
  const awayStarted = await page.evaluate(() => S.awayCur > 0);
  rep.ok('외출 시작', awayStarted);
  await page.click('#qlAway span'); await page.waitForTimeout(400);
  if ((await sheet()).on) { await page.click('#uiActs .sh-b1'); await page.waitForTimeout(300); }
  rep.eq('귀가 → 외출 기록 1건', await page.evaluate(() => ({ cur: S.awayCur, n: (((S.awayLog || {})[todayKey()]) || []).length })), { cur: 0, n: 1 });

  // 6) 유치원 등원 → 하원 시트 저장
  await page.click('#qlKg span'); await page.waitForTimeout(400);
  if ((await sheet()).on) { await page.click('#uiActs .sh-b1'); await page.waitForTimeout(300); }
  rep.ok('등원', await page.evaluate(() => S.kgCur > 0));
  /* 등원을 90분 전으로(같은 날 안에서) — 같은 분에 하원하면 '등원이 하원보다 늦을 수 없습니다' */
  await page.evaluate(() => { const d0 = new Date(); d0.setHours(0, 1, 0, 0); S.kgCur = Math.max(d0.getTime(), Date.now() - 90 * 60000); saveState(); renderAll(); });
  await page.click('#qlKg span'); await page.waitForTimeout(400);
  rep.ok('하원 시트 열림', await page.evaluate(() => document.getElementById('kgOvl').classList.contains('on')));
  await page.click('#kgSave'); await page.waitForTimeout(500);
  const kgAlert = await sheet(); if (kgAlert.on) { console.log('    (하원 저장 안내: ' + kgAlert.m + ')'); await page.click('#uiActs .sh-b1'); await page.waitForTimeout(300); }
  rep.eq('하원 저장 → 유치원 기록 1건', await page.evaluate(() => ({ cur: S.kgCur, n: (((S.kgLog || {})[todayKey()]) || []).length })), { cur: 0, n: 1 });

  // 7) 목욕 — 오늘 기록
  await page.evaluate(() => bathOpen()); await page.waitForTimeout(300);
  await page.click('#bathToday'); await page.waitForTimeout(400);
  rep.ok('목욕 오늘 기록', await page.evaluate(() => !!bathLog()[todayKey()]));
  await page.evaluate(() => { const c = document.getElementById('bathClose'); if (c) c.click(); }); await page.waitForTimeout(300);

  // 8) 빠른 수정 시트 — 소변 1건 삭제(확인)
  await page.evaluate(() => qeOpen('count', 'pee', 0)); await page.waitForTimeout(300);
  await page.click('#qeDel'); await page.waitForTimeout(300);
  await page.click('#uiActs .sh-b1'); await page.waitForTimeout(500);
  rep.eq('빠른 수정 → 소변 삭제', (await q()).pee, 1);

  // 9) 기록 탭 — 체중·병원·지출
  await page.evaluate(() => goTab('record')); await page.waitForTimeout(300);
  await page.fill('#wKg', '5.23'); await page.click('#wAdd'); await page.waitForTimeout(300);
  await page.fill('#vMemo', '접종'); await page.click('#vAdd'); await page.waitForTimeout(300);
  await page.fill('#eAmt', '12000'); await page.fill('#eMemo', '사료'); await page.click('#eAdd'); await page.waitForTimeout(300);
  rep.eq('체중·병원·지출', await page.evaluate(() => ({ w: S.weight.map(x => x.kg), v: S.visits.length, e: S.expenses.length })), { w: ['5.23'], v: 1, e: 1 });

  // 10) 공지 작성
  await page.evaluate(() => { goTab('notice'); }); await page.waitForTimeout(300);
  await page.click('#segNtc').catch(() => {}); await page.waitForTimeout(200);
  await page.fill('#ntcText', '시험 공지'); await page.click('#ntcSave'); await page.waitForTimeout(400);
  rep.ok('공지 저장', await page.evaluate(() => (S.ntc || []).some(n => n.text === '시험 공지')));

  // 11) 새로고침 → 그대로 · 서버에도 올라감
  await page.waitForTimeout(2500);
  const before = await page.evaluate(() => JSON.stringify({ q: S.qlog, w: S.weight, n: (S.ntc || []).length, b: S.bathLog }));
  await page.reload(); await page.waitForTimeout(2500);
  const after = await page.evaluate(() => JSON.stringify({ q: S.qlog, w: S.weight, n: (S.ntc || []).length, b: S.bathLog }));
  rep.eq('새로고침 후 유지', after, before);
  const srv = env.db.get('/handbook/' + H.FAM) || {};
  rep.eq('서버 반영(체중·공지)', { w: (srv.weight || []).map(x => x.kg), n: (srv.ntc || []).length }, { w: ['5.23'], n: 1 });
  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

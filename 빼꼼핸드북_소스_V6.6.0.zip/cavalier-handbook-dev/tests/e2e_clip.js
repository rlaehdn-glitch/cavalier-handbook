/* 영상 클립이 들어간 편: 첫 2초 클립(ATTACK이면 0.5배속) + 사진, 원본 소리 섞기 경로(테스트용 opus) */
const H = require('./harness');
const fs = require('fs');
const OUT = H.OUT;
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); const ids = H.seedAlbum(env, { n: 12, videos: true });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album');
  await page.waitForTimeout(3000);
  await page.evaluate(() => window.SHORTS || null);
  const pick = await page.evaluate(() => {
    const m = ALB.meta; const v = Object.keys(m).filter(k => m[k].t === 'r');
    const p = Object.keys(m).filter(k => m[k].t === 'p').slice(0, 6);
    return [v[0], v[2]].concat(p);   // 소리 있는 세로 클립 + 소리 없는 클립 + 사진 6
  });
  await page.evaluate((pick) => shLoad().then(sx => { sx._R.AC = { enc: 'opus', mux: 'opus' }; return sx.fromIds(pick); }), pick);
  await page.waitForTimeout(3500);
  await page.screenshot({ path: OUT + '20_clip_edit.png' });
  const info = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return s.length; });
  await page.click('[data-act="next"]');
  await page.waitForTimeout(1200);
  const t0 = Date.now();
  await page.click('[data-act="make"]');
  await page.waitForSelector('.sx-done video', { timeout: 400000 });
  const secs = (Date.now() - t0) / 1000;
  await page.waitForTimeout(600);
  await page.screenshot({ path: OUT + '21_clip_up.png' });
  const b64 = await page.evaluate(async () => {
    const v = document.querySelector('.sx-done video'); const r = await fetch(v.src); const u8 = new Uint8Array(await r.arrayBuffer());
    let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s);
  });
  fs.writeFileSync(H.OUT + 'out_clip.mp4', Buffer.from(b64, 'base64'));
  const sub = await page.textContent('.sx-done');
  fs.writeFileSync(H.OUT + 'clip_result.json', JSON.stringify({ secs, sub, errors: page.errors, logs: page.logs.filter(l => !/ERR_FAILED|404/.test(l)), mediaReqs: env.media.reqs.filter(r => /\/file\/v\//.test(r)).length }, null, 1));
  const rep = require('./lib/report').start('e2e_clip');
  rep.ok('클립 + 원본 소리 포함 영상', String(sub).includes('영상 원본 소리 포함'));
  rep.eq('화면 오류 없음', page.errors, []);
  rep.end();
  await b.close();
})().catch(e => { fs.writeFileSync(H.OUT + 'clip_result.json', JSON.stringify({ fatal: String(e && e.stack || e) })); process.exit(1); });

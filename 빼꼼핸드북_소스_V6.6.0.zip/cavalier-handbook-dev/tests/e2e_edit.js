/* 구성 편집: 사진 추가(고르기 화면), 끌어서 순서 바꾸기(마우스), 포맷 바꾸기, 항목 빼기, 자막 수정 반영 */
const H = require('./harness');
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 16, videos: false, yt: 0 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  const ids = await page.evaluate(() => Object.keys(ALB.meta).slice(0, 4));
  await page.evaluate((ids) => shLoad().then(sx => sx.fromIds(ids)), ids);
  await page.waitForTimeout(2500);
  const top = () => page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return s.length; });
  const order = () => page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return Array.from(s[s.length - 1].querySelectorAll('.sx-it img')).map(i => i.getAttribute('data-th')); });
  const res = {};
  res.o0 = await order();
  // 사진 추가
  await page.click('.sx-scr.on [data-act="add"]'); await page.waitForTimeout(1200);
  const gcs = await page.$$('.sx-scr.on:last-child .sx-gc:not([data-have])');
  await gcs[0].click(); await gcs[1].click();
  res.addLabel = await page.textContent('.sx-scr.on:last-child [data-act="done"]');
  await page.click('.sx-scr.on:last-child [data-act="done"]'); await page.waitForTimeout(1200);
  res.o1 = await order();
  // 마우스로 1번을 3번 뒤로 끌기
  const its = await page.$$('.sx-scr.on .sx-it');
  const b0 = await its[0].boundingBox(), b3 = await its[3].boundingBox();
  await page.mouse.move(b0.x + 30, b0.y + 40); await page.mouse.down();
  await page.mouse.move(b0.x + 60, b0.y + 40, { steps: 3 });
  await page.mouse.move(b3.x + b3.width * 0.8, b3.y + 40, { steps: 8 });
  await page.mouse.up(); await page.waitForTimeout(800);
  res.o2 = await order();
  // 포맷 바꾸기 → TRUST: 가운데 사진 2.5초
  await page.click('.sx-scr.on [data-fm="TRUST"]'); await page.waitForTimeout(600);
  res.durs = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-scr.on .sx-it .du')).map(d => d.textContent));
  res.len = await page.textContent('.sx-scr.on .sx-len .lt');
  // 항목 빼기
  await page.click('.sx-scr.on .sx-it[data-i="1"] .im'); await page.waitForTimeout(600);
  await page.click('.sx-ovl.on [data-act="del"]'); await page.waitForTimeout(700);
  res.o3 = (await order()).length;
  // 자막 수정
  await page.click('.sx-scr.on [data-act="cap"]'); await page.waitForTimeout(500);
  await page.fill('.sx-ovl.on [data-k="hk"]', 'Custom hook'); await page.fill('.sx-ovl.on [data-i="0"]', '첫 장 자막');
  await page.click('.sx-ovl.on [data-act="ok"]'); await page.waitForTimeout(800);
  res.capMark = await page.evaluate(() => !!document.querySelector('.sx-scr.on .sx-it[data-i="0"] .cp'));
  // 다음 → 마무리 → 저장된 초안 확인
  await page.click('.sx-scr.on [data-act="next"]'); await page.waitForTimeout(1500);
  const r = Object.values(env.db.get('/handbook/testfam01-shorts/r') || {})[0] || {};
  res.saved = { st: r.st, fm: r.fm, n: (r.it || []).length, hk: r.hk, c0: r.it && r.it[0].c };
  res.finHook = await page.evaluate(() => (document.querySelector('.sx-scr.on:last-child') || document.body).textContent.match(/영상 맨 위 자막: [^설]*/) + '');
  res.errors = page.errors;
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_edit');
  rep.eq('사진 추가 버튼', res.addLabel, '추가 (2)');
  rep.eq('장면 길이', res.durs, ['3.0초', '2.5초', '2.5초', '2.5초', '2.5초', '3.0초']);
  rep.eq('전체 길이', res.len, '길이 16.0초');
  rep.eq('삭제 후 5장', res.o3, 5);
  rep.ok('자막 표시', res.capMark);
  rep.eq('초안 저장 내용', res.saved, { st: 'draft', fm: 'TRUST', n: 5, hk: 'Custom hook', c0: '첫 장 자막' });
  rep.eq('화면 오류 없음', res.errors, []);
  rep.end();
  await b.close();
})();

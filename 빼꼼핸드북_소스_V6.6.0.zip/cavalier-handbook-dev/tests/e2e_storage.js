/* 안전망 ⑥ [R1] 폰 저장공간이 가득 찼을 때 — 기록은 서버로 가더라도, 이 폰 저장 실패를 화면에 알려야 함 */
const H = require('./harness');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_storage');
  const b = await H.launch();
  const env = H.newEnv();
  const { page } = await H.newPhone(b, { env });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  const filled = await page.evaluate(() => {   /* 남는 공간이 1글자도 없도록 큰 조각 → 작은 조각 순서로 채움 */
    let n = 0;
    for (const size of [262144, 8192, 512, 16, 1]) { const chunk = 'x'.repeat(size); for (let i = 0; i < 5000; i++) { try { localStorage.setItem('__junk' + size + '_' + i, chunk); n++; } catch (e) { break; } } }
    return n;
  });
  rep.ok('저장공간 채움 (' + filled + ')', true);
  await page.click('#qlPoo span'); await page.waitForTimeout(2500);
  rep.ok('기록은 화면에 있음', await page.evaluate(() => ((((S.qlog || {})[todayKey()] || {}).poo) || []).length === 1));
  const saved = await page.evaluate(() => { try { const r = JSON.parse(localStorage.getItem('ckcs-data') || '{}'); return ((((r.qlog || {})[todayKey()] || {}).poo) || []).length; } catch (e) { return -1; } });
  rep.eq('이 폰 저장은 실패(공간 없음)', saved, 0);
  rep.ok('[R1] 저장 실패 경고가 화면에 보임', await page.evaluate(() => { const w = document.getElementById('lsWarn'); return !!w && getComputedStyle(w).display !== 'none'; }), 'defect');
  await page.evaluate(() => { Object.keys(localStorage).filter((k) => k.startsWith('__junk')).forEach((k) => localStorage.removeItem(k)); });
  await page.click('#qlPee span'); await page.waitForTimeout(1500);
  rep.ok('[R1] 공간이 생기면 다시 저장되고 경고가 사라짐', await page.evaluate(() => { const w = document.getElementById('lsWarn'); const r = JSON.parse(localStorage.getItem('ckcs-data') || '{}'); return (!w || getComputedStyle(w).display === 'none') && ((((r.qlog || {})[todayKey()] || {}).poo) || []).length === 1; }), 'defect');
  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

/* 앨범 확대 화면의 [쇼츠] 버튼 → 그 사진으로 쇼츠 편집이 열리는지 */
const H = require('./harness');
const OUT = H.OUT;
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 30 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  await page.screenshot({ path: OUT + '50_album.png', clip: { x: 0, y: 380, width: 390, height: 230 } });
  await page.evaluate(() => window.scrollTo(0, 650));
  const c = await page.$$('#albGrid [data-open]'); await c[1].click(); await page.waitForTimeout(1200);
  await page.screenshot({ path: OUT + '51_lb.png' });
  await page.click('#albLbSx'); await page.waitForTimeout(3500);
  await page.screenshot({ path: OUT + '52_edit.png' });
  const rep = require('./lib/report').start('e2e_look2');
  rep.ok('확대 화면 → 쇼츠 편집 열림', await page.evaluate(() => !!document.querySelector('.sx-scr.on .sx-strip')));
  rep.eq('화면 오류 없음', page.errors, []);
  rep.end();
  await b.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

/* V6.5.2: 만들다 만 쇼츠(초안) 삭제 · 기록으로 옮기기 · 시리즈 번호 회수 */
const H = require('./harness');
const E = require('../src/shorts/engine.js');
const assert = require('assert');
const OUT = H.OUT;
const FAM = H.FAM, TD = '2026-10-28';
const SP = '/handbook/' + FAM + '-shorts/';
function ui(page) { return page.evaluate(() => ({ on: document.getElementById('uiSheet').classList.contains('on'), t: document.getElementById('uiT').textContent, m: document.getElementById('uiM').textContent, acts: Array.from(document.querySelectorAll('#uiActs .sh-b1')).map(b => b.textContent + (b.classList.contains('destr') ? '(red)' : '')) })); }
function rows(page) { return page.evaluate(() => Array.from(document.querySelectorAll('.sx-home .sx-draft')).map(r => r.dataset.draft + ' | ' + r.querySelector('.sx-sub').textContent)); }
function scrs(page) { return page.evaluate(() => Array.from(document.querySelectorAll('#sxRoot .sx-scr.on')).map(s => (s.querySelector('.sx-ttl') || s.querySelector('.sx-big') || {}).textContent)); }
(async () => {
  const b = await H.launch();
  const env = H.newEnv();
  const ids = H.seedAlbum(env, { n: 30 });
  const meta = env.db.get('/handbook/' + FAM + '-album/meta');
  const photos = ids.filter(id => meta[id].t === 'p');
  const sel = a => a.map(id => ({ id, m: meta[id], sc: E.score(meta[id], TD) }));
  function mk(i0, o) {
    const d = E.draft(sel(photos.slice(i0, i0 + 6)), 'PHOTOS', { home: '2026-07-25', today: TD, recipes: {}, keepAll: true, src: 'pick' });
    const t = Date.now() - o.age * 86400000;
    return Object.assign(d, { st: 'draft', at: t, ut: t, by: o.by || '도우', ti: o.ti }, o.x || {});
  }
  env.db.set(SP + 'cfg', { mig1: 1, nsn: 14 });
  env.db.set(SP + 'r', {
    rA: mk(0, { age: 1, ti: 'Draft A' }),
    rB: mk(6, { age: 2, ti: 'Draft B', by: '가족', x: { sn: 12, mk: Date.now() - 2 * 86400000 } }),
    rC: mk(12, { age: 3, ti: 'Draft C', x: { sn: 13 } }),
    rU: Object.assign(mk(18, { age: 5, ti: 'Uploaded' }), { st: 'up', sn: 11, up: Date.now() - 5 * 86400000, mo: 'A' })
  });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  const res = {};
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  await page.click('#albSxBtn'); await page.waitForTimeout(1500);
  res.rows0 = await rows(page);
  res.normal = await page.evaluate(() => ({ edit: (document.querySelector('[data-act="dedit"]') || {}).textContent, ddel: document.querySelectorAll('[data-ddel]').length, delall: !!document.querySelector('[data-act="delall"]'), pills: Array.from(document.querySelectorAll('.sx-draft .sx-badge')).map(e => e.textContent) }));
  assert.strictEqual(res.normal.ddel, 0); assert.strictEqual(res.normal.edit, '편집');
  await page.screenshot({ path: OUT + '90_drafts.png' });
  await page.click('[data-act="dedit"]'); await page.waitForTimeout(300);
  res.editMode = await page.evaluate(() => ({ btns: Array.from(document.querySelectorAll('.sx-row .sx-acts button')).map(e => e.textContent), ddel: document.querySelectorAll('[data-ddel]').length }));
  assert.strictEqual(res.editMode.ddel, 3);
  await page.screenshot({ path: OUT + '90b_edit.png' });
  // 편집 중 행을 눌러도 열리지 않음
  await page.click('[data-draft="rA"] .t1'); await page.waitForTimeout(600);
  res.rowTapInEdit = await scrs(page);
  assert.deepStrictEqual(res.rowTapInEdit, ['쇼츠']);

  // 1) 번호 없는 초안 삭제
  await page.click('[data-ddel="rA"]'); await page.waitForTimeout(500);
  res.askA = await ui(page);
  await page.screenshot({ path: OUT + '91_confirm.png' });
  await page.click('#uiActs .sh-b1.destr'); await page.waitForTimeout(1500);
  res.dbA = { rA: env.db.get(SP + 'r/rA'), nsn: env.db.get(SP + 'cfg/nsn'), fsn: env.db.get(SP + 'cfg/fsn') };
  assert.strictEqual(res.dbA.rA, null); assert.strictEqual(res.dbA.nsn, 14);

  // 2) 맨 끝 번호(#13) 초안 삭제 → nsn 13으로 되돌림
  await page.click('[data-ddel="rC"]'); await page.waitForTimeout(500);
  res.askC = await ui(page);
  await page.click('#uiActs .sh-b1.destr'); await page.waitForTimeout(1500);
  res.dbC = { rC: env.db.get(SP + 'r/rC'), nsn: env.db.get(SP + 'cfg/nsn'), fsn: env.db.get(SP + 'cfg/fsn') };
  assert.strictEqual(res.dbC.rC, null); assert.strictEqual(res.dbC.nsn, 13); assert.strictEqual(res.dbC.fsn, null);

  // 3) 영상까지 만든 다른 폰 초안 → '기록으로 옮기기'
  await page.click('[data-ddel="rB"]'); await page.waitForTimeout(500);
  res.askB = await ui(page);
  await page.screenshot({ path: OUT + '92_made.png' });
  await page.click('#uiActs .sh-b1:not(.destr)'); await page.waitForTimeout(2000);
  const rB = env.db.get(SP + 'r/rB');
  res.dbB = { st: rB && rB.st, sn: rB && rB.sn, fp: rB && !!env.db.get(SP + 'fp/' + rB.fp), nsn: env.db.get(SP + 'cfg/nsn'), su: rB && rB.it.map(x => env.db.get('/handbook/' + FAM + '-album/meta/' + x.id + '/su')) };
  assert.strictEqual(res.dbB.st, 'up'); assert.strictEqual(res.dbB.nsn, 13); assert(res.dbB.fp);
  res.rows1 = await rows(page);
  await page.click('.sx-home .sx-seg [data-tab="log"]'); await page.waitForTimeout(500);
  res.log = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-home .sx-li .t2')).map(e => e.textContent));
  await page.click('.sx-home .sx-seg [data-tab="rec"]'); await page.waitForTimeout(300);

  // 4) 빈 번호 이어받기: #13·#14 초안 중 #13 삭제 → 다음 '영상 만들기'가 #13
  env.db.set(SP + 'cfg/nsn', 15);
  env.db.set(SP + 'r/rD', mk(0, { age: 1, ti: 'Draft D', x: { sn: 13 } }));
  env.db.set(SP + 'r/rE', mk(6, { age: 2, ti: 'Draft E', x: { sn: 14 } }));
  env.db.set(SP + 'r/rF', mk(12, { age: 3, ti: 'Draft F' }));
  await page.reload(); await page.waitForTimeout(3000);
  await page.click('#albSxBtn'); await page.waitForTimeout(1500);
  res.rows2 = await rows(page);
  await page.click('[data-act="dedit"]'); await page.waitForTimeout(300);
  await page.click('[data-ddel="rD"]'); await page.waitForTimeout(500);
  res.askD = await ui(page);
  await page.click('#uiActs .sh-b1.destr'); await page.waitForTimeout(1500);
  res.dbD = { nsn: env.db.get(SP + 'cfg/nsn'), fsn: env.db.get(SP + 'cfg/fsn') };
  assert.strictEqual(res.dbD.nsn, 15); assert.deepStrictEqual(res.dbD.fsn, [13]);
  // 추천 → 편집(새 구성: 삭제 버튼 숨김) → 다음 → 마무리 미리보기 #13 → 영상 만들기 → 바로 취소
  await page.click('.sx-rec .go'); await page.waitForTimeout(2500);
  res.delBtnNew = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return getComputedStyle(s[s.length - 1].querySelector('[data-act="del"]')).visibility; });
  await page.click('.sx-scr.on:last-child [data-act="next"]'); await page.waitForTimeout(1500);
  res.finSn = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return (s[s.length - 1].querySelector('.sx-desc').textContent.split('\n').pop()); });
  await page.click('.sx-scr.on:last-child [data-act="make"]'); await page.waitForTimeout(900);
  await page.click('.sx-scr.on:last-child [data-act="cancel"]').catch(() => {}); await page.waitForTimeout(900);
  const recs = env.db.get(SP + 'r');
  const nw = Object.keys(recs).filter(k => !['rB', 'rU', 'rE', 'rF'].includes(k));
  res.dbMake = { newRid: nw, newSn: nw.map(k => recs[k].sn), nsn: env.db.get(SP + 'cfg/nsn'), fsn: env.db.get(SP + 'cfg/fsn') };
  assert.strictEqual(nw.length, 1); assert.strictEqual(recs[nw[0]].sn, 13); assert.strictEqual(res.dbMake.nsn, 15); assert.strictEqual(res.dbMake.fsn, null);
  // 편집 화면에서 다시 그 초안 삭제 (마무리 → 편집에서 삭제 버튼 보임)
  res.scrAfterCancel = await scrs(page);
  await page.click('.sx-scr.on:last-child [data-act="back"]'); await page.waitForTimeout(800);
  res.delBtnSaved = await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); return getComputedStyle(s[s.length - 1].querySelector('[data-act="del"]')).visibility; });
  await page.screenshot({ path: OUT + '93_edit_del.png' });
  await page.click('.sx-scr.on:last-child [data-act="del"]'); await page.waitForTimeout(500);
  res.askEdit = await ui(page);
  await page.click('#uiActs .sh-b1.destr'); await page.waitForTimeout(1800);
  res.scrAfterEditDel = await scrs(page);
  res.dbEdit = { gone: env.db.get(SP + 'r/' + nw[0]), nsn: env.db.get(SP + 'cfg/nsn'), fsn: env.db.get(SP + 'cfg/fsn') };
  assert.strictEqual(res.dbEdit.gone, null); assert.deepStrictEqual(res.dbEdit.fsn, [13]);
  res.rows3 = await rows(page);
  res.modeAfterEditDel = await page.evaluate(() => document.querySelectorAll('[data-ddel]').length);
  if (!res.modeAfterEditDel) { await page.click('[data-act="dedit"]'); await page.waitForTimeout(300); }

  // 5) 확인창 열린 채 폰 뒤로가기 → 확인창만 닫히고 그대로
  await page.click('[data-ddel="rE"]'); await page.waitForTimeout(500);
  await page.goBack(); await page.waitForTimeout(800);
  res.afterBack = { ui: (await ui(page)).on, scrs: await scrs(page), rE: !!env.db.get(SP + 'r/rE') };
  assert.strictEqual(res.afterBack.rE, true);

  // 6) 모두 삭제 → 번호 전부 회수(#13·#14 → nsn 13)
  await page.click('[data-act="delall"]'); await page.waitForTimeout(500);
  res.askAll = await ui(page);
  await page.screenshot({ path: OUT + '94_delall.png' });
  await page.click('#uiActs .sh-b1.destr'); await page.waitForTimeout(2500);
  res.dbAll = { recs: Object.keys(env.db.get(SP + 'r') || {}), nsn: env.db.get(SP + 'cfg/nsn'), fsn: env.db.get(SP + 'cfg/fsn') };
  assert.deepStrictEqual(res.dbAll.recs.sort(), ['rB', 'rU']); assert.strictEqual(res.dbAll.nsn, 13); assert.strictEqual(res.dbAll.fsn, null);
  res.rows4 = await rows(page);
  res.modeAfterAll = await page.evaluate(() => ({ dedit: !!document.querySelector('[data-act="dedit"]'), sec: !!document.querySelector('.sx-home .sx-draft') }));
  await page.screenshot({ path: OUT + '95_after.png' });
  res.errors = page.errors; res.logs = page.logs.filter(l => !/ERR_FAILED|404/.test(l));
  console.log(JSON.stringify(res, null, 1));
  assert.strictEqual(page.errors.length, 0);
  console.log('RESULT PASS e2e_del — 초안 삭제·기록으로 옮기기·번호 회수 통과');
  await b.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

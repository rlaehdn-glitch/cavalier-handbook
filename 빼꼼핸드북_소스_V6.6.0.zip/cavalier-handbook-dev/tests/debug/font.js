const H = require('../harness');
(async () => {
  const b = await H.launch({ net: true });
  const env = H.newEnv(); H.seedAlbum(env, { n: 4, videos: false, yt: 0 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST, allowFonts: true });
  const fontReqs = [];
  page.on('requestfinished', r => { if (/fonts\.(gstatic|googleapis)/.test(r.url())) fontReqs.push(r.url().slice(0, 90)); });
  page.on('requestfailed', r => { if (/fonts\./.test(r.url())) fontReqs.push('FAIL ' + r.url().slice(0, 90) + ' ' + (r.failure() || {}).errorText); });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(2500);
  const r = await page.evaluate(async () => {
    const sx = await shLoad(); const R = sx._R;
    await R.loadFonts();
    const t = '오늘도 귀여움 한도 초과';
    const before = document.fonts.check('60px Jua', t);
    await R.ensureGlyphs([t]);
    const after = document.fonts.check('60px Jua', t);
    const faces = []; document.fonts.forEach(f => { if (/Jua|Poppins/.test(f.family)) faces.push(f.family + ':' + f.status + ':' + (f.unicodeRange || '').slice(0, 30)); });
    const c = document.createElement('canvas'); c.width = 900; c.height = 200; const g = c.getContext('2d'); g.fillStyle = '#865'; g.fillRect(0, 0, 900, 200);
    const lay = R.textLayer([{ t: t, px: 60, max: 3 }]); g.drawImage(lay.c, -90, 0);
    g.font = '60px Jua'; g.fillStyle = '#fff'; g.fillText(t, 20, 180);
    document.body.appendChild(c); c.id = 'dbgc'; c.style.cssText = 'position:fixed;left:0;top:0;z-index:9999;width:450px;height:100px';
    return { before, after, nFaces: faces.length, loadedJua: faces.filter(f => /Jua:loaded/.test(f)).length, sample: faces.slice(0, 3) };
  });
  console.log(JSON.stringify(r, null, 1)); console.log(fontReqs.slice(0, 8));
  await page.screenshot({ path: H.OUT + 'dbg_font.png', clip: { x: 0, y: 0, width: 450, height: 100 } });
  await b.close();
})();

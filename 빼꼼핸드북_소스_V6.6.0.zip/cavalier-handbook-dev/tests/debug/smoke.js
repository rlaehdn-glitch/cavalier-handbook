const H = require('../harness');
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, {});
  const { page } = await H.newPhone(b, { env, dir: process.argv[2] || H.DIST });
  await page.goto(H.BASE + '#album');
  await page.waitForTimeout(2500);
  await page.screenshot({ path: H.OUT + 'orig_album.png' });
  await page.evaluate(() => window.scrollTo(0, 400));
  await page.waitForTimeout(800);
  await page.screenshot({ path: H.OUT + 'orig_album2.png' });
  const first = await page.$('#albGrid [data-open]');
  if (first) { await first.click(); await page.waitForTimeout(1200); await page.screenshot({ path: H.OUT + 'orig_lb.png' }); }
  console.log('errors', page.errors.slice(0, 5));
  console.log('logs', page.logs.slice(0, 10));
  console.log('db log', env.db.log.slice(0, 12));
  await b.close();
})();

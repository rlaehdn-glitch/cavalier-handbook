/* 영상 만들기 — 실제 MP4 생성(1080×1920) → 올렸어요 → 기록·지문 1건 → 사용 사진 표시 */
const H = require('./harness');
const fs = require('fs');
const OUT = H.OUT;
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 30 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album');
  await page.waitForTimeout(3000);
  await page.click('#albSxBtn');
  await page.waitForTimeout(1200);
  await page.click('.sx-rec .go');
  await page.waitForTimeout(2500);
  await page.screenshot({ path: OUT + '10_edit.png' });
  // play preview 1.2s
  await page.click('.sx-pv');
  await page.waitForTimeout(1200);
  await page.screenshot({ path: OUT + '11_edit_play.png' });
  await page.click('.sx-pv');
  // scroll down
  await page.evaluate(() => { const s = document.querySelectorAll('.sx-scr.on'); s[s.length - 1].scrollTo(0, 800); });
  await page.waitForTimeout(400);
  await page.screenshot({ path: OUT + '12_edit_low.png' });
  // item sheet
  await page.click('.sx-it[data-i="2"] .im');
  await page.waitForTimeout(700);
  await page.screenshot({ path: OUT + '13_item.png' });
  await page.click('.sx-ovl.on [data-act="ok"]');
  await page.waitForTimeout(500);
  // caption sheet
  await page.click('[data-act="cap"]');
  await page.waitForTimeout(600);
  await page.screenshot({ path: OUT + '14_cap.png' });
  await page.click('.sx-ovl.on [data-act="ok"]');
  await page.waitForTimeout(500);
  await page.click('[data-act="next"]');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '15_fin.png' });
  const t0 = Date.now();
  await page.click('[data-act="make"]');
  await page.waitForTimeout(2500);
  await page.screenshot({ path: OUT + '16_make.png' });
  await page.waitForSelector('.sx-done video', { timeout: 240000 });
  console.log('render secs', (Date.now() - t0) / 1000);
  await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '17_up.png' });
  const b64 = await page.evaluate(async () => {
    const v = document.querySelector('.sx-done video'); const r = await fetch(v.src); const ab = await r.arrayBuffer();
    const u8 = new Uint8Array(ab); let s = ''; const CH = 0x8000;
    for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    return btoa(s);
  });
  fs.writeFileSync(H.OUT + 'out1.mp4', Buffer.from(b64, 'base64'));
  console.log('mp4 bytes', Buffer.from(b64, 'base64').length);
  // 올렸어요
  await page.click('[data-act="done"]');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '18_log.png' });
  const rec = env.db.get('/handbook/testfam01-shorts/r');
  const fp = env.db.get('/handbook/testfam01-shorts/fp');
  console.log('recipes', Object.keys(rec || {}).length, JSON.stringify(Object.values(rec)[0]).slice(0, 400));
  console.log('fp', JSON.stringify(fp));
  const meta = env.db.get('/handbook/testfam01-album/meta');
  console.log('used', Object.keys(meta).filter(k => meta[k].su).map(k => k + ':' + meta[k].su + '@' + meta[k].sl).join(' '));
  console.log('errors', page.errors.slice(0, 5));
  console.log('logs', page.logs.filter(l => !/ERR_FAILED|404/.test(l)).slice(0, 10));
  const rep = require('./lib/report').start('e2e_make');
  const r0 = Object.values(rec || {})[0] || {};
  rep.ok('영상 파일 생김 (' + Buffer.from(b64, 'base64').length + 'B)', Buffer.from(b64, 'base64').length > 1000000);
  rep.eq('올렸어요 → 기록 1건(올림)', [Object.keys(rec || {}).length, r0.st], [1, 'up']);
  rep.eq('지문 1건', Object.keys(fp || {}).length, 1);
  rep.ok('사용 사진 표시', Object.keys(meta).filter(k => meta[k].su).length >= 8);
  rep.eq('화면 오류 없음', page.errors, []);
  rep.end();
  await b.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

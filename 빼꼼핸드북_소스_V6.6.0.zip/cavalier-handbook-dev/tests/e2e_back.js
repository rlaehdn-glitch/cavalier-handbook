/* 뒤로가기: 홈 → 만들기(편집) → 다음(마무리) → 뒤로 → 편집이어야 함 */
const H = require('./harness');
async function stack(page) { return page.evaluate(() => Array.from(document.querySelectorAll('#sxRoot .sx-scr.on')).map(s => (s.querySelector('.sx-ttl') || s.querySelector('.sx-big') || {}).textContent)); }
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 30 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  const res = {};
  // A) 앱 안 뒤로 버튼
  await page.click('#albSxBtn'); await page.waitForTimeout(1500);
  await page.click('.sx-rec .go'); await page.waitForTimeout(2000);
  await page.click('.sx-scr.on:last-child [data-act="next"]'); await page.waitForTimeout(1500);
  res.A_before = await stack(page);
  await page.click('.sx-scr.on:last-child [data-act="back"]'); await page.waitForTimeout(900);
  res.A_after = await stack(page);
  // B) 폰 뒤로가기(브라우저 back)
  await page.click('.sx-scr.on:last-child [data-act="next"]'); await page.waitForTimeout(1500);
  res.B_before = await stack(page);
  await page.goBack(); await page.waitForTimeout(900);
  res.B_after = await stack(page);
  // C) 사용자 탭 없이(합성 클릭) 다음 → 폰 뒤로가기 — 크롬 '기록 조작 개입' 재현
  await page.evaluate(() => document.querySelector('.sx-scr.on:last-child [data-act="next"]').click()); await page.waitForTimeout(1500);
  res.C_before = await stack(page);
  await page.goBack(); await page.waitForTimeout(900);
  res.C_after = await stack(page);
  res.hist = await page.evaluate(() => [history.length, JSON.stringify(history.state)]);
  res.errors = page.errors;
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_back');
  ['A', 'B', 'C'].forEach(k => rep.eq('마무리 → 뒤로 → 구성 편집 (' + k + ')', [res[k + '_before'], res[k + '_after']], [['쇼츠', '구성 편집', '마무리'], ['쇼츠', '구성 편집']]));
  rep.eq('화면 오류 없음', res.errors, []);
  rep.end();
  await b.close();
})();

/* 앨범 연결: 선택 모드 → 쇼츠로, 확대 화면 → 태그·쇼츠, 사진 업로드 → 촬영 시각 + 장면 태그 시트(산책 기록 겹침), 뒤로가기 */
const H = require('./harness');
const fs = require('fs');
const OUT = H.OUT;
const A = H.ASSETS + 'photos/';
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 20 });
  // 산책 기록: 2026-10-27 08:00~08:40 (업로드 사진 1·2의 촬영 시각과 겹침)
  const st = { profile: { name: '빼꼼이', birth: '2026-05-20', home: '2026-07-25', reg: '' }, media: { url: H.MEDIA },
    walkLog: { '2026-10-27': [{ o: new Date('2026-10-27T08:00:00+09:00').getTime(), i: new Date('2026-10-27T08:40:00+09:00').getTime() }] } };
  const { page } = await H.newPhone(b, { env, dir: H.DIST, state: st });
  const res = {};
  await page.goto(H.BASE + '#album');
  await page.waitForTimeout(3000);
  // 1) 선택 모드
  await page.click('#albSelB');
  await page.waitForTimeout(400);
  const cells = await page.$$('#albGrid [data-open]');
  for (const i of [0, 2, 3, 5]) await cells[i].click();
  await page.waitForTimeout(300);
  res.selText = await page.textContent('#albSelN');
  res.selGoDisabled = await page.$eval('#albSelGo', b => b.disabled);
  res.bnavHidden = await page.$eval('#bnav', e => getComputedStyle(e).display === 'none');
  await page.evaluate(() => window.scrollTo(0, 650));
  await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '30_select.png' });
  // 유튜브 칸은 고를 수 없음
  const yt = await page.$('#albGrid [data-lid]');
  res.ytExists = !!yt;
  await page.click('#albSelGo');
  await page.waitForTimeout(3000);
  res.editOpen = await page.evaluate(() => !!document.querySelector('.sx-scr.on .sx-strip'));
  res.editCount = await page.evaluate(() => document.querySelectorAll('.sx-scr.on .sx-it').length);
  res.selEnded = await page.evaluate(() => !document.body.classList.contains('alb-sel'));
  await page.screenshot({ path: OUT + '31_from_sel.png' });
  // 뒤로가기 → 앨범
  await page.goBack(); await page.waitForTimeout(800);
  res.afterBackStack = await page.evaluate(() => window.SHORTS.isOpen());
  res.afterBackTab = await page.evaluate(() => document.body.getAttribute('data-tab'));
  // 2) 확대 화면
  await page.evaluate(() => window.scrollTo(0, 650));
  const c2 = await page.$$('#albGrid [data-open]');
  await c2[1].click(); await page.waitForTimeout(1200);
  res.lbTags = await page.textContent('#albLbTags');
  await page.screenshot({ path: OUT + '32_lb.png' });
  await page.click('#albLbTags button'); await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '33_tag_edit.png' });
  await page.click('.sx-ovl.on .sx-chip[data-v="놀이"]');
  await page.click('.sx-ovl.on .sx-chip[data-v="신남"]');
  await page.click('.sx-ovl.on [data-act="save"]'); await page.waitForTimeout(1000);
  res.lbTags2 = await page.textContent('#albLbTags');
  const curId = await page.evaluate(() => ALB.cur);
  res.tagSaved = env.db.get('/handbook/testfam01-album/meta/' + curId);
  await page.click('#albLbSx'); await page.waitForTimeout(3000);
  res.photoEditFirst = await page.evaluate(() => { const it = document.querySelector('.sx-scr.on .sx-it .im img'); return it && it.getAttribute('data-th'); });
  res.photoEditCount = await page.evaluate(() => document.querySelectorAll('.sx-scr.on .sx-it').length);
  await page.screenshot({ path: OUT + '34_from_photo.png' });
  await page.goBack(); await page.waitForTimeout(800);
  res.lbStillOpen = await page.evaluate(() => document.getElementById('albLb').classList.contains('on'));
  await page.goBack(); await page.waitForTimeout(600);
  res.lbClosed = await page.evaluate(() => !document.getElementById('albLb').classList.contains('on'));
  // 3) 사진 업로드 → 촬영 시각 + 태그 시트
  const inp = await page.$('#albFile');
  await inp.setInputFiles([A + 'up1.jpg', A + 'up2.jpg', A + 'up3.jpg']);
  await page.waitForSelector('.sx-ovl.on', { timeout: 30000 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: OUT + '35_upload_tags.png' });
  res.suggestNote = await page.evaluate(() => { const n = document.querySelector('.sx-ovl.on .sx-note'); return n && n.textContent; });
  res.preOn = await page.evaluate(() => Array.from(document.querySelectorAll('.sx-ovl.on .sx-chip.on')).map(b => b.textContent));
  await page.click('.sx-ovl.on [data-act="save"]'); await page.waitForTimeout(1200);
  const meta = env.db.get('/handbook/testfam01-album/meta');
  res.uploaded = Object.keys(meta).filter(k => meta[k].sd).map(k => ({ id: k, sd: meta[k].sd, ts: meta[k].ts }));
  // 4) 설정 화면
  await page.click('#albSxBtn'); await page.waitForTimeout(1500);
  await page.click('.sx-scr.on [data-act="set"]'); await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '36_settings.png' });
  res.errors = page.errors; res.logs = page.logs.filter(l => !/ERR_FAILED|404/.test(l));
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_album');
  rep.eq('여러 장 선택', [res.selText, res.selGoDisabled, res.bnavHidden], ['4장 선택됨', false, true]);
  rep.eq('선택 → 쇼츠 편집 4장', [res.editOpen, res.editCount, res.selEnded], [true, 4, true]);
  rep.eq('뒤로 → 앨범', [res.afterBackStack, res.afterBackTab], [false, 'album']);
  rep.eq('확대 화면 태그', [res.lbTags, res.lbTags2], ['가을장면 태그 추가', '가을놀이신남태그 수정']);
  rep.eq('태그 저장', [res.tagSaved.ts, res.tagSaved.tm], ['놀이', '신남']);
  rep.eq('확대 → 쇼츠 8장', res.photoEditCount, 8);
  rep.eq('확대 화면 유지·닫기', [res.lbStillOpen, res.lbClosed], [true, true]);
  rep.eq('업로드 후 산책 자동 선택', [res.suggestNote, res.preOn], ['산책 기록과 시간이 겹쳐 ‘산책’을 미리 골랐어요', ['산책']]);
  rep.ok('업로드 3장 · 촬영 시각·태그 저장', res.uploaded.length === 3 && res.uploaded.every(u => u.sd && u.ts === '산책'));
  rep.eq('화면 오류 없음', [res.errors, res.logs], [[], []]);
  rep.end();
  await b.close();
})();

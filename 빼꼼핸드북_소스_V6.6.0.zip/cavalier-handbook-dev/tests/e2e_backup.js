/* 안전망 ③ 백업·가져오기 — 텍스트 내보내기/가져오기, 파일 백업 내용, [D2] 파일 형식 붙여넣기·옛 백업 합치기 */
const H = require('./harness');
const R = require('./lib/report');
const fs = require('fs');
(async () => {
  const rep = R.start('e2e_backup');
  const b = await H.launch();
  const env = H.newEnv();
  const { page } = await H.newPhone(b, { env });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  const cnt = () => page.evaluate(() => { const d = (S.qlog || {})[todayKey()] || {}; const n = (k) => (Array.isArray(d[k]) ? d[k].length : 0); return { poo: n('poo'), pee: n('pee'), weight: (S.weight || []).length }; });
  const srvCnt = () => page.evaluate(() => todayKey()).then((t) => { const s = env.db.get('/handbook/' + H.FAM) || {}; const d = ((s.qlog || {})[t]) || {}; return { poo: (d.poo || []).length, pee: (d.pee || []).length, weight: (s.weight || []).length }; });
  /* 가져오기 버튼 뒤 — V6.5.2는 '가져오기 완료' 알림, V6.6은 방식 고르기(합치기 / 되돌리기) */
  async function importText(text, mode) {
    await page.evaluate((t) => { goTab('settings'); document.getElementById('ioArea').value = t; }, text);
    await page.click('#impBtn'); await page.waitForTimeout(500);
    for (let i = 0; i < 3; i++) {
      const acts = await page.evaluate(() => (document.getElementById('uiSheet').classList.contains('on') ? Array.from(document.querySelectorAll('#uiActs .sh-b1')).map((b) => b.textContent) : []));
      if (!acts.length) break;
      let idx = acts.findIndex((a) => a.includes(mode === 'replace' ? '되돌리기' : '합치기'));
      if (idx < 0) idx = 0;
      await page.locator('#uiActs .sh-b1').nth(idx).click(); await page.waitForTimeout(500);
    }
    await page.waitForTimeout(2500);
  }
  await page.click('#qlPoo span'); await page.click('#qlPoo span'); await page.click('#qlPee span');
  await page.evaluate(() => { S.weight.push({ d: todayKey(), kg: '5.2' }); saveState(); });
  await page.waitForTimeout(2500);
  const base = await cnt();
  rep.eq('준비: 대변 2·소변 1·체중 1', base, { poo: 2, pee: 1, weight: 1 });

  // 1) 텍스트 내보내기 → 그대로 가져오기 = 변화 없음
  await page.evaluate(() => goTab('settings')); await page.click('#expBtn'); await page.waitForTimeout(200);
  const raw = await page.inputValue('#ioArea');
  rep.ok('내보내기 텍스트에 기록 포함', (() => { try { const p = JSON.parse(raw); return !!(p.qlog && p.weight); } catch (e) { return false; } })());
  await importText(raw, 'merge');
  rep.eq('같은 텍스트 가져오기 → 그대로', await cnt(), base);

  // 2) 파일 백업 버튼 — 내려받은 파일 내용
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#bkupBtn')]);
  const file = fs.readFileSync(await dl.path(), 'utf8');
  const fj = JSON.parse(file);
  rep.ok('파일 백업 = {app, exported, data}', fj.app === 'cavalier-handbook' && !!fj.data && !!fj.data.qlog);

  // 3) [D2] 파일 내용을 그대로 붙여넣기 → 기록이 지워지면 안 됨
  await importText(file, 'merge');
  rep.eq('[D2] 파일 형식 붙여넣기 → 이 폰 기록 유지', await cnt(), base, 'defect');
  rep.eq('[D2] 파일 형식 붙여넣기 → 서버 기록 유지', await srvCnt(), base, 'defect');

  // 4) [D2] 옛 백업 '합치기' → 백업 이후 새 기록은 남아야 함
  await page.evaluate(() => goTab('home'));
  await page.click('#qlPee span'); await page.waitForTimeout(2500);
  const now = await cnt();
  await importText(file, 'merge');
  rep.eq('[D2] 옛 백업 합치기 → 새 소변 기록 유지', await cnt(), now, 'defect');

  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

/* 쇼츠 화면 둘러보기 — 앨범 → 쇼츠 홈 → 추천 → 편집 → 마무리 화면이 열리고 오류가 없는지(캡처는 tests/out/) */
const H = require('./harness');
const OUT = H.OUT;
require('fs').mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 30 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album');
  await page.waitForTimeout(3500);
  await page.screenshot({ path: OUT + '01_album.png' });
  console.log('badge', await page.textContent('#albSxN'), 'shorts loaded', await page.evaluate(() => !!window.SHORTS));
  // open shorts home
  await page.click('#albSxBtn');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: OUT + '02_home.png' });
  await page.evaluate(() => document.querySelector('.sx-scr.on').scrollTo(0, 600));
  await page.waitForTimeout(300);
  await page.screenshot({ path: OUT + '03_home2.png' });
  console.log('errors', page.errors.slice(0, 5));
  console.log('logs', page.logs.filter(l => !/ERR_FAILED|404/.test(l)).slice(0, 10));
  console.log('cfg', JSON.stringify(env.db.get('/handbook/testfam01-shorts/cfg')));
  const rep = require('./lib/report').start('e2e_look');
  rep.ok('쇼츠 파일 불러옴', await page.evaluate(() => !!window.SHORTS));
  rep.eq('화면 오류 없음', page.errors, []);
  rep.end();
  await b.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

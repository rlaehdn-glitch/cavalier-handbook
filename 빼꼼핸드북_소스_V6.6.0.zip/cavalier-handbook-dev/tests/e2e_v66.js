/* V6.6 새 동작 — 겹친 시트 뒤로가기, 확인 뒤 닫기, 사진 삭제 뒤 뒤로가기, 진단 화면·복사, 화면 그리기 보호, 파일 가져오기·되돌리기,
   이름 묻기 시트, 버전 불일치 안내, 쇼츠 시트 닫자마자 입력창 열기(기록 칸 문지기) */
const H = require('./harness');
const R = require('./lib/report');
const fs = require('fs'); const path = require('path');
const E = require('../src/shorts/engine.js');
const V = fs.readFileSync(path.join(__dirname, '..', 'VERSION'), 'utf8').split('\n')[0].trim();   /* 지금 버전(예: 6.6.0) */
(async () => {
  const rep = R.start('e2e_v66');
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 8, videos: false, yt: 0 });
  const { page, ctx } = await H.newPhone(b, { env });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://rlaehdn-glitch.github.io' });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(3000);
  const st = () => page.evaluate(() => ({ tab: document.body.getAttribute('data-tab'), sheets: Array.from(document.querySelectorAll('.sheet-ovl.on, #qeOvl.on, #wtOvl.on, #sosOvl.on, #ntcOvl.on')).map((e) => e.id), lb: document.getElementById('albLb').classList.contains('on') }));
  const nav = async (t) => { await page.click('.bn-btn[data-tab="' + t + '"]'); await page.waitForTimeout(350); };
  const back = async () => { await page.goBack(); await page.waitForTimeout(600); };

  // A) 목욕 시트 위 확인창 → 뒤로 3번
  await nav('cal'); await nav('home');
  await page.evaluate(() => bathOpen()); await page.waitForTimeout(250);
  await page.evaluate(() => { uiConfirm({ msg: '겹친 확인창' }); }); await page.waitForTimeout(250);
  await back(); rep.eq('겹친 확인창 → 뒤로 → 확인창만 닫힘', (await st()).sheets, ['bathOvl']);
  await back(); rep.eq('→ 뒤로 → 목욕 시트 닫힘(홈 그대로)', await st(), { tab: 'home', sheets: [], lb: false });
  await back(); rep.eq('→ 뒤로 → 이전 탭(달력)', (await st()).tab, 'cal');
  // B) 확인 '계속' → 시트 닫기 버튼 → 뒤로 한 번에 이전 탭
  await nav('home');
  await page.evaluate(() => bathOpen()); await page.waitForTimeout(250);
  await page.evaluate(() => { uiConfirm({ msg: '확인 뒤 닫기' }); }); await page.waitForTimeout(250);
  await page.click('#uiActs .sh-b1'); await page.waitForTimeout(200);
  await page.click('#bathClose'); await page.waitForTimeout(500);
  rep.eq('확인 → 닫기 버튼 → 모두 닫힘', (await st()).sheets, []);
  await back(); rep.eq('→ 뒤로 한 번에 이전 탭(달력)', (await st()).tab, 'cal');
  // C) 사진 확대 → 삭제 확인 → 삭제 → 뒤로 = 이전 탭
  await nav('home'); await nav('album'); await page.waitForTimeout(1200);
  const n0 = await page.evaluate(() => Object.keys(ALB.meta || {}).length);
  await page.click('#albGrid .alb-cell'); await page.waitForTimeout(700);
  await page.click('#albLbMore'); await page.waitForTimeout(300);                       // ⋯ → 삭제 → 확인
  await page.locator('#uiActs .sh-b1', { hasText: '삭제' }).click(); await page.waitForTimeout(300);
  await page.click('#uiActs .sh-b1'); await page.waitForTimeout(1500);
  rep.eq('사진 삭제 → 확대 닫힘 · 1장 줄어듦', [await st().then((s) => s.lb), await page.evaluate(() => Object.keys(ALB.meta || {}).length)], [false, n0 - 1]);
  await back(); rep.eq('→ 뒤로 한 번에 이전 탭(홈)', (await st()).tab, 'home');
  // D) 진단 화면
  await nav('lib'); await page.evaluate(() => goTab('settings')); await page.waitForTimeout(800);
  const dg = await page.textContent('#diagBody');
  rep.ok('진단: 앱 버전 V' + V, dg.includes('V' + V));
  rep.ok('진단: 기록 문서 크기·저장공간 표시', dg.includes('기록 문서') && dg.includes('이 폰 저장공간'));
  await page.evaluate(() => logErr('시험 오류', 'boom-123')); await page.waitForTimeout(200);
  rep.ok('진단: 오류 기록 표시', (await page.textContent('#diagBody')).includes('boom-123') && (await page.textContent('#diagErrN')).includes('건'));
  await page.click('#diagCopy'); await page.waitForTimeout(400);
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  rep.ok('진단 복사 → 버전·오류 포함', clip.includes('V' + V) && clip.includes('boom-123'));
  // E) 화면 그리기 보호 — 한 칸이 실패해도 나머지는 그림
  const guard = await page.evaluate(() => { const keep = S.visits; S.visits = null; let threw = false; try { renderAll(); } catch (e) { threw = true; } S.visits = keep; renderAll(); return { threw, logged: errLog().some((x) => x.w === '화면: 병원') }; });
  rep.eq('renderAll 보호(오류 기록, 멈추지 않음)', guard, { threw: false, logged: true });
  // F) 파일에서 가져오기 — 합치기
  await page.evaluate(() => goTab('home')); await page.click('#qlPoo span'); await page.waitForTimeout(300);
  const file = await page.evaluate(() => { const o = JSON.parse(JSON.stringify(S)); const k = todayKey(); o.qlog[k] = { poo: (o.qlog[k].poo || []).concat(['01:02:03|m']) }; return JSON.stringify({ app: 'cavalier-handbook', exported: new Date().toISOString(), data: o }); });
  const fp = H.OUT + 'v66_backup.json'; fs.writeFileSync(fp, file);
  await page.evaluate(() => goTab('settings'));
  await page.setInputFiles('#impFile', fp); await page.waitForTimeout(600);
  rep.ok('파일 선택 → 가져오기 방식 고르기', (await page.textContent('#uiT')).includes('백업 가져오기'));
  await page.locator('#uiActs .sh-b1').nth(0).click(); await page.waitForTimeout(800);
  rep.eq('합치기 → 백업에만 있던 대변 1건 더해짐', await page.evaluate(() => ((S.qlog[todayKey()] || {}).poo || []).length), 2);
  // G) 되돌리기 — 지금 상태 파일로 먼저 저장, 5초 안 되돌리기
  const old = await page.evaluate(() => JSON.stringify({ app: 'cavalier-handbook', exported: '2026-10-01T00:00:00Z', data: { qlog: {}, weight: [] } }));
  const fp2 = H.OUT + 'v66_old.json'; fs.writeFileSync(fp2, old);
  await page.setInputFiles('#impFile', fp2); await page.waitForTimeout(500);
  await page.locator('#uiActs .sh-b1').nth(1).click(); await page.waitForTimeout(400);
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 5000 }).catch(() => null), page.click('#uiActs .sh-b1')]);
  await page.waitForTimeout(600);
  /* 이 시험 환경(헤드리스·LANG=C)은 한글 파일 이름을 'download'로 바꾸므로 이름 대신 내용을 확인 */
  const dlData = dl ? JSON.parse(fs.readFileSync(await dl.path(), 'utf8')) : null;
  rep.ok('되돌리기 전 상태를 파일로 먼저 저장(대변 2건 들어 있음)', !!dlData && dlData.app === 'cavalier-handbook' && (((dlData.data.qlog || {})[await page.evaluate(() => todayKey())] || {}).poo || []).length === 2);
  rep.eq('되돌리기 → 백업 시점(대변 0)', await page.evaluate(() => ((S.qlog[todayKey()] || {}).poo || []).length), 0);
  await page.click('#uiToastU'); await page.waitForTimeout(500);
  rep.eq('토스트 되돌리기 → 대변 2 복구', await page.evaluate(() => ((S.qlog[todayKey()] || {}).poo || []).length), 2);
  // I) 이름이 저장 안 된 폰에서 공지 확인 → 기본 입력창이 아니라 앱 시트로 이름 묻기
  await page.evaluate(() => { localStorage.removeItem('_ntc_by'); S.ntc = [{ id: 'nT', text: '시험 공지', by: '가족', at: Date.now(), ack: {} }]; window.__ackP = ntcAck('nT'); }); await page.waitForTimeout(400);
  const ask = await page.evaluate(() => ({ on: document.getElementById('uiSheet').classList.contains('on'), t: document.getElementById('uiT').textContent, inp: getComputedStyle(document.getElementById('uiIn')).display !== 'none' }));
  rep.ok('이름 없음 → 앱 시트로 이름 묻기', ask.on && ask.t.includes('이름') && ask.inp);
  await page.fill('#uiIn', '도우'); await page.locator('#uiActs .sh-b1').first().click(); await page.waitForTimeout(400);
  const ack = await page.evaluate(async () => ({ r: await window.__ackP, by: localStorage.getItem('_ntc_by'), ack: Object.keys((S.ntc[0] || {}).ack || {}) }));
  rep.eq('→ 이름 저장 · 공지 확인 기록', ack, { r: true, by: '도우', ack: ['도우'] });
  // H) 버전 불일치 안내 — shorts.js만 옛 버전일 때
  const { page: p2 } = await H.newPhone(b, { env });
  await p2.route('**/cavalier-handbook/shorts.js*', async (route) => { const body = fs.readFileSync(H.DIST + '/shorts.js', 'utf8').replace("const SXV = '" + V + "'", "const SXV = '0.0.1'"); return route.fulfill({ status: 200, headers: { 'content-type': 'application/javascript' }, body }); });
  await p2.goto(H.BASE + '#album'); await p2.waitForTimeout(4000);
  await p2.evaluate(() => shLoad()).catch(() => {}); await p2.waitForTimeout(800);
  const vm = await p2.evaluate(() => ({ on: document.getElementById('uiSheet').classList.contains('on'), m: document.getElementById('uiM').textContent, logged: errLog().some((x) => x.w === '버전 불일치') }));
  rep.ok('shorts.js 옛 버전 → 안내 표시', vm.on && vm.m.includes('쇼츠 파일 버전이 다릅니다'));
  rep.ok('→ 오류 기록함에 남음', vm.logged);
  // J) 쇼츠 기록 시트를 닫자마자 앱 입력창(링크 붙여넣기)을 열 때 — 되돌리기 도중 넣은 기록 칸을 잃어 입력창이 바로 닫히던 문제(V6.6 개발 중 발견)
  const env3 = H.newEnv(); const ids3 = H.seedAlbum(env3, { n: 20 });
  const SP = '/handbook/' + H.FAM + '-shorts/', meta3 = env3.db.get('/handbook/' + H.FAM + '-album/meta');
  const ph3 = ids3.filter((id) => meta3[id].t === 'p').slice(0, 6).map((id) => ({ id, m: meta3[id], sc: E.score(meta3[id], '2026-10-28') }));
  const up3 = Date.now() - 86400000;
  env3.db.set(SP + 'cfg', { mig1: 1, nsn: 12 });
  env3.db.set(SP + 'r', { rU: Object.assign(E.draft(ph3, 'PHOTOS', { home: '2026-07-25', today: '2026-10-28', recipes: {}, keepAll: true, src: 'pick' }), { st: 'up', sn: 11, at: up3, ut: up3, up: up3, mo: 'A', by: '도우', ti: 'Uploaded' }) });
  const { page: p3 } = await H.newPhone(b, { env: env3 });
  await p3.goto(H.BASE + '#album'); await p3.waitForTimeout(3000);
  await p3.click('#albSxBtn'); await p3.waitForTimeout(1500);
  await p3.click('.sx-scr.on .sx-seg [data-tab="log"]'); await p3.waitForTimeout(600);
  await p3.click('.sx-scr.on [data-log]'); await p3.waitForTimeout(800);
  await p3.click('.sx-ovl.on [data-act="link"]'); await p3.waitForTimeout(900);
  rep.ok('쇼츠 기록 시트 → 링크 붙여넣기 입력창 유지', await p3.evaluate(() => document.getElementById('uiSheet').classList.contains('on')));
  await p3.fill('#uiIn', 'https://youtube.com/shorts/AbCdEfGhIjK?si=xyz'); await p3.click('#uiActs .sh-b1'); await p3.waitForTimeout(1500);
  rep.eq('→ 링크 저장', Object.values(env3.db.get(SP + 'r')).map((r) => r.yu), ['https://youtube.com/shorts/AbCdEfGhIjK']);
  await p3.goBack(); await p3.waitForTimeout(800);
  rep.eq('→ 뒤로 한 번에 쇼츠 홈 닫힘(앨범)', await p3.evaluate(() => [document.body.getAttribute('data-tab'), document.querySelectorAll('#sxRoot .sx-scr.on').length]), ['album', 0]);
  rep.eq('화면 오류 없음', page.errors.concat(p2.errors, p3.errors), []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

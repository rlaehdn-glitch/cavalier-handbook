/* 테스트 한 번에 돌리기 — 먼저 build.py로 dist/를 새로 만든 뒤 그 결과를 시험한다(고친 소스를 빌드 안 하고 시험하는 실수 방지)
   node tests/run.js            빠른 묶음(영상 만들기 제외, 약 5분)
   node tests/run.js --full     전체(영상 만들기 4종 포함, 약 10분)
   node tests/run.js --defects  알려진 결함 확인 항목의 실패를 허용(고치기 전 기준 확인용)
   node tests/run.js --no-build 빌드 없이 지금 dist/ 그대로 시험
   결과: tests/out/summary.txt (실패한 것은 tests/out/fail-이름.log) */
const cp = require('child_process'); const fs = require('fs'); const path = require('path');
const QUICK = ['structure.test.js', 'unit/engine.test.js', 'e2e_core.js', 'e2e_sync.js', 'e2e_backup.js', 'e2e_nav.js', 'e2e_midnight.js', 'e2e_storage.js', 'e2e_retention.js', 'e2e_walk.js',
  'e2e_look.js', 'e2e_look2.js', 'e2e_recs.js', 'e2e_edit.js', 'e2e_back.js', 'e2e_v651.js', 'e2e_album.js', 'e2e_two.js', 'e2e_regress.js', 'e2e_del.js', 'e2e_del_look.js', 'e2e_v66.js', 'e2e_visual.js'];
const SLOW = ['e2e_make.js', 'e2e_clip.js', 'e2e_kocap.js', 'e2e_flow2.js'];
const args = process.argv.slice(2);
if (!args.includes('--no-build')) cp.execFileSync('python3', [path.join(__dirname, '..', 'build.py')], { stdio: 'inherit', cwd: path.join(__dirname, '..') });
const list = args.includes('--full') ? SLOW.concat(QUICK) : QUICK;
const env = Object.assign({}, process.env, args.includes('--defects') ? { EXPECT_DEFECTS: '1' } : {});
const LANES = 3, results = []; let next = 0;
function runOne(f) {
  return new Promise((res) => {
    const t0 = Date.now();
    const p = cp.spawn(process.execPath, [path.join(__dirname, f)], { env, cwd: path.join(__dirname, '..') });
    let out = ''; p.stdout.on('data', (d) => (out += d)); p.stderr.on('data', (d) => (out += d));
    const kill = setTimeout(() => p.kill('SIGKILL'), 420000);
    p.on('close', (code) => { clearTimeout(kill); const m = out.match(/RESULT (PASS|FAIL)[^\n]*/g); const line = m ? m[m.length - 1] : (code === 0 ? 'RESULT PASS ' + f : 'RESULT FAIL ' + f + ' (요약 없음)'); results.push({ f, code, secs: Math.round((Date.now() - t0) / 1000), line, out }); res(); });
  });
}
async function lane() { while (next < list.length) { const f = list[next++]; await runOne(f); } }
(async () => {
  await Promise.all(Array.from({ length: LANES }, lane));
  results.sort((a, b) => list.indexOf(a.f) - list.indexOf(b.f));
  const lines = results.map((r) => (r.code === 0 ? 'PASS ' : 'FAIL ') + r.f.padEnd(22) + String(r.secs).padStart(4) + 's  ' + r.line.replace(/^RESULT (PASS|FAIL) /, ''));
  const bad = results.filter((r) => r.code !== 0);
  const sum = lines.join('\n') + '\n\n' + (bad.length ? '실패 ' + bad.length + '개: ' + bad.map((r) => r.f).join(', ') : '전체 통과 ' + results.length + '개') + '\n';
  fs.mkdirSync(path.join(__dirname, 'out'), { recursive: true });
  fs.writeFileSync(path.join(__dirname, 'out', 'summary.txt'), sum);
  bad.forEach((r) => fs.writeFileSync(path.join(__dirname, 'out', 'fail-' + path.basename(r.f) + '.log'), r.out));
  console.log(sum);
  process.exitCode = bad.length ? 1 : 0;
})();

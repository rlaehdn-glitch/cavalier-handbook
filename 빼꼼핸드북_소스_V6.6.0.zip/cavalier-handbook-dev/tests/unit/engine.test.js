/* 쇼츠 엔진 단위 시험 — 추천 생성·구성·포맷·제목·중복 방지·시리즈 번호(빈 번호 회수) 계산을 화면 없이 확인 */
const assert = require('assert');
const E = require('../../src/shorts/engine.js');
const today = '2026-10-28';
function mk(n, opt) {
  const meta = {};
  for (let i = 0; i < n; i++) {
    const d = new Date('2026-08-01T10:00:00'); d.setDate(d.getDate() + Math.floor(i * 2.2));
    const id = 'p' + String(i).padStart(3, '0');
    const m = { t: 'p', d: E.dkey(d), at: d.getTime(), m: '' };
    if (i % 5 === 0) m.lk = { x: '가족' };
    if (i % 6 === 0) m.ts = '산책';
    if (i % 6 === 1) m.ts = '놀이';
    if (i % 6 === 2) m.ts = '잠';
    if (i % 6 === 3) m.ts = '교감';
    if (i % 9 === 0) m.m = '훈련 중 앉아';
    if (i % 4 === 0) m.tm = '신남';
    meta[id] = m;
  }
  meta['v001'] = { t: 'r', k: 'v/v001.mp4', d: '2026-10-20', at: new Date('2026-10-20T10:00:00').getTime(), dur: 8, m: '우다다' };
  return meta;
}
const meta = mk(60);
const cfg = Object.assign({}, E.DEF_CFG);
// 1) recommend: 3 recs, distinct formats preferred, zero overlap
let r = E.recommend(meta, cfg, {}, {}, today);
console.log('recs', r.recs.map(g => [g.key, g.fm, g.ids.length, g.score, g.nNew]));
assert.strictEqual(r.recs.length, 3);
const all = r.recs.flatMap(g => g.ids); assert.strictEqual(new Set(all).size, all.length, 'zero overlap');
assert.strictEqual(new Set(r.recs.map(g => g.fm)).size, 3, 'distinct formats');
r.recs.forEach(g => { assert(g.ids.length >= 6 && g.ids.length <= 8); assert(g.ids.filter(id => E.isClip(meta[id])).length <= 1); });
// 2) compose: 15~20s, intro first, outro last
r.recs.forEach(g => {
  const d = E.draft(g.sel, g.fm, { home: '2026-07-25', today, recipes: {} });
  const tot = E.total(d.it);
  console.log(g.fm, 'items', d.it.length, 'total', tot, '|', d.ti, '|', d.hk, '|', d.dl, '|', d.mq.join('/'));
  assert(tot >= 15 && tot <= 20, 'length ' + tot);
  assert(d.de.split('\n').pop().startsWith('빼꼼 #'));
  if (g.fm === 'SLEEP') { const last = d.it[d.it.length - 1]; assert(E.sits(meta[last.id]).includes('잠'), 'sleep ends with sleep'); }
});
// 3) fingerprint excludes same combo
const g0 = r.recs[0];
const fps = {}; fps[E.fpOf(g0.ids)] = 5;
let r2 = E.recommend(meta, cfg, {}, fps, today);
assert(!r2.recs.some(g => g.sig === g0.sig), 'same combo blocked');
// 4) overlap ≥50% with uploaded excluded
const rec = { r1: { st: 'up', it: g0.ids.slice(0, 4).map(id => ({ id })), up: 1 } };
let r3 = E.recommend(meta, cfg, rec, {}, today);
r3.recs.forEach(g => { const o = E.overlap(g.ids, E.usedSets(rec)); assert(o.frac < 0.5, 'overlap ' + o.frac); });
// 5) cooldown & max use
const m2 = JSON.parse(JSON.stringify(meta));
Object.keys(m2).slice(0, 30).forEach(id => { m2[id].su = 1; m2[id].sl = '2026-10-20'; });
Object.keys(m2).slice(30, 35).forEach(id => { m2[id].su = 3; m2[id].sl = '2026-01-01'; });
const c = E.candidates(m2, cfg, today);
assert(!c.some(x => Object.keys(m2).slice(0, 35).includes(x.id)), 'cooldown/max excluded');
const c2 = E.candidates(m2, cfg, today, { cool: true });
assert(c2.some(x => Object.keys(m2).slice(0, 30).includes(x.id)) && !c2.some(x => Object.keys(m2).slice(30, 35).includes(x.id)), 'cool option');
// 6) titles avoid recently used templates
const recs10 = {}; for (let i = 0; i < 3; i++) recs10['x' + i] = { st: 'up', fm: 'TRUST', tt: 'TRUST.' + i, up: 100 + i };
const ts = E.titles('TRUST', { N: 96, act: 'walk', season: 'autumn', k: 1 }, recs10);
console.log('titles', ts.map(t => t.key + ':' + t.t));
assert.deepStrictEqual(ts.map(t => t.key).slice(0, 2), ['TRUST.3', 'TRUST.4']);
// 7) burst dedupe
const b = { a: { t: 'p', d: '2026-10-01', sd: '2026-10-01T10:00:00' }, b: { t: 'p', d: '2026-10-01', sd: '2026-10-01T10:00:01' }, c: { t: 'p', d: '2026-10-01', ih: 'ffff0000ffff0000' }, d: { t: 'p', d: '2026-10-01', ih: 'ffff0000ffff0001' } };
assert(E.sameBurst(b.a, b.b) && E.sameBurst(b.c, b.d) && !E.sameBurst(b.a, b.c));
// 8) bundleFrom keeps chosen first
const bf = E.bundleFrom('p010', meta, cfg, today);
assert(bf[0].id === 'p010' && bf.length >= 6 && bf.length <= 8, 'bundle');
const dd = E.draft(bf, E.fmtOf(bf).fm || 'PHOTOS', { home: '2026-07-25', today, firstId: 'p010' });
assert.strictEqual(dd.it[0].id, 'p010');
// 9) dayN
assert.strictEqual(E.dayN('2026-07-25', '2026-07-25'), 1);
assert.strictEqual(E.dayN('2026-10-28', '2026-07-25'), 96);
// 10) keepAll selection with 12 items keeps all
const pick = Object.keys(meta).slice(0, 12).map(id => ({ id, m: meta[id], sc: E.score(meta[id], today) }));
const dk = E.draft(pick, 'PHOTOS', { home: '2026-07-25', today, keepAll: true });
assert.strictEqual(dk.it.length, 12);
console.log('keepAll total', E.total(dk.it));
// 11) sleep-only group never SLEEP
assert.strictEqual(E.fmtOf([1,2,3,4,5,6].map(i => ({ m: { ts: '잠' } }))).fm, '');
// 12) 시리즈 번호 예약·회수 (V6.5.2)
const P = (nsn, rec, fsn) => E.snPick(nsn, rec, fsn);
assert.deepStrictEqual(P(0, {}, null), { sn: 1, nsn: 2, fsn: [] }, 'fresh');
assert.deepStrictEqual(P(12, {}, null), { sn: 12, nsn: 13, fsn: [] }, 'user nsn');
assert.deepStrictEqual(P(12, { a: { st: 'draft', sn: 12 } }, null), { sn: 13, nsn: 14, fsn: [] }, 'skip taken');
// 가장 최근 번호 초안 삭제 → 카운터 되돌림
assert.deepStrictEqual(E.snFree(13, {}, null, 12), { nsn: 12, fsn: [] }, 'latest released');
// 앞 번호 초안 삭제(뒤 번호 초안 있음) → 빈 번호로 보관 → 다음 예약이 이어받음
const recB = { b: { st: 'draft', sn: 13 } };
const f1 = E.snFree(14, recB, null, 12);
assert.deepStrictEqual(f1, { nsn: 14, fsn: [12] }, 'older kept as free');
assert.deepStrictEqual(P(f1.nsn, recB, f1.fsn), { sn: 12, nsn: 14, fsn: [] }, 'free reused first');
// 빈 번호가 있는 채로 끝 번호까지 지우면 둘 다 회수
assert.deepStrictEqual(E.snFree(14, {}, [12], 13), { nsn: 12, fsn: [] }, 'trailing roll back');
// 뒤 번호가 이미 올라갔으면 앞 빈 번호는 버림(순서 뒤집힘 방지)
assert.deepStrictEqual(E.snState(14, { b: { st: 'up', sn: 13 } }, [12]), { nsn: 14, fsn: [] }, 'drop below uploaded');
assert.deepStrictEqual(P(14, { b: { st: 'up', sn: 13 } }, [12]), { sn: 14, nsn: 15, fsn: [] }, 'next after uploaded');
// 파이어베이스가 배열을 객체로 돌려줘도 처리
assert.deepStrictEqual(E.snList({ 0: 12, 1: '9', 2: 12, 3: -1, 4: 'x' }), [9, 12], 'list normalize');
// 아직 다른 초안이 쓰는 번호는 빈 번호가 되지 않음
assert.deepStrictEqual(E.snFree(14, recB, null, 13), { nsn: 14, fsn: [] }, 'taken not freed');
console.log('sn ok');
console.log('ALL ENGINE TESTS PASSED');

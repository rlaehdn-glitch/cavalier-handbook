/* 테스트 하네스 — 실제 index.html(+shorts.js)을 GitHub Pages 주소로 띄우고
   Firebase REST · Cloudflare Worker(R2)를 메모리 스텁으로 대신한다. 두 기기(컨텍스트)가 같은 스텁을 공유할 수 있다. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const DIST = path.join(__dirname, '..', 'dist');          /* 빌드 결과(올릴 파일 2개) */
const OUT = path.join(__dirname, 'out') + path.sep;         /* 화면 캡처·영상 결과 */
const ASSETS = path.join(__dirname, 'assets') + path.sep;   /* 시험용 사진·영상 */
try { fs.mkdirSync(OUT, { recursive: true }); } catch (e) { }

const ORIGIN = 'https://rlaehdn-glitch.github.io';
const BASE = ORIGIN + '/cavalier-handbook/';
const DB = 'https://fakedb.test';
const MEDIA = 'https://fakemedia.test';
const FAM = 'testfam01';
const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET,PUT,POST,PATCH,DELETE,OPTIONS',
  'access-control-allow-headers': '*',
  'access-control-expose-headers': 'content-length,content-range,accept-ranges,etag',
};

class FakeDB {
  constructor() { this.root = {}; this.writes = 0; this.log = []; }
  _parts(p) { return p.split('/').filter(Boolean).map(decodeURIComponent); }
  get(p) {
    let cur = this.root;
    for (const k of this._parts(p)) { if (cur == null || typeof cur !== 'object') return null; cur = cur[k]; }
    return cur === undefined ? null : cur;
  }
  _clean(v) {
    if (v === null || v === undefined) return undefined;
    if (typeof v !== 'object' || Array.isArray(v)) return v;
    const o = {};
    for (const k of Object.keys(v)) { const c = this._clean(v[k]); if (c !== undefined) o[k] = c; }
    return Object.keys(o).length ? o : undefined;
  }
  set(p, v) {
    const parts = this._parts(p);
    v = this._clean(JSON.parse(JSON.stringify(v === undefined ? null : v)));
    if (!parts.length) { this.root = v || {}; return; }
    let cur = this.root; const stack = [];
    for (let i = 0; i < parts.length - 1; i++) {
      const k = parts[i];
      if (cur[k] == null || typeof cur[k] !== 'object') cur[k] = {};
      stack.push([cur, k]); cur = cur[k];
    }
    const last = parts[parts.length - 1];
    if (v === undefined) delete cur[last]; else cur[last] = v;
    // 빈 객체 정리
    for (let i = stack.length - 1; i >= 0; i--) {
      const [o, k] = stack[i];
      if (o[k] && typeof o[k] === 'object' && !Object.keys(o[k]).length) delete o[k];
    }
    this.writes++;
  }
  patch(p, obj) { for (const k of Object.keys(obj || {})) this.set(p + '/' + k, obj[k]); }
}

class FakeMedia {
  constructor() { this.files = new Map(); this.uploads = new Map(); this.reqs = []; }
}

function readBody(req) { const b = req.postDataBuffer(); return b || Buffer.alloc(0); }

async function handleDB(route, db) {
  const req = route.request();
  const u = new URL(req.url());
  const method = req.method();
  if (method === 'OPTIONS') return route.fulfill({ status: 204, headers: CORS, body: '' });
  let p = u.pathname.replace(/\.json$/, '');
  db.log.push(method + ' ' + p);
  if (method === 'GET') {
    let v = db.get(p);
    if (u.searchParams.get('shallow') === 'true' && v && typeof v === 'object') { const o = {}; Object.keys(v).forEach(k => o[k] = true); v = o; }
    return route.fulfill({ status: 200, headers: { ...CORS, 'content-type': 'application/json' }, body: JSON.stringify(v) });
  }
  const body = readBody(req).toString('utf8');
  let val = null;
  try { val = body ? JSON.parse(body) : null; } catch (e) { return route.fulfill({ status: 400, headers: CORS, body: '{"error":"bad json"}' }); }
  if (method === 'PUT') { db.set(p, val); return route.fulfill({ status: 200, headers: { ...CORS, 'content-type': 'application/json' }, body: JSON.stringify(val) }); }
  if (method === 'PATCH') { db.patch(p, val); return route.fulfill({ status: 200, headers: { ...CORS, 'content-type': 'application/json' }, body: JSON.stringify(val) }); }
  if (method === 'DELETE') { db.set(p, null); return route.fulfill({ status: 200, headers: { ...CORS, 'content-type': 'application/json' }, body: 'null' }); }
  if (method === 'POST') { const k = '-N' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); db.set(p + '/' + k, val); return route.fulfill({ status: 200, headers: { ...CORS, 'content-type': 'application/json' }, body: JSON.stringify({ name: k }) }); }
  return route.fulfill({ status: 405, headers: CORS, body: '' });
}

async function handleMedia(route, media) {
  const req = route.request();
  const u = new URL(req.url());
  const method = req.method();
  if (method === 'OPTIONS') return route.fulfill({ status: 204, headers: CORS, body: '' });
  const p = decodeURIComponent(u.pathname);
  media.reqs.push(method + ' ' + p + (u.search || ''));
  const json = (o, st) => route.fulfill({ status: st || 200, headers: { ...CORS, 'content-type': 'application/json' }, body: JSON.stringify(o) });
  if (p === '/ping') return json({ ok: true });
  if (p === '/put' && method === 'PUT') { const key = u.searchParams.get('key'); media.files.set(key, { body: readBody(req), ct: u.searchParams.get('ct') || 'application/octet-stream' }); return json({ ok: true, key }); }
  if (p === '/create') { const id = 'up' + Math.random().toString(36).slice(2); media.uploads.set(id, { key: u.searchParams.get('key'), ct: u.searchParams.get('ct'), parts: {} }); return json({ ok: true, uploadId: id }); }
  if (p === '/part') { const up = media.uploads.get(u.searchParams.get('uploadId')); if (!up) return json({ ok: false, error: 'no upload' }, 404); const n = +u.searchParams.get('n'); up.parts[n] = readBody(req); return json({ ok: true, etag: 'e' + n }); }
  if (p === '/complete') { const id = u.searchParams.get('uploadId'); const up = media.uploads.get(id); if (!up) return json({ ok: false, error: 'no upload' }, 404); const ns = Object.keys(up.parts).map(Number).sort((a, b) => a - b); media.files.set(up.key, { body: Buffer.concat(ns.map(n => up.parts[n])), ct: up.ct }); media.uploads.delete(id); return json({ ok: true }); }
  if (p === '/abort') { media.uploads.delete(u.searchParams.get('uploadId')); return json({ ok: true }); }
  if (p.startsWith('/file/')) {
    const key = p.slice(6);
    if (method === 'DELETE') { media.files.delete(key); return json({ ok: true }); }
    const f = media.files.get(key);
    if (!f) return route.fulfill({ status: 404, headers: CORS, body: 'not found' });
    const total = f.body.length;
    const range = req.headers()['range'];
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let s = m && m[1] ? +m[1] : 0, e = m && m[2] ? +m[2] : total - 1;
      if (e >= total) e = total - 1;
      return route.fulfill({ status: 206, headers: { ...CORS, 'content-type': f.ct, 'accept-ranges': 'bytes', 'content-range': `bytes ${s}-${e}/${total}`, 'content-length': String(e - s + 1) }, body: f.body.slice(s, e + 1) });
    }
    return route.fulfill({ status: 200, headers: { ...CORS, 'content-type': f.ct, 'accept-ranges': 'bytes', 'content-length': String(total) }, body: f.body });
  }
  return json({ ok: false, error: 'unknown ' + p }, 404);
}

const TINY_JPG = Buffer.from('/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==', 'base64');

async function newPhone(browser, opts) {
  const o = Object.assign({ name: '도우', dev: null, dir: DIST, viewport: { width: 390, height: 844 }, state: null }, opts || {});
  const ctx = await browser.newContext({ ignoreHTTPSErrors: !!o.allowFonts, viewport: o.viewport, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36', locale: 'ko-KR', timezoneId: 'Asia/Seoul' });
  const st = o.state || { profile: { name: '빼꼼이', birth: '2026-05-20', home: '2026-07-25', reg: '' }, media: { url: MEDIA } };
  await ctx.addInitScript(([st, name, dev, fam, db]) => {
    try {
      if (!localStorage.getItem('__seeded')) {
        localStorage.setItem('_sync_url', db); localStorage.setItem('_sync_code', fam); localStorage.setItem('_sync_on', '1');
        localStorage.setItem('ckcs-data', JSON.stringify(st));
        localStorage.setItem('_ntc_by', name);
        if (dev) localStorage.setItem('_dev', dev);
        localStorage.setItem('__seeded', '1');
      }
    } catch (e) { }
  }, [st, o.name, o.dev, FAM, DB]);
  const pattern = o.allowFonts ? (u) => !/fonts\.(googleapis|gstatic)\.com/.test(u.href) : '**/*';
  await ctx.route(pattern, async (route) => {
    const url = route.request().url();
    if (url.startsWith(BASE)) {
      let rel = url.slice(BASE.length).split('?')[0].split('#')[0] || 'index.html';
      const fp = path.join(o.dir, rel);
      if (fs.existsSync(fp) && fs.statSync(fp).isFile()) {
        const ct = rel.endsWith('.js') ? 'application/javascript' : rel.endsWith('.html') ? 'text/html; charset=utf-8' : 'application/octet-stream';
        return route.fulfill({ status: 200, headers: { 'content-type': ct, 'cache-control': 'no-store' }, body: fs.readFileSync(fp) });
      }
      return route.fulfill({ status: 404, body: 'nf' });
    }
    if (url.startsWith(DB)) return handleDB(route, o.env.db);
    if (url.startsWith(MEDIA)) return handleMedia(route, o.env.media);
    if (url.startsWith('https://i.ytimg.com/')) return route.fulfill({ status: 200, headers: { 'content-type': 'image/jpeg', ...CORS }, body: TINY_JPG });
    if (o.allowFonts && /fonts\.(googleapis|gstatic)\.com/.test(url)) return route.continue();
    return route.abort();
  });
  const page = await ctx.newPage();
  page.errors = []; page.logs = [];
  page.on('pageerror', e => page.errors.push(String(e && e.stack || e)));
  page.on('console', m => { const t = m.type(); if (t === 'error' || t === 'warning') page.logs.push(t + ': ' + m.text()); });
  return { ctx, page };
}

/* 앨범 시드 — tests/assets/photos 의 사진을 파이어베이스(base64) 또는 R2(p2)로 넣는다 */
function seedAlbum(env, opts) {
  const o = Object.assign({ n: 30, p2Every: 4, videos: true, yt: 2, startDate: '2026-08-01' }, opts || {});
  const A = path.join(__dirname, 'assets');
  const meta = {};
  const base = new Date(o.startDate + 'T09:00:00+09:00').getTime();
  const ids = [];
  for (let i = 1; i <= o.n; i++) {
    const id = 'a' + (1700000000000 + i * 1000).toString(36) + 'p' + String(i).padStart(2, '0');
    const at = base + i * 2.2 * 86400000;
    const d = new Date(at + 9 * 3600000).toISOString().slice(0, 10);
    const full = fs.readFileSync(path.join(A, 'photos', 'p' + String(((i - 1) % 36) + 1).padStart(2, '0') + '.jpg'));
    const th = fs.readFileSync(path.join(A, 'photos', 'p' + String(((i - 1) % 36) + 1).padStart(2, '0') + '_th.jpg'));
    const m = { t: 'p', d, m: '', at, s: full.length + th.length };
    if (i % 5 === 0) m.lk = { dX: '가족' };
    if (i % 7 === 0) m.m = ['첫 산책', '우다다 타임', '낮잠', '목욕 후', '훈련 중 앉아'][(i / 7) % 5 | 0];
    if (o.p2Every && i % o.p2Every === 0) {
      m.p2 = 1; m.ps = 'c';
      env.media.files.set('v/' + id + '.jpg', { body: full, ct: 'image/jpeg' });
      env.media.files.set('v/' + id + 't.jpg', { body: th, ct: 'image/jpeg' });
    } else {
      env.db.set('/handbook/' + FAM + '-album/full/' + id, 'data:image/jpeg;base64,' + full.toString('base64'));
      env.db.set('/handbook/' + FAM + '-album/th/' + id, 'data:image/jpeg;base64,' + th.toString('base64'));
    }
    meta[id] = m; ids.push(id);
  }
  if (o.videos) {
    const vids = [['clip_portrait.mp4', 8], ['clip_land.mp4', 6], ['clip_silent.mp4', 5]];
    vids.forEach((v, j) => {
      const id = 'a' + (1700001000000 + j * 1000).toString(36) + 'v' + j;
      const key = 'v/' + id + '.mp4';
      env.media.files.set(key, { body: fs.readFileSync(path.join(A, v[0])), ct: 'video/mp4' });
      const th = fs.readFileSync(path.join(A, 'photos', 'p0' + (j + 1) + '_th.jpg'));
      env.db.set('/handbook/' + FAM + '-album/th/' + id, 'data:image/jpeg;base64,' + th.toString('base64'));
      const at = base + (10 + j * 15) * 86400000 + 3600000;
      meta[id] = { t: 'r', d: new Date(at + 9 * 3600000).toISOString().slice(0, 10), m: j === 0 ? '우다다' : '', at, s: th.length, k: key, th: 1, dur: v[1], vs: 1000 };
      ids.push(id);
    });
  }
  for (let j = 0; j < (o.yt || 0); j++) {
    const id = 'a' + (1700002000000 + j * 1000).toString(36) + 'y' + j;
    const at = base + (5 + j * 20) * 86400000;
    meta[id] = { t: 'v', d: new Date(at + 9 * 3600000).toISOString().slice(0, 10), m: '유튜브 ' + (j + 1), u: 'https://youtube.com/shorts/ABCDEFGHIJ' + j, at, s: 0 };
  }
  env.db.set('/handbook/' + FAM + '-album/meta', meta);
  env.db.set('/handbook/' + FAM + '-album/idx', { rev: Date.now() });
  env.db.set('/handbook/' + FAM + '-album/p2s', 'c');
  return ids;
}

function newEnv() { return { db: new FakeDB(), media: new FakeMedia() }; }

async function launch(o) {
  o = o || {};
  const opt = { args: ['--autoplay-policy=no-user-gesture-required'] };
  if (o.net && process.env.HTTPS_PROXY) opt.proxy = { server: process.env.HTTPS_PROXY, bypass: 'localhost,127.0.0.1' };
  return chromium.launch(opt);
}

module.exports = { launch, newPhone, newEnv, seedAlbum, BASE, DB, MEDIA, FAM, DIST, OUT, ASSETS };

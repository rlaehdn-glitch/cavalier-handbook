/* 안전망 ⑧ 산책 지도 기록(GPS) — 시작 → 위치 8점 → 끝내기 → 저장 → 요약 → 뒤로가기, 경로가 서버에 올라감 */
const H = require('./harness');
const R = require('./lib/report');
(async () => {
  const rep = R.start('e2e_walk');
  const b = await H.launch();
  const env = H.newEnv();
  const { page, ctx } = await H.newPhone(b, { env });
  await ctx.grantPermissions(['geolocation'], { origin: 'https://rlaehdn-glitch.github.io' });
  await ctx.setGeolocation({ latitude: 37.64, longitude: 126.89, accuracy: 5 });
  await page.goto(H.BASE + '#home'); await page.waitForTimeout(2500);
  const ov = () => page.evaluate(() => Array.from(document.querySelectorAll('.sheet-ovl.on')).map((e) => e.id));
  await page.click('.bn-btn[data-tab="cal"]'); await page.waitForTimeout(300); await page.click('.bn-btn[data-tab="home"]'); await page.waitForTimeout(300);
  await page.evaluate(() => wgStart()); await page.waitForTimeout(800);
  rep.ok('산책 화면 열림', (await ov()).includes('wgScr'));
  rep.ok('진행 중 표시(S.walkCur)', await page.evaluate(() => S.walkCur > 0 && !!WG.cur));
  for (let i = 1; i <= 8; i++) {
    await page.evaluate((i) => wgOnFix({ coords: { latitude: 37.64 + i * 0.00005, longitude: 126.89, accuracy: 5, altitude: null }, timestamp: Date.now() }), i);
    await page.waitForTimeout(1100);
  }
  const dist = await page.evaluate(() => Math.round(WG.cur.st.dist));
  rep.ok('거리 계산 30~60m (' + dist + 'm)', dist >= 30 && dist <= 60);
  await page.evaluate(() => wgEnd()); await page.waitForTimeout(600);
  rep.ok('끝내기 → 상태 체크 시트', (await ov()).includes('wgChk'));
  await page.evaluate(() => wgSave({})); await page.waitForTimeout(1500);
  const seg = await page.evaluate(() => { const a = (S.walkLog || {})[todayKey()] || []; return a.length ? { n: a.length, d: a[0].d, g: a[0].g, cur: S.walkCur } : null; });
  rep.ok('저장 → 산책 기록 1건 (거리 ' + (seg && seg.d) + 'm)', !!seg && seg.n === 1 && seg.d >= 30 && seg.d <= 60 && seg.cur === 0);
  rep.ok('요약 시트 열림', (await ov()).includes('wgSum'));
  await page.waitForTimeout(2000);
  rep.ok('경로가 서버에 올라감', !!(seg && env.db.get('/handbook/' + H.FAM + '-walk/t/' + seg.g)));
  const before = await page.evaluate(() => document.body.getAttribute('data-tab'));
  await page.goBack(); await page.waitForTimeout(800);
  rep.eq('뒤로 → 요약만 닫힘(탭 그대로)', { ov: await ov(), tab: await page.evaluate(() => document.body.getAttribute('data-tab')) }, { ov: [], tab: before });
  await page.goBack(); await page.waitForTimeout(800);
  rep.eq('한 번 더 뒤로 → 이전 탭(달력)', await page.evaluate(() => document.body.getAttribute('data-tab')), 'cal');
  rep.eq('화면 오류 없음', page.errors, []);
  await b.close();
  rep.end();
})().catch((e) => { console.error('FAIL', e); process.exit(1); });

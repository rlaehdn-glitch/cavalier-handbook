/* 쇼츠 추천 — 추천 3편 포맷이 서로 다름, 다시 추천 시 겹침 0, 사진 부족 안내, 쉬는 사진 포함 */
const H = require('./harness');
(async () => {
  const b = await H.launch();
  const env = H.newEnv(); H.seedAlbum(env, { n: 36, videos: true, yt: 0 });
  // 일부 사진에 태그를 넣어 포맷이 갈리게
  const meta = env.db.get('/handbook/testfam01-album/meta'); const ids = Object.keys(meta).filter(k => meta[k].t === 'p');
  ids.forEach((id, i) => { if (i % 4 === 0) meta[id].ts = '놀이'; if (i % 4 === 1) meta[id].ts = '교감'; if (i % 5 === 2) meta[id].ts = '잠'; if (i % 3 === 0) meta[id].tm = '신남'; });
  env.db.set('/handbook/testfam01-album/meta', meta);
  const { page } = await H.newPhone(b, { env, dir: H.DIST });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3500);
  const res = {};
  res.badge = await page.textContent('#albSxN');
  res.first = await page.evaluate(async () => { const sx = await shLoad(); await sx.open('rec'); await new Promise(r => setTimeout(r, 900)); return sx._RC.recs.map(g => g.fm + ':' + g.key + ':' + g.ids.length); });
  await page.screenshot({ path: H.OUT + '70_recs.png' });
  await page.click('.sx-scr.on [data-act="again"]'); await page.waitForTimeout(500);
  res.again = await page.evaluate(() => SHORTS._RC.recs.map(g => g.fm + ':' + g.key + ':' + g.ids.length));
  const ov = await page.evaluate(() => { const a = SHORTS._RC.recs.flatMap(g => g.ids); return a.length - new Set(a).size; });
  res.againOverlap = ov;
  // 모든 사진을 최근 사용(쿨다운)으로 → 부족 안내 → 쉬는 사진 포함
  await page.evaluate(() => { Object.keys(ALB.meta).forEach(k => { ALB.meta[k].su = 1; ALB.meta[k].sl = todayKey(); }); SHORTS._RC.recs = null; SHORTS._RC.skip = {}; document.querySelector('.sx-scr.on .sx-seg [data-tab="rec"]').click(); });
  await page.waitForTimeout(400);
  res.lackMsg = await page.evaluate(() => document.querySelector('.sx-scr.on .sx-pane').textContent.slice(0, 80));
  await page.screenshot({ path: H.OUT + '71_lack.png' });
  await page.click('.sx-scr.on [data-act="cool"]'); await page.waitForTimeout(500);
  res.coolRecs = await page.evaluate(() => SHORTS._RC.recs.length);
  res.errors = page.errors;
  console.log(JSON.stringify(res, null, 1));
  const rep = require('./lib/report').start('e2e_recs');
  rep.eq('홈 배지', res.badge, '3편');
  rep.ok('추천 3편 · 포맷 서로 다름', res.first.length === 3 && new Set(res.first.map(x => x.split(':')[0])).size === 3);
  rep.eq('다시 추천 겹침 0', res.againOverlap, 0);
  rep.ok('사진 부족 안내', String(res.lackMsg).includes('추천할 새 사진이 부족해요'));
  rep.eq('쉬는 사진 포함 추천', res.coolRecs, 2);
  rep.eq('화면 오류 없음', res.errors, []);
  rep.end();
  await b.close();
})();

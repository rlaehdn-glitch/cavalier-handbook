/* 구조 검사 — 빌드 결과(dist/index.html)를 구문 분석해 '누더기' 재발을 막는다
   함수·변수 이름 중복 0 (같은 이름이 둘이면 뒤엣것이 앞엣것을 몰래 덮어씀), 뒤로가기 처리 1곳, 기본 confirm()·prompt() 호출 0,
   안 쓰는 함수 0, 버전 자리표시 남김 0, index.html·shorts.js 버전 같음, 기록 칸(history)은 문지기로만 */
const fs = require('fs'); const path = require('path'); const cp = require('child_process');
const R = require('./lib/report');
const rep = R.start('structure');
const ROOT = path.join(__dirname, '..');
const out = path.join(__dirname, 'out', 'map.json');
fs.mkdirSync(path.dirname(out), { recursive: true });   /* 처음 받은 묶음에는 tests/out이 없다 */
cp.execFileSync(process.execPath, [path.join(ROOT, 'tools', 'map.js'), path.join(ROOT, 'dist', 'index.html'), out]);
const m = JSON.parse(fs.readFileSync(out, 'utf8'));
rep.eq('함수 이름 중복 0', m.dupFuncs, []);
rep.eq('변수 이름 중복 0', m.dupVars, []);
rep.eq('뒤로가기(popstate) 처리 1곳', m.popstate.length, 1);
rep.eq('기본 confirm() 직접 호출 0', m.nativeDialogs.filter((d) => d.name === 'confirm').length, 0);
rep.eq('기본 prompt() 직접 호출 0', m.nativeDialogs.filter((d) => d.name === 'prompt').length, 0);
rep.eq('안 쓰는 함수 0', m.unused.map((u) => u.nm), []);
const html = fs.readFileSync(path.join(ROOT, 'dist', 'index.html'), 'utf8'), js = fs.readFileSync(path.join(ROOT, 'dist', 'shorts.js'), 'utf8');
rep.eq('버전 자리표시 남김 0', (html + js).match(/__APP_(VER|DATE|BUILD)__/g) || [], []);
/* 기록 칸(history) 넣기·되돌리기는 문지기(navHistPush / navHistBack) 안에서만 — 직접 부르면 되돌리기 도중 넣은 칸을 브라우저가 잃는다 */
const code = (t) => t.replace(/\/\*[\s\S]*?\*\//g, '');   /* 주석 제외 */
const hcount = (t, re) => (code(t).match(re) || []).length;
rep.eq('index.html: history.pushState 직접 호출 1곳(문지기)', hcount(html, /history\.pushState\(/g), 1);
rep.eq('index.html: history.back/go 직접 호출 1곳씩(문지기)', [hcount(html, /history\.back\(/g), hcount(html, /history\.go\(/g)], [1, 1]);
rep.eq('shorts.js: history 직접 호출은 옛 index.html용 예비 1곳씩', [hcount(js, /history\.pushState\(/g), hcount(js, /history\.back\(/g), hcount(js, /history\.go\(/g)], [1, 1, 1]);
const v = fs.readFileSync(path.join(ROOT, 'VERSION'), 'utf8').split('\n')[0].trim();
rep.ok('index.html 버전 = VERSION (' + v + ')', html.includes("const APP_VER='" + v + "'"));
rep.ok('shorts.js 버전 = VERSION', js.includes("const SXV = '" + v + "'"));
rep.end();

/* 한글 장면 자막을 직접 고른 경우의 실제 렌더링(Jua 서체 로드) + 기본(자막 없음) 확인 */
const H = require('./harness');
const fs = require('fs');
(async () => {
  const b = await H.launch({ net: true });
  const env = H.newEnv(); H.seedAlbum(env, { n: 8, videos: false, yt: 0 });
  const { page } = await H.newPhone(b, { env, dir: H.DIST, allowFonts: true });
  await page.goto(H.BASE + '#album'); await page.waitForTimeout(3000);
  const ids = await page.evaluate(() => Object.keys(ALB.meta).filter(k => ALB.meta[k].t === 'p').slice(0, 3));
  await page.evaluate((ids) => shLoad().then(sx => sx.fromIds(ids)), ids);
  await page.waitForTimeout(2500);
  // 2번째 장면: 한글 추천 문장, 3번째: 영문 추천
  await page.click('.sx-scr.on:last-child .sx-it[data-i="1"] .im'); await page.waitForTimeout(600);
  await page.click('.sx-ovl.on [data-sug="오늘도 귀여움 한도 초과"]'); await page.click('.sx-ovl.on [data-act="ok"]'); await page.waitForTimeout(600);
  await page.click('.sx-scr.on:last-child [data-act="next"]'); await page.waitForTimeout(1500);
  await page.click('[data-act="make"]');
  await page.waitForSelector('.sx-done video', { timeout: 300000 });
  const b64 = await page.evaluate(async () => { const v = document.querySelector('.sx-done video'); const r = await fetch(v.src); const u8 = new Uint8Array(await r.arrayBuffer()); let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); });
  fs.writeFileSync(H.OUT + 'out_ko.mp4', Buffer.from(b64, 'base64'));
  const fonts = await page.evaluate(() => [document.fonts.check('800 40px Poppins'), document.fonts.check('40px Jua', '가')]);
  const sub = await page.textContent('.sx-done');
  console.log(JSON.stringify({ fonts, sub, errors: page.errors }));
  const rep = require('./lib/report').start('e2e_kocap');
  rep.ok('한글 자막 넣은 영상 완성', String(sub).includes('영상이 준비됐어요'));
  rep.eq('화면 오류 없음', page.errors, []);
  rep.end();
  await b.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

#!/usr/bin/env python3
"""빼꼼 핸드북 빌드 — 소스(src/) → 올릴 파일 2개(dist/index.html, dist/shorts.js)

사용
  python3 build.py                 dist/ 에 두 파일을 만든다
  python3 build.py --check DIR     DIR/index.html·DIR/shorts.js 와 바이트 단위로 같은지 확인(구조만 바꿨을 때)

구성
  src/app/manifest.json   index.html 조립 순서(머리 → CSS 23개 → 본문 HTML → 스크립트 4개)
  src/app/html|css|js     index.html 조각. 같은 <script> 안의 js 파일은 한 공간(전역)을 공유한다
  src/shorts/*.js         shorts.js 조각(엔진 → 합성 → 화면 1·2·3), vendor/ 는 mp4-muxer(MIT)
  VERSION                 버전 1곳. 소스의 __APP_VER__ · __APP_DATE__ · __APP_BUILD__ 를 이 값으로 바꾼다
"""
import json, os, re, sys

ROOT = os.path.dirname(os.path.abspath(__file__))


def rd(p):
    return open(os.path.join(ROOT, p), encoding='utf-8', newline='').read()


def version():
    """VERSION 파일: 1줄째 '6.6.0', 2줄째 '2026-10-28'. 빌드 번호 = 6*100+6*10+0 → 660 (상대 폰 버전 비교용 숫자)"""
    v, d = [x.strip() for x in rd('VERSION').strip().split('\n')[:2]]
    a, b, c = [int(x) for x in v.split('.')]
    # 빌드 번호는 '자리 붙이기'라서 둘째·셋째 자리는 0~9만 쓴다(6.6.10은 6.7.0과 같은 번호가 되어 버림)
    if not (0 <= b <= 9 and 0 <= c <= 9):
        sys.exit('VERSION 오류: ' + v + ' — 둘째·셋째 자리는 0~9만 씁니다(6.6.9 다음은 6.7.0)')
    if not re.match(r'^\d{4}-\d{2}-\d{2}$', d):
        sys.exit('VERSION 오류: 날짜는 2026-10-28 형식')
    return v, d, a * 100 + b * 10 + c


def stamp(text):
    v, d, n = version()
    return text.replace('__APP_VER__', v).replace('__APP_DATE__', d).replace('__APP_BUILD__', str(n))


def build_app():
    m = json.load(open(os.path.join(ROOT, 'src/app/manifest.json'), encoding='utf-8'))
    out = []
    for it in m['items']:
        if 'text' in it:
            out.append(it['text'])
        elif 'file' in it:
            out.append(rd('src/app/' + it['file']))
        else:
            out.append(it['open'] + ''.join(rd('src/app/' + f) for f in it['files']) + it['close'])
    return stamp(''.join(out))


def build_shorts():
    v, d, n = version()
    vendor = rd('src/shorts/vendor/mp4-muxer.min.js').strip()
    lic = '/*! mp4-muxer 5.2.2 · MIT License · Copyright (c) 2023 Vanilagy · https://github.com/Vanilagy/mp4-muxer */'
    engine = rd('src/shorts/engine.js').replace("if (typeof module === 'object' && module.exports) module.exports = E;", '')
    parts = [rd('src/shorts/' + f) for f in ('render.js', 'ui1.js', 'ui2.js', 'ui3.js')]
    pre, tail = '"use strict";var Mp4Muxer=', ';typeof module=="object"&&typeof module.exports=="object"&&Object.assign(module.exports,Mp4Muxer);'
    assert vendor.startswith(pre) and vendor.rstrip().endswith(tail), 'mp4-muxer 형식이 바뀜'
    body = vendor[len(pre):].rstrip()[:-len(tail)]
    head = ("/* 빼꼼 핸드북 — 쇼츠 V" + v + " (" + d + ")\n"
            "   index.html(V" + v + ")이 앨범을 열 때 불러오는 별도 파일. 화면정의서 SH-01~SH-08 중 1단계(공통 화면 + 직접 올리기 A).\n"
            "   데이터: /handbook/{가족코드}-shorts/ (cfg · r 레시피 · fp 지문) + 앨범 meta 추가 항목(ts·tm·sd·su·sl·ih).\n"
            "   완성 영상은 저장하지 않는다(폰 메모리에서만). */\n"
            "(function () {\n'use strict';\nif (window.SHORTS) return;\nconst SXV = '" + v + "';\n" + lic + "\nconst Mp4Muxer = " + body.rstrip(';') + ";\n")
    return stamp(head + '\n' + engine + '\n' + '\n'.join(parts) + '\n})();\n')


if __name__ == '__main__':
    os.makedirs(os.path.join(ROOT, 'dist'), exist_ok=True)
    outs = {'index.html': build_app(), 'shorts.js': build_shorts()}
    for name, text in outs.items():
        open(os.path.join(ROOT, 'dist', name), 'w', encoding='utf-8', newline='').write(text)
        print(name, len(text.encode('utf-8')), 'bytes')
    if '--check' in sys.argv:
        ref = sys.argv[sys.argv.index('--check') + 1]
        for name, text in outs.items():
            same = open(os.path.join(ref, name), encoding='utf-8', newline='').read() == text
            print(name, 'IDENTICAL' if same else 'DIFFERENT')
